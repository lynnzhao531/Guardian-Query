from src.pool_manager import update_pools
import os

print(f"CWD: {os.getcwd()}")
print("Updating pools for Round 12...")
try:
    update_pools(12)
    print("Update called.")
except Exception as e:
    print(f"Update failed: {e}")

print("Done.")
