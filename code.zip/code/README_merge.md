# Guardian CSV Merge Pipeline

Merges 5 method-coded Guardian CSVs into a single master vector dataset with decision and method scores.

## Quick Start

```bash
pip install -r requirements.txt

python src/merge_master_vector.py \
    --data-dir . \
    --out-dir ./outputs \
    --audit-dir ./audits
```

## Outputs

| File | Description |
|------|-------------|
| `outputs/master_vector.parquet` | Canonical master dataset (preserves nullable dtypes) |
| `outputs/master_vector.csv` | Human-readable copy |
| `outputs/training_cases_clean.parquet` | Cleaned Training_cases (separate from master) |
| `outputs/training_cases_clean.csv` | Human-readable copy |

## Audit Files

| File | What it shows |
|------|---------------|
| `audits/row_counts.json` | Raw rows, post-URL-filter rows, Method/Decision non-null counts per dataset |
| `audits/schema_report.json` | Expected vs actual counts, any keyword coercion issues |
| `audits/label_distributions.json` | Value counts for Method and Decision per dataset |
| `audits/duplicate_urls_across_datasets.csv` | URLs that appear in more than one method-coded CSV |
| `audits/decision_conflicts.csv` | URLs where different datasets gave different Decision scores (resolved to max) |
| `audits/method_conflicts.csv` | URLs where the same method column has multiple different values (resolved to max) |
| `audits/case_studies_legacy_mismatch.csv` | Case study rows where Method/Decision is NA but legacy_method_1/decision_1 is not |
| `audits/flag_liveblog_nonzero.csv` | Live blogs / "as it happened" with nonzero scores (should be reviewed) |
| `audits/flag_commentisfree_nonzero.csv` | Opinion/commentisfree articles with nonzero scores (should be reviewed) |

## Troubleshooting Count Mismatches

If console output shows `⚠ COUNT WARNINGS`:

1. **More rows than expected** — check if new articles were coded since the reference counts were set
2. **Fewer rows than expected** — check if URL canonicalization dropped valid rows (look for rows where `url` was whitespace-only or missing)
3. **Method/Decision non-null differs** — some rows may have labels that failed `pd.to_numeric` coercion (check `audits/schema_report.json` for details)
4. **Concatenated rows off** — the expected ~1066 is the sum of the 5 post-URL-filter counts; if individual datasets are on target but the sum differs, check for extra/removed rows in one file
5. **Unique url_canon off** — URLs shared across datasets reduce the count; check `audits/duplicate_urls_across_datasets.csv`

## Key Design Decisions

- **No fillna(0)** — Method/Decision missing values stay as `pd.NA`, never filled with 0
- **method_1 / decision_1 are legacy** — renamed to `legacy_*` and excluded from labels
- **Each method column is NA unless populated** — a row from `rct.csv` only fills `method_rct`; the other 5 stay NA
- **Conflicts use max()** — when the same URL has different decision or method values, the highest value is kept and a conflict flag is set
- **Keyword columns use tri-state OR** — `True` wins over `False` wins over `NA`
- **BOM handled** — all CSVs read with `utf-8-sig` encoding
