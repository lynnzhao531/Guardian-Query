import json
import logging
import sys
import os
import pandas as pd
import numpy as np
import joblib

# Ensure path availability
sys.path.append(os.getcwd())

# We MUST have MyFeaturePipeline in namespace for unpickling
from src.my_model1_feature_pipeline import MyFeaturePipeline
from src.scorers import Model1Scorer

logging.basicConfig(level=logging.INFO)

# Load thresholds
with open("project_state/PER_MODEL_THRESHOLDS.json") as f:
    t = json.load(f)

# Load test articles
articles = []
with open("test_articles.jsonl") as f:
    for line in f:
        if line.strip():
            articles.append(json.loads(line))

print(f"Loaded {len(articles)} articles.")

# Initialize production scorer
scorer = Model1Scorer("models/tgml")
# We need to monkeypatch DataFrameSelector/OrdinalClassifier if they are used in unpickling 
# (though retrain_model1_only already uses the ones from src.tgml.models)
from src.tgml.models import OrdinalClassifier
sys.modules['__main__'].OrdinalClassifier = OrdinalClassifier

print("\n--- Model 1 Scoring ---")
results = scorer.score(articles)

for i, res in enumerate(results):
    a = articles[i]
    d_p1 = res.get("model1_decision_p1", 0.0)
    
    m_probs = {m: res.get(f"model1_method_{m}_p1", 0.0) for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]}
    max_m = max(m_probs.values()) if m_probs else 0.0
    
    passed = d_p1 >= t['model1']['t_dec'] and max_m >= t['model1']['t_meth']
    
    print(f"\nArticle {i+1}: {a['url_canon']}")
    print(f"  Decision P(1): {d_p1:.4f}")
    print(f"  Max Method P(1): {max_m:.4f}")
    print(f"  PASS: {passed}")
    for m, p in m_probs.items():
        print(f"    {m}: {p:.4f}")

# Feature Importance Check for a dummy example to prove non-zero contributing features
print("\n--- Feature Sparsity Check ---")
pipeline = joblib.load("models/tgml/tfidf_vectorizer.joblib")
X = pipeline.transform([articles[0]["title"] + "\n\n" + articles[0]["body"]])
print(f"Article 1 features: {X.nnz} non-zero entries out of {X.shape[1]}")
