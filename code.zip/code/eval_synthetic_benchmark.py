import json
import logging
import os
import sys
import pandas as pd
import numpy as np
import joblib

# Add src to path
sys.path.append(os.getcwd())

from src.scorers import Model1Scorer, Model3Scorer
from src.llm_judge_router import score_articles

logging.basicConfig(level=logging.ERROR)

def load_gold_data(path):
    data = []
    with open(path, "r") as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
    return data

def main():
    gold_articles = load_gold_data("synthetic_test_articles.jsonl")
    print(f"Loaded {len(gold_articles)} synthetic articles.")

    # Load Model 1
    print("Loading Model 1...")
    m1 = Model1Scorer("models/tgml")
    
    # Load Model 3
    print("Loading Model 3...")
    m3 = Model3Scorer("models/model3/model3_models.joblib", None)
    
    # Load LLM state
    with open("project_state/STATE.json") as f:
        llm_state = json.load(f)
    print(f"LLM State: SFT={llm_state['sft_model_name']}, DPO={llm_state['dpo_model_name']}")

    # Prepare results storage
    rows = []
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    
    for art in gold_articles:
        url = art["url_canon"]
        gold = art["gold"]
        
        input_art = [{
            "url_canon": url,
            "title": art["title"],
            "section": art["section"],
            "body_text": art["body_text"]
        }]
        
        print(f"\nScoring {url}...")
        
        # Model 1
        res1 = m1.score(input_art)[0]
        
        # Model 3
        res3 = m3.score(input_art)[0]
        
        # LLM
        res_llm_list = score_articles(input_art, llm_state, mock_llm=False)
        res_llm = res_llm_list[0]
        
        # Initialize row
        row = {
            "id": url,
            "gold_dec": gold["decision_score"],
            "m1_dec": res1.get("model1_decision_p1", 0.0),
            "m3_dec": res3.get("model3_decision_p1", 0.0),
            "llm_dec": res_llm.get("llm_final_decision_p1", 0.0),
            "llm_used": res_llm.get("model_used"),
            "llm_dpo_valid": res_llm.get("dpo_valid")
        }
        
        # Add all individual scores 
        for m in methods:
            row[f"model1_method_{m}_p1"] = res1.get(f"model1_method_{m}_p1", 0.0)
            row[f"model3_method_{m}_p1"] = res3.get(f"model3_method_{m}_p1", 0.0)
            row[f"llm_final_method_{m}_p1"] = res_llm.get(f"llm_final_method_{m}_p1", 0.0)
        
        row["model1_decision_p1"] = res1.get("model1_decision_p1", 0.0)
        row["model3_decision_p1"] = res3.get("model3_decision_p1", 0.0)
        row["llm_final_decision_p1"] = res_llm.get("llm_final_decision_p1", 0.0)
        
        # Decision score (discrete)
        row["model1_decision_score"] = res1.get("model1_decision_score", 0.0)
        row["model3_decision_score"] = res3.get("model3_decision_score", 0.0)
        row["llm_final_decision_score"] = res_llm.get("llm_final_decision_score", 0.0)

        # Method summary for display
        gold_methods = {m: gold.get(m, 0.0) for m in methods}
        top_gold = max(gold_methods, key=gold_methods.get)
        row["gold_method"] = top_gold
        
        m1_methods = {m: row[f"model1_method_{m}_p1"] for m in methods}
        row["m1_method"] = max(m1_methods, key=m1_methods.get)
        row["m1_max_p1"] = m1_methods[row["m1_method"]]
        
        m3_methods = {m: row[f"model3_method_{m}_p1"] for m in methods}
        row["m3_method"] = max(m3_methods, key=m3_methods.get)
        row["m3_max_p1"] = m3_methods[row["m3_method"]]
        
        llm_methods = {m: row[f"llm_final_method_{m}_p1"] for m in methods}
        row["llm_method"] = max(llm_methods, key=llm_methods.get) if any(llm_methods.values()) else "none"
        row["llm_max_p1"] = llm_methods[row["llm_method"]] if row["llm_method"] != "none" else 0.0
        
        rows.append(row)

    df = pd.DataFrame(rows)
    # Save full results for audit
    df.to_parquet("reports/synthetic_benchmark_full.parquet", index=False)
    print("\n" + "="*50)
    print("FINAL EVALUATION REPORT")
    print("="*50)
    
    # Decisions
    print("\nDecision P(1) Comparison:")
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 1000)
    print(df[["id", "gold_dec", "m1_dec", "m3_dec", "llm_dec"]].to_string(index=False))
    
    # Methods
    print("\nTop Method Classification Comparison:")
    print(df[["id", "gold_method", "m1_method", "m3_method", "llm_method"]].to_string(index=False))
    
    # Diagnostics
    print("\nLLM Diagnostic Info:")
    print(df[["id", "llm_used", "llm_dpo_valid"]].to_string(index=False))
    
    # Save to CSV
    df.to_csv("reports/synthetic_benchmark_comparative.csv", index=False)
    print(f"\nSaved detailed results to reports/synthetic_benchmark_comparative.csv")

if __name__ == "__main__":
    main()
