import json
import logging
import sys
import numpy as np
import pandas as pd
import joblib

class OrdinalClassifier: pass
class DataFrameSelector: pass
def preprocess_numeric(x): return x

sys.modules['__main__'].OrdinalClassifier = OrdinalClassifier
sys.modules['__main__'].DataFrameSelector = DataFrameSelector
sys.modules['__main__'].preprocess_numeric = preprocess_numeric

import src
from src.scorers import Model1Scorer, Model3Scorer
src.scorers.np = np

logging.basicConfig(level=logging.ERROR)

articles = []
with open("test_articles.jsonl") as f:
    for line in f:
        if not line.strip(): continue
        a = json.loads(line)
        articles.append({
            "url_canon": a["url_canon"],
            "title": a["title"],
            "section": a["section"],
            "body_text": a["body"],
            "publication_date_utc": "2026-02-21T00:00:00Z"
        })

print(f"Loaded {len(articles)} articles.")

m1 = Model1Scorer("models/tgml")
with open("project_state/STATE.json") as f:
    state = json.load(f)
m3 = Model3Scorer("models/model3", state.get("concept_config_path", "knowledge_base/hypotheses/concept_categories.yaml"))

with open("project_state/PER_MODEL_THRESHOLDS.json") as f:
     t = json.load(f)

for i, a in enumerate(articles):
    try:
        res1 = m1.score([a])[0]
    except Exception as e:
        print(f"M1 Error on article {i}: {e}")
        res1 = {}
        
    try:
        res3 = m3.score([a])[0]
    except Exception as e:
        print(f"M3 Error on article {i}: {e}")
        res3 = {}
    
    print(f"--- Article {i+1}: {a['url_canon']} ---")
    d1 = res1.get('model1_decision_p1', 0)
    d3 = res3.get('model3_decision_p1', 0)
    m1_max = max([res1.get(f'model1_method_{m}_p1', 0) for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]]) if res1 else 0
    m3_max = max([res3.get(f'model3_method_{m}_p1', 0) for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]]) if res3 else 0
    
    p1 = d1 >= t['model1']['t_dec'] and m1_max >= t['model1']['t_meth']
    p3 = d3 >= t['model3']['t_dec'] and m3_max >= t['model3']['t_meth']
    
    print(f"Model 1: Dec={d1:.3f} | MaxMeth={m1_max:.3f} | PASS={p1}")
    print(f"Model 3: Dec={d3:.3f} | MaxMeth={m3_max:.3f} | PASS={p3}")
    print(f"M1 details: {json.dumps({k: round(v,3) for k,v in res1.items() if 'p1' in k})}")
    print(f"M3 details: {json.dumps({k: round(v,3) for k,v in res3.items() if 'p1' in k})}")
    print("")
