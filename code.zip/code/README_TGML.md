# TGML: Theory-Guided ML for Guardian Article Scoring

Scores Guardian articles on **Decision** (0/0.5/1) and **6 Method dimensions** using ordinal regression with theory-guided features.

## Quick Start

```bash
pip install -r requirements.txt

# 1. Train all models
PYTHONPATH=src python -m tgml.train \
    --data outputs/master_vector.parquet \
    --outdir models --reportdir reports --auditdir audits

# 2. Evaluate on held-out test set
PYTHONPATH=src python -m tgml.evaluate \
    --data outputs/master_vector.parquet \
    --modeldir models --reportdir reports --auditdir audits

# 3. Export query term suggestions
PYTHONPATH=src python -m tgml.export_query_terms \
    --modeldir models --outdir reports/query_spaces
```

## Architecture

```
features = TF-IDF(title+body) + Theory(regex cues) + Keywords(tri-state)
model    = OrdinalClassifier(2 × LogisticRegression, balanced weights)
output   = constrained predictions (hard: liveblogs→0, soft: low-decision caps methods)
```

## Feature Groups

| Group | Count | Description |
|-------|-------|-------------|
| TF-IDF | ~100K | Word unigrams+bigrams from title+body |
| Theory | ~15 | Regex cues: org actors, scale actions, evidence links, per-method cues |
| Keywords | ~52 | Existing boolean columns as tri-state (True=1, False=0, NA=−1) |

## Constraints

- **Hard**: Liveblogs + commentisfree → force all predictions to 0 (rubric rule)
- **Soft**: When P(decision=1) < 0.1, reduce P(method=1) by 30% (configurable)

## Model Files

| File | Target | Training data |
|------|--------|--------------|
| `decision.joblib` | Decision score | master_vector (1055 labeled) |
| `method_rct.joblib` | RCT method | master_vector (511 labeled) |
| `method_prepost.joblib` | Pre-post method | master_vector, CV (92 labeled) |
| `method_case_study.joblib` | Case study method | master_vector (327 labeled) |
| `method_expert_secondary.joblib` | Secondary data | master_vector, CV (31 labeled) |
| `method_expert_qual.joblib` | Expert qualitative | training_cases (50 rows, binary) |
| `method_gut.joblib` | Gut/no-evidence | master_vector, CV (99 labeled) |

## Audit Files

| File | Description |
|------|-------------|
| `audits/schema_summary.json` | Column list, dtypes, % missing |
| `audits/label_distributions.json` | Value counts per target |
| `audits/label_value_violations.csv` | Should be empty |
| `audits/non_substantive_labeled_nonzero.csv` | Liveblogs/opinion with nonzero human labels |
| `reports/theory_feature_coverage.json` | % rows with hits per theory feature family |
| `reports/constraint_effects.json` | How many predictions changed by constraints |
| `reports/query_spaces/*.json` | Top terms per model for building search queries |
