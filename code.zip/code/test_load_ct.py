import pandas as pd
import joblib
df = pd.DataFrame({"title": ["A"], "body": ["B"], "text_for_model": ["A\n\nB"], "url_canon": ["C"]})
col_trans = joblib.load("test_joblib_autoimport.joblib")
res = col_trans.transform(["foo\n\nbar"])
print(res)
