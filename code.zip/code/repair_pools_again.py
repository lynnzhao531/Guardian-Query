from src.pool_manager import ensure_pool_files_exist, POOLS_DIR
import os

print("Deleting corrupt pool files...")
for f in POOLS_DIR.glob("*.csv"):
    try:
        f.unlink()
    except Exception as e:
        print(f"Error deleting {f}: {e}")

print("Regenerating headers...")
ensure_pool_files_exist()
print("Done.")
