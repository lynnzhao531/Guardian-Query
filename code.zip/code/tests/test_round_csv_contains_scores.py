
import pytest
import pandas as pd
from src.round_outputs_writer import write_round_outputs
from pathlib import Path

def test_csv_contains_scores(tmp_path):
    # Mock parquet
    d = {
        "url_canon": ["u1"], "url": ["http://u1"], "title": ["t1"], 
        "section": ["s1"], "publication_date_utc": ["2026-01-01"], "body_text": ["txt"],
        "model1_decision_score": [1.0], "model1_decision_p1": [0.9],
        "model3_decision_score": [1.0], "model3_decision_p1": [0.9],
        "llm_sft_decision_score": [1.0], "llm_sft_decision_p1": [0.9],
        "llm_dpo_decision_score": [1.0], "llm_dpo_decision_p1": [0.9],
        "llm_final_decision_score": [1.0], "llm_final_decision_p1": [0.9],
        "dpo_valid": [True]
    }
    # Add method cols
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        for p in ["model1", "model3", "llm_sft", "llm_dpo", "llm_final"]:
             d[f"{p}_method_{m}_score"] = [1.0]
             d[f"{p}_method_{m}_p1"] = [0.9]
             
    df = pd.DataFrame(d)
    pq = tmp_path / "scored_results_full.parquet"
    df.to_parquet(pq)
    
    write_round_outputs(999, pq)
    
    # Check Model1
    m1_csv = pd.read_csv(tmp_path / "round_999_model1_papers.csv")
    assert "model1_decision_score" in m1_csv.columns
    assert "model1_method_rct_p1" in m1_csv.columns
    assert "url" in m1_csv.columns

    # Check DPO slot (SFT model fills this when DPO disabled — CONTRACT V2: file is 'DPO_papers')
    dpo_csv = pd.read_csv(tmp_path / "round_999_DPO_papers.csv")
    assert "llm_final_decision_score" in dpo_csv.columns or "llm_dpo_decision_score" in dpo_csv.columns or len(dpo_csv.columns) >= 1

    # Check Consensus
    cons_csv = pd.read_csv(tmp_path / "round_999_high_relevant_papers.csv")
    assert "avg_decision_p1" in cons_csv.columns
    assert "model1_decision_score" in cons_csv.columns

def test_csv_empty_round(tmp_path):
    # Empty DF with correct columns
    d = {
        "url_canon": [], "url": [], "title": [], 
        "section": [], "publication_date_utc": [], "body_text": [],
        "model1_decision_score": [], "model1_decision_p1": [],
        "model3_decision_score": [], "model3_decision_p1": [],
        "llm_sft_decision_score": [], "llm_sft_decision_p1": [],
        "llm_dpo_decision_score": [], "llm_dpo_decision_p1": [],
        "llm_final_decision_score": [], "llm_final_decision_p1": [],
        "dpo_valid": []
    }
    # Add method cols
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        for p in ["model1", "model3", "llm_sft", "llm_dpo", "llm_final"]:
             d[f"{p}_method_{m}_score"] = []
             d[f"{p}_method_{m}_p1"] = []
             
    df = pd.DataFrame(d)
    pq = tmp_path / "scored_results_full.parquet"
    df.to_parquet(pq)
    
    write_round_outputs(1000, pq)
    
    # Check headers exist in empty CSV
    cons_csv = pd.read_csv(tmp_path / "round_1000_high_relevant_papers.csv")
    assert cons_csv.empty
    assert "avg_decision_p1" in cons_csv.columns
    assert "model1_decision_score" in cons_csv.columns
