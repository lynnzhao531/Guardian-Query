
import pandas as pd
import pytest
from pathlib import Path

def test_metadata_present():
    base_dir = Path("outputs/rounds")
    if not base_dir.exists(): return
    
    rounds = sorted([d for d in base_dir.iterdir() if d.name.startswith("round_")])
    if not rounds: return
    
    latest = rounds[-1]
    rid = latest.name.split("_")[1]
    
    files = [
        f"round_{rid}_model1_papers.csv",
        f"round_{rid}_model3_papers.csv",
        f"round_{rid}_SFT_papers.csv",
        f"round_{rid}_DPO_papers.csv",
        f"round_{rid}_high_relevant_papers.csv"
    ]
    
    required = ["url_canon", "url", "title", "section", "publication_date_utc", "body_text"]
    
    for f in files:
        p = latest / f
        if not p.exists(): continue
        
        df = pd.read_csv(p)
        for c in required:
            assert c in df.columns, f"Missing {c} in {f}"
            
        # Also check they are not all NaN if rows exist
        if not df.empty:
            # url and title should be populated
            assert df["url"].notna().all()
            # body_text might be empty string but not NaN?
            # pandas reads empty string as NaN often.
            pass
