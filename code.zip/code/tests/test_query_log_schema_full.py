
# tests/test_query_log_schema_full.py
import pytest
import pandas as pd
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONTRACT_PATH = BASE_DIR / "project_state/CONTRACT.json"

def test_query_log_schema_consistency():
    """
    Verifies that the query log schema matches the CONTRACT.json strict definition exactly.
    """
    with open(CONTRACT_PATH) as f:
        contract = json.load(f)
    
    required_cols = contract.get("query_log_columns", [])
    
    # We can't check the file if it doesn't exist, but we can verify that 
    # if it DOES exist, it better have the columns.
    # We can create a dummy file with round_runner logic or just assume 
    # it was created by migration/dry-run.
    
    log_path = BASE_DIR / "outputs/query_log.csv"
    if not log_path.exists():
        pytest.skip("query_log.csv not found yet, skipping check.")
        
    df = pd.read_csv(log_path)
    
    missing = [c for c in required_cols if c not in df.columns]
    
    assert not missing, f"Query log missing columns: {missing}"
