
import pytest
import pandas as pd
from src.round_outputs_writer import write_round_outputs

def test_filters_not_equal_scored(tmp_path):
    # One pass, one fail
    d = {
        "url_canon": ["u1", "u2"], "url": ["u", "u"], "title": ["t", "t"], "section": ["s", "s"], 
        "publication_date_utc": ["d", "d"], "body_text": ["b", "b"],
        "model1_decision_score": [1.0, 0.0],
        "model1_decision_p1": [0.9, 0.1],
        "model1_method_rct_score": [1.0, 0.0],
        "model1_method_rct_p1": [0.9, 0.1]
    }
    for m in ["prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        d[f"model1_method_{m}_p1"] = [0.0, 0.0]
        d[f"model1_method_{m}_score"] = [0.0, 0.0]
        
    # Mock other models to pass validation
    for p in ["model3", "llm_sft", "llm_final"]:
         d[f"{p}_decision_score"] = [1.0, 1.0]
         d[f"{p}_decision_p1"] = [0.9, 0.9]
         for m2 in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
             d[f"{p}_method_{m2}_score"] = [1.0, 1.0]
             d[f"{p}_method_{m2}_p1"] = [0.9, 0.9]
        
    df = pd.DataFrame(d)
    pq = tmp_path / "scored_results_full.parquet"
    df.to_parquet(pq)
    
    write_round_outputs(777, pq)
    
    m1_csv = pd.read_csv(tmp_path / "round_777_model1_papers.csv")
    assert len(m1_csv) == 1
    assert len(df) == 2
    assert len(m1_csv) < len(df)
