import pytest
import json
from pathlib import Path

def test_swap_logic_unit():
    """Verify the comparison logic (manual mock check) matches one_stop_dpo_workflow.py Step 6."""
    # This simulates the logic in Step 6
    
    m_main = {
        "model_A": {"model_id": "model_A", "trap_pass_count": 0, "precision_p50": 0.85},
        "model_B": {"model_id": "model_B", "trap_pass_count": 0, "precision_p50": 0.80}
    }
    
    # In swap, model_B is at index 0, model_A at index 1
    m_swap = {
        "model_B": {"model_id": "model_B", "trap_pass_count": 0, "precision_p50": 0.80},
        "model_A": {"model_id": "model_A", "trap_pass_count": 0, "precision_p50": 0.85}
    }
    
    # Comparison logic by model_id
    for mid in ["model_A", "model_B"]:
        met_m = m_main[mid]
        met_s = m_swap[mid]
        
        assert met_m["trap_pass_count"] == met_s["trap_pass_count"]
        assert abs(met_m["precision_p50"] - met_s["precision_p50"]) <= 0.001
    
    print("MOCK CONSISTENCY CHECK PASSED")

def test_swap_failure_on_mismatch():
    m_main = {"model_A": {"precision_p50": 0.85}}
    m_swap = {"model_A": {"precision_p50": 0.80}} # Big delta
    
    mid = "model_A"
    delta = abs(m_main[mid]["precision_p50"] - m_swap[mid]["precision_p50"])
    
    assert delta > 0.001
