
import pytest
import pandas as pd
from src.round_outputs_writer import write_round_outputs

def test_high_relevance_requires_decision_1(tmp_path):
    # Mock data with Decision=0.9 (Fail) but high P1
    d = {
        "url_canon": ["u1"], "url": ["u"], "title": ["t"], "section": ["s"], "publication_date_utc": ["d"], "body_text": ["b"],
        "model1_decision_score": [0.0], # Failed
        "model1_decision_p1": [0.99],
        "model1_method_rct_p1": [0.99] # High method
    }
    # Fill all columns to avoid strict schema error
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        d[f"model1_method_{m}_p1"] = [0.99]
        d[f"model1_method_{m}_score"] = [0.0]
        # Also other models need to exist if we are strict?
        # The writer checks prefix validity for model1, model3, llm_sft, llm_final
        for p in ["model3", "llm_sft", "llm_final"]:
             d[f"{p}_decision_score"] = [1.0]
             d[f"{p}_decision_p1"] = [0.9]
             for m2 in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
                 d[f"{p}_method_{m2}_score"] = [1.0]
                 d[f"{p}_method_{m2}_p1"] = [0.9]
        
    df = pd.DataFrame(d)
    pq = tmp_path / "scored_results_full.parquet"
    df.to_parquet(pq)
    
    write_round_outputs(888, pq)
    
    m1_csv = pd.read_csv(tmp_path / "round_888_model1_papers.csv")
    assert len(m1_csv) == 0 # Should be empty
