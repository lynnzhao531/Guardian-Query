import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from src.scorers import InferenceFeaturePipeline
from src.retrain_model1_only import MyFeaturePipeline

def test_model1_not_degenerate_on_val():
    df = pd.read_parquet("outputs/master_vector.parquet")
    df["text_for_model"] = df["title"].fillna("") + "\n\n" + df["body"].fillna("")
    df = df.dropna(subset=["decision"])
    
    # Ensure exact same split size as training to target val subset
    _, val_df = train_test_split(df, test_size=0.15, random_state=42)
    sample_df = val_df.sample(min(50, len(val_df)), random_state=42)
    
    pipeline = joblib.load("models/tgml/tfidf_vectorizer.joblib")
    X_val = pipeline.transform(sample_df["text_for_model"].tolist())
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    m_probs_list = []
    
    for m in methods:
        p = f"models/tgml/model_method_{m}.joblib"
        if os.path.exists(p):
            clf = joblib.load(p)
            probs = clf.predict_proba(X_val)
            # The CalibratedClassifier wrapper returns [0, 0.5, 1.0] generally, index 2 is p1
            if probs.shape[1] >= 3:
                m_probs_list.append(probs[:, 2])
            else:
                m_probs_list.append(probs[:, -1])
            
    m_probs_arr = np.array(m_probs_list)
    max_method_p1 = m_probs_arr.max(axis=0) if len(m_probs_list) > 0 else np.zeros(len(sample_df))
    
    std = np.std(max_method_p1)
    unique_vals = len(np.unique(max_method_p1))
    
    print(f"Max Method P1 STD: {std:.4f}")
    print(f"Max Method P1 Unique Values: {unique_vals}")
    
    assert std >= 0.02 or unique_vals > 5, "Model 1 is degenerately collapsed. Standard deviation of method P1 is near zero."
