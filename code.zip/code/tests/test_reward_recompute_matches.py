
import sys
import pytest
from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.append(str(BASE_DIR))

from src.recompute_round_metrics import recompute_round_metrics

def test_recompute_audit_pass():
    """
    Runs the recompute logic on an existing round (if any) and asserts no mismatches.
    """
    rounds_dir = BASE_DIR / "outputs/rounds"
    if not rounds_dir.exists():
        pytest.skip("No rounds to verify.")
        
    rounds = list(rounds_dir.glob("round_*"))
    if not rounds:
        pytest.skip("No rounds found.")
        
    # Pick last round
    last_round = sorted(rounds)[-1]
    round_id = int(last_round.name.split("_")[1])
    
    log_path = BASE_DIR / "outputs/query_log.csv"
    if not log_path.exists():
        pytest.skip("query_log.csv missing - cannot recompute.")
    
    # Run recompute
    try:
        audit = recompute_round_metrics(round_id)
        if audit["status"] == "SKIPPED":
            pytest.skip(f"Recompute skipped: {audit.get('mismatches')}")
        assert audit["status"] == "PASS", f"Recompute failed: {audit['mismatches']}"
    except SystemExit:
         pytest.fail("recompute_round_metrics raised SystemExit")
    except Exception as e:
         pytest.skip(f"Recompute skipped due to setup issues: {e}")
