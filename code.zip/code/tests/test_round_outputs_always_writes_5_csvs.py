import pytest
import pandas as pd
import tempfile
from pathlib import Path
from src.round_outputs_writer import write_round_outputs, REQUIRED_METADATA, METHOD_NAMES

def _get_model_score_cols(prefix):
    cols = [f"{prefix}_decision_score", f"{prefix}_decision_p1"]
    for m in METHOD_NAMES:
        cols.append(f"{prefix}_method_{m}_score")
        cols.append(f"{prefix}_method_{m}_p1")
    return cols

def test_round_outputs_always_writes_5_csvs():
    """Verify that even with an empty dataframe, 5 CSVs are written with full headers."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        parquet_path = tmp_path / "scored_results_full.parquet"
        
        # Create empty DF with some base columns
        df = pd.DataFrame(columns=REQUIRED_METADATA + ["model1_decision_score"])
        df.to_parquet(parquet_path)
        
        # We need thresholds file to exist
        thresholds_path = Path("project_state/PER_MODEL_THRESHOLDS.json")
        if not thresholds_path.parent.exists():
            thresholds_path.parent.mkdir(parents=True)
        if not thresholds_path.exists():
            import json
            with open(thresholds_path, "w") as f:
                json.dump({
                    "model1": {"t_dec": 0.6, "t_meth": 0.8},
                    "model3": {"t_dec": 0.6, "t_meth": 0.8},
                    "llm_final": {"t_dec": 0.6, "t_meth": 0.8}
                }, f)
        
        write_round_outputs(999, str(parquet_path))
        
        expected_files = [
            "round_999_model1_papers.csv",
            "round_999_model3_papers.csv",
            "round_999_SFT_papers.csv",
            "round_999_DPO_papers.csv",
            "round_999_high_relevant_papers.csv"
        ]
        
        for f in expected_files:
            p = tmp_path / f
            assert p.exists(), f"Missing {f}"
            
            # Check headers
            df_check = pd.read_csv(p)
            for meta in REQUIRED_METADATA:
                assert meta in df_check.columns
            
            if "model1" in f:
                for col in _get_model_score_cols("model1"):
                    assert col in df_check.columns
            elif "model3" in f:
                for col in _get_model_score_cols("model3"):
                    assert col in df_check.columns
            elif "SFT" in f:
                # Based on our patch, it should have llm_sft cols
                 for col in _get_model_score_cols("llm_sft"):
                    assert col in df_check.columns
            elif "DPO" in f:
                 for col in _get_model_score_cols("llm_dpo"):
                    assert col in df_check.columns

def test_sft_and_dpo_csv_exist_when_empty():
    """Explicitly verify SFT and DPO files exist even when they have 0 rows."""
    # This is partially covered above but ensures the naming is correct
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        parquet_path = tmp_path / "scored_results_full.parquet"
        
        # Add one row that passes none of the high-rel filters
        row = {m: "test" for m in REQUIRED_METADATA}
        row["model1_decision_score"] = 0.0
        row["model3_decision_score"] = 0.0
        row["llm_final_decision_score"] = 0.0
        
        df = pd.DataFrame([row])
        df.to_parquet(parquet_path)
        
        write_round_outputs(888, str(parquet_path))
        
        assert (tmp_path / "round_888_SFT_papers.csv").exists()
        assert (tmp_path / "round_888_DPO_papers.csv").exists()
        
        sft_df = pd.read_csv(tmp_path / "round_888_SFT_papers.csv")
        assert len(sft_df) == 0
