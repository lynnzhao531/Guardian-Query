import pytest
import csv
import tempfile
from pathlib import Path
from src.validate_round_outputs import validate_round, REQUIRED_METADATA, METHOD_NAMES

def _get_model_score_cols(prefix: str):
    cols = [f"{prefix}_decision_score", f"{prefix}_decision_p1"]
    for m in METHOD_NAMES:
        cols.append(f"{prefix}_method_{m}_score")
        cols.append(f"{prefix}_method_{m}_p1")
    return cols

def test_validator_ignores_extra_files():
    """Verify that the validator only cares about the 5 required files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        round_id = 123
        round_dir = tmp_path / f"round_{round_id}"
        round_dir.mkdir()
        
        # Create 5 valid files
        prefixes = {
            "model1": f"round_{round_id}_model1_papers.csv",
            "model3": f"round_{round_id}_model3_papers.csv",
            "sft": f"round_{round_id}_SFT_papers.csv",
            "dpo": f"round_{round_id}_DPO_papers.csv",
            "consensus": f"round_{round_id}_high_relevant_papers.csv",
        }
        
        for key, fname in prefixes.items():
            path = round_dir / fname
            with open(path, "w", newline="") as f:
                writer = csv.writer(f)
                header = list(REQUIRED_METADATA)
                if key == "model1": header += _get_model_score_cols("model1")
                if key == "model3": header += _get_model_score_cols("model3")
                if key == "consensus": header += ["predicted_method", "confidence_score", "margin", "agreement_count", "avg_decision_p1", "top3_avg_method_mean"] + [f"avg_method_p1_{m}" for m in METHOD_NAMES]
                writer.writerow(header)
                
        # Add an EXTRA junk file
        (round_dir / "junk.txt").write_text("should be ignored")
        (round_dir / "debug_log.json").write_text("{}")
        
        # Should PASS
        assert validate_round(round_id, tmp_path, strict=True) is True
