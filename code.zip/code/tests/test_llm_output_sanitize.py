
import pytest
import json
import copy
from src.llm_output_sanitize import sanitize_model_json

MOCK_VALID_JSON = {
    "decision": {"score": 1, "p0": 0, "p05": 0, "p1": 1},
    "method_rct": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
    "method_prepost": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
    "method_case_study": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
    "method_expert_qual": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
    "method_expert_secondary": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
    "method_gut": {"score": 0, "p0": 1, "p05": 0, "p1": 0}
}

def test_exact_match():
    json_str = json.dumps(MOCK_VALID_JSON)
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is True
    assert data == MOCK_VALID_JSON
    assert tag == "exact_match"

def test_code_fence():
    json_str = f"```json\n{json.dumps(MOCK_VALID_JSON)}\n```"
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is True
    assert data == MOCK_VALID_JSON
    assert tag == "salvaged"

def test_leading_trailing_prose():
    json_str = f"Here is the result:\n{json.dumps(MOCK_VALID_JSON)}\nI hope this helps."
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is True
    assert data == MOCK_VALID_JSON
    assert tag == "salvaged"

def test_repeated_identical_json():
    json_str = json.dumps(MOCK_VALID_JSON) + "\n" + json.dumps(MOCK_VALID_JSON)
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is True
    assert data == MOCK_VALID_JSON
    assert tag == "repetition_ignored"

def test_conflicting_json_objects():
    diff_json = copy.deepcopy(MOCK_VALID_JSON)
    diff_json["decision"]["score"] = 0
    json_str = json.dumps(MOCK_VALID_JSON) + "\n" + json.dumps(diff_json)
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is False
    assert tag == "conflicting_json_objects"

def test_wrong_keys():
    bad_json = copy.deepcopy(MOCK_VALID_JSON)
    del bad_json["decision"]
    ok, data, tag = sanitize_model_json(json.dumps(bad_json))
    assert ok is False
    assert "invalid_schema" in tag
    assert "Missing dimension: decision" in tag

def test_illegal_values():
    bad_json = copy.deepcopy(MOCK_VALID_JSON)
    bad_json["decision"]["score"] = 99 # Illegal
    ok, data, tag = sanitize_model_json(json.dumps(bad_json))
    assert ok is False
    assert "invalid_schema" in tag
    assert "Invalid score 99" in tag

def test_malformed_trailing_json():
    json_str = json.dumps(MOCK_VALID_JSON) + "\n{ malformed... "
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is False
    assert tag == "malformed_trailing_json"

def test_unbalanced_braces():
    json_str = "{" + json.dumps(MOCK_VALID_JSON)
    ok, data, tag = sanitize_model_json(json_str)
    assert ok is False
    assert tag == "unbalanced_braces"
