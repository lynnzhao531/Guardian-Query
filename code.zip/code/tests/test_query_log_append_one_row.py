
# tests/test_query_log_append_one_row.py

import pytest
import pandas as pd
import tempfile
import os
from pathlib import Path

# Mock the appending logic usually found in round_runner or logs manager
def append_query_log_logic(log_path, round_data):
    """
    Logic: append row if round_id not present.
    """
    path = Path(log_path)
    new_row_df = pd.DataFrame([round_data])
    
    if path.exists():
        existing = pd.read_csv(path)
        # Idempotency check
        if round_data["round_id"] in existing["round_id"].values:
            return # Skip
        combined = pd.concat([existing, new_row_df])
    else:
        combined = new_row_df
        
    combined.to_csv(path, index=False)

def test_query_log_single_append_idempotency():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_file = Path(tmpdir) / "query_log.csv"
        
        row_1 = {
            "round_id": 1, 
            "timestamp": "2025-01-01",
            "timestamp_utc_iso": "2025-01-01T00:00:00+00:00",
            "llm_high_count": 5, 
            "dpo_valid_count": 2,
            "query_base": "test",
            "query_budget_cap_usd": 60.0,
            "reward_R": 0.5,
            "preflight_totals_by_level": "{}",
            "guardian_page_size": 50,
            "new_consensus_credit_total": 1.0
        }
        
        # 1. Run 1
        append_query_log_logic(log_file, row_1)
        
        df = pd.read_csv(log_file)
        assert len(df) == 1
        assert df.iloc[0]["round_id"] == 1
        
        # 2. Run 2 (Same Round - Resume)
        append_query_log_logic(log_file, row_1)
        
        df_2 = pd.read_csv(log_file)
        assert len(df_2) == 1 # Still 1 row
        
        # 3. New Round
        row_2 = {
            "round_id": 2,
            "timestamp": "2025-01-02",
            "timestamp_utc_iso": "2025-01-02T00:00:00+00:00",
            "llm_high_count": 3,
            "dpo_valid_count": 1,
            "query_base": "test2",
            "query_budget_cap_usd": 60.0,
            "reward_R": 0.6,
            "preflight_totals_by_level": "{}",
            "guardian_page_size": 50,
            "new_consensus_credit_total": 2.0
        }
        append_query_log_logic(log_file, row_2)
        
        df_3 = pd.read_csv(log_file)
        assert len(df_3) == 2
