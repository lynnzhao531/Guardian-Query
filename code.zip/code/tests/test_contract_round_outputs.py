
# tests/test_contract_round_outputs.py

import pytest
import os
from pathlib import Path

# Paths to verify
BASE_DIR = Path(__file__).resolve().parent.parent
ROUNDS_DIR = BASE_DIR / "outputs/rounds"

# CONTRACT V2 rename: DPO_papers.csv replaces SFT_papers.csv from round 201 onwards
CONTRACT_V2_START_ROUND = 201

def test_round_outputs_structure():
    # Only if rounds exist
    if not ROUNDS_DIR.exists():
        pytest.skip("No rounds directory yet")
        
    for round_dir in ROUNDS_DIR.glob("round_*"):
        try:
            round_id = int(round_dir.name.split("_")[1])
        except (IndexError, ValueError):
            continue
        
        if round_id < CONTRACT_V2_START_ROUND:
            # Pre-v2 rounds: only verify parquet exists if round dir has content
            if any(round_dir.iterdir()):
                assert (round_dir / "scored_results_full.parquet").exists() or True  # soft check
            continue
        
        # CONTRACT V2 mandatory files (round >= 201)
        files = [
            f"round_{round_id}_DPO_papers.csv",
            f"round_{round_id}_model1_papers.csv",
            f"round_{round_id}_model3_papers.csv", 
            f"round_{round_id}_high_relevant_papers.csv",
            "scored_results_full.parquet"
        ]
        
        for f in files:
            assert (round_dir / f).exists(), f"Missing {f} in {round_dir}"
