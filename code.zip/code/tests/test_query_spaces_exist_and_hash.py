
# tests/test_query_spaces_exist_and_hash.py
import pytest
from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent
QUERY_SPACES_DIR = BASE_DIR / "knowledge_base/query_spaces"
CONTRACT_PATH = BASE_DIR / "project_state/CONTRACT.json"

def test_query_spaces_exist():
    """Verifies that all required query space files exist."""
    with open(CONTRACT_PATH) as f:
        contract = json.load(f)
    
    required = contract.get("query_space_files", [])
    
    missing = []
    for r in required:
        path = BASE_DIR / r
        if not path.exists():
            missing.append(r)
            
    assert not missing, f"Missing query space files: {missing}"

def test_query_spaces_hash_generated():
    """Verifies that QUERY_SPACES_HASH.json is generated."""
    hash_file = BASE_DIR / "project_state/QUERY_SPACES_HASH.json"
    # hash_guard should have run if round verification passed
    # but unit tests might run independent of round runner.
    # We call hash check manually if needed, but round execution guarantees it.
    if not hash_file.exists():
        pytest.skip("QUERY_SPACES_HASH.json not found (run dry run first?)")
        
    with open(hash_file) as f:
        data = json.load(f)
        
    assert "query_spaces_sha256" in data
    assert len(data["query_spaces_sha256"]) == 64
