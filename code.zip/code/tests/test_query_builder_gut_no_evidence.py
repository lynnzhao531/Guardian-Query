
import pytest
from src.query_builder import QueryBuilder
from unittest.mock import MagicMock

def test_query_builder_gut_no_evidence():
    """
    Ensure 'gut' method never includes EVIDENCE clause.
    """
    config = {"min_total_available": 20, "max_total_available": 2500}
    qb = QueryBuilder(config, config, "knowledge_base/query_spaces", {})
    
    # Gut uses T2, T1, T5, T9. None have {evidence} by default except maybe via tightening?
    # But tightening step 2 (Add G) explicitly checks "if target_method != 'gut'".
    # So we verify T2 (which has {actor} but no {evidence})
    qb.templates = {
        "T2": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) AND ({actor}) NOT ({excludes})"
    }
    qb.spaces = {
        "method_gut": {"include_terms": ["no data"]},
        "decision": {"include_terms": ["pilot"], "broad_addons": []},
        "exclude_terms": {"exclude_terms": []}
    }
    
    mock_client = MagicMock()
    mock_client.request.return_value = {"response": {"total": 100}}
    
    res = qb.build_query("gut", 1, mock_client)
    q = res["query_final"]
    
    assert "no data" in q
    assert "EVIDENCE" not in q
    assert "STUDY" not in q # Evidence clause terms
