import joblib
import numpy as np
import pandas as pd
import os
from sklearn.model_selection import train_test_split

def test_model3_not_degenerate():
    model_path = "models/model3/model3_models.joblib"
    if not os.path.exists(model_path):
        import pytest
        pytest.skip("Model artifact not found. Run retraining script first.")
        
    m = joblib.load(model_path)
    
    # Load val data for testing
    df = pd.read_parquet("outputs/master_vector.parquet")
    df = df.dropna(subset=["decision"])
    unique_ids = df["url_canon"].unique()
    _, val_ids = train_test_split(unique_ids, test_size=0.15, random_state=42)
    df_val = df[df["url_canon"].isin(val_ids)]
    
    # Need to compute features for these samples
    from src.retrain_model3_only import get_text
    from sentence_transformers import SentenceTransformer
    from src.tgml.theory_features import TheoryFeaturizer
    
    embedder = SentenceTransformer('all-MiniLM-L6-v2')
    texts = df_val.apply(get_text, axis=1).tolist()
    embeddings = embedder.encode(texts)
    
    theory_feat = TheoryFeaturizer()
    theory_df = theory_feat.transform(df_val)
    X_theory = theory_df.values.astype(np.float64)
    X = np.hstack([embeddings, X_theory])
    
    val_probs = []
    # Only test trained heads (logic matching the retrain script gate)
    for k in m:
        if k == "decision" or k == "method_expert_qual": continue
        # predict_proba returns [p0, p05, p1]
        probs = m[k].predict_proba(X)
        val_probs.append(probs[:, 2])
        
    assert len(val_probs) > 0, "No method heads were trained."
    
    max_method_p1 = np.max(np.array(val_probs), axis=0)
    std_val = np.std(max_method_p1)
    
    print(f"Validation std(max_method_p1): {std_val:.4f}")
    assert std_val >= 0.05, f"Model is degenerate: std={std_val:.4f} < 0.05"
