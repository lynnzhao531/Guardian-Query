import subprocess
import sys
import os

def test_model3_cold_load_joblib():
    """
    Test that the Model 3 artifact can be loaded in a fresh process.
    This ensures no broken relative/custom class imports exist in the pickle.
    """
    model_path = "models/model3/model3_models.joblib"
    if not os.path.exists(model_path):
        import pytest
        pytest.skip("Model artifact not found.")

    # Script to run in fresh process
    script = f"""
import sys
import os
import joblib

# Need to ensure PYTHONPATH is set so src and other modules are found
sys.path.append(os.getcwd())

model_path = "{model_path}"
try:
    m = joblib.load(model_path)
    print("SUCCESS: Loaded keys:", list(m.keys()))
except Exception as e:
    print(f"FAILURE: {{type(e).__name__}}: {{e}}")
    sys.exit(1)
"""
    
    # Run in subprocess
    env = os.environ.copy()
    env["PYTHONPATH"] = os.getcwd() + ":" + env.get("PYTHONPATH", "")
    
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
        env=env
    )
    
    print("STDOUT:", result.stdout)
    print("STDERR:", result.stderr)
    
    assert result.returncode == 0, f"Cold load failed: {result.stderr}"
    assert "SUCCESS" in result.stdout
