
import pytest
from src.query_builder import QueryBuilder
from unittest.mock import MagicMock

def test_query_never_single_term():
    """
    Ensure build_query never returns a single term.
    It must contain Method AND Decision AND Policy.
    """
    config = {"min_total_available": 20, "max_total_available": 2500}
    contract = config
    qb = QueryBuilder(config, contract, "knowledge_base/query_spaces", {})
    
    # Mock templates and spaces
    qb.templates = {
        "T1": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) NOT ({excludes})",
        "T2": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) AND ({actor}) NOT ({excludes})"
    }
    qb.spaces = {
        "method_rct": {"include_terms": ["rct"]},
        "decision": {"include_terms": ["pilot"], "broad_addons": []},
        "exclude_terms": {"exclude_terms": []}
    }
    
    # Mock client to return valid total
    mock_client = MagicMock()
    mock_client.request.return_value = {"response": {"total": 100}}
    
    res = qb.build_query("rct", 1, mock_client)
    q = res["query_final"]
    
    # Check structure
    assert q.count(" AND ") >= 2
    assert "rct" in q
    assert "pilot" in q
    assert "POLICY" in q # Policy context is strict uppercase in Builder
