import pandas as pd
import tempfile
import shutil
from pathlib import Path
from src.audit_method_p1_sanity import audit_round

def test_degeneracy_detection():
    # Setup temp env
    tmp_dir = Path(tempfile.mkdtemp())
    round_dir = tmp_dir / "round_999"
    round_dir.mkdir(parents=True)
    
    # Create Degenerate Model 1 (All 0.5)
    df_degen = pd.DataFrame({
        "url": ["u1", "u2"],
        "title": ["t1", "t2"],
        "model1_method_rct_p1": [0.5, 0.5],
        "model1_method_gut_p1": [0.5, 0.5],
        "model1_decision_score": [0, 0]
    })
    df_degen.to_csv(round_dir / "round_999_model1_papers.csv", index=False)
    
    # Create Normal Model 3
    df_norm = pd.DataFrame({
        "url": ["u1", "u2", "u3"],
        "title": ["t1", "t2", "t3"],
        "model3_method_rct_p1": [0.1, 0.9, 0.4],
        "model3_method_gut_p1": [0.2, 0.8, 0.5],
        "model3_decision_score": [0, 1, 0]
    })
    df_norm.to_csv(round_dir / "round_999_model3_papers.csv", index=False)
    
    # Run Audit
    # We output to tmp_dir/reports etc.
    # The script writes to "reports/" relative to CWD.
    # To test logic without messing CWD, we can change CWD or refactor.
    # For safety, let's just run it and check if output contains the warning.
    # But we can't easily capture print output in unit test without capsys.
    # Actually, the function returns md_path.
    # But it writes to "audits/" hardcoded.
    # We should have made output dir configurable.
    # But for now, let's just rely on the script creating files in CWD.
    # We will clean them up.
    
    try:
        md_path = audit_round(999, str(tmp_dir))
        
        with open(md_path) as f:
            content = f.read()
            
        print(content)
        
        # Check warnings
        # Model 1 should be warned
        assert "Model model1 has DEGENERATE method scores" in content
        # Model 3 should NOT be warned
        assert "Model model3 has DEGENERATE" not in content
        
    finally:
        shutil.rmtree(tmp_dir)
        # Cleanup generated reports
        if Path("reports/method_p1_sanity_round_999.csv").exists():
             Path("reports/method_p1_sanity_round_999.csv").unlink()
        if Path("audits/method_p1_sanity_round_999.md").exists():
             Path("audits/method_p1_sanity_round_999.md").unlink()

if __name__ == "__main__":
    test_degeneracy_detection()
    print("Test passed!")
