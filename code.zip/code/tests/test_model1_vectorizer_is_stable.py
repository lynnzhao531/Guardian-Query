import joblib
import pandas as pd
import numpy as np
from src.scorers import InferenceFeaturePipeline
# The wrapper needs this available on unpickling inside the test module.
from src.retrain_model1_only import MyFeaturePipeline

def test_vectorizer_stability():
    pipeline = joblib.load("models/tgml/tfidf_vectorizer.joblib")
    
    texts = [
        "This is a mocked news article containing an evaluation of a trial. The council decided to test an intervention.",
        "Breaking news: random text. It was a clustered randomized trial across multiple schools.",
        "Another entirely random string of characters representing text."
    ]
    
    # InferenceFeaturePipeline expects a list of texts
    X1 = pipeline.transform(texts)
    X2 = pipeline.transform(texts)
    
    # Assert shape is consistent and deterministic
    assert X1.shape == X2.shape, "Dimensionality mutated across successive calls."
    assert X1.shape[0] == 3, f"Expected 3 rows, got {X1.shape[0]}"
    
    # Assert arrays are totally identical
    assert (X1 != X2).nnz == 0, "Outputs were non-deterministic across successive runs."
    assert X1.shape[1] > 0, "Vector output dimension space is empty."
