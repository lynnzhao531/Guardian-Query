
import pytest
from src.query_builder import QueryBuilder
from unittest.mock import MagicMock

def test_query_supply_cap_enforced():
    """
    Ensure queries > 2500 are rejected/tightened.
    If all are > 2500, it should fail or use emergency? 
    Wait, emergency logic in Builder might also return > 2500 if not checked?
    Strictly speacking, emergency query doesn't check max cap in code provided (it just returns).
    But the tightener logic should filter out wide candidates.
    """
    config = {"min_total_available": 20, "max_total_available": 2500}
    contract = config
    qb = QueryBuilder(config, contract, "knowledge_base/query_spaces", {})
    
    # Mock templates
    qb.templates = {
        "T1": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) NOT ({excludes})"
    }
    qb.spaces = {
        "method_rct": {"include_terms": ["rct"]},
        "decision": {"include_terms": ["pilot"], "broad_addons": []},
        "exclude_terms": {"exclude_terms": []}
    }
    
    mock_client = MagicMock()
    # First call returns 3000 (Too Wide)
    # Tighten steps: Add Actor -> 2000 (Accept)
    mock_client.request.side_effect = [
        {"response": {"total": 3000}}, # Base
        {"response": {"total": 2000}}  # Tighten + Actor
    ]
    
    res = qb.build_query("rct", 1, mock_client)
    q = res["query_final"]
    
    assert res["guardian_total_available"] == 2000
    assert "GOVERNMENT" in q # Actor added
    
def test_dead_candidate_skipped():
    """
    If total = 0, broaden. If still 0, next template.
    """
    config = {"min_total_available": 20, "max_total_available": 2500}
    qb = QueryBuilder(config, config, "knowledge_base/query_spaces", {})
    qb.templates = {
        "T4": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) NOT ({excludes})", # First in list
        "T3": "({method_terms}) AND ({decision_terms}) AND ({policy_context}) NOT ({excludes})"  # Second
    }
    qb.spaces = {
        "method_rct": {"include_terms": ["rct"]},
        "decision": {"include_terms": ["pilot"], "broad_addons": ["plan"]},
        "exclude_terms": {"exclude_terms": []}
    }
    
    mock_client = MagicMock()
    # T4 Base -> 0
    # T4 Broaden D -> 0
    # T4 Broaden M -> 0
    # T3 Base -> 100 (Accept)
    mock_client.request.side_effect = [
        {"response": {"total": 0}},
        {"response": {"total": 0}},
        {"response": {"total": 0}},
        {"response": {"total": 100}}
    ]
    
    res = qb.build_query("rct", 1, mock_client)
    assert res["template_id"] == "T3"
    assert res["guardian_total_available"] == 100
