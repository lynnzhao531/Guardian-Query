
# tests/test_llm_router_fallback.py

import pytest
import os
import json
from src.llm_judge_router import score_articles
from unittest.mock import MagicMock, patch

# Mock State
STATE = {
    "sft_model_name": "ft:gpt-4o-mini::sft_123",
    "dpo_model_name": "ft:gpt-4o-mini::dpo_456"
}

# Mock Articles
ARTICLES = [{"url_canon": "url1", "body_text": "text"}]

@patch("src.llm_judge_router.call_llm_scoring")
@patch("src.llm_judge_router.get_config")
def test_dpo_failure_safe_fallback(mock_cfg, mock_llm):
    # Config: DPO enabled
    mock_cfg.return_value = {
        "dpo_enabled": True, 
        "dpo_attempt_policy": "all",
        "sft_weight_in_ensemble": 0.85
    }
    
    # 1. SFT Succeeds
    sft_response = {
        "success": True,
        "data": {
            "decision": {"score": 1, "p0": 0.1, "p05": 0.1, "p1": 0.8},
            "method_rct": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
            "method_prepost": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
            "method_case_study": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
            "method_expert_qual": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
            "method_expert_secondary": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
            "method_gut": {"score": 0, "p0": 1, "p05": 0, "p1": 0},
        },
        "raw_text": "{}",
        "finish_reason": "stop"
    }
    
    # 2. DPO Fails (API Error)
    dpo_response = {
        "success": False,
        "error": "Timeout",
        "data": None
    }
    
    # Side Effect: First call (SFT) -> sft_response, Second (DPO) -> dpo_response
    mock_llm.side_effect = [sft_response, dpo_response]
    
    results = score_articles(ARTICLES, STATE)
    row = results[0]
    
    # Checks
    assert row["dpo_attempted"] is True
    assert row["dpo_valid"] is False
    assert row["model_used"] == "sft_only"
    assert "api_error" in row["dpo_fail_reason"]
    
    # Ensure llm_final exists and matches adjusted SFT (0.5 since no hyp hits)
    assert row["llm_final_decision_score"] == 0.5
    assert row["llm_final_decision_p1"] == 0.8
    
    # Ensure llm_sft exists
    assert row["llm_sft_decision_p1"] == 0.8

