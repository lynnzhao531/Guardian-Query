import json
import pandas as pd
import random
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SYSTEM_PROMPT = """Output ONLY JSON. No prose. No markdown. Do not repeat.

CONSERVATIVE SCORING RULES (NON-NEGOTIABLE):
- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.
- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').
- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).
- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present.

Output ONLY valid JSON matching the schema. No prose. No markdown.
"""

def map_score_to_probs(score):
    if pd.isna(score): score = 0.0
    if score == 1:
        return {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}
    elif score == 0.5:
        return {"score": 0.5, "p0": 0.2, "p05": 0.6, "p1": 0.2}
    else:
        return {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}

def build_preferred(row):
    out = {"decision": map_score_to_probs(row.get("decision", 0))}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        out[f"method_{m}"] = map_score_to_probs(row.get(f"method_{m}", 0))
    return json.dumps(out)

def build_easy_neg(row):
    # Flip everything to its opposite extreme
    def flip(val):
        if pd.isna(val) or val < 0.5: return 1.0
        return 0.0
    
    out = {"decision": map_score_to_probs(flip(row.get("decision", 0)))}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        out[f"method_{m}"] = map_score_to_probs(flip(row.get(f"method_{m}", 0)))
    return json.dumps(out)

def build_hard_neg(row):
    out = {"decision": map_score_to_probs(row.get("decision", 0))}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        out[f"method_{m}"] = map_score_to_probs(row.get(f"method_{m}", 0))
    
    gold_dec = row.get("decision", 0)
    
    if gold_dec == 1:
        # It's high decision. Just flip decision to 0. Leave everything else untouched.
        out["decision"] = map_score_to_probs(0.0)
    else:
        # It's a low decision. We need to flip exactly one thing.
        # We will flip one method to 1 (if it's 0), or if it has a method already, flip decision to 1.
        has_method = any(row.get(f"method_{m}", 0) == 1 for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"])
        
        if has_method:
            out["decision"] = map_score_to_probs(1.0)
        else:
            trap = row.get('trap_tag', 'none')
            if 'prepost' in trap:
                out["method_prepost"] = map_score_to_probs(1.0)
            elif 'case' in trap:
                out["method_case_study"] = map_score_to_probs(1.0)
            elif 'opinion' in trap:
                out["method_gut"] = map_score_to_probs(1.0)
            else:
                active_methods = [m for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"] if row.get(f'has_{m}_kw', False)]
                if active_methods:
                    out[f"method_{active_methods[0]}"] = map_score_to_probs(1.0)
                else:
                    out["method_expert_qual"] = map_score_to_probs(1.0)
                
    return json.dumps(out)

def make_dpo_line(row, kind):
    pref = build_preferred(row)
    neg = build_hard_neg(row) if kind == 'hard' else build_easy_neg(row)
    
    title = row.get('title', 'Unknown')
    date = row.get('date', 'Unknown')
    evidence = row.get('evidence_text', '')
    
    user_msg = f"Title: {title}\nDate: {date}\n\nEvidence:\n{evidence}"
    
    return {
        "input": {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ]
        },
        "preferred_output": [{"role": "assistant", "content": pref}],
        "non_preferred_output": [{"role": "assistant", "content": neg}],
    }

def main():
    random.seed(42)
    
    # 1. Load data
    master_path = BASE_DIR / "outputs/master_vector.parquet"
    if not master_path.exists():
        master_path = BASE_DIR / "outputs/training_cases_clean.parquet"
    df_labels = pd.read_parquet(master_path)
    
    chunks_path = BASE_DIR / "data/processed/evidence_chunks.parquet"
    df_chunks = pd.read_parquet(chunks_path)[['url_canon', 'evidence_text']]
    
    labels_path = BASE_DIR / "data/processed/micro_labels.parquet"
    df_micro = pd.read_parquet(labels_path)
    
    # Merge
    df = df_labels.merge(df_chunks, on='url_canon', how='inner')
    df = df.merge(df_micro, on='url_canon', how='inner')
    
    print(f"Merged dataset: {len(df)} rows.")
    
    # 2. Balance classes
    # We want to oversample rare methods and decisions
    groups = []
    
    # decision
    d1 = df[df['decision'] == 1]
    if len(d1) > 0: groups.append(d1.sample(min(100, len(d1)), replace=False))
    
    # methods
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        m1 = df[df[f'method_{m}'] == 1]
        if len(m1) > 0: groups.append(m1.sample(min(40, len(m1)), replace=False))
        
    # negatives
    d0 = df[df['decision'] < 1]
    if len(d0) > 0: groups.append(d0.sample(min(200, len(d0)), replace=False))
    
    if not groups:
        print("No data found!")
        return
        
    balanced_df = pd.concat(groups).drop_duplicates(subset=['url_canon'])
    print(f"Balanced subset: {len(balanced_df)} rows.")
    
    # 3. Create JSONL lists
    dpo_lines = []
    meta_lines = []
    
    for _, row in balanced_df.iterrows():
        r_dict = row.to_dict()
        
        # Hard pair
        hard_line = make_dpo_line(r_dict, 'hard')
        dpo_lines.append(hard_line)
        meta_lines.append({
            "url_canon": r_dict['url_canon'],
            "pair_kind": "hard",
            "target_dim": "decision" if r_dict.get('decision', 0) == 1 else "trap",
            "trap_tag": r_dict.get('trap_tag', 'none')
        })
        
        # Easy pair
        easy_line = make_dpo_line(r_dict, 'easy')
        dpo_lines.append(easy_line)
        meta_lines.append({
            "url_canon": r_dict['url_canon'],
            "pair_kind": "easy",
            "target_dim": "all",
            "trap_tag": r_dict.get('trap_tag', 'none')
        })
        
    # 4. Train/val split
    # 80/20 split based on article level to avoid leaking
    urls = balanced_df['url_canon'].tolist()
    random.shuffle(urls)
    split_idx = int(len(urls) * 0.8)
    train_urls = set(urls[:split_idx])
    
    train_dpo, val_dpo = [], []
    train_meta, val_meta = [], []
    
    for line, meta in zip(dpo_lines, meta_lines):
        if meta['url_canon'] in train_urls:
            train_dpo.append(line)
            train_meta.append(meta)
        else:
            val_dpo.append(line)
            val_meta.append(meta)
            
    # 5. Write outputs
    out_dir = BASE_DIR / "fine_tune_data"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    with open(out_dir / "dpo_train_v2.jsonl", "w") as f:
        for l in train_dpo: f.write(json.dumps(l) + "\n")
        
    with open(out_dir / "dpo_val_v2.jsonl", "w") as f:
        for l in val_dpo: f.write(json.dumps(l) + "\n")
        
    with open(out_dir / "dpo_train_v2.meta.jsonl", "w") as f:
        for l in train_meta: f.write(json.dumps(l) + "\n")
        
    print(f"Generated {len(train_dpo)} train pairs and {len(val_dpo)} val pairs.")

if __name__ == "__main__":
    main()
