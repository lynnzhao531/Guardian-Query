import os
import json
from dotenv import load_dotenv
from openai import OpenAI

def launch():
    load_dotenv()
    key = os.getenv("OPENAI_API_KEY")
    assert key and len(key) >= 20, "OPENAI_API_KEY missing or too short"
    
    client = OpenAI(api_key=key)
    
    # Upload files
    train_path = "fine_tune_data/dpo_train_v2_fast_clean.jsonl"
    val_path = "fine_tune_data/dpo_val_v2_fast_clean.jsonl"
    
    train_file = client.files.create(file=open(train_path, "rb"), purpose="fine-tune")
    val_file = client.files.create(file=open(val_path, "rb"), purpose="fine-tune")
    
    # Create DPO job
    job = client.fine_tuning.jobs.create(
        model="ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH",
        training_file=train_file.id,
        validation_file=val_file.id,
        method={
            "type": "dpo",
            "dpo": {
                "hyperparameters": {
                    "beta": 0.8
                }
            }
        }
    )
    
    results = [
        f"JOB_ID: {job.id}",
        f"TRAIN_FILE_ID: {train_file.id}",
        f"VAL_FILE_ID: {val_file.id}"
    ]
    
    # Print results
    for line in results:
        print(line)
        
    # Write report
    with open("reports/dpo_job_launch_fast.md", "w") as f:
        f.write("\n".join(results) + "\n")
        
    # Update STATE.json
    state_path = "STATE.json"
    if os.path.exists(state_path):
        with open(state_path, "r") as f:
            try:
                state = json.load(f)
            except json.JSONDecodeError:
                state = {}
    else:
        state = {}
        
    state["latest_dpo_job_id"] = job.id
    state["latest_dpo_train_file_id"] = train_file.id
    state["latest_dpo_val_file_id"] = val_file.id
    
    with open(state_path, "w") as f:
        json.dump(state, f, indent=4)

if __name__ == "__main__":
    launch()
