import pandas as pd
import numpy as np
import json
import logging
from pathlib import Path
from src.llm_judge_router import score_articles
from src.hypothesis_verifier import HypothesisVerifier

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
EVAL_SET_PATH = ROOT / "project_state" / "fixed_eval_set.parquet"
RAW_OUT_PATH = ROOT / "reports" / "fixed_eval_sft_raw.parquet"
REPORT_PATH = ROOT / "reports" / "hypothesis_fp_reduction_report.md"
PARAMS_PATH = ROOT / "project_state" / "HYPOTHESIS_ADJUST_PARAMS.json"
HYP_PATH = ROOT / "knowledge_base" / "hypotheses" / "hypotheses_selected.json"

DIMENSIONS = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]

def run_final_evaluation():
    if not EVAL_SET_PATH.exists(): return
    df = pd.read_parquet(EVAL_SET_PATH)
    
    # We LOAD already computed raw scores if they exist to save cost,
    # but we RE-APPLY the adjustment logic using the new frozen params.
    if RAW_OUT_PATH.exists():
        logging.info("Using cached raw scores from reports/fixed_eval_sft_raw.parquet")
        raw_df = pd.read_parquet(RAW_OUT_PATH)
    else:
        logging.warning("No cached scores found. Re-scoring articles (this costs money!)")
        articles = df.to_dict('records')
        state = {"sft_model_name": "gpt-4o-mini", "dpo_model_name": None}
        results = score_articles(articles, state)
        raw_df = pd.DataFrame(results)
        # Standardize and save
        raw_df["url_canon"] = raw_df["url_canon"].astype(str).str.strip()
        df["url_canon"] = df["url_canon"].astype(str).str.strip()
        raw_df = raw_df.merge(df[["url_canon", "gold_decision", "split_label", "body_text"] + [f"gold_method_{m}" for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]]], on="url_canon")
        raw_df.to_parquet(RAW_OUT_PATH, index=False)

    # Load Params
    with open(PARAMS_PATH, "r") as f:
        params = json.load(f)
    with open(HYP_PATH, "r") as f:
        selected_hyps = json.load(f)

    logging.info(f"Applying frozen adjustment (a={params['a']}, b={params['b']}) to evaluation set...")
    
    # Re-apply adjust to ensure llm_final reflects newest params
    final_data_list = []
    for _, row in raw_df.iterrows():
        sft_raw = {f"{d}_p1": row[f"llm_sft_{d}_p1"] for d in DIMENSIONS}
        # adjust() now loads HYPOTHESIS_ADJUST_PARAMS.json internally
        adjusted = HypothesisVerifier.adjust(row["body_text"], sft_raw, selected_hyps)
        
        res_row = {"url_canon": row["url_canon"]}
        for d in DIMENSIONS:
            res_row[f"llm_final_{d}_score"] = adjusted[f"{d}_score"]
            res_row[f"llm_final_{d}_p1"] = adjusted[f"{d}_p1"]
        final_data_list.append(res_row)
        
    final_df = raw_df.drop(columns=[c for c in raw_df.columns if "llm_final" in c]).merge(pd.DataFrame(final_data_list), on="url_canon")

    # Metrics
    report = ["# Hypothesis FP Reduction Report (Final)\n"]
    report.append(f"**Chosen Parameters**: a={params['a']}, b={params['b']}, t1={params['t1']}, t05={params['t05']}\n")
    report.append(f"**Constraint Status**: {params['status']}\n")
    
    metrics = {}
    for prefix in ["llm_sft", "llm_final"]:
        metrics[prefix] = {}
        report.append(f"## {prefix.upper()} Confusion Matrices\n")
        rows = []
        for d in ["decision", "method_rct", "method_case_study"]:
            # Filter for rows where gold label exists for this dimension
            subset = final_df[final_df[f"gold_{d}"].notna()]
            if subset.empty: 
                rows.append({"Dimension": d, "P": 0, "R": 0, "TP": 0, "FP": 0, "FN": 0})
                continue
                
            y_true = (subset[f"gold_{d}"] == 1.0).astype(int)
            y_pred = (subset[f"{prefix}_{d}_score"] == 1.0).astype(int)
            tp = int(((y_true == 1) & (y_pred == 1)).sum())
            fp = int(((y_true == 0) & (y_pred == 1)).sum())
            fn = int(((y_true == 1) & (y_pred == 0)).sum())
            p = tp / (tp + fp) if (tp + fp) > 0 else 0
            r = tp / (tp + fn) if (tp + fn) > 0 else 0
            rows.append({"Dimension": d, "P": p, "R": r, "TP": tp, "FP": fp, "FN": fn})
            metrics[prefix][d] = {"tp": tp, "fp": fp}
            
        report.append(pd.DataFrame(rows).to_markdown(index=False) + "\n")

    # Overall Decision metrics
    sft_tp = metrics["llm_sft"]["decision"]["tp"]
    sft_fp = metrics["llm_sft"]["decision"]["fp"]
    fin_tp = metrics["llm_final"]["decision"]["tp"]
    fin_fp = metrics["llm_final"]["decision"]["fp"]
    
    fp_red = (sft_fp - fin_fp) / max(sft_fp, 1)
    tp_loss = (sft_tp - fin_tp) / max(sft_tp, 1)
    
    report.append(f"\n**Decision FP Reduction**: {fp_red*100:.1f}%\n")
    report.append(f"**Decision TP Loss**: {tp_loss*100:.1f}%\n")

    # Examples
    report.append("\n## Examples: FPs Removed\n")
    # FP removed: SFT=1, Final < 1, Gold=0
    fps_removed = final_df[(final_df["llm_sft_decision_score"] == 1.0) & (final_df["llm_final_decision_score"] < 1.0) & (final_df["gold_decision"] == 0.0)].head(10)
    for _, r in fps_removed.iterrows():
        hits = HypothesisVerifier.get_hit_counts(r["body_text"], selected_hyps).get("decision", {})
        report.append(f"- **{r['url_canon'].split('/')[-1]}**: Adjusted {r['llm_sft_decision_p1']:.2f} -> {r['llm_final_decision_p1']:.2f}. Hits: {hits}\n")

    report.append("\n## Examples: TPs Retained\n")
    # TP retained: SFT=1, Final=1, Gold=1
    tps_retained = final_df[(final_df["llm_sft_decision_score"] == 1.0) & (final_df["llm_final_decision_score"] == 1.0) & (final_df["gold_decision"] == 1.0)].head(10)
    for _, r in tps_retained.iterrows():
        hits = HypothesisVerifier.get_hit_counts(r["body_text"], selected_hyps).get("decision", {})
        report.append(f"- **{r['url_canon'].split('/')[-1]}**: Adjusted {r['llm_sft_decision_p1']:.2f} -> {r['llm_final_decision_p1']:.2f}. Hits: {hits}\n")

    with open(REPORT_PATH, "w") as f:
        f.write("\n".join(report))
    logging.info(f"Final report saved to {REPORT_PATH}")

if __name__ == "__main__":
    run_final_evaluation()
