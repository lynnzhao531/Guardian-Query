import pandas as pd
import json
import os
from pathlib import Path

def main():
    log_path = "outputs/query_log.csv"
    if not os.path.exists(log_path):
        print(f"Error: {log_path} not found.")
        return

    df = pd.read_csv(log_path)
    
    # Last 30 rounds
    recent = df.tail(30).copy()
    
    # Per-round table columns
    cols = [
        "round_id", "template_id", "guardian_total_available", "guardian_candidates_retrieved",
        "skipped_live_count", "skipped_long_count", "skipped_missing_text_count",
        "filtered_remaining_count", "scored_count",
        "high_rel_llm_final_count", "consensus_high_rel_count",
        "llm_mode_used_counts_json"
    ]
    
    # Ensure all cols exist
    existing_cols = [c for c in cols if c in recent.columns]
    recent_subset = recent[existing_cols]
    
    # Generate Markdown Table
    md_table = recent_subset.to_markdown(index=False)
    
    # Per-template summary
    template_stats = []
    for tid, tdf in recent.groupby("template_id"):
        scored_0_pct = (tdf["scored_count"] == 0).mean() * 100
        avg_skipped_live_pct = (tdf["skipped_live_count"] / tdf["guardian_candidates_retrieved"].replace(0, 1)).mean() * 100
        avg_skipped_long_pct = (tdf["skipped_long_count"] / tdf["guardian_candidates_retrieved"].replace(0, 1)).mean() * 100
        avg_remaining_pct = (tdf["filtered_remaining_count"] / tdf["guardian_candidates_retrieved"].replace(0, 1)).mean() * 100
        
        template_stats.append({
            "template_id": tid,
            "rounds_count": len(tdf),
            "scored_0_pct": scored_0_pct,
            "avg_skipped_live_pct": avg_skipped_live_pct,
            "avg_skipped_long_pct": avg_skipped_long_pct,
            "avg_remaining_pct": avg_remaining_pct
        })
    
    ts_df = pd.DataFrame(template_stats)
    ts_table = ts_df.to_markdown(index=False)
    
    # Identify "dead templates"
    # filtered_remaining_count==0 in >=2 of last 3 uses
    dead_templates = []
    for tid, tdf in df.groupby("template_id"):
        last_3 = tdf.tail(3)
        if len(last_3) >= 2:
            zero_remaining_count = (last_3["filtered_remaining_count"] == 0).sum()
            if zero_remaining_count >= 2:
                dead_templates.append(tid)
    
    # Write Report
    report_content = f"""# Recent Rounds Diagnostics

## Per-Round Performance (Last 30 Rounds)
{md_table}

## Per-Template Statistics
{ts_table}

## Dead Templates
Identified as `filtered_remaining_count == 0` in >= 2 of last 3 uses:
{", ".join(dead_templates) if dead_templates else "None"}
"""
    
    os.makedirs("reports", exist_ok=True)
    with open("reports/recent_rounds_diagnostics.md", "w") as f:
        f.write(report_content)
    
    print("Report generated: reports/recent_rounds_diagnostics.md")

if __name__ == "__main__":
    main()
