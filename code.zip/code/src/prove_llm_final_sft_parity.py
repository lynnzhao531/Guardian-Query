import pandas as pd
import sys
from pathlib import Path

def check_parity(round_id):
    round_dir = Path(f"outputs/rounds/round_{round_id}")
    parquet_path = round_dir / "scored_results_full.parquet"
    if not parquet_path.exists():
        print(f"Error: {parquet_path} missing")
        return False
        
    df = pd.read_parquet(parquet_path)
    if "llm_sft_decision_score" not in df.columns or "llm_final_decision_score" not in df.columns:
        print(f"Error: Missing score columns in round {round_id}")
        return False
        
    # Decision Score Parity
    mismatches = df[df["llm_sft_decision_score"] != df["llm_final_decision_score"]]
    
    # Decision P1 Parity (tolerance 1e-9)
    p1_mismatches = df[abs(df["llm_sft_decision_p1"] - df["llm_final_decision_p1"]) > 1e-9]
    
    # Method Parity
    method_mismatches = 0
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    for m in methods:
        s_score = f"llm_sft_method_{m}_score"
        f_score = f"llm_final_method_{m}_score"
        s_p1 = f"llm_sft_method_{m}_p1"
        f_p1 = f"llm_final_method_{m}_p1"
        
        if s_score in df.columns and f_score in df.columns:
            method_mismatches += len(df[df[s_score] != df[f_score]])
        if s_p1 in df.columns and f_p1 in df.columns:
            method_mismatches += len(df[abs(df[s_p1] - df[f_p1]) > 1e-9])
            
    total_mismatches = len(mismatches) + len(p1_mismatches) + method_mismatches
    
    report_path = Path("reports/next20_llmfinal_equals_sft_proof.md")
    mode = "a" if report_path.exists() else "w"
    
    with open(report_path, mode) as f:
        if mode == "w":
            f.write("# LLM Final == SFT Parity Proof\n\n")
        f.write(f"## Round {round_id}\n")
        f.write(f"- Rows checked: {len(df)}\n")
        f.write(f"- Combined mismatches: {total_mismatches}\n")
        if total_mismatches == 0:
            f.write("- **Status: PASS**\n\n")
        else:
            f.write("- **Status: FAIL**\n\n")
            
    print(f"Round {round_id}: {total_mismatches} mismatches")
    return total_mismatches == 0

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python prove_llm_final_sft_parity.py <round_id>")
        sys.exit(1)
    rid = sys.argv[1]
    success = check_parity(rid)
    sys.exit(0 if success else 1)
