#!/usr/bin/env python3
"""
Step 0: Setup project structure.
Creates all required directories and initial config/state files.
Run this first if starting from scratch.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent

DIRS = [
    "project_state",
    "data/raw",
    "data/processed",
    "fine_tune_data",
    "knowledge_base/query_spaces",
    "models/tgml",
    "audits",
    "reports",
]


def main():
    print("Creating project directories...")
    for d in DIRS:
        p = ROOT / d
        p.mkdir(parents=True, exist_ok=True)
        print(f"  ✓ {p}")

    # Check for required files
    required = [
        ("project_state/CONFIG.yaml", "Run needs CONFIG.yaml"),
        ("project_state/STATE.json", "Run needs STATE.json"),
        ("project_state/COST_LEDGER.json", "Run needs COST_LEDGER.json"),
    ]
    for fpath, msg in required:
        if not (ROOT / fpath).exists():
            print(f"  ⚠ Missing: {fpath} — {msg}")
        else:
            print(f"  ✓ {fpath} exists")

    print("\n✓ Project setup complete")


if __name__ == "__main__":
    main()
