import pandas as pd
import json
import numpy as np
from pathlib import Path
import os
import sys

# Load Thresholds
THRESHOLDS_FILE = Path("project_state/PER_MODEL_THRESHOLDS.json")
with open(THRESHOLDS_FILE, "r") as f:
    orig_thresholds = json.load(f)

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

def compute_consensus_internal(row, thresholds, eps):
    # Decision Gate
    prefix = "llm_final"
    dec_score = row.get(f"{prefix}_decision_score", 0.0)
    dec_p1 = row.get(f"{prefix}_decision_p1", 0.0)
    t_dec = thresholds[prefix]["t_dec"]
    if dec_score < 1.0 or dec_p1 < t_dec:
        return False
        
    # Model 1 Dec Pass (for expert exception)
    m1_dec_score = row.get("model1_decision_score", 0.0)
    m1_dec_p1 = row.get("model1_decision_p1", 0.0)
    t_dec_m1 = thresholds["model1"]["t_dec"]
    m1_dec_pass = (m1_dec_score >= 1.0 and m1_dec_p1 >= t_dec_m1)

    # Topsets
    def get_ts(prefix, exclude_eq=False):
        methods = METHOD_NAMES
        if exclude_eq:
            methods = [m for m in METHOD_NAMES if m != "expert_qual"]
        scores = {m: row.get(f"{prefix}_method_{m}_p1", 0.0) for m in methods}
        if not scores: return set()
        mx = max(scores.values())
        if mx == 0: return set()
        return {m for m, v in scores.items() if v >= (mx - eps)}

    ts_llm = get_ts("llm_final")
    ts_m3 = get_ts("model3", exclude_eq=True)
    agreement = ts_llm.intersection(ts_m3)
    
    # Expert Exception
    llm_scores = {m: row.get(f"llm_final_method_{m}_p1", 0.0) for m in METHOD_NAMES}
    llm_best = max(llm_scores, key=llm_scores.get) if llm_scores else "none"
    pass_by_expert = False
    if llm_best == "expert_qual":
        t_meth_llm = thresholds["llm_final"]["t_meth"]
        if llm_scores["expert_qual"] >= (t_meth_llm + 0.1) or m1_dec_pass:
            pass_by_expert = True
            agreement = {"expert_qual"}
            
    if not agreement:
        return False
        
    # Model 3 Method Gate
    m3_meth_p1s = [row.get(f"model3_method_{m}_p1", 0.0) for m in METHOD_NAMES if m != "expert_qual"]
    m3_max_p1 = max(m3_meth_p1s) if m3_meth_p1s else 0.0
    t_meth_m3 = thresholds["model3"]["t_meth"]
    m3_meth_pass = m3_max_p1 >= t_meth_m3
    
    if not m3_meth_pass and not pass_by_expert:
        return False
        
    return True

def run_sweep():
    # Load Benchmark
    bench_path = Path("reports/synthetic_benchmark_full.parquet")
    if not bench_path.exists():
        print(f"Error: {bench_path} missing. Run eval_synthetic_benchmark.py first.")
        # Try finding the raw scoring if full missing? No, we need full.
        return
    bench_df = pd.read_parquet(bench_path)
    # Mark traps
    bench_df["is_trap"] = bench_df["id"].str.startswith("f") | (bench_df["gold_dec"] < 1.0)
    
    # Load Rounds for yield check
    round_data = {}
    for rid in [28, 29]:
        rp = Path(f"outputs/rounds/round_{rid}/scored_results_full.parquet")
        if rp.exists():
            round_data[rid] = pd.read_parquet(rp)

    results = []
    
    t_m3_range = np.arange(0.10, 0.36, 0.01) # 0.20 to 0.35
    eps_range = [0.02, 0.03, 0.04, 0.05]
    
    for t_m3 in t_m3_range:
        for eps in eps_range:
            curr_thresholds = json.loads(json.dumps(orig_thresholds))
            curr_thresholds["model3"]["t_meth"] = float(t_m3)
            
            # 1. Synthetic Audit
            bench_df["cons_pass"] = bench_df.apply(lambda r: compute_consensus_internal(r, curr_thresholds, eps), axis=1)
            traps_passed = bench_df[bench_df["is_trap"] & bench_df["cons_pass"]].shape[0]
            prototypes_passed = bench_df[~bench_df["is_trap"] & bench_df["cons_pass"]].shape[0]
            
            # 2. Round Yields
            yields = {}
            for rid, rdf in round_data.items():
                rdf["cons_pass"] = rdf.apply(lambda r: compute_consensus_internal(r, curr_thresholds, eps), axis=1)
                yields[rid] = int(rdf["cons_pass"].sum())
                
            results.append({
                "t_meth_m3": round(t_m3, 3),
                "eps": eps,
                "traps_passed": traps_passed,
                "prototypes_passed": prototypes_passed,
                **{f"round_{rid}_yield": y for rid, y in yields.items()}
            })
            
    res_df = pd.DataFrame(results)
    
    # Filter for safe ones
    safe_df = res_df[res_df["traps_passed"] == 0].copy()
    
    # Selection logic: Maximize Round 28 yield, then Round 29 yield, then smallest eps, then largest threshold
    if not safe_df.empty:
        # Sort by total yield descending
        yield_cols = [c for c in safe_df.columns if c.endswith("_yield")]
        safe_df["total_yield"] = safe_df[yield_cols].sum(axis=1)
        safe_df = safe_df.sort_values(["total_yield", "eps", "t_meth_m3"], ascending=[False, True, False])
        
        best = safe_df.iloc[0]
        print("\n=== Best Recommended Configuration ===")
        print(best.to_string())
    
    # Write report
    os.makedirs("audits", exist_ok=True)
    report_path = "audits/threshold_sweep_audit.md"
    with open(report_path, "w") as f:
        f.write("# Consensus Parameter Sweep Audit\n\n")
        f.write("## Safe Configurations (Traps Passed = 0)\n\n")
        f.write(safe_df.to_markdown(index=False))
        f.write("\n\n## Conclusion\n")
        if not safe_df.empty:
            f.write(f"Recommended: `model3.t_meth` = {best['t_meth_m3']}, `eps` = {best['eps']}\n")
        else:
            f.write("No safe configuration found that keeps traps = 0.\n")

    print(f"\nSweep report written to {report_path}")

if __name__ == "__main__":
    run_sweep()
