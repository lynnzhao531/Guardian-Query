#!/usr/bin/env python3
"""
Step 1: Load merged dataset + produce full data audit report.
Reads project_state files, validates schema, writes audits/data_audit_report.md.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))


# ── helpers ───────────────────────────────────────────────────────────

def load_config() -> dict:
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state() -> dict:
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state: dict) -> None:
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def md5_file(path: str | Path) -> str:
    return hashlib.md5(Path(path).read_bytes()).hexdigest()


# ── main ──────────────────────────────────────────────────────────────

def main() -> None:
    cfg = load_config()
    state = load_state()

    data_path = ROOT / cfg["data"]["merged_dataset"]
    print(f"Loading: {data_path}")
    assert data_path.exists(), f"Dataset not found: {data_path}"

    # ── Load ──────────────────────────────────────────────────────────
    df = pd.read_parquet(data_path)
    file_hash = md5_file(data_path)
    file_size = os.path.getsize(data_path)

    article_id_col = cfg["data"]["article_id_column"]
    decision_col = cfg["data"]["decision_column"]
    method_cols = cfg["data"]["method_columns"]
    allowed = set(cfg["data"]["allowed_scores"])

    # ── Validation: score columns ∈ {0, 0.5, 1, NaN} ─────────────────
    bad_values = []
    for label, col in [("decision", decision_col)] + [(k, v) for k, v in method_cols.items()]:
        if col not in df.columns:
            bad_values.append({"label": label, "column": col, "issue": "COLUMN MISSING"})
            continue
        non_null = df[col].dropna()
        invalid = non_null[~non_null.isin(allowed)]
        if len(invalid) > 0:
            for idx, val in invalid.items():
                bad_values.append({
                    "label": label, "column": col,
                    "row_index": int(idx), "value": float(val),
                    "issue": "VALUE NOT IN {0, 0.5, 1}",
                })

    if bad_values:
        print("\n⚠  BAD VALUES DETECTED — STOPPING")
        for bv in bad_values[:20]:
            print(f"  {bv}")
        pd.DataFrame(bad_values).to_csv(ROOT / "audits" / "bad_label_values.csv", index=False)
        sys.exit(1)

    # ── Build audit report ────────────────────────────────────────────
    lines: list[str] = []
    w = lines.append

    w("# Data Audit Report\n")
    w(f"**File**: `{data_path}`  ")
    w(f"**Size**: {file_size:,} bytes  ")
    w(f"**MD5**: `{file_hash}`  ")
    w(f"**Rows**: {len(df):,}  ")
    w(f"**Unique article IDs** (`{article_id_col}`): {df[article_id_col].nunique():,}  \n")

    # ── Columns + dtypes ──────────────────────────────────────────────
    w("## Columns and Dtypes\n")
    w("| # | Column | Dtype | Null % |")
    w("|---|--------|-------|--------|")
    for i, col in enumerate(df.columns):
        null_pct = round(100 * df[col].isna().mean(), 1)
        w(f"| {i} | `{col}` | {df[col].dtype} | {null_pct}% |")
    w("")

    # ── Score distributions ───────────────────────────────────────────
    w("## Score Distributions\n")
    score_cols = [decision_col] + list(method_cols.values())
    for col in score_cols:
        if col not in df.columns:
            continue
        nn = int(df[col].notna().sum())
        na = int(df[col].isna().sum())
        vc = df[col].dropna().value_counts().sort_index()
        w(f"### `{col}`\n")
        w(f"Non-null: {nn}, Missing: {na}\n")
        w("| Score | Count | % |")
        w("|-------|-------|---|")
        for sc, cnt in vc.items():
            w(f"| {sc} | {cnt} | {round(100*cnt/nn, 1)}% |")
        w("")

    # ── Key meta stats ────────────────────────────────────────────────
    w("## Key Statistics\n")
    body_na = round(100 * df["body"].isna().mean(), 1)
    title_na = round(100 * df["title"].isna().mean(), 1)
    w(f"- Body missing: {body_na}%")
    w(f"- Title missing: {title_na}%")
    w(f"- is_liveblog True: {int(df['is_liveblog'].sum())}")
    w(f"- is_commentisfree True: {int(df['is_commentisfree'].sum())}")
    w(f"- source_datasets unique values: {df['source_datasets'].nunique()}")
    w(f"- decision_conflict True: {int(df['decision_conflict'].sum()) if 'decision_conflict' in df.columns else 'N/A'}")
    w("")

    # ── 10 random rows (truncated text) ───────────────────────────────
    w("## 10 Random Rows (truncated)\n")
    random.seed(42)
    sample_idx = random.sample(range(len(df)), min(10, len(df)))
    sample = df.iloc[sample_idx][
        [article_id_col, "title", decision_col] + list(method_cols.values())
    ].copy()
    # Truncate title
    sample["title"] = sample["title"].fillna("").str[:80]
    w(sample.to_markdown(index=False))
    w("")

    # ── Write ─────────────────────────────────────────────────────────
    audit_dir = ROOT / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)
    report_path = audit_dir / "data_audit_report.md"
    report_path.write_text("\n".join(lines))
    print(f"✓ Audit report written to {report_path}")

    # ── Also write JSON summary for downstream scripts ────────────────
    summary = {
        "file": str(data_path),
        "md5": file_hash,
        "rows": len(df),
        "unique_ids": int(df[article_id_col].nunique()),
        "decision_non_null": int(df[decision_col].notna().sum()),
        "method_non_null": {
            k: int(df[v].notna().sum()) for k, v in method_cols.items()
        },
        "body_missing_pct": body_na,
        "title_missing_pct": title_na,
        "bad_values": len(bad_values),
    }
    with open(audit_dir / "data_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    # ── Update STATE ──────────────────────────────────────────────────
    state["data_file_path"] = str(data_path)
    state["dataset_hash_md5"] = file_hash
    if "step_1_audit" not in state["steps_completed"]:
        state["steps_completed"].append("step_1_audit")
    state["current_step"] = "step_1_complete"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  DATA AUDIT COMPLETE")
    print(f"  Rows: {len(df):,}  |  Decision labels: {int(df[decision_col].notna().sum())}")
    print(f"  Bad values: {len(bad_values)}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
