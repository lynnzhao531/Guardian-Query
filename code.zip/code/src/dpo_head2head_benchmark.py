"""
src/dpo_head2head_benchmark.py  —  STRICT DPO head-to-head comparison.

Qualifies models on 0 trap passes, then ranks by precision@50 on holdout.
"""

import argparse
import csv
import datetime
import hashlib
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import numpy as np
import pandas as pd

# ──────────────────────────────────────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("dpo_benchmark")

# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────
METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
REQUIRED_KEYS = ["decision", "method_scores"] # as returned by safe_llm_judge

# ──────────────────────────────────────────────────────────────────────────────
# Setup
# ──────────────────────────────────────────────────────────────────────────────

def _sha256_file(path: Path) -> str:
    if not path.exists(): return "missing"
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_thresholds(path: Path) -> Dict:
    if not path.exists():
        log.warning(f"Thresholds file {path} missing. Using defaults.")
        return {"t_dec": 0.60, "t_meth": 0.80}
    with open(path) as f:
        data = json.load(f)
    # Prefer llm_final or dpo keys if they exist
    if "llm_final" in data:
        return data["llm_final"]
    if "model1" in data:
        return data["model1"]
    return data

# ──────────────────────────────────────────────────────────────────────────────
# Eval Set Building
# ──────────────────────────────────────────────────────────────────────────────

def build_holdout(parquet_path: Path) -> List[Dict]:
    if not parquet_path.exists():
        log.error(f"Holdout parquet missing: {parquet_path}")
        sys.exit(10)
    
    df = pd.read_parquet(parquet_path)
    # Map method columns to single gold_method
    # method_rct, method_prepost, etc. are 0, 0.5, 1.0
    def get_gold_method(row):
        scores = {m: row.get(f"method_{m}", 0.0) for m in METHOD_NAMES}
        # Filter out NaNs
        scores = {k: (v if pd.notna(v) else 0.0) for k, v in scores.items()}
        if max(scores.values()) == 0:
            return "none"
        return max(scores, key=scores.get)

    eval_items = []
    for _, row in df.iterrows():
        text = str(row.get("title", "")) + "\n\n" + str(row.get("body", ""))
        eval_items.append({
            "id": row.get("url_canon", row.get("id", "unknown")),
            "text": text,
            "gold_method": get_gold_method(row),
            "gold_decision": float(row.get("decision", 0.0)) if pd.notna(row.get("decision")) else 0.0,
            "is_trap": False
        })
    
    # Audit stats
    log.info(f"Built holdout: {len(eval_items)} items.")
    return eval_items

def load_synthetic(jsonl_path: Path) -> List[Dict]:
    if not jsonl_path.exists():
        log.error(f"Synthetic benchmark missing: {jsonl_path}")
        sys.exit(10)
    items = []
    with open(jsonl_path) as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))
    log.info(f"Loaded synthetic: {len(items)} items.")
    return items

# ──────────────────────────────────────────────────────────────────────────────
# Inference
# ──────────────────────────────────────────────────────────────────────────────

def score_item(model_id: str, text: str, api_key: str) -> Dict:
    """Deterministic inference via safe_llm_judge."""
    from src.safe_llm_judge import call_llm_scoring
    res = call_llm_scoring(
        model_name=model_id,
        article_text=text,
        max_output_tokens=2048,
        strict_schema=True,
        api_key=api_key
    )
    if not res.get("success"):
        log.error(f"RAW FAILURE TEXT: {res.get('raw_text')}")
        raise RuntimeError(f"Model {model_id} failed: {res.get('error')}")
    
    data = res["data"]
    # Validate probabilities
    dec_p1 = data.get("decision", {}).get("p1", 0.0)
    if not (0 <= dec_p1 <= 1):
        raise ValueError(f"Invalid decision_p1: {dec_p1}")
    
    meth_p1s = [data.get(f"method_{m}", {}).get("p1", 0.0) for m in METHOD_NAMES]
    for p in meth_p1s:
        if not (0 <= p <= 1):
            raise ValueError(f"Invalid method_p1: {p}")
            
    return data

# ──────────────────────────────────────────────────────────────────────────────
# Metrics
# ──────────────────────────────────────────────────────────────────────────────

def run_eval(model_id: str, items: List[Dict], api_key: str, thresholds: Dict) -> Tuple[List[Dict], Dict]:
    preds = []
    t_dec = thresholds.get("t_dec", 0.60)
    t_meth = thresholds.get("t_meth", 0.80)
    
    log.info(f"Evaluating {model_id} on {len(items)} items...")
    
    for item in items:
        try:
            raw = score_item(model_id, item["text"], api_key)
            dec_p1 = raw.get("decision", {}).get("p1", 0.0)
            meth_scores = {m: raw.get(f"method_{m}", {}).get("p1", 0.0) for m in METHOD_NAMES}
            max_meth_p1 = max(meth_scores.values()) if meth_scores else 0.0
            
            passed = (dec_p1 >= t_dec) and (max_meth_p1 >= t_meth)
            score = dec_p1 * max_meth_p1
            
            preds.append({
                "id": item["id"],
                "passed": passed,
                "score": score,
                "decision_p1": dec_p1,
                "max_method_p1": max_meth_p1,
                "gold_decision": item["gold_decision"],
                "gold_method": item["gold_method"],
                "is_trap": item.get("is_trap", False),
                "raw": raw
            })
        except Exception as e:
            log.error(f"Error on {item['id']}: {e}")
            sys.exit(10) # Strict stop
    
    # Calc metrics
    traps = [p for p in preds if p["is_trap"]]
    protos = [p for p in preds if not p["is_trap"] and p["gold_decision"] == 1.0] # Synthetic protos
    holdout = [p for p in preds if not p["is_trap"]] # Holdout + Protos? Actually just filter by set if needed.
    
    # We'll treat synthetic as one set and holdout as another in the main loop
    return preds

def compute_summary(model_id: str, syn_preds: List[Dict], hold_preds: List[Dict]) -> Dict:
    trap_pass = sum(1 for p in syn_preds if p["is_trap"] and p["passed"])
    proto_pass = sum(1 for p in syn_preds if not p["is_trap"] and p["passed"])
    
    # Holdout metrics
    hold_df = pd.DataFrame(hold_preds)
    hold_df["gold_high_rel"] = (hold_df["gold_decision"] == 1.0) # Simplified
    
    pass_items = hold_df[hold_df["passed"]]
    prec_overall = len(pass_items[pass_items["gold_high_rel"]]) / len(pass_items) if len(pass_items) > 0 else 0.0
    
    sorted_hold = hold_df.sort_values("score", ascending=False)
    p50 = len(sorted_hold.head(50)[sorted_hold.head(50)["gold_high_rel"]]) / 50.0
    p100 = len(sorted_hold.head(100)[sorted_hold.head(100)["gold_high_rel"]]) / 100.0
    
    # F1 (rough)
    # ... Simplified for brevity in this snippet ...
    
    return {
        "model_id": model_id,
        "trap_pass_count": trap_pass,
        "prototype_pass_count": proto_pass,
        "precision_p50": p50,
        "precision_p100": p100,
        "precision_overall": prec_overall,
        "pass_count": len(pass_items)
    }

# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dpo_a", required=True)
    parser.add_argument("--dpo_b", required=True)
    parser.add_argument("--holdout_parquet", default="archive/stale_rounds_20260222/outputs/master_vector.parquet")
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--limit", type=int, help="Limit holdout items for smoke testing")
    parser.add_argument("--strict", action="store_true", default=True)
    args = parser.parse_args()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        log.error("OPENAI_API_KEY missing.")
        sys.exit(10)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load sets
    syn_items = load_synthetic(Path("eval/synthetic_benchmark.jsonl"))
    hold_items = build_holdout(Path(args.holdout_parquet))
    if args.limit:
        hold_items = hold_items[:args.limit]
        log.info(f"Limited holdout to {args.limit} items.")
    
    # Save built holdout
    with open(out_dir / "holdout_eval_built.jsonl", "w") as f:
        for it in hold_items:
            # strip text for audit to keep it small
            audit_it = {k:v for k,v in it.items() if k != "text"}
            f.write(json.dumps(audit_it) + "\n")

    # 2. Thresholds
    thresholds = load_thresholds(Path("project_state/PER_MODEL_THRESHOLDS.json"))
    with open(out_dir / "thresholds_used.json", "w") as f:
        json.dump(thresholds, f, indent=2)

    # 3. Runs
    results = {}
    for mid in [args.dpo_a, args.dpo_b]:
        syn_p = run_eval(mid, syn_items, api_key, thresholds)
        hold_p = run_eval(mid, hold_items, api_key, thresholds)
        
        # Save preds
        m_suffix = "a" if mid == args.dpo_a else "b"
        with open(out_dir / f"preds_dpo_{m_suffix}.jsonl", "w") as f:
            for p in syn_p + hold_p:
                f.write(json.dumps(p) + "\n")
        
        results[mid] = {
            "syn": syn_p,
            "hold": hold_p,
            "summary": compute_summary(mid, syn_p, hold_p)
        }

    # 4. Global artifacts
    hashes = {
        "synthetic": _sha256_file(Path("eval/synthetic_benchmark.jsonl")),
        "holdout": _sha256_file(Path(args.holdout_parquet))
    }
    with open(out_dir / "eval_hashes.json", "w") as f:
        json.dump(hashes, f, indent=2)

    # 5. Metrics table
    metrics_list = [results[args.dpo_a]["summary"], results[args.dpo_b]["summary"]]
    pd.DataFrame(metrics_list).to_csv(out_dir / "metrics.csv", index=False)
    with open(out_dir / "metrics.json", "w") as f:
        json.dump(metrics_list, f, indent=2)

    # 6. Winner Selection
    # Qualify
    a_sum = results[args.dpo_a]["summary"]
    b_sum = results[args.dpo_b]["summary"]
    
    def select_winner(s1, s2):
        # Disqualify on traps
        q1 = s1["trap_pass_count"] == 0
        q2 = s2["trap_pass_count"] == 0
        
        if not q1 and not q2: return None, "Both disqualified (traps)"
        if not q1: return s2["model_id"], f"Model B wins (A failed traps: {s1['trap_pass_count']})"
        if not q2: return s1["model_id"], f"Model A wins (B failed traps: {s2['trap_pass_count']})"
        
        # p50
        if s1["precision_p50"] > s2["precision_p50"]: return s1["model_id"], "Model A higher p@50"
        if s2["precision_p50"] > s1["precision_p50"]: return s2["model_id"], "Model B higher p@50"
        
        # precision overall
        if s1["precision_overall"] > s2["precision_overall"]: return s1["model_id"], "Model A higher precision overall"
        if s2["precision_overall"] > s1["precision_overall"]: return s2["model_id"], "Model B higher precision overall"
        
        # proto count
        if s1["prototype_pass_count"] > s2["prototype_pass_count"]: return s1["model_id"], "Model A higher proto count"
        if s2["prototype_pass_count"] > s1["prototype_pass_count"]: return s2["model_id"], "Model B higher proto count"

        if s1["pass_count"] < s2["pass_count"]: return s1["model_id"], "Model A more conservative"
        if s2["pass_count"] < s1["pass_count"]: return s2["model_id"], "Model B more conservative"
        
        # Final tie-breaker: deterministic alphabetical
        if s1["model_id"] < s2["model_id"]:
            return s1["model_id"], "Tie-breaker reached end; alphabetical selection"
        else:
            return s2["model_id"], "Tie-breaker reached end; alphabetical selection"

    winner_id, reason = select_winner(a_sum, b_sum)
    with open(out_dir / "WINNER.txt", "w") as f:
        f.write(f"WINNER: {winner_id}\nREASON: {reason}\n")
    
    # 7. Disagreements
    a_df = pd.DataFrame(results[args.dpo_a]["hold"])
    b_df = pd.DataFrame(results[args.dpo_b]["hold"])
    
    merged = a_df.merge(b_df, on="id", suffixes=("_a", "_b"))
    merged["delta"] = (merged["score_a"] - merged["score_b"]).abs()
    top30 = merged.sort_values("delta", ascending=False).head(30)
    top30.to_csv(out_dir / "disagreements_top30.csv", index=False)

    log.info(f"BENCHMARK COMPLETE. Winner: {winner_id}")
    log.info(f"Artifacts in {out_dir}")

if __name__ == "__main__":
    main()
