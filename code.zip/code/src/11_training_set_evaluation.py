#!/usr/bin/env python3
import json
import torch
import pandas as pd
import numpy as np
import joblib
import yaml
from pathlib import Path
from sklearn.metrics import classification_report
from transformers import AutoTokenizer

ROOT = Path(__file__).resolve().parent.parent

# ── Baseline (Model 1) Imports ────────────────────────────────────────

class OrdinalClassifier:
    # Need to match the definition in src/03_train_tgml_baseline.py
    def __init__(self, classes=None, **lr_kwargs):
        self.classes = np.array(classes or [0.0, 0.5, 1.0])
        self.lr_kwargs = lr_kwargs
        self.clfs = []

    def predict_proba(self, X):
        n = X.shape[0]
        cps = []
        for clf in self.clfs:
            if clf is not None:
                cps.append(clf.predict_proba(X)[:, 1])
            else:
                cps.append(np.zeros(n))
        probs = np.zeros((n, len(self.classes)))
        probs[:, 0] = 1.0 - cps[0]
        for k in range(1, len(self.classes) - 1):
            probs[:, k] = cps[k - 1] - cps[k]
        probs[:, -1] = cps[-1]
        probs = np.clip(probs, 0, 1)
        rs = probs.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        return probs / rs

    def predict(self, X):
        return self.classes[np.argmax(self.predict_proba(X), axis=1)]

# ── Model 3 Imports ───────────────────────────────────────────────────

import importlib
train_mod = importlib.import_module("04_model3_train")
CBMModel = train_mod.CBMModel
CBMDataset = train_mod.CBMDataset

# ── Main ─────────────────────────────────────────────────────────────

def main():
    # 1. Load splits and training data
    with open(ROOT / "data" / "processed" / "article_splits.json") as f:
        splits = json.load(f)
    train_ids = set(splits["train_articles"])
    
    # Baseline uses training_long.parquet
    df_long = pd.read_parquet(ROOT / "data" / "processed" / "training_long.parquet")
    train_df_baseline = df_long[df_long["article_id"].isin(train_ids)].copy()
    
    # Model 3 uses master_vector.csv + concept_labels.parquet
    df_mv = pd.read_csv(ROOT / "outputs" / "master_vector.csv")
    labels_df = pd.read_parquet(ROOT / "data" / "concept_labels.parquet")
    full_df = pd.merge(df_mv, labels_df, on="url_canon")
    full_df["full_text"] = full_df["title"].fillna("") + "\n\n" + full_df["body"].fillna("")
    
    # Filter for training articles
    train_df_model3 = full_df[full_df["url_canon"].isin(train_ids)].copy()

    print(f"Loaded training set: {len(train_df_baseline)} baseline rows, {len(train_df_model3)} Model 3 articles.")

    labels = ["0.0", "0.5", "1.0"]
    targets = ["decision", "method_rct", "method_prepost", "method_case_study", 
               "method_expert_qual", "method_expert_secondary", "method_gut"]
    
    # ── Evaluate Model 1 (Baseline) ──────────────────────────────────
    print("\n" + "="*60)
    print("  MODEL 1 (Baseline) - TRAINING PERFORMANCE")
    print("="*60)
    
    model_dir_tgml = ROOT / "models" / "tgml"
    tfidf = joblib.load(model_dir_tgml / "tfidf_vectorizer.joblib")
    
    for target in targets:
        # Load specific model for target
        if target == "decision":
            clf_path = model_dir_tgml / "decision_ordinal.joblib"
            df_eval = train_df_baseline
            label_col = "decision_score"
            text_col = "text_for_model"
            mt_filter = None
        else:
            mt_name = target.replace("method_", "")
            # Mapping correction for Model 1 naming vs Dataset naming
            if mt_name == "case_study":
                clf_path = model_dir_tgml / "method_case_studies.joblib"
                mt_filter = "case_studies"
            else:
                clf_path = model_dir_tgml / f"{target}.joblib"
                mt_filter = mt_name
                
            if not clf_path.exists():
                clf_path = ROOT / "models" / f"{target}.joblib"
            
            df_eval = train_df_baseline[train_df_baseline["method_type"] == mt_filter]
            label_col = "method_score"
            text_col = "text_for_model"

        if not clf_path.exists() or len(df_eval) == 0:
            print(f"\n[ {target} ] - Skipping (model or data missing)")
            continue

        print(f"\n[ {target} ] ({len(df_eval)} rows)")
        clf = joblib.load(clf_path)
        X_train = tfidf.transform(df_eval[text_col].fillna(""))
        y_true = df_eval[label_col].values
        
        mask = ~np.isnan(y_true)
        if not mask.any():
            print("  No non-NaN targets.")
            continue
            
        y_pred = clf.predict(X_train[mask])
        y_true_str = [f"{float(v):.1f}" for v in y_true[mask]]
        y_pred_str = [f"{float(v):.1f}" for v in y_pred]
        
        print(classification_report(y_true_str, y_pred_str, labels=labels, zero_division=0))

    # ── Evaluate Model 3 (Transformer) ──────────────────────────────
    print("\n" + "="*60)
    print("  MODEL 3 (Transformer) - TRAINING PERFORMANCE")
    print("="*60)
    
    with open(ROOT / "configs" / "model_3.yaml") as f:
        cfg = yaml.safe_load(f)
        
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    model = CBMModel(cfg).to(device)
    model.load_state_dict(torch.load(ROOT / "models" / "model3_best.pt", map_location=device))
    model.eval()
    
    tokenizer = AutoTokenizer.from_pretrained(cfg['model']['base_encoder'])
    
    label_map_rev = {0: "0.0", 1: "0.5", 2: "1.0"}
    all_results = {t: {"preds": [], "targets": []} for t in targets}
    
    texts = train_df_model3["full_text"].values
    
    # Model 3 targets in order defined in 04_model3_train.py
    # Head 0: decision, 1: method_rct, 2: method_prepost, 3: method_case_study, 
    # 4: method_expert_qual, 5: method_expert_secondary, 6: method_gut
    
    batch_size = 16
    with torch.no_grad():
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i+batch_size]
            inputs = tokenizer(batch_texts.tolist(), padding=True, truncation=True, max_length=512, return_tensors="pt").to(device)
            _, f_logits_list = model(inputs["input_ids"], inputs["attention_mask"])
            
            for head_idx, target in enumerate(targets):
                preds = torch.argmax(f_logits_list[head_idx], dim=1).cpu().numpy()
                gt_values = train_df_model3.iloc[i:i+batch_size][target].values
                
                for p, t in zip(preds, gt_values):
                    if not np.isnan(t):
                        all_results[target]["preds"].append(label_map_rev[p])
                        all_results[target]["targets"].append(f"{float(t):.1f}")

    for target in targets:
        print(f"\n[ {target} ] ({len(all_results[target]['targets'])} rows)")
        if len(all_results[target]["targets"]) == 0:
            print("  No non-NaN targets.")
            continue
        print(classification_report(all_results[target]["targets"], all_results[target]["preds"], labels=labels, zero_division=0))

if __name__ == "__main__":
    main()
