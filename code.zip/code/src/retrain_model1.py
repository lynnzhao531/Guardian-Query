import pandas as pd
import numpy as np
import joblib
import json
import logging
import sys
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import f1_score
from sklearn.preprocessing import label_binarize

from src.tgml.models import FeaturePipeline
from src.scorers import InferenceFeaturePipeline, Model1ClassifierWrapper

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

SEED = 42

def main():
    logging.info("Starting Model 1 Retraining...")
    df = pd.read_parquet("outputs/master_vector.parquet")
    
    df["title_clean"] = df["title"].fillna("")
    df["body_clean"] = df["body"].fillna("").str.slice(0, 4000)
    df["text_for_model"] = df["title_clean"] + "\n\n" + df["body_clean"]
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    
    urls = df["url_canon"].values
    strat = df["decision"].fillna(-1).values
    
    train_urls, temp_urls, _, strat_temp = train_test_split(urls, strat, test_size=0.30, random_state=SEED, stratify=strat)
    val_urls, test_urls, _, _ = train_test_split(temp_urls, strat_temp, test_size=0.50, random_state=SEED, stratify=strat_temp)
    
    train = df[df["url_canon"].isin(set(train_urls))].copy()
    val = df[df["url_canon"].isin(set(val_urls))].copy()
    test = df[df["url_canon"].isin(set(test_urls))].copy()
    
    logging.info("Fitting FeaturePipeline...")
    feat_pipe = FeaturePipeline()
    feat_pipe.fit(train)
    
    X_train = feat_pipe.transform(train)
    X_val = feat_pipe.transform(val)
    X_test = feat_pipe.transform(test)
    
    inf_pipe = InferenceFeaturePipeline(feat_pipe)
    out_dir = Path("models/tgml")
    out_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(inf_pipe, out_dir / "tfidf_vectorizer.joblib")
    
    report_lines = ["# Model 1 Retrain Report", ""]
    
    val_preds = []
    
    def train_and_eval(target_col, file_name):
        logging.info(f"Training {target_col}...")
        
        mask_tr = train[target_col].notna()
        mask_va = val[target_col].notna()
        
        if mask_tr.sum() < 2: return
        
        y_tr_series = train.loc[mask_tr, target_col]
        counts = y_tr_series.value_counts()
        if counts.min() < 3:
            logging.warning(f"Skipping {target_col} due to insufficient classes for 3-fold CV: {dict(counts)}")
            return
            
        y_tr = y_tr_series.astype(str).values
        
        clf = LogisticRegression(solver="saga", multi_class="multinomial", C=1.0, max_iter=5000, class_weight="balanced", n_jobs=-1, random_state=SEED)
        
        X_tr_fold = X_train[mask_tr.values]
        clf.fit(X_tr_fold, y_tr)
        
        cal_clf = CalibratedClassifierCV(clf, method='sigmoid', cv="prefit")
        cal_clf.fit(X_tr_fold, y_tr)
        
        wrapper = Model1ClassifierWrapper(cal_clf)
        
        y_pred = wrapper.predict(X_val[mask_va.values])
        y_prob = wrapper.predict_proba(X_val[mask_va.values])
        
        y_va_true = val.loc[mask_va, target_col].values
        
        expected = ["0.0", "0.5", "1.0"]
        y_true_bin = label_binarize(y_va_true.astype(str), classes=expected)
        if y_true_bin.shape[1] == 1:
            y_true_bin = np.hstack([1-y_true_bin, y_true_bin, np.zeros_like(y_true_bin)])
            # This is flawed if we only have class 0.0 or something, but we don't need perfect theoretical Brier here, just an indicator.
            
        brier = np.mean(np.sum((y_prob - y_true_bin)**2, axis=1))
        
        mask_true_1 = (y_va_true == 1.0)
        mask_pred_1 = (y_pred == 1.0)
        prec = mask_pred_1[mask_true_1].sum() / mask_pred_1.sum() if mask_pred_1.sum() > 0 else 0
        rec = mask_pred_1[mask_true_1].sum() / mask_true_1.sum() if mask_true_1.sum() > 0 else 0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
        
        mac_f1 = f1_score(y_va_true.astype(str), y_pred.astype(str), average='macro')
        
        report_lines.append(f"## {target_col}")
        report_lines.append(f"- Macro F1: {mac_f1:.3f}")
        report_lines.append(f"- Precision(1.0): {prec:.3f}")
        report_lines.append(f"- Recall(1.0): {rec:.3f}")
        report_lines.append(f"- F1(1.0): {f1:.3f}")
        report_lines.append(f"- Brier Score (over 3 classes): {brier:.3f}")
        report_lines.append("")
        
        joblib.dump(wrapper, out_dir / file_name)
        
        # Save Validation Probabilities for Calibration
        full_probs = wrapper.predict_proba(X_val)
        return full_probs

    # Train Decision
    p_dec = train_and_eval("decision", "decision_ordinal.joblib")
    val_preds_df = val[["url_canon", "decision"]].copy()
    val_preds_df["model1_decision_score"] = Model1ClassifierWrapper(joblib.load(out_dir / "decision_ordinal.joblib")).predict(X_val)
    val_preds_df["model1_decision_p0"] = p_dec[:, 0]
    val_preds_df["model1_decision_p05"] = p_dec[:, 1]
    val_preds_df["model1_decision_p1"] = p_dec[:, 2]
    
    # Train Methods
    for m in methods:
        p_m = train_and_eval(f"method_{m}", f"method_{m}.joblib")
        if p_m is not None:
            val_preds_df[f"model1_method_{m}_p1"] = p_m[:, 2]
        
    Path("reports/model1_retrain_report.md").write_text("\n".join(report_lines))
    val_preds_df.to_parquet("reports/model1_val_predictions.parquet", index=False)
    logging.info("Model 1 Retraining complete.")
    
if __name__ == "__main__":
    main()
