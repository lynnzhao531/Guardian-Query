import json
from pathlib import Path

ROOT = Path("/Users/Mycroft/Desktop/LLM reasoning")

def audit_shard(dataset_path: Path):
    if not dataset_path.exists():
        return None
    
    total_lines = 0
    valid_schema = 0
    identical_pairs = 0
    failures = []
    
    with open(dataset_path, "r") as f:
        for line in f:
            total_lines += 1
            try:
                row = json.loads(line)
                
                # Verify keys
                msgs = row.get("messages", [])
                pref = row.get("preferred_output", [])
                non_pref = row.get("non_preferred_output", [])
                
                assert len(pref) == 1
                assert len(non_pref) == 1
                
                pref_content = pref[0]["content"]
                non_pref_content = non_pref[0]["content"]
                
                if pref_content == non_pref_content:
                    identical_pairs += 1
                
                # Validate schema on pref
                pref_json = json.loads(pref_content)
                assert all(k in pref_json for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"])
                for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
                    assert all(sub_k in pref_json[k] for sub_k in ["score", "p0", "p05", "p1"])

                # Validate schema on non_pref
                non_pref_json = json.loads(non_pref_content)
                assert all(k in non_pref_json for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"])
                for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
                    assert all(sub_k in non_pref_json[k] for sub_k in ["score", "p0", "p05", "p1"])
                    
                valid_schema += 1
                
            except Exception as e:
                if len(failures) < 5:
                    failures.append({"line": total_lines, "error": str(e)})

    return {
        "total_lines": total_lines,
        "valid_schema": valid_schema,
        "identical_pairs": identical_pairs,
        "failures": failures
    }

def main():
    train_path = ROOT / "fine_tune_data/dpo_train_shard_001_clean.jsonl"
    val_path = ROOT / "fine_tune_data/dpo_val_clean.jsonl"
    report_path = ROOT / "reports/dpo_shard_audit_clean.md"
    
    train_stats = audit_shard(train_path)
    val_stats = audit_shard(val_path)

    with open(report_path, "w") as f:
        f.write("# DPO Shard Audit (Pre-Cleaning)\n\n")
        
        if train_stats:
            f.write("## Training Shard\n")
            f.write(f"- **Total Lines**: {train_stats['total_lines']}\n")
            if train_stats['total_lines'] > 0:
                f.write(f"- **Schema Valid**: {train_stats['valid_schema']} ({(train_stats['valid_schema']/train_stats['total_lines'])*100:.1f}%)\n")
                f.write(f"- **Identical Pairs**: {train_stats['identical_pairs']} ({(train_stats['identical_pairs']/train_stats['total_lines'])*100:.1f}%)\n")
            else:
                f.write("- **Schema Valid**: 0 (0.0%)\n")
                f.write("- **Identical Pairs**: 0 (0.0%)\n")
            
            if train_stats['failures']:
                f.write("\n### Top 5 Failures\n")
                for fail in train_stats['failures']:
                    f.write(f"- Line {fail['line']}: `{fail['error']}`\n")

        if val_stats:
            f.write("\n## Validation Shard\n")
            f.write(f"- **Total Lines**: {val_stats['total_lines']}\n")
            if val_stats['total_lines'] > 0:
                f.write(f"- **Schema Valid**: {val_stats['valid_schema']} ({(val_stats['valid_schema']/val_stats['total_lines'])*100:.1f}%)\n")
                f.write(f"- **Identical Pairs**: {val_stats['identical_pairs']} ({(val_stats['identical_pairs']/val_stats['total_lines'])*100:.1f}%)\n")
            else:
                f.write("- **Schema Valid**: 0 (0.0%)\n")
                f.write("- **Identical Pairs**: 0 (0.0%)\n")
            
            if val_stats['failures']:
                f.write("\n### Top 5 Failures\n")
                for fail in val_stats['failures']:
                    f.write(f"- Line {fail['line']}: `{fail['error']}`\n")
    
    print(f"Audit report written to {report_path}")

if __name__ == "__main__":
    main()
