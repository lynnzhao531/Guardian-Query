#!/usr/bin/env python3
"""
Step 6: Stage II Fine-tuning — SFT job launcher with cost guard.
Submits first SFT shard to OpenAI fine-tuning API.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import yaml
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()

    from openai import OpenAI
    client = OpenAI()

    # ── Determine shard to use ────────────────────────────────────────
    sft_shards = state.get("sft_shards", [])
    if not sft_shards:
        print("ERROR: No SFT shards found in STATE.json. Run Step 4 first.")
        sys.exit(1)

    shard = sft_shards[0]
    shard_path = shard["path"]
    estimated_cost = shard.get("estimated_cost_usd", 10.0)
    print(f"SFT shard: {shard_path}")
    print(f"  Lines: {shard['lines']}, Tokens: {shard['tokens']}")
    print(f"  Estimated cost: ${estimated_cost:.2f}")

    # ── Budget check ──────────────────────────────────────────────────
    cap = cfg["budget"]["total_cap_usd"]
    already_spent = ledger["total_spent_usd"]
    reserved = ledger["outstanding_reserved_budget_usd"]
    remaining = cap - already_spent - reserved
    print(f"\nBudget: spent=${already_spent:.2f}, reserved=${reserved:.2f}, "
          f"remaining=${remaining:.2f}")

    if estimated_cost > remaining:
        print(f"\n⚠ BUDGET EXCEEDED: shard costs ~${estimated_cost:.2f} "
              f"but only ${remaining:.2f} remains.")
        print("STOPPING. Ask user before proceeding.")
        sys.exit(1)

    # Reserve budget
    ledger["outstanding_reserved_budget_usd"] = round(reserved + estimated_cost, 2)
    ledger["remaining_budget_usd"] = round(cap - already_spent - ledger["outstanding_reserved_budget_usd"], 2)
    save_ledger(ledger)

    # ── Upload training file ──────────────────────────────────────────
    print("\nUploading training file...")
    with open(shard_path, "rb") as f:
        train_file = client.files.create(file=f, purpose="fine-tune")
    print(f"  Training file ID: {train_file.id}")

    # Upload validation file
    val_path = ROOT / "fine_tune_data" / "sft_val.jsonl"
    val_file_id = None
    if val_path.exists():
        print("Uploading validation file...")
        with open(val_path, "rb") as f:
            val_file = client.files.create(file=f, purpose="fine-tune")
        val_file_id = val_file.id
        print(f"  Validation file ID: {val_file_id}")

    # ── Start fine-tuning job ─────────────────────────────────────────
    print(f"\nStarting SFT job on {cfg['fixed_models']['generator_G']}...")

    ft_params = {
        "training_file": train_file.id,
        "model": cfg["fixed_models"]["generator_G"],
        "hyperparameters": {"n_epochs": 3},
    }
    if val_file_id:
        ft_params["validation_file"] = val_file_id

    job = client.fine_tuning.jobs.create(**ft_params)
    print(f"  Job ID: {job.id}")
    print(f"  Status: {job.status}")

    # ── Update state ──────────────────────────────────────────────────
    state["latest_sft_job_id"] = job.id
    if "step_6_sft" not in state["steps_completed"]:
        state["steps_completed"].append("step_6_sft")
    state["current_step"] = "step_6_sft_submitted"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  SFT JOB SUBMITTED")
    print(f"  Job ID: {job.id}")
    print(f"  Monitor with: python src/08_monitor_finetune.py")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
