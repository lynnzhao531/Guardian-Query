import json
import logging
import time
import os
from typing import Optional, Dict, Any, List
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# Assumes OpenAI client is required.
# In a real environment, you'd likely import a configured client or initialize here.
import openai
from pydantic import BaseModel, ValidationError

class LLMResponse(BaseModel):
    decision: float
    method_rct: float
    method_prepost: float
    method_case_study: float
    method_expert_qual: float
    method_expert_secondary: float
    method_gut: float
    probabilities: Dict[str, List[float]]  # flattened probs for simplicity or structured

# We use raw JSON schema for stricter control if needed, or Pydantic for parsing
SCORE_SCHEMA = {
    "type": "object",
    "properties": {
        "decision": {
            "type": "object",
            "properties": {
                "score": {"type": "number", "enum": [0, 0.5, 1]},
                "p0": {"type": "number"},
                "p05": {"type": "number"},
                "p1": {"type": "number"}
            },
            "required": ["score", "p0", "p05", "p1"],
            "additionalProperties": False
        },
        "method_rct": {
           "type": "object", 
           "properties": {
                "score": {"type": "number", "enum": [0, 0.5, 1]},
                "p0": {"type": "number"},
                "p05": {"type": "number"},
                "p1": {"type": "number"}
           },
           "required": ["score", "p0", "p05", "p1"],
           "additionalProperties": False
        },
        # Repeating for other methods for brevity in schema def...
        # In implementation we will construct this dynamically or be verbose.
        "method_prepost": { "type": "object", "properties": {"score": {"type": "number", "enum": [0,0.5,1]}, "p0":{"type":"number"}, "p05":{"type":"number"}, "p1":{"type":"number"}}, "required": ["score", "p0", "p05", "p1"], "additionalProperties": False},
        "method_case_study": { "type": "object", "properties": {"score": {"type": "number", "enum": [0,0.5,1]}, "p0":{"type":"number"}, "p05":{"type":"number"}, "p1":{"type":"number"}}, "required": ["score", "p0", "p05", "p1"], "additionalProperties": False},
        "method_expert_qual": { "type": "object", "properties": {"score": {"type": "number", "enum": [0,0.5,1]}, "p0":{"type":"number"}, "p05":{"type":"number"}, "p1":{"type":"number"}}, "required": ["score", "p0", "p05", "p1"], "additionalProperties": False},
        "method_expert_secondary": { "type": "object", "properties": {"score": {"type": "number", "enum": [0,0.5,1]}, "p0":{"type":"number"}, "p05":{"type":"number"}, "p1":{"type":"number"}}, "required": ["score", "p0", "p05", "p1"], "additionalProperties": False},
        "method_gut": { "type": "object", "properties": {"score": {"type": "number", "enum": [0,0.5,1]}, "p0":{"type":"number"}, "p05":{"type":"number"}, "p1":{"type":"number"}}, "required": ["score", "p0", "p05", "p1"], "additionalProperties": False},
    },
    "required": [
        "decision", "method_rct", "method_prepost", "method_case_study", 
        "method_expert_qual", "method_expert_secondary", "method_gut"
    ],
    "additionalProperties": False
}


def call_llm_scoring(
    model_name: str,
    article_text: str,
    max_output_tokens: int = 500,
    strict_schema: bool = True,
    api_key: str = None,
    mock_response: bool = False,
    system_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    Safely calls LLM with strict JSON schema.
    Returns dictionary with:
      - success: bool
      - data: parsed dict or None
      - error: str or None
      - raw_text: str
      - finish_reason: str
      - usage: dict
    """
    if mock_response:
        # Return valid dummy data for dry run
        return {
            "success": True,
            "data": {
                "decision": {"score": 1, "p0": 0.05, "p05": 0.05, "p1": 0.9},
                "method_rct": {"score": 0.5, "p0": 0.2, "p05": 0.7, "p1": 0.1},
                "method_prepost": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
                "method_case_study": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
                "method_expert_qual": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
                "method_expert_secondary": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
                "method_gut": {"score": 0, "p0": 0.9, "p05": 0.05, "p1": 0.05},
            },
            "error": None,
            "raw_text": "MOCKED_RESPONSE_FOR_DRY_RUN",
            "finish_reason": "stop",
            "usage": {"completion_tokens": 100, "prompt_tokens": 100}
        }

    if not api_key:
        api_key = os.getenv("OPENAI_API_KEY")

    client = openai.OpenAI(api_key=api_key)
    
    messages = [
        {"role": "system", "content": system_prompt if system_prompt else "You are a policy relevance scorer. Analyze the article and return valid JSON scores."},
        {"role": "user", "content": f"Article Text:\n{article_text[:15000]}"} # truncation safety
    ]
    
    # ── CONSERVATIVE ADDENDUM ──────────────────────────────────────────
    addendum = [
        "\nCONSERVATIVE SCORING RULES (NON-NEGOTIABLE):",
        "- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.",
        "- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').",
        "- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).",
        "- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present."
    ]
    
    # Validated Hypotheses Snippet
    hyp_path = Path(__file__).resolve().parent.parent / "knowledge_base/hypotheses/hypotheses_selected.md"
    if hyp_path.exists():
        with open(hyp_path, "r") as f:
            lines = f.readlines()[:25]
            addendum.append("\nVALIDATED HYPOTHESES (USE AS GUIDANCE):")
            addendum.extend([l.strip() for l in lines])
            
    messages[0]["content"] += "\n" + "\n".join(addendum)
    
    try:
        response_format = {"type": "json_schema", "json_schema": {
            "name": "scoring_output",
            "schema": SCORE_SCHEMA,
            "strict": True
        }} if strict_schema else {"type": "json_object"}

        completion = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=0,
            max_tokens=max_output_tokens,
            response_format=response_format
        )
        
        raw_text = completion.choices[0].message.content
        finish_reason = completion.choices[0].finish_reason
        usage = completion.usage.model_dump() if completion.usage else {}
        
        # Parse JSON
        parsed = json.loads(raw_text)
        
        return {
            "success": True,
            "data": parsed,
            "error": None,
            "raw_text": raw_text,
            "finish_reason": finish_reason,
            "usage": usage
        }

    except Exception as e:
        # Catch parse errors, API errors, etc.
        return {
            "success": False,
            "data": None,
            "error": f"{str(e)} | RAW: {raw_text}",
            "raw_text": raw_text,
            "finish_reason": "error",
            "usage": {}
        }
