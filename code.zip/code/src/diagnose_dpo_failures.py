import pandas as pd
import json
import os
from pathlib import Path
import argparse

BASE_DIR = Path(__file__).resolve().parent.parent

def diagnose(round_min=None, round_max=None, contiguous_window=None):
    query_log_path = BASE_DIR / "outputs/query_log.csv"
    if not query_log_path.exists():
        print("Error: query_log.csv not found")
        return

    df = pd.read_csv(query_log_path)
    
    # Chronological sort
    df = df.sort_values(by="timestamp_utc_iso")
    
    # Filter by round range
    if round_min is not None:
        df = df[df['round_id'] >= round_min]
    if round_max is not None:
        df = df[df['round_id'] <= round_max]
    
    # Contiguous window filter
    if contiguous_window:
        # User defined window, e.g. 32-41
        try:
            low, high = map(int, contiguous_window.split("-"))
            df = df[(df['round_id'] >= low) & (df['round_id'] <= high)]
        except:
            print(f"Warning: Invalid contiguous_window format '{contiguous_window}'. Expected 'MIN-MAX'.")

    # Only show last 10 rounds from the resulting set
    df_recent = df.tail(10)
    
    report = []
    report.append("# DPO Diagnostics Report")
    report.append(f"\nLynn. Analyzing {len(df_recent)} rounds for DPO performance (Chronological Order).")
    
    table_rows = []
    for _, row in df_recent.iterrows():
        rid = row['round_id']
        att = row.get('dpo_attempted_count', 0)
        val = row.get('dpo_valid_count', 0)
        cb = "YES" if row.get('dpo_circuit_breaker_triggered') == 1 else "no"
        rate = (val / att) if att > 0 else 0
        table_rows.append(f"| {rid:8} | {att:11} | {val:7} | {rate:12.1f} | {cb:14} |")
        
    report.append("\n## DPO Performance Summary")
    report.append("\n|   Round |   Attempted |   Valid |   Valid Rate | CB Triggered   |")
    report.append("|--------:|------------:|--------:|-------------:|:---------------|")
    for tr in table_rows:
        report.append(tr)

    report.append("\n## Failure Reason Breakdown")
    for _, row in df_recent.iterrows():
        rid = row['round_id']
        reasons = row.get('dpo_fail_reason_counts_json', "{}")
        if reasons != "{}":
            report.append(f"\n### Round {rid}")
            report.append(f"```json\n{reasons}\n```")
    
    # Sample failure logs from audit files if available
    report.append("\n**Failure Samples (Last 3):**")
    failures = []
    for rid in df_recent['round_id'].unique():
        fail_log = BASE_DIR / f"audits/round_{rid}/dpo_failures.jsonl"
        if fail_log.exists():
            with open(fail_log, 'r') as f:
                for line in f:
                    try:
                        failures.append(json.loads(line))
                    except:
                        pass
    
    for f in failures[-3:]:
        url = f.get('url_canon', 'unknown')
        reason = f.get('reason', 'unknown')
        report.append(f"- `{url[:30]}...`: {reason}")

    report.append("\n\n## LLM Mode Distribution")
    for _, row in df_recent.iterrows():
        rid = row['round_id']
        modes = row.get('llm_mode_used_counts_json', "{}")
        if modes != "{}":
            report.append(f"\n### Round {rid}")
            report.append(f"```json\n{modes}\n```")

    report_path = BASE_DIR / "reports/dpo_diagnostics.md"
    os.makedirs(report_path.parent, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(report))
    print(f"Lynn. DPO diagnostics report written to {report_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--round_min", type=int)
    parser.add_argument("--round_max", type=int)
    parser.add_argument("--contiguous_window", type=str, help="Format: MIN-MAX")
    args = parser.parse_args()
    
    diagnose(round_min=args.round_min, round_max=args.round_max, contiguous_window=args.contiguous_window)
