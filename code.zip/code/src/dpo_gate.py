"""
src/dpo_gate.py  —  DPO evaluation gate.

Every chunk_size rounds, evaluate DPO candidates A and B.
Select first candidate that passes success criteria.

Success criteria (ALL must pass):
  1. load + smoke_test: run on all 12 eval items, no exceptions, valid JSON parse.
  2. trap_pass_count == 0  (hard: model must NOT classify traps as relevant).
  3. prototype_pass_count >= max(2, baseline_prototype_pass_count).
  4. decision_confidence_mean >= 0.55 on prototype items.

Eval set: 12 fixed items (6 prototypes + 6 traps).
"""

import json
import logging
import datetime
import os
from pathlib import Path
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent

# ────────────────────────────────────────────────────────────────────────────────
# Fixed 12-item evaluation set
# ────────────────────────────────────────────────────────────────────────────────

EVAL_ITEMS = [
    # ── PROTOTYPES (should be classified as relevant) ──────────────────────────
    {
        "id": "proto_rct",
        "kind": "prototype",
        "method": "rct",
        "body_text": (
            "A randomised controlled trial in three NHS trusts evaluated the "
            "effectiveness of a new nurse-led triage protocol. The intervention "
            "group received the protocol for six months; the control group received "
            "standard care. The study found a 22% reduction in A&E wait times "
            "(p<0.01) among the intervention group. The government has announced it "
            "will roll out the protocol nationally based on these findings."
        ),
    },
    {
        "id": "proto_prepost",
        "kind": "prototype",
        "method": "prepost",
        "body_text": (
            "Before Cornwall Council introduced a universal basic income pilot for "
            "500 residents, average monthly rent arrears stood at £340. After "
            "12 months of the scheme, arrears fell to £190 per household. "
            "Housing officials say the scheme will be widened to 5,000 households "
            "after the pre-post comparison showed consistent improvement."
        ),
    },
    {
        "id": "proto_case_study",
        "kind": "prototype",
        "method": "case_study",
        "body_text": (
            "A detailed case study of Manchester's rough sleeping reduction programme "
            "found that housing-first placements cut reoffending by 41% over three "
            "years. Researchers from the University of Salford tracked 300 individuals. "
            "Ministers cited the study when announcing plans to replicate the model "
            "across five other cities."
        ),
    },
    {
        "id": "proto_expert_qual",
        "kind": "prototype",
        "method": "expert_qual",
        "body_text": (
            "An independent review led by Professor Sarah Chen examined the evidence "
            "base for minimum unit pricing for alcohol in Scotland. The review panel "
            "conducted structured interviews with 40 health economists and clinicians. "
            "Its recommendations, accepted by ministers, will now inform new policy "
            "for England and Wales."
        ),
    },
    {
        "id": "proto_expert_secondary",
        "kind": "prototype",
        "method": "expert_secondary",
        "body_text": (
            "A meta-analysis of 28 school breakfast programme evaluations across OECD "
            "countries found a pooled effect size of 0.32 SD on numeracy scores. "
            "The Department for Education commissioned the analysis to inform its "
            "decision on whether to fund universal free school breakfasts from 2027."
        ),
    },
    {
        "id": "proto_gut",
        "kind": "prototype",
        "method": "gut",
        "body_text": (
            "The health secretary announced yesterday that vaping products for under-18s "
            "would be banned immediately, stating he trusted his instinct that the "
            "evidence of harm was sufficient, despite admitting no formal evaluation "
            "had been commissioned. The policy will take effect next month with "
            "retailers required to remove products from shelves."
        ),
    },
    # ── TRAPS (should NOT be classified as relevant) ──────────────────────────
    {
        "id": "trap_word",
        "kind": "trap",
        "trap_type": "word_trap",
        "body_text": (
            "Scientists have evaluated the randomised orbit of asteroids in a new "
            "controlled experiment. The study, conducted by NASA, found evidence of "
            "planetary formation processes. No policy recommendations were made and "
            "the research has no direct government application."
        ),
    },
    {
        "id": "trap_science",
        "kind": "trap",
        "trap_type": "science_trap",
        "body_text": (
            "A clinical trial of a new antibiotic showed a 78% cure rate for MRSA "
            "in a double-blind randomised controlled trial of 400 patients. The drug "
            "was developed by a private biotech company and is not yet approved for "
            "NHS use. No government policy decision has been announced."
        ),
    },
    {
        "id": "trap_policy_no_eval",
        "kind": "trap",
        "trap_type": "policy_no_eval",
        "body_text": (
            "The prime minister today announced a new £2 billion infrastructure package "
            "to build 50 new schools. He described the scheme as a once-in-a-generation "
            "investment. No evaluation framework was mentioned and no evidence from "
            "prior pilots was cited."
        ),
    },
    {
        "id": "trap_eval_no_choice",
        "kind": "trap",
        "trap_type": "eval_no_choice",
        "body_text": (
            "Researchers at UCL published an analysis comparing two types of exercise "
            "for managing depression. The randomised study found both yoga and running "
            "reduced depression scores by similar margins. The paper concluded further "
            "research was needed. No policy decision was referenced."
        ),
    },
    {
        "id": "trap_comment",
        "kind": "trap",
        "trap_type": "commentary",
        "body_text": (
            "Opinion: The government's plan to trial four-day weeks for civil servants "
            "is a terrible idea. Based on my experience working in the public sector, "
            "productivity will plummet and taxpayers will foot the bill for a failed "
            "ideological experiment. Ministers should reverse course immediately."
        ),
    },
    {
        "id": "trap_liveblog",
        "kind": "trap",
        "trap_type": "liveblog",
        "body_text": (
            "LIVE: Parliament debates proposed NHS reforms — as it happened. "
            "12:04 — MPs begin debate. 12:30 — Minister of Health speaks on "
            "pilot programme data. 13:00 — Vote delayed. 14:15 — Debate continues. "
            "We will continue to update this page throughout the afternoon."
        ),
    },
]

PROTOTYPE_ITEMS = [x for x in EVAL_ITEMS if x["kind"] == "prototype"]
TRAP_ITEMS = [x for x in EVAL_ITEMS if x["kind"] == "trap"]

# Thresholds
MIN_PROTOTYPE_PASS = 2          # absolute floor
MIN_DECISION_CONFIDENCE = 0.55  # mean p1 across prototypes
TRAP_PASS_ALLOWED = 0           # hard: must be 0


# ────────────────────────────────────────────────────────────────────────────────
# Core gate logic
# ────────────────────────────────────────────────────────────────────────────────

def _score_item(model_name: str, text: str, api_key: str) -> Dict[str, Any]:
    """Call SFT-style scoring on a single text. Returns parsed JSON or raises."""
    from src.safe_llm_judge import call_llm_scoring
    result = call_llm_scoring(
        model_name=model_name,
        article_text=text,
        max_output_tokens=400,
        strict_schema=True,
        api_key=api_key,
        mock_response=False,
    )
    if not result.get("success"):
        raise RuntimeError(f"LLM call failed: {result.get('error', 'unknown')}")
    return result["data"]


def _item_passes_as_relevant(data: Dict[str, Any]) -> bool:
    """Returns True if the model classified item as high-relevance (decision_score==1, p1>=0.55)."""
    decision = data.get("decision", {})
    return decision.get("score", 0) == 1 and decision.get("p1", 0) >= 0.55


def _evaluate_candidate(
    model_name: str,
    api_key: str,
    chunk_id: int,
    baseline_prototype_pass: int,
) -> Dict[str, Any]:
    """
    Runs 12-item eval on model_name.
    Returns metrics dict with 'pass' key.
    """
    proto_results = []
    trap_results = []
    errors = []

    for item in PROTOTYPE_ITEMS:
        try:
            data = _score_item(model_name, item["body_text"], api_key)
            passed = _item_passes_as_relevant(data)
            p1 = data.get("decision", {}).get("p1", 0.0)
            proto_results.append({"id": item["id"], "passed": passed, "p1": p1, "data": data})
        except Exception as e:
            errors.append({"id": item["id"], "error": str(e)})
            proto_results.append({"id": item["id"], "passed": False, "p1": 0.0, "error": str(e)})

    for item in TRAP_ITEMS:
        try:
            data = _score_item(model_name, item["body_text"], api_key)
            passed = _item_passes_as_relevant(data)
            p1 = data.get("decision", {}).get("p1", 0.0)
            trap_results.append({"id": item["id"], "passed": passed, "p1": p1, "data": data})
        except Exception as e:
            errors.append({"id": item["id"], "error": str(e)})
            trap_results.append({"id": item["id"], "passed": False, "p1": 0.0, "error": str(e)})

    prototype_pass_count = sum(1 for r in proto_results if r["passed"])
    trap_pass_count = sum(1 for r in trap_results if r["passed"])
    confidence_scores = [r["p1"] for r in proto_results]
    decision_confidence_mean = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0.0

    required_proto = max(MIN_PROTOTYPE_PASS, baseline_prototype_pass)

    crit_load_ok = len(errors) == 0
    crit_trap = trap_pass_count == TRAP_PASS_ALLOWED
    crit_proto = prototype_pass_count >= required_proto
    crit_conf = decision_confidence_mean >= MIN_DECISION_CONFIDENCE

    gate_pass = crit_load_ok and crit_trap and crit_proto and crit_conf

    return {
        "model_name": model_name,
        "chunk_id": chunk_id,
        "prototype_pass_count": prototype_pass_count,
        "trap_pass_count": trap_pass_count,
        "decision_confidence_mean": decision_confidence_mean,
        "required_proto_pass": required_proto,
        "errors": errors,
        "crit_load_ok": crit_load_ok,
        "crit_trap": crit_trap,
        "crit_proto": crit_proto,
        "crit_conf": crit_conf,
        "gate_pass": gate_pass,
        "proto_results": proto_results,
        "trap_results": trap_results,
    }


def run_dpo_gate(
    candidates: List[str],
    chunk_id: int,
    run_root: Optional[Path] = None,
    baseline_prototype_pass: int = 0,
) -> Optional[str]:
    """
    Evaluate DPO candidates in order. Return first passing model_id, or None.
    Writes audit JSON to audits/dpo/dpo_gate_chunk_<k>.json.

    On success, also writes LLM_FINAL_OVERRIDE.json to working/project_state/.
    """
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        logger.error("OPENAI_API_KEY not set. DPO gate skipped.")
        return None

    gate_audit = {
        "chunk_id": chunk_id,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "candidates": candidates,
        "baseline_prototype_pass": baseline_prototype_pass,
        "results": [],
        "selected": None,
    }

    selected_model = None

    for candidate in candidates:
        if not candidate or candidate.strip() in ("dpo_a", "dpo_b", "none", ""):
            logger.warning(f"DPO gate: candidate '{candidate}' is a placeholder — skipping.")
            gate_audit["results"].append({
                "model_name": candidate,
                "gate_pass": False,
                "reason": "placeholder_model_id_skipped",
            })
            continue

        logger.info(f"DPO gate: evaluating candidate '{candidate}' (chunk {chunk_id})")
        try:
            metrics = _evaluate_candidate(candidate, api_key, chunk_id, baseline_prototype_pass)
        except Exception as e:
            logger.error(f"DPO gate: exception during evaluate of '{candidate}': {e}")
            metrics = {
                "model_name": candidate,
                "gate_pass": False,
                "errors": [str(e)],
                "reason": "exception_during_eval",
            }

        gate_audit["results"].append(metrics)

        if metrics.get("gate_pass"):
            selected_model = candidate
            gate_audit["selected"] = candidate
            logger.info(f"DPO gate: SELECTED '{candidate}' at chunk {chunk_id}")
            break
        else:
            logger.info(f"DPO gate: '{candidate}' did NOT pass at chunk {chunk_id}")

    # Write gate audit
    if run_root is not None:
        audit_dir = Path(run_root) / "audits" / "dpo"
    else:
        audit_dir = BASE_DIR / "audits" / "dpo"
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit_path = audit_dir / f"dpo_gate_chunk_{chunk_id}.json"
    with open(audit_path, "w") as f:
        json.dump(gate_audit, f, indent=2)
    logger.info(f"DPO gate audit written: {audit_path}")

    # Write override if selected
    if selected_model and run_root:
        override = {
            "active_llm_final": selected_model,
            "selected_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "reason": "dpo_gate_pass",
            "chunk_id": chunk_id,
            "metrics": {
                k: v for k, v in gate_audit["results"][-1].items()
                if k not in ("proto_results", "trap_results", "data")
            },
        }
        override_path = Path(run_root) / "working" / "project_state" / "LLM_FINAL_OVERRIDE.json"
        override_path.parent.mkdir(parents=True, exist_ok=True)
        with open(override_path, "w") as f:
            json.dump(override, f, indent=2)
        logger.info(f"LLM_FINAL_OVERRIDE written: {override_path}")

    return selected_model
