import pandas as pd
import numpy as np
import joblib
import json
import logging
import sys
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import f1_score
from sklearn.preprocessing import label_binarize
from sklearn.base import BaseEstimator, TransformerMixin
import torch

from sentence_transformers import SentenceTransformer
from src.tgml.theory_features import TheoryFeaturizer
from src.scorers import Model3FeatureExtractor, Model3ClassifierWrapper

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

SEED = 42

def process_batch(texts, batch_size=32):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(texts, batch_size=batch_size, show_progress_bar=True)
    
    theory_extractor = Model3FeatureExtractor()
    theory_features = theory_extractor.transform(texts)
    
    X = np.hstack([embeddings, theory_features])
    return X

def main():
    logging.info("Starting Model 3 Retraining...")
    df = pd.read_parquet("outputs/master_vector.parquet")
    
    df["title_clean"] = df["title"].fillna("")
    df["body_clean"] = df["body"].fillna("").str.slice(0, 4000)
    df["text_for_model"] = df["title_clean"] + "\n\n" + df["body_clean"]
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    
    urls = df["url_canon"].values
    strat = df["decision"].fillna(-1).values
    
    train_urls, temp_urls, _, strat_temp = train_test_split(urls, strat, test_size=0.30, random_state=SEED, stratify=strat)
    val_urls, test_urls, _, _ = train_test_split(temp_urls, strat_temp, test_size=0.50, random_state=SEED, stratify=strat_temp)
    
    train = df[df["url_canon"].isin(set(train_urls))].copy()
    val = df[df["url_canon"].isin(set(val_urls))].copy()
    test = df[df["url_canon"].isin(set(test_urls))].copy()
    
    logging.info("Extracting features (Embeddings + Theory)...")
    X_train = process_batch(train["text_for_model"].tolist())
    X_val = process_batch(val["text_for_model"].tolist())
    X_test = process_batch(test["text_for_model"].tolist())
    
    out_dir = Path("models/model3")
    out_dir.mkdir(parents=True, exist_ok=True)
    
    report_lines = ["# Model 3 Retrain Report", ""]
    val_preds_df = val[["url_canon", "decision"]].copy()
    models_dict = {}
    
    def train_and_eval(target_col):
        logging.info(f"Training {target_col}...")
        
        mask_tr = train[target_col].notna()
        mask_va = val[target_col].notna()
        
        if mask_tr.sum() < 2: return None, None
        
        y_tr_series = train.loc[mask_tr, target_col]
        counts = y_tr_series.value_counts()
        if counts.min() < 3:
            logging.warning(f"Skipping {target_col} due to insufficient classes for 3-fold CV: {dict(counts)}")
            return None, None
            
        y_tr = y_tr_series.astype(str).values
        
        clf = LogisticRegression(solver="saga", multi_class="multinomial", C=1.0, max_iter=5000, class_weight="balanced", n_jobs=-1, random_state=SEED)
        
        X_tr_fold = X_train[mask_tr.values]
        clf.fit(X_tr_fold, y_tr)
        
        cal_clf = CalibratedClassifierCV(clf, method='sigmoid', cv="prefit")
        cal_clf.fit(X_tr_fold, y_tr)
        
        wrapper = Model3ClassifierWrapper(cal_clf)
        
        y_pred = wrapper.predict(X_val[mask_va.values])
        y_prob = wrapper.predict_proba(X_val[mask_va.values])
        
        y_va_true = val.loc[mask_va, target_col].values
        
        expected = ["0.0", "0.5", "1.0"]
        y_true_bin = label_binarize(y_va_true.astype(str), classes=expected)
        
        brier = np.mean(np.sum((y_prob - y_true_bin)**2, axis=1))
        
        mask_true_1 = (y_va_true == 1.0)
        mask_pred_1 = (y_pred == 1.0)
        prec = mask_pred_1[mask_true_1].sum() / mask_pred_1.sum() if mask_pred_1.sum() > 0 else 0
        rec = mask_pred_1[mask_true_1].sum() / mask_true_1.sum() if mask_true_1.sum() > 0 else 0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
        
        mac_f1 = f1_score(y_va_true.astype(str), y_pred.astype(str), average='macro')
        
        report_lines.append(f"## {target_col}")
        report_lines.append(f"- Macro F1: {mac_f1:.3f}")
        report_lines.append(f"- Precision(1.0): {prec:.3f}")
        report_lines.append(f"- Recall(1.0): {rec:.3f}")
        report_lines.append(f"- F1(1.0): {f1:.3f}")
        report_lines.append(f"- Brier Score (over 3 classes): {brier:.3f}")
        report_lines.append("")
        
        models_dict[target_col] = wrapper
        full_probs = wrapper.predict_proba(X_val)
        return wrapper, full_probs

    p_dec_w, p_dec = train_and_eval("decision")
    if p_dec_w is not None:
        val_preds_df["model3_decision_score"] = p_dec_w.predict(X_val)
        val_preds_df["model3_decision_p0"] = p_dec[:, 0]
        val_preds_df["model3_decision_p05"] = p_dec[:, 1]
        val_preds_df["model3_decision_p1"] = p_dec[:, 2]
    
    p1_cols = []
    for m in methods:
        p_m_w, p_m = train_and_eval(f"method_{m}")
        if p_m is not None:
            col_target = f"model3_method_{m}_p1"
            val_preds_df[col_target] = p_m[:, 2]
            p1_cols.append(col_target)
            
    # Save Artifacts
    joblib.dump(models_dict, out_dir / "model3_models.joblib")
    with open(out_dir / "model3_meta.json", "w") as f:
        json.dump({"embedder": "sentence-transformers/all-MiniLM-L6-v2", "features": "embedding+theory"}, f, indent=2)
        
    Path("reports/model3_retrain_report.md").write_text("\n".join(report_lines))
    val_preds_df.to_parquet("reports/model3_val_predictions.parquet", index=False)
    
    # Enforce degeneracy
    if p1_cols:
        max_p1 = val_preds_df[p1_cols].max(axis=1)
        std_p1 = max_p1.std()
        report_lines.append(f"## Degeneracy Check")
        report_lines.append(f"- Validation std(max_method_p1): {std_p1:.4f}")
        if std_p1 < 0.05:
            logging.error(f"Degeneracy check failed! std(max_method_p1)={std_p1:.4f} < 0.05")
            sys.exit(1)
        else:
            logging.info(f"Degeneracy check passed: std(max_method_p1)={std_p1:.4f}")
            
if __name__ == "__main__":
    main()
