import hashlib
import json
import os
import datetime
from pathlib import Path

# Define paths to hash
BASE_DIR = Path(__file__).resolve().parent.parent
FILES_TO_HASH = [
    BASE_DIR / "project_state/CONTRACT.json",
    BASE_DIR / "src/framework_contract.py",
    BASE_DIR / "src/round_runner.py",
    BASE_DIR / "src/run_query_loop.py",
    BASE_DIR / "src/query_builder.py",
    BASE_DIR / "src/bandit.py",
    BASE_DIR / "src/llm_judge_router.py",
    BASE_DIR / "src/config_loader.py",
]

HASHES_FILE = BASE_DIR / "project_state/IMMUTABLE_HASHES.json"
AUDIT_FILE = BASE_DIR / "audits/framework_hash_warning.md"

def compute_file_hash(path):
    if not path.exists():
        return "MISSING"
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception as e:
        return f"ERROR: {e}"

def check_immutable_hashes():
    """
    Computes current hashes, compares with stored hashes.
    Updates stored hashes if they changed, and writes an WARNING audit.
    Does NOT stop execution unless CONTRACT.json changed (logic can be added for that if strictly required, 
    but prompt says 'do NOT stop unless CONTRACT schema changed').
    """
    current_hashes = {str(p.relative_to(BASE_DIR)): compute_file_hash(p) for p in FILES_TO_HASH}
    
    stored_hashes = {}
    if HASHES_FILE.exists():
        with open(HASHES_FILE, "r") as f:
            stored_hashes = json.load(f)
            
    # Compare
    diffs = []
    contract_changed = False
    
    for file, curr_h in current_hashes.items():
        old_h = stored_hashes.get(file)
        if curr_h != old_h:
            diffs.append(f"- {file}: {old_h} -> {curr_h}")
            if "CONTRACT.json" in file and old_h is not None and old_h != "MISSING":
                 contract_changed = True
    
    # If changed, write warning and update
    if diffs:
        print("WARNING: Core framework files changed. Updating hashes.")
        os.makedirs(AUDIT_FILE.parent, exist_ok=True)
        with open(AUDIT_FILE, "a") as f:
             f.write(f"\n# Hash Change Warning - {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n")
             for d in diffs:
                 f.write(d + "\n")
        
        # Update stored
        with open(HASHES_FILE, "w") as f:
            json.dump(current_hashes, f, indent=2)
            
    return contract_changed

if __name__ == "__main__":
    check_immutable_hashes()
