
import json
import re
import logging

def sanitize_model_json(raw_text: str) -> tuple:
    """
    Lynn. Extracts and validates a JSON object from potentially messy LLM output.
    Returns (success: bool, data: dict, reason_tag: str)
    """
    if not raw_text or not isinstance(raw_text, str):
        return False, {}, "empty_input"

    # 1. Strip markdown code fences and surrounding prose
    # We look for the FIRST '{' and matching '}' - this implicitly handles code fences and prose
    start_idx = raw_text.find('{')
    if start_idx == -1:
        return False, {}, "no_json_start"
    
    # Greedy match for balanced braces
    obj_str = None
    stack = 0
    end_idx = -1
    for i in range(start_idx, len(raw_text)):
        if raw_text[i] == '{':
            stack += 1
        elif raw_text[i] == '}':
            stack -= 1
            if stack == 0:
                end_idx = i
                obj_str = raw_text[start_idx : i+1]
                break
    
    if not obj_str:
        return False, {}, "unbalanced_braces"

    # 3. Parse JSON
    try:
        data = json.loads(obj_str)
    except json.JSONDecodeError as e:
        return False, {}, f"json_decode_failed: {str(e)[:50]}"

    # 4. Strict Rubric Validation
    try:
        validate_rubric_schema_exact(data)
    except ValueError as e:
        return False, {}, f"invalid_schema: {str(e)}"

    # 5. Check for repetition or conflicting objects
    # Check if there's another '{' in the rest of the text
    remaining_text = raw_text[end_idx + 1:]
    reason_tag = "salvaged" if (start_idx > 0 or end_idx < len(raw_text)-1) else "exact_match"
    
    if '{' in remaining_text:
        # Check if model repeated the same JSON
        second_start = remaining_text.find('{')
        # Simple balanced brace extraction for the second object to compare
        stack2 = 0
        obj_str2 = None
        for j in range(second_start, len(remaining_text)):
            if remaining_text[j] == '{': stack2 += 1
            elif remaining_text[j] == '}':
                stack2 -= 1
                if stack2 == 0:
                    obj_str2 = remaining_text[second_start : j+1]
                    break
        
        if obj_str2:
            try:
                data2 = json.loads(obj_str2)
                if data2 == data:
                    # Check for even MORE objects
                    # If this recursively finds more, they should also be identical
                    # For simplicity, we just check if there's yet ANOTHER brace after this one
                    third_text = remaining_text[remaining_text.find(obj_str2) + len(obj_str2):]
                    if '{' in third_text:
                        # Recursively check or just note repetition
                        # Let's keep it simple: if there's a third one, we'll just check if it's identical eventually
                        # but for now, we'll mark it as repetition_ignored if we found at least one identical one
                        reason_tag = "repetition_ignored"
                    else:
                        reason_tag = "repetition_ignored"
                else:
                    return False, {}, "conflicting_json_objects"
            except:
                return False, {}, "malformed_trailing_json"
        else:
            # Found '{' but no matching '}'
            return False, {}, "malformed_trailing_json"

    return True, data, reason_tag

def validate_rubric_schema_exact(data: dict):
    """
    Lynn. Validates that the data follows the exact judge output schema.
    """
    required_dims = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]
    
    # Check keys
    for dim in required_dims:
        if dim not in data:
            raise ValueError(f"Missing dimension: {dim}")
        
        vals = data[dim]
        if not isinstance(vals, dict):
            raise ValueError(f"{dim} is not an object")
            
        for k in ["score", "p0", "p05", "p1"]:
            if k not in vals:
                raise ValueError(f"{dim} missing key: {k}")
        
        # Value validation - EXACT {0, 0.5, 1}
        # Note: model might output 1 or 1.0, both are fine as numbers
        score = vals["score"]
        if score not in [0, 0.5, 1, 0.0, 1.0]: # Added 0.0 and 1.0 explicitly
            raise ValueError(f"Invalid score {score} for {dim}")
            
        # Probabilities [0, 1]
        for k in ["p0", "p05", "p1"]:
            v = vals[k]
            if not isinstance(v, (int, float)) or not (0 <= v <= 1):
                raise ValueError(f"Invalid probability {k} for {dim}: {v}")

    return True
