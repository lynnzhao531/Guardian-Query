import torch
import pandas as pd
import numpy as np
from pathlib import Path
import yaml
import importlib

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "model_3.yaml"
CONCEPTS_PATH = ROOT / "configs" / "concepts.yaml"
MODEL_PATH = ROOT / "models" / "model3_best.pt"
QUERY_OUT_DIR = ROOT / "reports" / "query_spaces"

def load_config(path):
    with open(path) as f:
        return yaml.safe_load(f)

def mine_query_space():
    cfg = load_config(CONFIG_PATH)
    concepts_cfg = load_config(CONCEPTS_PATH)
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    
    # Dynamic import
    train_mod = importlib.import_module("04_model3_train")
    model = train_mod.CBMModel(cfg).to(device)
    
    if MODEL_PATH.exists():
        model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
        model.eval()
        print("Loaded best model for mining.")
    else:
        print("Model not found. Using untrained weights for structure mining.")
    
    # Mine bottleneck weights
    # For each label head, check weights assigned to concepts
    label_cols = ["decision", "method_rct", "method_prepost", "method_case_study", 
                  "method_expert_qual", "method_expert_secondary", "method_gut"]
    
    # Flatten concepts list
    concept_names = []
    for group in ["decision_concepts", "general_method_concepts", "method_specific_concepts"]:
        concept_names.extend(concepts_cfg.get(group, {}).keys())

    QUERY_OUT_DIR.mkdir(parents=True, exist_ok=True)
    
    print("Mining concept-to-label weights...")
    for i, head in enumerate(model.label_head):
        target = label_cols[i]
        # weights shape: [3, hidden+num_concepts]
        weights = head.weight.data.cpu().numpy()
        
        # We focus on the last 'num_concepts' features (the bottleneck)
        num_c = len(concept_names)
        concept_weights = weights[:, -num_c:] # [3, num_concepts]
        
        # Class 2 (High score) weights
        high_weights = concept_weights[2]
        
        # Sort concepts by weight for this target
        sorted_indices = np.argsort(high_weights)[::-1]
        
        mining_lines = [f"# Query Space Mining: {target}\n"]
        mining_lines.append("| Concept | Weight (to Class 2) | Note |")
        mining_lines.append("|---------|-------------------|------|")
        
        for idx in sorted_indices:
            name = concept_names[idx]
            weight = high_weights[idx]
            mining_lines.append(f"| {name} | {weight:.4f} | {'Strong' if weight > 0.5 else 'Weak'} |")
            
        out_path = QUERY_OUT_DIR / f"model3_mining_{target}.md"
        out_path.write_text("\n".join(mining_lines))
        print(f"Saved mining report for {target} to {out_path}")

if __name__ == "__main__":
    mine_query_space()
