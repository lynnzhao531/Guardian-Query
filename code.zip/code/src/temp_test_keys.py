import requests
from dotenv import load_dotenv
import os

load_dotenv()

keys = [
    os.getenv("GUARDIAN_API_KEY_1"),
    os.getenv("GUARDIAN_API_KEY_2"),
    os.getenv("GUARDIAN_API_KEY_3")
]

base_url = "https://content.guardianapis.com/search"

for i, key in enumerate(keys):
    if not key:
        print(f"Key {i+1} is missing.")
        continue
    
    params = {"api-key": key, "page-size": 1}
    try:
        resp = requests.get(base_url, params=params, timeout=10)
        if resp.status_code == 200:
            print(f"Key {i+1} ({key[:4]}...{key[-4:]}): WORKING")
        else:
            print(f"Key {i+1} ({key[:4]}...{key[-4:]}): FAILED (Status: {resp.status_code})")
            print(f"  Response: {resp.text}")
    except Exception as e:
        print(f"Key {i+1} ({key[:4]}...{key[-4:]}): ERROR ({e})")
