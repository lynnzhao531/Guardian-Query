#!/usr/bin/env python3
"""
Step 5: Stage I Knowledge Synthesis — Abduction → Induction → Optimization.
Uses o3-mini for hypothesis generation, text-embedding-3-small for clustering,
gpt-4.1-mini for induction evaluation. All calls are cached and cost-tracked.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import sys
import time
import uuid
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "project_state" / "api_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


# ── Cost estimation ──────────────────────────────────────────────────

def estimate_cost(input_tokens: int, output_tokens: int, model: str, cfg: dict) -> float:
    """Estimate cost in USD based on token counts and model."""
    p = cfg["pricing_estimates"]
    if "o3-mini" in model:
        return (input_tokens / 1e6) * p["o3_mini_input"] + (output_tokens / 1e6) * p["o3_mini_output"]
    elif "4.1-mini" in model or "4o-mini" in model:
        return (input_tokens / 1e6) * p["gpt_4_1_mini_input"] + (output_tokens / 1e6) * p["gpt_4_1_mini_output"]
    elif "embedding" in model:
        return (input_tokens / 1e6) * p["embedding_small"]
    return 0.01  # fallback


def check_budget(estimated_cost: float, ledger: dict, cfg: dict) -> bool:
    """Return True if estimated_cost fits within remaining budget."""
    cap = cfg["budget"]["total_cap_usd"]
    remaining = cap - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"]
    return estimated_cost <= remaining


def record_cost(ledger: dict, step: str, cost: float) -> None:
    ledger["total_spent_usd"] = round(ledger["total_spent_usd"] + cost, 4)
    cap = 50.0
    ledger["remaining_budget_usd"] = round(cap - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"], 4)
    ledger["per_step_costs"].append({"step": step, "cost_usd": round(cost, 4)})


# ── Cached API calls ─────────────────────────────────────────────────

def _cache_key(messages: list[dict], model: str) -> str:
    h = hashlib.md5(json.dumps({"model": model, "messages": messages}, sort_keys=True).encode()).hexdigest()
    return h


def cached_chat(client, model: str, messages: list[dict], cfg: dict, ledger: dict,
                 step_name: str, temperature: float = 0.7, max_tokens: int = 4096) -> str:
    """Call OpenAI chat with response caching and cost tracking."""
    key = _cache_key(messages, model)
    cache_file = CACHE_DIR / f"{key}.json"

    if cache_file.exists():
        cached = json.loads(cache_file.read_text())
        return cached["content"]

    # Estimate cost before calling
    import tiktoken
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    input_toks = sum(len(enc.encode(m["content"])) + 4 for m in messages)
    est_cost = estimate_cost(input_toks, max_tokens, model, cfg)

    if not check_budget(est_cost, ledger, cfg):
        raise RuntimeError(f"BUDGET EXCEEDED: estimated ${est_cost:.4f} for {step_name}, "
                           f"remaining ${ledger['remaining_budget_usd']:.2f}")

    # o3-mini and reasoning models use max_completion_tokens, not max_tokens,
    # and do not support the temperature parameter
    is_reasoning = "o3" in model or "o1" in model
    api_kwargs = dict(model=model, messages=messages)
    if is_reasoning:
        api_kwargs["max_completion_tokens"] = max_tokens
    else:
        api_kwargs["max_tokens"] = max_tokens
        api_kwargs["temperature"] = temperature

    resp = client.chat.completions.create(**api_kwargs)
    content = resp.choices[0].message.content
    actual_cost = estimate_cost(
        resp.usage.prompt_tokens, resp.usage.completion_tokens, model, cfg,
    )
    record_cost(ledger, step_name, actual_cost)

    # Cache
    cache_file.write_text(json.dumps({
        "model": model, "content": content,
        "prompt_tokens": resp.usage.prompt_tokens,
        "completion_tokens": resp.usage.completion_tokens,
        "cost_usd": actual_cost,
    }, indent=2))

    return content


def cached_embeddings(client, texts: list[str], model: str, cfg: dict,
                      ledger: dict, step_name: str) -> list[list[float]]:
    """Batch embed with caching."""
    key = hashlib.md5(json.dumps({"model": model, "texts": texts}, sort_keys=True).encode()).hexdigest()
    cache_file = CACHE_DIR / f"emb_{key}.json"

    if cache_file.exists():
        return json.loads(cache_file.read_text())

    import tiktoken
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    total_tokens = sum(len(enc.encode(t)) for t in texts)
    est_cost = estimate_cost(total_tokens, 0, "embedding", cfg)

    if not check_budget(est_cost, ledger, cfg):
        raise RuntimeError(f"BUDGET EXCEEDED for embeddings: ${est_cost:.4f}")

    resp = client.embeddings.create(model=model, input=texts)
    embeddings = [d.embedding for d in resp.data]
    actual_cost = estimate_cost(resp.usage.total_tokens, 0, "embedding", cfg)
    record_cost(ledger, step_name, actual_cost)

    cache_file.write_text(json.dumps(embeddings))
    return embeddings


# ── Abduction ─────────────────────────────────────────────────────────

ABDUCTION_SYSTEM = """You are an expert ML research assistant. Given a batch of labeled news articles, 
propose generalizable hypotheses (rules) that predict the correct labels.

Output valid JSON with this structure:
{
  "hypotheses": [
    {
      "category": "<decision|common_method|rct|prepost|case_studies|expert_qual|expert_secondary|gut>",
      "text": "<generalizable rule>",
      "positive_indicators": ["term or phrase", ...],
      "negative_indicators": ["term or phrase", ...],
      "notes": "<optional>"
    }
  ],
  "suggested_query_terms": {
    "<category>": ["term1", "term2", ...]
  }
}

Rules:
- Hypotheses should be GENERALIZABLE, not article-specific.
- Include both what makes something score HIGH and what makes it score LOW.
- Cover decision scoring and method scoring separately.
- For each hypothesis, provide concrete text indicators."""


def build_abduction_user_prompt(batch: pd.DataFrame) -> str:
    """Build user prompt from a batch of long-view rows."""
    lines = ["Analyze these labeled articles and propose hypotheses:\n"]
    for i, (_, row) in enumerate(batch.iterrows()):
        text_excerpt = str(row["text_for_model"])[:500]
        preferred = json.dumps({
            "decision_score": row["decision_score"],
            "method_type": row["method_type"],
            "method_score": row["method_score"],
        })
        # Generate a plausible wrong answer
        scores = [0, 0.5, 1]
        wrong_method = random.choice([s for s in scores if s != row["method_score"]])
        non_preferred = json.dumps({
            "decision_score": row["decision_score"],
            "method_type": row["method_type"],
            "method_score": wrong_method,
        })
        lines.append(f"--- Article {i+1} ---")
        lines.append(f"Method type: {row['method_type']}")
        lines.append(f"Title: {row.get('title', 'N/A')}")
        lines.append(f"Excerpt: {text_excerpt}")
        lines.append(f"CORRECT label: {preferred}")
        lines.append(f"WRONG label: {non_preferred}\n")

    lines.append("\nPropose hypotheses that explain why the CORRECT labels are correct.")
    return "\n".join(lines)


def run_abduction(client, batch: pd.DataFrame, cfg: dict, ledger: dict, batch_id: str) -> list[dict]:
    """Run one abduction cycle, return list of hypothesis dicts."""
    messages = [
        {"role": "system", "content": ABDUCTION_SYSTEM},
        {"role": "user", "content": build_abduction_user_prompt(batch)},
    ]
    raw = cached_chat(client, cfg["fixed_models"]["reasoner_R"], messages,
                      cfg, ledger, f"abduction_{batch_id}", temperature=0.8, max_tokens=4096)

    # Parse the JSON from the response — strip markdown fences if present
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        # Strip opening fence (```json or just ```)
        first_newline = cleaned.find("\n")
        if first_newline > 0:
            cleaned = cleaned[first_newline + 1:]
        # Strip closing fence
        if cleaned.rstrip().endswith("```"):
            cleaned = cleaned.rstrip()[:-3].rstrip()

    try:
        start = cleaned.find("{")
        end = cleaned.rfind("}") + 1
        if start >= 0 and end > start:
            parsed = json.loads(cleaned[start:end])
            hypotheses = parsed.get("hypotheses", [])
            for h in hypotheses:
                h["hypothesis_id"] = str(uuid.uuid4())[:8]
                h["source_batch_ids"] = [batch_id]
            return hypotheses
    except json.JSONDecodeError as e:
        print(f"  ⚠ JSON parse error for batch {batch_id}: {e}")
        # Try line-by-line fallback for partial JSON
        pass

    print(f"  ⚠ Could not parse abduction response for batch {batch_id}")
    print(f"  Response preview: {raw[:200]}...")
    return []


# ── Deduplication via clustering ──────────────────────────────────────

def deduplicate_hypotheses(hypotheses: list[dict], client, cfg: dict,
                           ledger: dict) -> list[dict]:
    """Embed hypotheses and cluster to remove duplicates."""
    if len(hypotheses) <= 3:
        return hypotheses

    texts = [h["text"] for h in hypotheses]
    embeddings = cached_embeddings(
        client, texts, cfg["fixed_models"]["embedding"],
        cfg, ledger, "hypothesis_embedding",
    )
    emb_array = np.array(embeddings)

    # Agglomerative clustering with cosine distance
    from sklearn.cluster import AgglomerativeClustering
    n_clusters = max(1, len(hypotheses) // 2)  # gentler dedup: keep ~half
    clustering = AgglomerativeClustering(
        n_clusters=min(n_clusters, len(hypotheses)),
        metric="cosine", linkage="average",
    )
    labels = clustering.fit_predict(emb_array)

    # Keep one representative per cluster (longest text as proxy for detail)
    deduped = []
    for cluster_id in range(max(labels) + 1):
        cluster_hyps = [h for h, l in zip(hypotheses, labels) if l == cluster_id]
        # Pick the one with the longest text
        representative = max(cluster_hyps, key=lambda h: len(h["text"]))
        representative["cluster_id"] = int(cluster_id)
        representative["cluster_size"] = len(cluster_hyps)
        deduped.append(representative)

    return deduped


# ── Induction utility ────────────────────────────────────────────────

def evaluate_hypothesis_set(hypothesis_set: list[dict], eval_df: pd.DataFrame,
                            client, cfg: dict, ledger: dict) -> float:
    """Evaluate a candidate hypothesis set K by scoring eval_df with generator G."""
    from sklearn.metrics import f1_score

    # Build system prompt with hypotheses
    rubric_summary = """Score articles on Decision (0/0.5/1) and Method (0/0.5/1).
Decision 1=evidence linked to org decision, 0.5=potential decision, 0=no decision.
Method 1=clear evaluative method, 0.5=indirect/weak method, 0=no method."""

    hyp_bullets = "\n".join(f"- [{h['category']}] {h['text']}" for h in hypothesis_set)
    system = f"""You are labeling Guardian articles. Use these rules:

{rubric_summary}

LEARNED RULES:
{hyp_bullets}

Output ONLY valid JSON: {{"decision_score": 0|0.5|1, "method_type": "<type>", "method_score": 0|0.5|1}}"""

    correct_dec = 0
    correct_method = 0
    parse_errors = 0
    total = 0
    y_true_dec, y_pred_dec = [], []
    y_true_method, y_pred_method = [], []

    for _, row in eval_df.iterrows():
        user_msg = f"Method type to score: {row['method_type']}\n\nArticle:\n{str(row['text_for_model'])[:2000]}"
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user_msg},
        ]
        try:
            raw = cached_chat(client, cfg["fixed_models"]["generator_G"], messages,
                              cfg, ledger, "induction_eval", temperature=0.0, max_tokens=100)
            start = raw.find("{")
            end = raw.rfind("}") + 1
            pred = json.loads(raw[start:end])
            y_true_dec.append(row["decision_score"])
            y_pred_dec.append(pred.get("decision_score", -1))
            y_true_method.append(row["method_score"])
            y_pred_method.append(pred.get("method_score", -1))
        except Exception:
            parse_errors += 1
        total += 1

    if len(y_true_dec) < 5:
        return 0.0

    # Compute macro F1
    str_labels = ["0.0", "0.5", "1.0"]
    dec_f1 = f1_score(
        [str(float(v)) for v in y_true_dec],
        [str(float(v)) for v in y_pred_dec],
        labels=str_labels, average="macro", zero_division=0,
    )
    method_f1 = f1_score(
        [str(float(v)) for v in y_true_method],
        [str(float(v)) for v in y_pred_method],
        labels=str_labels, average="macro", zero_division=0,
    )
    parse_error_rate = parse_errors / total if total > 0 else 1.0

    # Composite utility
    U = 0.4 * dec_f1 + 0.5 * method_f1 - 0.1 * parse_error_rate
    return round(U, 4)


# ── Simulated Annealing ──────────────────────────────────────────────

def simulated_annealing(hypothesis_pool: list[dict], eval_df: pd.DataFrame,
                        client, cfg: dict, ledger: dict) -> tuple[list[dict], float]:
    """Optimize hypothesis set using simulated annealing."""
    sa_cfg = cfg["knowledge_synthesis"]["simulated_annealing"]
    hs_cfg = cfg["knowledge_synthesis"]["hypothesis_set_size"]
    T = sa_cfg["initial_temperature"]
    cooling = sa_cfg["cooling_rate"]
    stagnation_limit = 20  # Max Power
    max_iter = 250         # Max Power

    # Group hypotheses by category
    by_cat = {}
    for h in hypothesis_pool:
        cat = h.get("category", "common_method")
        by_cat.setdefault(cat, []).append(h)

    # Initialize: pick from pool per category
    current_set = []
    for cat, quota in hs_cfg.items():
        if cat == "per_method":
            for method in ["rct", "prepost", "case_studies", "expert_qual", "expert_secondary", "gut"]:
                pool = by_cat.get(method, [])
                current_set.extend(pool[:quota])
        else:
            pool = by_cat.get(cat, [])
            current_set.extend(pool[:quota])

    if not current_set:
        current_set = hypothesis_pool[:min(10, len(hypothesis_pool))]

    current_U = evaluate_hypothesis_set(current_set, eval_df, client, cfg, ledger)
    best_set = current_set[:]
    best_U = current_U
    stagnation = 0

    print(f"  SA init: U={current_U:.4f}, set size={len(current_set)}")

    for iteration in range(max_iter):
        # Budget check
        if not check_budget(0.50, ledger, cfg):
            print("  ⚠ Budget tight, stopping SA early")
            break

        # Choose random move: add, cut, or swap
        move = random.choice(["add", "cut", "swap"])
        candidate = current_set[:]

        if move == "add" and len(hypothesis_pool) > len(candidate):
            unused = [h for h in hypothesis_pool if h not in candidate]
            if unused:
                candidate.append(random.choice(unused))
        elif move == "cut" and len(candidate) > 3:
            candidate.pop(random.randint(0, len(candidate) - 1))
        elif move == "swap" and candidate and hypothesis_pool:
            idx = random.randint(0, len(candidate) - 1)
            unused = [h for h in hypothesis_pool if h not in candidate]
            if unused:
                candidate[idx] = random.choice(unused)

        candidate_U = evaluate_hypothesis_set(candidate, eval_df, client, cfg, ledger)

        # Accept?
        delta = candidate_U - current_U
        if delta > 0 or random.random() < np.exp(delta / max(T, 0.01)):
            current_set = candidate
            current_U = candidate_U
            stagnation = 0
        else:
            stagnation += 1

        if current_U > best_U:
            best_set = current_set[:]
            best_U = current_U

        T *= cooling

        if stagnation >= stagnation_limit:
            print(f"  SA stagnation at iter {iteration}, best U={best_U:.4f}")
            break

        if iteration % 5 == 0:
            print(f"  SA iter {iteration}: T={T:.3f}, U={current_U:.4f}, best={best_U:.4f}")

    return best_set, best_U


# ── main ──────────────────────────────────────────────────────────────

def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()
    random.seed(cfg["splits"]["seed"])
    np.random.seed(cfg["splits"]["seed"])

    from openai import OpenAI
    client = OpenAI()

    # Load long view + splits
    df = pd.read_parquet(state.get("training_long_path",
                                   str(ROOT / "data" / "processed" / "training_long.parquet")))
    with open(ROOT / "data" / "processed" / "article_splits.json") as f:
        splits = json.load(f)

    train_df = df[df["article_id"].isin(set(splits["train_articles"]))].copy()
    val_df = df[df["article_id"].isin(set(splits["val_articles"]))].copy()

    # Full eval subset — user wants max power within $50 budget
    eval_size = min(100, len(val_df))
    eval_df = val_df.sample(n=eval_size, random_state=42)
    print(f"Training rows: {len(train_df)}, Eval subset: {len(eval_df)}")

    # ── Abduction: generate hypotheses from multiple batches ──────────
    b = cfg["knowledge_synthesis"]["abduction_batch_size_default"]
    n_batches = 10  # Max Power
    all_hypotheses = []

    print(f"\n── ABDUCTION ({n_batches} batches of size {b}) ──")
    for batch_i in range(n_batches):
        batch = train_df.sample(n=min(b, len(train_df)), random_state=42 + batch_i)
        batch_id = f"batch_{batch_i:03d}"
        hyps = run_abduction(client, batch, cfg, ledger, batch_id)
        all_hypotheses.extend(hyps)
        print(f"  Batch {batch_i}: {len(hyps)} hypotheses generated")
        save_ledger(ledger)

    print(f"\nTotal raw hypotheses: {len(all_hypotheses)}")

    # ── Deduplicate ───────────────────────────────────────────────────
    if all_hypotheses:
        print("\n── DEDUPLICATION ──")
        deduped = deduplicate_hypotheses(all_hypotheses, client, cfg, ledger)
        print(f"  After dedup: {len(deduped)} hypotheses")
        save_ledger(ledger)
    else:
        deduped = []

    # Save hypothesis pool
    kb_dir = ROOT / "knowledge_base"
    kb_dir.mkdir(parents=True, exist_ok=True)
    pool_path = kb_dir / "hypotheses_pool.jsonl"
    with open(pool_path, "w") as f:
        for h in deduped:
            f.write(json.dumps(h) + "\n")
    print(f"  Saved to {pool_path}")

    # ── Optimization via SA ───────────────────────────────────────────
    if deduped:
        print("\n── SIMULATED ANNEALING ──")
        best_set, best_U = simulated_annealing(deduped, eval_df, client, cfg, ledger)
        print(f"\n  Best hypothesis set: {len(best_set)} rules, U={best_U:.4f}")
        save_ledger(ledger)

        # Save best set
        with open(kb_dir / "best_hypothesis_set.json", "w") as f:
            json.dump({"utility": best_U, "hypotheses": best_set}, f, indent=2)
    else:
        best_set, best_U = [], 0.0

    # ── Report ────────────────────────────────────────────────────────
    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    lines = ["# Stage I Knowledge Synthesis Report\n"]
    lines.append(f"**Abduction batches**: {n_batches}")
    lines.append(f"**Batch size**: {b}")
    lines.append(f"**Raw hypotheses**: {len(all_hypotheses)}")
    lines.append(f"**After dedup**: {len(deduped)}")
    lines.append(f"**Best set size**: {len(best_set)}")
    lines.append(f"**Best utility**: {best_U:.4f}")
    lines.append(f"**Total cost so far**: ${ledger['total_spent_usd']:.4f}\n")

    lines.append("## Best Hypotheses\n")
    for h in best_set:
        lines.append(f"### [{h.get('category', '?')}] {h.get('text', '?')[:100]}")
        if h.get("positive_indicators"):
            lines.append(f"  + indicators: {', '.join(h['positive_indicators'][:5])}")
        if h.get("negative_indicators"):
            lines.append(f"  - indicators: {', '.join(h['negative_indicators'][:5])}")
        lines.append("")

    (report_dir / "stage1_knowledge_synthesis_report.md").write_text("\n".join(lines))
    print(f"✓ Report → {report_dir / 'stage1_knowledge_synthesis_report.md'}")

    # ── Update state ──────────────────────────────────────────────────
    state["knowledge_base_version"] = "v1"
    state["best_hypothesis_set_id"] = str(kb_dir / "best_hypothesis_set.json")
    if "step_5_knowledge_synthesis" not in state["steps_completed"]:
        state["steps_completed"].append("step_5_knowledge_synthesis")
    state["current_step"] = "step_5_complete"
    save_state(state)
    save_ledger(ledger)

    print(f"\n{'='*60}")
    print(f"  KNOWLEDGE SYNTHESIS COMPLETE")
    print(f"  Cost so far: ${ledger['total_spent_usd']:.4f} / $50.00")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
