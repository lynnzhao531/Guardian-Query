import os
from openai import OpenAI
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    api_key = get_api_key()
    client = OpenAI(api_key=api_key)
    job_id = "ftjob-QW3yXIQQ3nNqaXseoVBfLJsl"
    
    try:
        job = client.fine_tuning.jobs.cancel(job_id)
        print(f"Canceled job: {job.id}, status: {job.status}")
        
        report_path = BASE_DIR / "reports/dpo_fast_run.md"
        report_path.parent.mkdir(exist_ok=True, parents=True)
        with open(report_path, "w") as f:
            f.write(f"# DPO Fast Run\n\n- **Canceled old job**: `{job_id}`\n- **Status**: {job.status}\n\nProceeding to build fast dataset.\n")
    except Exception as e:
        print(f"Error canceling job: {e}")

if __name__ == "__main__":
    main()
