import hashlib
import json
import os
import sys
from pathlib import Path
from src.config_loader import get_config

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
CONTRACT_PATH = BASE_DIR / "project_state/CONTRACT.json"
CONFIG_V1_PATH = BASE_DIR / "project_state/CONFIG.yaml"
CONFIG_V2_PATH = BASE_DIR / "project_state/CONFIG_V2.yaml"
TEMPLATES_PATH = BASE_DIR / "knowledge_base/templates_fixed.json"
QUERY_SPACES_DIR = BASE_DIR / "knowledge_base/query_spaces"

CODE_DIRS = ["src", "project_state"]

def compute_file_hash(path):
    if not path.exists():
        return "MISSING"
    sha = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            sha.update(chunk)
    return sha.hexdigest()

def compute_code_bundle_hash():
    """Hashes all .py files in src and project_state JSON/YAMLs."""
    hashes = []
    # Source files
    for d in CODE_DIRS:
        dir_path = BASE_DIR / d
        if dir_path.exists():
            for f in sorted(dir_path.rglob("*")):
                if f.is_file() and (f.suffix in [".py", ".json", ".yaml"]):
                    # Exclude dynamic state files and authorized audits
                    if any(x in str(f) for x in ["cache", "audit", ".DS_Store", "LOCKDOWN", "STATE.json", "guardian_state.json", "COST_LEDGER.json", "guardian_key_state.json", "QUERY_SPACES_HASH.json", "IMMUTABLE_HASHES.json"]):
                        continue
                    h = compute_file_hash(f)
                    hashes.append(f"{str(f.relative_to(BASE_DIR))}:{h}")
    
    # Sort and hash the list of hashes
    bundle = "\n".join(sorted(hashes)).encode('utf-8')
    return hashlib.sha256(bundle).hexdigest()

def compute_query_spaces_hash():
    """Hashes all JSONs in query_spaces."""
    hashes = []
    if QUERY_SPACES_DIR.exists():
        for f in sorted(QUERY_SPACES_DIR.glob("*.json")):
            h = compute_file_hash(f)
            hashes.append(f"{f.name}:{h}")
    
    if not hashes:
        return "EMPTY"
        
    combined = "\n".join(sorted(hashes)).encode('utf-8')
    final_hash = hashlib.sha256(combined).hexdigest()
    
    # Store explicit hash as required
    hash_file = BASE_DIR / "project_state/QUERY_SPACES_HASH.json"
    with open(hash_file, "w") as f:
        json.dump({"query_spaces_sha256": final_hash, "files": hashes}, f, indent=2)
        
    return final_hash

def check_run_lockdown():
    cfg = get_config()
    mode = cfg.get("run_mode", "DEV")
    
    bundle_hash = compute_code_bundle_hash()
    contract_hash = compute_file_hash(CONTRACT_PATH)
    config_hash = compute_file_hash(CONFIG_V1_PATH)
    config_v2_hash = compute_file_hash(CONFIG_V2_PATH)
    templates_hash = compute_file_hash(TEMPLATES_PATH)
    query_spaces_hash = compute_query_spaces_hash()
    
    hashes = {
        "code_bundle": bundle_hash,
        "contract": contract_hash,
        "config_v1": config_hash,
        "config_v2": config_v2_hash,
        "templates": templates_hash,
        "query_spaces": query_spaces_hash
    }
    
    lock_file = BASE_DIR / "project_state/LOCKDOWN_HASHES.json"
    
    if mode == "RUN":
        if not lock_file.exists():
            print("WARNING: RUN mode active but no LOCKDOWN_HASHES.json found. Establishing baseline.")
            with open(lock_file, "w") as f:
                json.dump(hashes, f, indent=2)
        else:
            with open(lock_file, "r") as f:
                stored_hashes = json.load(f)
            
            diffs = []
            for k, v in hashes.items():
                if stored_hashes.get(k) != v:
                    diffs.append(f"{k}: {stored_hashes.get(k)} -> {v}")
            
            if diffs:
                msg = f"FATAL: RUN mode violation. Hashes changed:\n" + "\n".join(diffs)
                with open(BASE_DIR / "audits/hash_violation_audit.md", "a") as f:
                    f.write(f"\n# FATAL VIOLATION {os.times()}\n{msg}\n")
                print(msg)
                sys.exit(1)
    else:
        # DEV mode: Update baseline
        with open(lock_file, "w") as f:
            json.dump(hashes, f, indent=2)
            
    return hashes

if __name__ == "__main__":
    h = check_run_lockdown()
    print("Hash Guard Passed.")
    print(json.dumps(h, indent=2))
