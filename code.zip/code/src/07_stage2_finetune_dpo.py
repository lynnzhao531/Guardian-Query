#!/usr/bin/env python3
"""
Step 7: Stage II Fine-tuning — DPO job launcher.
Starts DPO fine-tuning from the SFT model.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()

    from openai import OpenAI
    client = OpenAI()

    # ── Get SFT model name ────────────────────────────────────────────
    sft_model = state.get("sft_model_name")
    if not sft_model:
        print("ERROR: No sft_model_name found in state.")
        sys.exit(1)

    print(f"Starting DPO from SFT model: {sft_model}")

    # ── Determine DPO shard ───────────────────────────────────────────
    dpo_shards = state.get("dpo_shards", [])
    if not dpo_shards:
        print("ERROR: No DPO shards found. Run Step 4 first.")
        sys.exit(1)

    shard = dpo_shards[0]
    # OVERRIDE path to use clean shard
    shard["path"] = str(ROOT / "fine_tune_data" / "dpo_train_shard_001_clean.jsonl")
    estimated_cost = shard.get("estimated_cost_usd", 10.0)
    print(f"DPO shard: {shard['path']}")
    print(f"  Lines: {shard['lines']}, Estimated cost: ${estimated_cost:.2f}")

    # ── Budget check ──────────────────────────────────────────────────
    cap = cfg["budget"]["total_cap_usd"]
    already_spent = ledger["total_spent_usd"]
    reserved = ledger["outstanding_reserved_budget_usd"]
    remaining = cap - already_spent - reserved

    print(f"\nBudget: spent=${already_spent:.2f}, reserved=${reserved:.2f}, "
          f"remaining=${remaining:.2f}")

    if estimated_cost > remaining:
        print(f"\n⚠ BUDGET EXCEEDED: shard costs ~${estimated_cost:.2f}")
        sys.exit(1)

    # Reserve
    ledger["outstanding_reserved_budget_usd"] = round(reserved + estimated_cost, 2)
    save_ledger(ledger)

    # ── Upload DPO training file ──────────────────────────────────────
    print("\nUploading DPO training file...")
    with open(shard["path"], "rb") as f:
        train_file = client.files.create(file=f, purpose="fine-tune")

    # Upload DPO validation file
    dpo_val_path = ROOT / "fine_tune_data" / "dpo_val_clean.jsonl"
    val_file_id = None
    if dpo_val_path.exists():
        with open(dpo_val_path, "rb") as f:
            val_file = client.files.create(file=f, purpose="fine-tune")
        val_file_id = val_file.id

    # ── Start DPO fine-tuning ─────────────────────────────────────────
    print("Starting DPO job...")
    ft_params = {
        "training_file": train_file.id,
        "model": sft_model,
        "method": {"type": "dpo", "dpo": {"hyperparameters": {"beta": "auto"}}},
    }
    if val_file_id:
        ft_params["validation_file"] = val_file_id

    job = client.fine_tuning.jobs.create(**ft_params)
    print(f"  Job ID: {job.id}")
    print(f"  Status: {job.status}")

    # ── Update state ──────────────────────────────────────────────────
    state["latest_dpo_job_id"] = job.id
    if "step_7_dpo" not in state["steps_completed"]:
        state["steps_completed"].append("step_7_dpo")
    state["current_step"] = "step_7_dpo_submitted"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  DPO JOB SUBMITTED: {job.id}")
    print(f"  Monitor with: python src/08_monitor_finetune.py")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
