import os
from openai import OpenAI
from pathlib import Path
import sys

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    api_key = get_api_key()
    client = OpenAI(api_key=api_key)
    
    job_id = "ftjob-QW3yXIQQ3nNqaXseoVBfLJsl"
    
    try:
        job = client.fine_tuning.jobs.retrieve(job_id)
        print(f"Job ID: {job.id}")
        print(f"Status: {job.status}")
        print(f"Base Model: {job.model}")
        
        train_id = job.training_file
        val_id = job.validation_file
        print(f"Training File ID: {train_id}")
        print(f"Validation File ID: {val_id}")
        
        # In python library, method is sometimes nested differently or absent in older versions.
        method = getattr(job, 'method', None)
        if method:
            print(f"Method Type: {method.type}")
            print(f"Method Params: {getattr(method, method.type, 'N/A')}")
            
        print(f"Trained Tokens so far: {job.trained_tokens}")
        print(f"Hyperparameters: {job.hyperparameters}")
        
        print("\n--- Recent Events (up to 20) ---")
        events = client.fine_tuning.jobs.list_events(fine_tuning_job_id=job_id, limit=20)
        for event in events.data:
            print(f"[{event.created_at}] {event.message}")
            if "Step" in event.message and "/" in event.message:
                pass # Already printing
                
    except Exception as e:
        print(f"Error inspecting job: {e}")

if __name__ == "__main__":
    main()
