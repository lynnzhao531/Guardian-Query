
# src/round_runner.py

import os
import sys
import pandas as pd
import json
import logging
import random
import datetime
from pathlib import Path

# Project Imports
from src.config_loader import get_config
from src.config_env import load_guardian_keys, get_guardian_base_url
from src.framework_contract import validate_repo_structure, validate_round_outputs, validate_query_log, validate_llm_router_health
from src.llm_judge_router import score_articles
from src.hash_guard import check_run_lockdown
from src.recompute_round_metrics import recompute_round_metrics
from src.guardian_client import GuardianClient
from src.bandit_simple import Bandit
from src.query_builder import QueryBuilder
from src.scorers import Model1Scorer, Model3Scorer
from src.pool_manager import ensure_pool_files_exist, update_pools
import numpy as np
from sklearn.linear_model import LogisticRegression

# HARDCODED CLASS TO FIX PICKLE LOADING
class OrdinalClassifier:
    """Frank & Hall: K-1 binary classifiers for ordinal targets."""

    def __init__(self, classes=None, **lr_kwargs):
        self.classes = np.array(classes or [0.0, 0.5, 1.0])
        self.lr_kwargs = lr_kwargs
        self.clfs = []

    def fit(self, X, y):
        self.clfs = []
        for k in range(len(self.classes) - 1):
            y_bin = (np.asarray(y, dtype=float) > self.classes[k]).astype(int)
            clf = LogisticRegression(**self.lr_kwargs)
            if len(np.unique(y_bin)) > 1:
                clf.fit(X, y_bin)
            else:
                clf = None
            self.clfs.append(clf)
        return self

    def predict_proba(self, X):
        n = X.shape[0]
        cps = []
        for clf in self.clfs:
            if clf is not None:
                cps.append(clf.predict_proba(X)[:, 1])
            else:
                cps.append(np.zeros(n))
        probs = np.zeros((n, len(self.classes)))
        probs[:, 0] = 1.0 - cps[0]
        for k in range(1, len(self.classes) - 1):
            probs[:, k] = cps[k - 1] - cps[k]
        probs[:, -1] = cps[-1]
        probs = np.clip(probs, 0, 1)
        rs = probs.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        return probs / rs

    def predict(self, X):
        return self.classes[np.argmax(self.predict_proba(X), axis=1)]

def choose_backoff_level(preflight_totals, min_total=25, max_total=2500, target=400):
    """
    Lynn. Picks the level minimizing |total - target| within [min_total, max_total].
    Falls back to strictest if all > max_total, or broadest if all < min_total.
    """
    valid = []
    all_levels = []
    
    for key, data in preflight_totals.items():
        total = data["total"]
        all_levels.append(data)
        if min_total <= total <= max_total:
            valid.append(data)
            
    if valid:
        # Pick level minimizing |total - target|
        chosen = min(valid, key=lambda x: abs(x["total"] - target))
        return chosen, "IN_BAND"
        
    # If all above max
    above = [d for d in all_levels if d["total"] > max_total]
    if above:
        # Choose strictest level (minimum total among those > max)
        chosen = min(above, key=lambda x: x["total"])
        return chosen, "TOO_MANY_STRICTEST"
        
    # If all below min
    below = [d for d in all_levels if d["total"] < min_total]
    if below:
        # Choose broadest level (maximum total)
        chosen = max(below, key=lambda x: x["total"])
        return chosen, "TOO_FEW_BROADEST"
        
    # Should not happen if emergency fallback exists
    return all_levels[0], "FALLBACK"

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
STATE_PATH = BASE_DIR / "project_state/STATE.json"
TEMPLATES_PATH = BASE_DIR / "knowledge_base/templates_fixed.json"
QUERY_SPACES_DIR = BASE_DIR / "knowledge_base/query_spaces"

def load_json(path):
    if not path.exists():
        return {} if path.suffix == '.json' else []
    with open(path) as f:
        return json.load(f)


def append_query_log(round_id, metrics):
    path = Path("outputs/query_log.csv")
    row = {
        "round_id": round_id,
        "timestamp_utc_iso": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        **metrics
    }
    new_df = pd.DataFrame([row])
    
    if path.exists() and path.stat().st_size > 0:
        # Ensure newline at end of file
        with open(path, "rb+") as f:
            f.seek(-1, 2)
            if f.read(1) != b"\n":
                f.write(b"\n")
                
        try:
            existing_df = pd.read_csv(path)
            # Idempotency: Drop existing row for this round
            existing_df = existing_df[existing_df["round_id"] != round_id]
            final_df = pd.concat([existing_df, new_df], ignore_index=True)
            # Sort by round_id to keep clean
            if "round_id" in final_df.columns:
                final_df = final_df.sort_values("round_id")
            final_df.to_csv(path, index=False)
        except Exception as e:
            logging.error(f"Failed to append/overwrite query log: {e}")
            sys.exit(1)
    else:
        new_df.to_csv(path, index=False)

def run_round(round_id: int, dry_run: bool = False):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    print(f"DEBUG: Entering run_round with id={round_id}")
    # LOCKDOWN CHECK
    hashes = check_run_lockdown()
    print("DEBUG: Lockdown passed")
    q_hash = hashes.get("query_spaces", "MISSING")
    
    cfg = get_config()
    logging.info(f"Starting Round {round_id} (Dry Run: {dry_run})")
    novelty_search_pages_used = 0
    
    # 0. Pre-flight checks
    validate_repo_structure()
    
    # 1. Load State
    if STATE_PATH.exists():
        with open(STATE_PATH) as f:
            state = json.load(f)
    else:
        state = {"seen_urls": {}, "bandit_stats": {}}
        
    # STRICT MODEL CHECK - NO FALLBACKS
    if "sft_model_name" not in state:
        logging.error("FATAL: sft_model_name missing in STATE.json. Update manually.")
        sys.exit(1)
        
    # 2. Setup Components
    # Ensure Pools Exist
    ensure_pool_files_exist()
    
    # Templates
    templates = load_json(TEMPLATES_PATH)
    template_ids = list(templates.keys())
    # Methods (from contract or config, but we need names for bandit)
    method_names = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    
    if not dry_run:
        keys = load_guardian_keys()
        base_url = get_guardian_base_url()
        client = GuardianClient(keys, base_url, BASE_DIR / "project_state/guardian_state.json", BASE_DIR / "audits/guardian_api_rotation.log")
        bandit = Bandit(state, method_names, template_ids)
        
    # 3. Selection
    if not dry_run:
        keys = load_guardian_keys()
        base_url = get_guardian_base_url()
        client = GuardianClient(keys, base_url, BASE_DIR / "project_state/guardian_state.json", BASE_DIR / "audits/guardian_api_rotation.log")
        bandit = Bandit(state, method_names, template_ids)
        
        t_id, m_name, backoff_base = bandit.select_action()
        
        # Preflight & Backoff Loop
        # Query Construction via QueryBuilder (V2)
        contract = load_json(BASE_DIR / "project_state/CONTRACT.json")
        qb = QueryBuilder(cfg, contract, QUERY_SPACES_DIR, templates)
        
        q_result = qb.build_query(m_name, round_id, client)
        
        # Lynn. Use optimal level selection
        p_totals = json.loads(q_result["preflight_totals_by_level_json"])
        min_t = contract.get("min_total_available", 25)
        max_t = contract.get("max_total_available", 2500)
        target_t = contract.get("target_total_available", 400)
        
        chosen_data, supply_state = choose_backoff_level(p_totals, min_t, max_t, target_t)
        
        query = chosen_data["query"]
        selected_level = chosen_data["level"]
        total_avail_captured = chosen_data["total"]
        preflight_totals_json_str = q_result["preflight_totals_by_level_json"]

        # Log selection
        sel_log = {
            "round_id": round_id,
            "chosen_level": selected_level,
            "supply_band_state": supply_state, # Use exact key for summary
            "total_at_preflight": total_avail_captured,
            "query": query
        }
        sel_log_dir = BASE_DIR / f"audits/round_{round_id}"
        sel_log_dir.mkdir(parents=True, exist_ok=True)
        with open(sel_log_dir / "supply_band_selection.json", "w") as f:
            json.dump(sel_log, f, indent=2)

        print(f"Lynn. Selection: {query} (Total: {total_avail_captured}) [State: {supply_state}]")
        
        # 4. Fetch (Multi-page)
        # CONTRACT V2: target_scored_n=100, newest, min 5 pages when supply>=250, max 20 pages, skip long > 15000
        target_n = 100; page_size = 50; max_pages = 20; min_pages_if_supply = 5
        novelty_search_pages_used = 0; filtered_articles = []
        skipped_live = 0; skipped_dedupe = 0; skipped_missing = 0; skipped_long_count_inline = 0
        guardian_requests_count = 0; guardian_pages_fetched_count = 0; real_total = 0
        seen = state.get("seen_urls", {})  # initialize before fetch loop uses it for dedup
        for p in range(1, max_pages + 1):
            params = {
                "q": query,
                "page": p,
                "page-size": page_size,
                "show-fields": "bodyText,headline,wordcount,publication,section,sectionId,shortUrl,lastModified",
                "order-by": "newest",
                "lang": "en"
            }
            try:
                guardian_requests_count += 1
                resp = client.request(params)
                page_results = resp.get("response", {}).get("results", [])
                real_total = resp.get("response", {}).get("total", 0)
                if not page_results: break
                for r in page_results:
                    f = r.get("fields", {})
                    u = r.get("webUrl", "")
                    if not u: continue
                    if u in seen: skipped_dedupe += 1; continue
                    title_lower = r.get("webTitle", "").lower()
                    section_id = r.get("sectionId", "").lower()
                    if ("/live/" in u.lower() or "as it happened" in title_lower
                            or "rolling coverage" in title_lower
                            or "commentisfree" in section_id):
                        skipped_live += 1; continue
                    t = f.get("bodyText", "")
                    if not t: skipped_missing += 1; continue
                    # CONTRACT V2: SKIP super-long (>15000). Do NOT truncate.
                    if len(t) > 15000: skipped_long_count_inline += 1; continue
                    filtered_articles.append({
                        "url_canon": u, "url": u,
                        "title": r.get("webTitle"), "section": r.get("sectionId"),
                        "publication_date_utc": r.get("webPublicationDate"),
                        "body_text": t
                    })
                guardian_pages_fetched_count = p
                # Stop only after min 5 pages (when supply>=250) AND scored target reached
                min_pages_required = min_pages_if_supply if real_total >= 250 else 1
                if len(filtered_articles) >= target_n and p >= min_pages_required:
                    break
                if real_total > 0 and p * page_size >= real_total:
                    break
            except Exception as e:
                logging.error(f"Guardian fetch failed page {p}: {e}")
                break
        
        articles = filtered_articles; novelty_search_pages_used = max(0, guardian_pages_fetched_count - 5)

    else:
        # Mock Selection but use Builder for valid string
        contract = load_json(BASE_DIR / "project_state/CONTRACT.json")
        qb = QueryBuilder(cfg, contract, QUERY_SPACES_DIR, templates)
        
        # We need a mock client that returns valid preflight msg
        class MockGuardian:
            def request(self, params):
                return {"response": {"total": 100}}
                
        q_result = qb.build_query("rct", round_id, MockGuardian())
        
        query = q_result["query_final"]
        selected_level = q_result["backoff_level_used"]
        total_avail_captured = q_result["guardian_total_available"]
        preflight_totals_json_str = q_result["preflight_totals_by_level_json"]
        
        t_id = q_result["template_id"]
        m_name = "rct"
        # Mock Articles
        articles = [
            {
                "url_canon": "test_url_1", "url": "test_url_1", 
                "title": "RCT Test", "section": "science",
                "publication_date_utc": "2026-01-01T00:00:00Z",
                "body_text": "This is a test article about RCTs."
            },
            {
                "url_canon": "test_url_2", "url": "test_url_2",
                "title": "Policy Test", "section": "politics",
                "publication_date_utc": "2026-01-01T00:00:00Z", 
                "body_text": "Another article about policy."
            }
        ]
        guardian_pages_fetched_count = 0
        guardian_requests_count = 0
        # total_avail_captured already set by builder
        
    # 5. Filter & Dedupe (only applied for dry_run path; live path already filtered inline)
    # For dry_run, apply filters to mock articles. For live, filtered_articles is already populated.
    # skipped_long_count_inline was tracked inline during fetch.
    skipped_long_count = getattr(__builtins__, '__dict__', {}).get('_rr_skipped_long', 0)
    if dry_run:
        # For dry_run: apply filters to mock articles
        filtered_articles_tmp = []
        skipped_live = 0; skipped_dedupe = 0; skipped_missing = 0; skipped_long_count = 0
        seen = state.get("seen_urls", {})
        for a in articles:
            url = a.get("url_canon", "")
            text = a.get("body_text", "")
            title = a.get("title", "").lower()
            section = a.get("section", "").lower()
            if url in seen: skipped_dedupe += 1; continue
            if ("/live/" in url.lower() or "as it happened" in title
                    or "rolling coverage" in title
                    or "commentisfree" in section):
                skipped_live += 1; continue
            if not text: skipped_missing += 1; continue
            if len(text) > 15000: skipped_long_count += 1; continue  # CONTRACT V2: skip, not truncate
            filtered_articles_tmp.append(a)
        filtered_articles = filtered_articles_tmp
    else:
        # Live path: filtered_articles already populated by fetch loop; transfer counters
        skipped_long_count = skipped_long_count_inline
    
    # 5.4.1 Novelty-seeking Fetch Loop (Authorized Patch 20260222)
    if not filtered_articles and not dry_run and len(filtered_articles) == 0 and skipped_dedupe > 0:
        max_novelty_pages = cfg.get("novelty_extra_pages", 5)
        # We already fetched 'total_pages_to_fetch' (line 237)
        next_page = total_pages_to_fetch + 1
        last_page = total_pages_to_fetch + max_novelty_pages
        
        while next_page <= last_page and len(filtered_articles) == 0:
            novelty_search_pages_used += 1
            params = {
                "q": query,
                "page": next_page,
                "page-size": page_size,
                "show-fields": "bodyText,headline,wordcount,publication,section,sectionId,shortUrl,lastModified",
                "order-by": "relevance",
                "lang": "en"
            }
            try:
                guardian_requests_count += 1
                resp = client.request(params)
                extra_results = resp.get("response", {}).get("results", [])
                if not extra_results:
                    break
                
                guardian_pages_fetched_count += 1
                
                for r in extra_results:
                    fields = r.get("fields", {})
                    a = {
                        "url_canon": r.get("webUrl"),
                        "url": r.get("webUrl"),
                        "title": r.get("webTitle"),
                        "section": r.get("sectionId"),
                        "publication_date_utc": r.get("webPublicationDate"),
                        "body_text": fields.get("bodyText", "")
                    }
                    url = a["url_canon"]
                    text = a.get("body_text", "")
                    title_low = a.get("title", "").lower()
                    section_low = a.get("section", "").lower()
                    
                    if url in seen:
                        skipped_dedupe += 1
                        continue
                    
                    is_lb = "/live/" in url.lower() or "as it happened" in title_low or "rolling coverage" in title_low
                    is_cif = "/commentisfree/" in url.lower() or section_low == "commentisfree"
                    if is_lb or is_cif:
                        skipped_live += 1
                        continue
                    
                    if not text:
                        skipped_missing += 1
                        continue
                        
                    limit = 8000
                    if len(text) > limit:
                        text = text[:limit]
                        a["body_text"] = text
                        a["_was_truncated"] = True
                    else:
                        a["_was_truncated"] = False
                    
                    filtered_articles.append(a)
                    if len(filtered_articles) > 0:
                        break
                next_page += 1
            except Exception as e:
                logging.error(f"Novelty fetch failed page {next_page}: {e}")
                break
    
    # 5.5 Supply Band Halt Check (LOCKED SEMANTICS)
    supply_band_halt = False
    if not dry_run and cfg.get("run_mode", "DEV") == "RUN":
        if total_avail_captured > 2500:
            logging.warning(f"Lynn. SUPPLY BAND HALT: Found {total_avail_captured} candidates (> 2500).")
            supply_band_halt = True
            filtered_articles = []
            
            # Encode halt reason
            try:
                p_dict = json.loads(preflight_totals_json_str)
            except:
                p_dict = {}
            p_dict["note"] = "supply_band_halt"
            preflight_totals_json_str = json.dumps(p_dict)

    # 5.6 Deterministic Seeded Downsampling
    downsampled_from = len(filtered_articles)
    downsampled_to = downsampled_from
    downsample_seed = round_id * 1337
    
    if not supply_band_halt and downsampled_from > 100:
        random.seed(downsample_seed)
        filtered_articles = random.sample(filtered_articles, 100)
        downsampled_to = 100
        logging.info(f"Lynn. Downsampling: {downsampled_from} -> 100.")
        
    # Log downsample metrics for audit
    audit_log = {
        "downsampled_from": downsampled_from,
        "downsampled_to": downsampled_to,
        "downsample_seed": downsample_seed,
        "supply_band_halt": supply_band_halt
    }
    audit_dir = BASE_DIR / f"audits/round_{round_id}"
    audit_dir.mkdir(parents=True, exist_ok=True)
    with open(audit_dir / "round_integrity_audit.json", "w") as f:
        json.dump(audit_log, f, indent=2)

    # 6. Score
    scored_results = []
    if not supply_band_halt and filtered_articles:
        m1_scorer = Model1Scorer(BASE_DIR / "models/tgml")
        m3_scorer = Model3Scorer(BASE_DIR / "models/model3_best.pt", BASE_DIR / "configs/model_3.yaml")
        
        # Batch Score M1/M3 (Fast)
        logging.info("Scoring Model1...")
        try:
            m1_scores = m1_scorer.score(filtered_articles)
            logging.info(f"Model1 scored {len(m1_scores)} items.")
        except Exception as e:
            logging.error(f"Model1 scoring failed: {e}")
            raise e
    
        logging.info("Scoring Model3...")
        try:
            m3_scores = m3_scorer.score(filtered_articles)
            logging.info(f"Model3 scored {len(m3_scores)} items.")
        except Exception as e:
            logging.error(f"Model3 scoring failed: {e}")
            raise e
        
        # LLM Score (Slow)
        logging.info("Scoring LLM...")
        llm_scores = score_articles(filtered_articles, state, round_id=round_id, mock_llm=dry_run)
        
        # Merge
        merged_results = []
        for i, art in enumerate(filtered_articles):
            row = art.copy() # Metadata
            row.update(m1_scores[i])
            row.update(m3_scores[i])
            row.update(llm_scores[i])
            merged_results.append(row)
            
        scored_results = merged_results

        # CONTRACT V2: FATAL check — all 3 models must have all 7 scores per row
        REQUIRED_DIMS = ["decision", "rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
        REQUIRED_MODELS = ["model1", "model3", "llm_final"]
        fatal_violations = []
        for i, row in enumerate(scored_results):
            for mdl in REQUIRED_MODELS:
                for dim in REQUIRED_DIMS:
                    col = f"{mdl}_{dim}_score" if dim == "decision" else f"{mdl}_method_{dim}_score"
                    if col not in row or row[col] is None or (isinstance(row[col], float) and pd.isna(row[col])):
                        fatal_violations.append({"row_index": i, "url": row.get("url_canon", ""), "model": mdl, "dim": dim, "col": col})
        if fatal_violations:
            violation_path = audit_dir / "FATAL_contract_violation.json"
            with open(violation_path, "w") as f_viol:
                json.dump({"round_id": round_id, "violations": fatal_violations}, f_viol, indent=2)
            logging.error(f"FATAL: Contract violation — {len(fatal_violations)} missing scores. See {violation_path}")
            sys.exit(1)
    else:
        # Halted
        scored_results = []
        # No scoring done


    # 7. Update State (Bandit & Seen)
    if not dry_run:
        # We need to mark seen
        for a in filtered_articles:
            seen[a["url_canon"]] = round_id # Store round id as value
        state["seen_urls"] = seen
    
    # 8. Save Outputs
    output_dir = Path(f"outputs/rounds/round_{round_id}")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    df = pd.DataFrame(scored_results)
    
    # Save Candidates
    if articles:
        pd.DataFrame(articles).to_csv(output_dir / "candidates_raw.csv", index=False)
    else:
        pd.DataFrame(columns=["url_canon", "body_text", "title", "url", "section", "publication_date_utc"]).to_csv(output_dir / "candidates_raw.csv", index=False)
        
    # Save Filtered (Inputs to scoring)
    if filtered_articles:
        pd.DataFrame(filtered_articles).to_csv(output_dir / "candidates_filtered.csv", index=False)
    else:
         pd.DataFrame(columns=["url_canon", "body_text", "title", "url", "section", "publication_date_utc"]).to_csv(output_dir / "candidates_filtered.csv", index=False)
    
    # Save Scored Results Full (Parquet)
    parquet_path = output_dir / "scored_results_full.parquet"
    if not df.empty:
        df.to_parquet(parquet_path)
    else:
        # Empty parquet with correct columns (reconstruct from articles + model cols)
        cols = ["url_canon", "url", "title", "section", "publication_date_utc", "body_text"]
        # Add all model cols to satisfy schema
        methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
        for p in ["model1", "model3", "llm_sft", "llm_dpo", "llm_final"]:
            cols.append(f"{p}_decision_score")
            cols.append(f"{p}_decision_p1")
            for m in methods:
                 cols.append(f"{p}_method_{m}_score")
                 cols.append(f"{p}_method_{m}_p1")
        
        # Add Router/DPO flags
        cols.extend(["dpo_valid", "dpo_attempted", "dpo_fail_reason", "model_used"])
        
        pd.DataFrame(columns=cols).to_parquet(parquet_path)
    
    # Also save full scored set as CSV for debugging
    if not df.empty:
        df.to_csv(output_dir / "scored_set.csv", index=False)
    else:
        pd.DataFrame(columns=cols).to_csv(output_dir / "scored_set.csv", index=False)

    # CALL WRITER
    from src.round_outputs_writer import write_round_outputs
    try:
        write_round_outputs(round_id, parquet_path)
    except Exception as e:
        logging.error(f"Failed to write round outputs: {e}")
        # Fatal? Yes, contract expects them.
        raise e

    # Update Pools
    if not dry_run and not supply_band_halt:
        try:
             update_pools(round_id)
        except Exception as e:
             logging.error(f"Pool update failed: {e}")
             # Fatal? Contract says pool files matching logic. 
             # Let's fail hard to respect "FIX-ONLY means fix it".
             raise e

    # Cost Assessment
    cost_in = 0.0
    cost_out = 0.0
    total_in = 0
    total_out = 0
    round_cost = 0.0
    
    if not df.empty:
        # Check if 'total_tokens_in' exists (maybe empty round has columns but 0 rows)
        if 'total_tokens_in' in df.columns:
            total_in = df['total_tokens_in'].sum()
            total_out = df['total_tokens_out'].sum()
            
            p_in = cfg.get("openai_price_per_1m_input", 2.50)
            p_out = cfg.get("openai_price_per_1m_output", 10.00)
            
            cost_in = (total_in / 1_000_000) * p_in
            cost_out = (total_out / 1_000_000) * p_out
            round_cost = cost_in + cost_out

    # Save State
    if not dry_run and not supply_band_halt:
        state["cumulative_cost"] = state.get("cumulative_cost", 0.0) + round_cost
        
        # Validation: If we scored > 0 items and round_cost == 0, that's FATAL.
        # Unless SFT failed for all? 
        # Check successful SFT
        # In round_runner logic, we filter for scored items.
        # If len(df) > 0, we expect usage.
        if len(df) > 0 and round_cost == 0.0:
             logging.error("FATAL: Usage tokens missing (0) for scored items.")
             with open("audits/usage_missing.md", "w") as f:
                  f.write(f"FATAL: Usage tokens missing (0) for {len(df)} scored items.")
             sys.exit(1)
             
        with open(STATE_PATH, "w") as f:
            json.dump(state, f, indent=2)

    # 9. Log Metrics

    # 9. Log Metrics
    print("Computing metrics...")
    
    from src.round_outputs_writer import is_high_rel_single, compute_consensus, check_pass, load_thresholds
    load_thresholds()
    
    if not df.empty:
        m1_high = df[df.apply(lambda x: is_high_rel_single(x, "model1"), axis=1)]
        m3_high = df[df.apply(lambda x: is_high_rel_single(x, "model3"), axis=1)]
        
        # Consensus count
        cons_rows = [compute_consensus(r) for _, r in df.iterrows() if compute_consensus(r)]
        consensus_count = len(cons_rows)
        
        # DPO High (Hardcoded logic from recompute_round_metrics.py)
        def is_dpo_high_local(r):
            d = r.get("llm_dpo_decision_score", 0)
            p1 = r.get("llm_dpo_decision_p1", 0)
            return abs(d - 1.0) < 1e-6 and p1 >= 0.50
            
        if 'dpo_valid' in df.columns:
             dpo_high = df[(df['dpo_valid'] == True) & df.apply(is_dpo_high_local, axis=1)]
        else:
             dpo_high = pd.DataFrame()
             
        # Use llm_final for final count
        llm_final_high_count = len(df[df.apply(lambda x: is_high_rel_single(x, "llm_final"), axis=1)])
        # SFT specific high count for auditor parity
        llm_sft_high_count = len(df[df.apply(lambda x: is_high_rel_single(x, "llm_sft"), axis=1)])
    else:
        m1_high = pd.DataFrame()
        m3_high = pd.DataFrame()
        dpo_high = pd.DataFrame()
        consensus_count = 0
        llm_final_high_count = 0
        llm_sft_high_count = 0

    dpo_att = len(df[df['dpo_attempted'] == True]) if not df.empty and 'dpo_attempted' in df.columns else 0
    dpo_val = len(df[df['dpo_valid'] == True]) if not df.empty and 'dpo_valid' in df.columns else 0
    dpo_cb = int(df['dpo_circuit_breaker_triggered'].any()) if not df.empty and 'dpo_circuit_breaker_triggered' in df.columns else 0
    
    metrics = {
        "query_base": query,
        "query_final": query, # No enhancement yet
        "template_id": t_id,
        "target_method": m_name, # Explicit from Bandit
        "backoff_level_used": selected_level,
        "preflight_total_available": total_avail_captured, # Best proxy from preflight
        "preflight_totals_by_level_json": preflight_totals_json_str if 'preflight_totals_json_str' in locals() else "{}",
        "guardian_total_available": total_avail_captured, # Could parse from response
        "guardian_pages_fetched": guardian_pages_fetched_count,
        "guardian_page_size": cfg.get("guardian_page_size", 50),
        "guardian_candidates_retrieved": len(articles),
        "guardian_requests_this_round": guardian_requests_count,
        "guardian_keys_used": client.current_index + 1 if 'client' in locals() else 0,
        "guardian_key_rotations_this_round": client.total_rotations if 'client' in locals() else 0,
        "skipped_live_count": skipped_live,
        "skipped_long_count": skipped_long_count,  # CONTRACT V2: skip-not-truncate for >15000 chars
        "skipped_missing_text_count": skipped_missing,
        "skipped_dedupe_count": skipped_dedupe,
        "seen_urls_count": len(seen),
        "novelty_search_pages": novelty_search_pages_used,
        "scored_target_n": 100, "scored_count": len(filtered_articles),
        "random_seed_used": round_id * 1337,
        
        "high_rel_model1_count": len(m1_high),
        "high_rel_model3_count": len(m3_high),
        "high_rel_llm_sft_count": llm_sft_high_count,
        "high_rel_llm_final_count": llm_final_high_count,
        "high_rel_dpo_count": llm_sft_high_count,
        "consensus_high_rel_count": consensus_count,
        
        "new_unique_high_rel_count": 0, "overlap_high_rel_count": 0,
        "duplicate_rate_consensus": 0.0,
        
        "new_consensus_credit_rct": 0.0,
        "new_consensus_credit_prepost": 0.0,
        "new_consensus_credit_case_study": 0.0,
        "new_consensus_credit_expert_qual": 0.0,
        "new_consensus_credit_expert_secondary": 0.0,
        "new_consensus_credit_gut": 0.0,
        
        "new_llm_rct": 0,
        "new_llm_prepost": 0,
        "new_llm_case_study": 0,
        "new_llm_expert_qual": 0,
        "new_llm_expert_secondary": 0,
        "new_llm_gut": 0,
        
        "llm_high_count": llm_final_high_count,
        "dpo_attempted_count": dpo_att,
        "dpo_valid_count": dpo_val,
        "dpo_success_rate": 0.0,
        "dpo_high_count": len(dpo_high),
        
        "llm_mode_used_counts_json": json.dumps(df['model_used'].value_counts().to_dict()) if not df.empty and 'model_used' in df.columns else "{}",
        "dpo_fail_reason_counts_json": json.dumps(df['dpo_fail_reason'].value_counts().to_dict()) if not df.empty and 'dpo_fail_reason' in df.columns else "{}",
        "dpo_circuit_breaker_triggered": dpo_cb,
        
        "reward_R": 0.0,
        "reward_V": min(1.0, len(df)/100.0),
        "reward_U_all": 0.0,
        "reward_U_llm": 0.0,
        "reward_DUP": 0.0,
        "reward_weight_alpha": cfg.get("reward_weight_alpha", 0.25),
        "reward_weight_beta": cfg.get("reward_weight_beta", 0.15),
        "reward_weight_gamma": cfg.get("reward_weight_gamma", 0.60),
        "reward_weight_delta": cfg.get("reward_weight_delta", 0.20),
        "reward_p": 1.5,
        
        "query_budget_cap_usd": cfg.get("query_scoring_cap_usd", 60.0),
        "query_cost_this_round_usd": round_cost,
        "query_cost_cumulative_usd": state.get("cumulative_cost", 0.0),
        
        "query_spaces_sha256": q_hash,
        "templates_sha256": hashes.get("templates", "MISSING"),
        "contract_sha256": hashes.get("contract", "MISSING"),
        "config_sha256": hashes.get("config_v2", "MISSING"),
        "code_sha256_bundle": hashes.get("code_bundle", "MISSING")
    }
    
    if dpo_att > 0:
        metrics["dpo_success_rate"] = dpo_val / dpo_att
        
    if not dry_run:
        print(f"Calling append_query_log for Round {round_id}...")
        append_query_log(round_id, metrics)
        print("Query log appended.")
    
    
    # Audits
    if not dry_run:
        validate_round_outputs(round_id)
        validate_query_log()
        validate_llm_router_health(round_id)
    
    # Recompute
    if not dry_run:
        recompute_round_metrics(round_id)
    
    logging.info(f"Round {round_id} complete.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--round_id", type=int, default=1)
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()
    
    run_round(args.round_id, dry_run=args.dry_run)
