import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI()

model_name = "ft:gpt-4.1-mini-2025-04-14:personal::DAbS3xSo"

print(f"Testing model: {model_name} with temperature=0.0")

try:
    resp = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": "Score this as 1: 'The council decided to fund the scheme based on the trial results.'"}],
        max_completion_tokens=100,
        temperature=0.0
    )
    print(f"Response: '{resp.choices[0].message.content}'")
except Exception as e:
    print(f"Error: {e}")
