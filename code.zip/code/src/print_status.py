
import sys
import json
import os
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
STATE_PATH = BASE_DIR / "project_state/STATE.json"
QUERY_LOG_PATH = BASE_DIR / "outputs/query_log.csv"
LEDGER_PATH = BASE_DIR / "project_state/COST_LEDGER.json"
HASH_FILE = BASE_DIR / "project_state/QUERY_SPACES_HASH.json"
TEMPLATES_HASH = BASE_DIR / "project_state/LOCKDOWN_HASHES.json" # Best guess

def main():
    # 1. Last completed round
    last_round = 0
    if QUERY_LOG_PATH.exists():
        df = pd.read_csv(QUERY_LOG_PATH)
        if not df.empty and "round_id" in df.columns:
            last_round = df["round_id"].max()
            
    # 2. Budget Remaining
    budget_remaining = "Unknown"
    if LEDGER_PATH.exists():
        with open(LEDGER_PATH) as f:
            ledger = json.load(f)
            # Assuming ledger has "total_spent" or similar, and CONFIG has cap.
            # But prompt says "budget remaining".
            # We can check config or just print "spent so far".
            # Prompt asked for "budget remaining".
            # We need to know the CAP.
            # Config loader needed.
            try:
                from src.config_loader import get_config
                cfg = get_config()
                cap = cfg.get("query_budget_cap_usd", 60.0)
                spent = ledger.get("total_spent_usd", 0.0)
                budget_remaining = f"${cap - spent:.2f} (Cap: ${cap}, Spent: ${spent:.2f})"
            except Exception:
                budget_remaining = f"Spent: ${ledger.get('total_spent_usd', 0.0):.2f}"
    
    # 3. Pool Progress
    pool_msg = "Pool Progress:\n"
    pools_dir = BASE_DIR / "outputs/pools"
    # Iterate known methods or scan dir?
    # Prompt: "overall credits / 35, llm count / 100"
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    for m in methods:
        # pool_{method}_consensus.csv
        p_cons = pools_dir / f"pool_{m}_consensus.csv"
        credits = 0.0
        if p_cons.exists():
            df_c = pd.read_csv(p_cons)
            if "credit" in df_c.columns:
                credits = df_c["credit"].sum()
        
        # pool_{method}_llm.csv
        p_llm = pools_dir / f"pool_{m}_llm.csv"
        llm_count = 0
        if p_llm.exists():
            df_l = pd.read_csv(p_llm)
            llm_count = len(df_l)
            
        pool_msg += f"  - {m:<15}: Credits {credits:.2f}/35, LLM {llm_count}/100\n"
        
    # 4. DPO Success Rate Rolling Avg (last 5)
    dpo_msg = "DPO Success Rate (Last 5): N/A"
    if QUERY_LOG_PATH.exists():
        df = pd.read_csv(QUERY_LOG_PATH)
        if "dpo_success_rate" in df.columns and not df.empty:
            last_5 = df.tail(5)
            # Weighted? Or just simple average of rate?
            # Or sum(valid)/sum(attempted)?
            # Prompt says "DPO success rate rolling average".
            # I'll calculate total_valid / total_attempted for last 5 rounds.
            valid = last_5["dpo_valid_count"].sum()
            att = last_5["dpo_attempted_count"].sum()
            if att > 0:
                rate = valid / att
                dpo_msg = f"{rate:.1%} ({valid}/{att})"
            else:
                dpo_msg = "0.0% (0/0)"

    # 5. Hashes
    qs_hash = "MISSING"
    if HASH_FILE.exists():
        with open(HASH_FILE) as f:
            qs_hash = json.load(f).get("query_spaces_sha256", "MISSING")
            
    tpl_hash = "MISSING"
    # Check LOCKDOWN_HASHES.json for templates
    lock_file = BASE_DIR / "project_state/LOCKDOWN_HASHES.json"
    if lock_file.exists():
        with open(lock_file) as f:
            tpl_hash = json.load(f).get("templates", "MISSING")
            
    print(f"Status Report")
    print(f"-------------")
    print(f"Last Completed Round: {last_round}")
    print(f"Budget Remaining:     {budget_remaining}")
    print(dpo_msg)
    print(f"Hashes:")
    print(f"  Query Spaces: {qs_hash[:16]}...")
    print(f"  Templates:    {tpl_hash[:16]}...")
    print(pool_msg)

if __name__ == "__main__":
    main()
