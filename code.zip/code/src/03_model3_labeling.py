import pandas as pd
import numpy as np
import yaml
import re
import json
from pathlib import Path
from tqdm import tqdm

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "concepts.yaml"
INPUT_CSV = ROOT / "outputs" / "master_vector.csv"
OUTPUT_PARQUET = ROOT / "data" / "concept_labels.parquet"
REPORT_PATH = ROOT / "reports" / "concept_label_audit.md"

def load_concepts():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

def apply_labeling():
    concepts_cfg = load_concepts()
    print(f"Loading {INPUT_CSV}...")
    df = pd.read_csv(INPUT_CSV)
    
    # Flatten concepts
    all_concepts = {}
    for group in ["decision_concepts", "general_method_concepts", "method_specific_concepts"]:
        all_concepts.update(concepts_cfg.get(group, {}))
    
    # Text fields
    df["title"] = df["title"].fillna("")
    df["body"] = df["body"].fillna("")
    df["full_text"] = df["title"] + "\n\n" + df["body"]
    
    results = []
    
    print("Applying weak labeling functions...")
    for idx, row in tqdm(df.iterrows(), total=len(df)):
        text = row["full_text"]
        item_labels = {"url_canon": row["url_canon"]}
        
        for cid, spec in all_concepts.items():
            label = -1  # ABSTAIN
            matches = []
            
            for pattern in spec["regex"]:
                for m in re.finditer(pattern, text):
                    label = 1
                    matches.append([m.start(), m.end()])
            
            item_labels[f"{cid}_label"] = label
            item_labels[f"{cid}_rationales"] = matches
            
        results.append(item_labels)
        
    labels_df = pd.DataFrame(results)
    
    # Save output
    OUTPUT_PARQUET.parent.mkdir(parents=True, exist_ok=True)
    labels_df.to_parquet(OUTPUT_PARQUET)
    print(f"Labels saved to {OUTPUT_PARQUET}")
    
    # Audit Report
    audit_lines = ["# Concept Label Audit Report\n"]
    audit_lines.append(f"**Total rows**: {len(labels_df)}\n")
    audit_lines.append("| Concept | Coverage | Positive | Abstain | Avg Matches |")
    audit_lines.append("|---------|----------|----------|---------|-------------|")
    
    for cid in all_concepts.keys():
        lbl_col = f"{cid}_label"
        rat_col = f"{cid}_rationales"
        
        pos = (labels_df[lbl_col] == 1).sum()
        abstain = (labels_df[lbl_col] == -1).sum()
        coverage = pos / len(labels_df)
        avg_matches = labels_df[rat_col].apply(len).mean()
        
        audit_lines.append(f"| {cid} | {coverage:.1%} | {pos} | {abstain} | {avg_matches:.1f} |")
        
    # Sample matches
    audit_lines.append("\n## Sample Matches (Top Concepts)")
    for cid in sorted(all_concepts.keys())[:5]: # Show first 5 for brevity
        audit_lines.append(f"\n### {cid}")
        pos_samples = labels_df[labels_df[f"{cid}_label"] == 1].sample(min(3, pos)) if pos > 0 else []
        for _, sample_row in pos_samples.iterrows():
            url = sample_row["url_canon"]
            rats = sample_row[f"{cid}_rationales"]
            # get unique text for this url from main df
            raw_text = df[df["url_canon"] == url]["full_text"].values[0]
            snippets = []
            for start, end in rats[:2]: # Show first 2 spans
                snip = raw_text[max(0, start-30):min(len(raw_text), end+30)].replace("\n", " ")
                snippets.append(f"...{snip}...")
            audit_lines.append(f"- **URL**: {url}")
            audit_lines.append(f"  - Snippets: {' | '.join(snippets)}")

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\n".join(audit_lines))
    print(f"Report written to {REPORT_PATH}")

if __name__ == "__main__":
    apply_labeling()
