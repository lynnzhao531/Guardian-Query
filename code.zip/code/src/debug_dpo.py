import os
import json
from openai import OpenAI
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
REPORTS_DIR = ROOT / "reports"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

JOB_ID = "ftjob-ktnOxIzFH7JMbxzIQDcS59Mq"

def main():
    client = OpenAI()
    
    print(f"Retrieving info for job: {JOB_ID}...")
    try:
        job = client.fine_tuning.jobs.retrieve(JOB_ID)
        
        # Safely extract hyperparameters
        hp = {}
        if hasattr(job, "hyperparameters") and job.hyperparameters:
            hp = {
                "n_epochs": getattr(job.hyperparameters, "n_epochs", None),
                "batch_size": getattr(job.hyperparameters, "batch_size", None),
                "learning_rate_multiplier": getattr(job.hyperparameters, "learning_rate_multiplier", None)
            }

        job_data = {
            "id": job.id,
            "status": job.status,
            "model": job.model,
            "fine_tuned_model": job.fine_tuned_model,
            "hyperparameters": hp
        }
        print(f"Job status: {job.status}")
        
        print(f"Listing checkpoints...")
        checkpoints = client.fine_tuning.jobs.checkpoints.list(JOB_ID)
        ckpt_list = []
        for ckpt in checkpoints:
            ckpt_list.append({
                "id": ckpt.id,
                "model_n": ckpt.fine_tuned_model_checkpoint,
                "step_number": ckpt.step_number,
                "metrics": {
                    "step": ckpt.metrics.step,
                    "train_loss": ckpt.metrics.train_loss,
                    "train_mean_token_accuracy": ckpt.metrics.train_mean_token_accuracy,
                    "valid_loss": ckpt.metrics.valid_loss,
                    "valid_mean_token_accuracy": ckpt.metrics.valid_mean_token_accuracy
                }
            })
            print(f"  - Step {ckpt.step_number}: {ckpt.fine_tuned_model_checkpoint}")
            
        output = {
            "job": job_data,
            "checkpoints": ckpt_list
        }
        
        out_path = REPORTS_DIR / "dpo_checkpoints.json"
        with open(out_path, "w") as f:
            json.dump(output, f, indent=2)
            
        print(f"\n✓ Saved checkpoint info to {out_path}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
