import os
import json
from openai import OpenAI
from pathlib import Path

def get_api_key():
    env_path = Path(".env")
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=get_api_key())
job_id = "ftjob-iEA3z0q21gdqxeHMi2nI0tRH"

try:
    job = client.fine_tuning.jobs.retrieve(job_id)
    events = client.fine_tuning.jobs.list_events(fine_tuning_job_id=job_id, limit=50)
    
    output = {
        "job": job.model_dump(),
        "events": [e.model_dump() for e in events.data]
    }
    print(json.dumps(output, indent=2))
except Exception as e:
    print(json.dumps({"error": str(e)}))
