import time
import os
import sys
from openai import OpenAI
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    if len(sys.argv) < 2:
        print("Usage: python poll_dpo_job.py <job_id>")
        sys.exit(1)
        
    job_id = sys.argv[1]
    client = OpenAI(api_key=get_api_key())
    
    print(f"Polling job {job_id}...")
    
    while True:
        try:
            job = client.fine_tuning.jobs.retrieve(job_id)
            print(f"Status: {job.status}")
            if job.status in ["succeeded", "failed", "cancelled"]:
                break
            time.sleep(30)
        except Exception as e:
            print(f"Error polling: {e}")
            time.sleep(30)
            
    # Write report
    report = [
        "# DPO v2 Job Result",
        f"- **Job ID**: {job.id}",
        f"- **Status**: {job.status}",
        f"- **Fine Tuned Model**: `{job.fine_tuned_model}`",
        f"- **Trained Tokens**: {job.trained_tokens}"
    ]
    
    rep_path = BASE_DIR / "reports/dpo_job_result.md"
    with open(rep_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"\nJob completed with status {job.status}.")
    print(f"Report written to {rep_path}.")
    
    # Save parameters to state
    import json
    state_path = BASE_DIR / "project_state/STATE.json"
    if state_path.exists():
        with open(state_path, "r") as f:
            state = json.load(f)
            
        if job.status == "succeeded":
            state["dpo_model_name"] = job.fine_tuned_model
            state["latest_dpo_job_id"] = job.id
            state["dpo_generation_kwargs"] = {"temperature": 0.0, "max_tokens": 250}
            with open(state_path, "w") as f:
                json.dump(state, f, indent=2)
            print("State updated with new model name and generation kwargs.")

if __name__ == "__main__":
    main()
