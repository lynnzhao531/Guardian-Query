import pandas as pd
import json
from pathlib import Path
import os
import sys

# Load Thresholds
THRESHOLDS_FILE = Path("project_state/PER_MODEL_THRESHOLDS.json")
if not THRESHOLDS_FILE.exists():
    print(f"Error: {THRESHOLDS_FILE} missing.")
    sys.exit(1)

with open(THRESHOLDS_FILE, "r") as f:
    THRESHOLDS = json.load(f)

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

def get_topset(row, prefix, eps=0.05, exclude_expert_qual=False):
    scores = {}
    for m in METHOD_NAMES:
        if exclude_expert_qual and m == "expert_qual":
            continue
        scores[m] = row.get(f"{prefix}_method_{m}_p1", 0.0)
    
    if not scores:
        return set()
    
    max_val = max(scores.values())
    return {m for m, v in scores.items() if v >= (max_val - eps)}

def audit_round(round_id):
    parquet_path = Path(f"outputs/rounds/round_{round_id}/scored_results_full.parquet")
    if not parquet_path.exists():
        print(f"Error: {parquet_path} missing.")
        return
        
    df = pd.read_parquet(parquet_path)
    
    # We need check_pass_dec for the expert exception
    from src.round_outputs_writer import check_pass, check_pass_dec, check_pass_meth
    
    # Identify articles that at least passed the LLM Decision gate
    # (High decision score, regardless of method gate)
    df["llm_dec_pass"] = df["llm_final_decision_score"] == 1.0
    llm_passes = df[df["llm_dec_pass"] == True].copy()
    
    print(f"Audit Round {round_id}: Found {len(llm_passes)} articles where LLM Decision == 1.0.")
    
    t_meth_m3 = THRESHOLDS["model3"]["t_meth"]
    
    results = []
    
    for _, row in llm_passes.iterrows():
        # 1. Model 3 Method Gate
        m3_meth_p1s = [row.get(f"model3_method_{m}_p1", 0.0) for m in METHOD_NAMES if m != "expert_qual"]
        m3_max_p1 = max(m3_meth_p1s) if m3_meth_p1s else 0.0
        m3_meth_gate_pass = m3_max_p1 >= t_meth_m3
        
        # 2. Agreement
        ts_llm = get_topset(row, "llm_final", eps=0.02)
        ts_m3 = get_topset(row, "model3", eps=0.02, exclude_expert_qual=True)
        intersection = ts_llm.intersection(ts_m3)
        agreement_pass = len(intersection) > 0
        
        # 3. Expert Exception
        llm_scores = {m: row.get(f"llm_final_method_{m}_p1", 0.0) for m in METHOD_NAMES}
        llm_best = max(llm_scores, key=llm_scores.get) if llm_scores else "none"
        
        expert_exception_triggered = False
        if llm_best == "expert_qual":
            t_meth_llm = THRESHOLDS.get("llm_final", {}).get("t_meth", 1.0)
            m1_dec_pass = check_pass_dec(row, "model1")
            if llm_scores["expert_qual"] >= (t_meth_llm + 0.1) or m1_dec_pass:
                expert_exception_triggered = True
        
        consensus_pass = (m3_meth_gate_pass and agreement_pass) or expert_exception_triggered
        
        results.append({
            "url": row["url_canon"],
            "title": row["title"][:50],
            "llm_best": llm_best,
            "m3_max_p1": round(m3_max_p1, 4),
            "m3_meth_gate": "PASS" if m3_meth_gate_pass else "FAIL",
            "agreement": "PASS" if agreement_pass else "FAIL",
            "expert_exception": "YES" if expert_exception_triggered else "NO",
            "final": "CONSENSUS" if consensus_pass else "BLOCKED",
            "llm_topset": list(ts_llm),
            "m3_topset": list(ts_m3),
            "intersection": list(intersection)
        })
        
    results_df = pd.DataFrame(results)
    
    if results_df.empty:
        report = f"# Consensus Audit - Round {round_id}\n\nNo high-relevance LLM articles found to audit."
    else:
        # Sort for near-misses
        results_df = results_df.sort_values(["final", "m3_max_p1"], ascending=[False, False])
        md_table = results_df.to_markdown(index=False)
        
        blocked = results_df[results_df["final"] == "BLOCKED"]
        m3_blocked = len(blocked[blocked["m3_meth_gate"] == "FAIL"])
        agr_blocked = len(blocked[(blocked["m3_meth_gate"] == "PASS") & (blocked["agreement"] == "FAIL")])
        
        report = f"""# Consensus Audit - Round {round_id}

## Summary
- **LLM High Relevance Articles**: {len(llm_passes)}
- **Consensus Articles**: {len(results_df[results_df["final"] == "CONSENSUS"])}
- **Blocked Articles**: {len(blocked)}

### Blockers Analysis
- **Blocked by Model 3 Method Gate**: {m3_blocked}
- **Blocked by Agreement (TopSet intersection empty)**: {agr_blocked}

## Details
{md_table}

## Interpretation
- If many are blocked by **Model 3 Method Gate**, consider decreasing `model3.t_meth`.
- If many are blocked by **Agreement**, consider increasing `eps`.
"""

    os.makedirs("reports", exist_ok=True)
    report_path = "reports/round29_consensus_blockers.md"
    with open(report_path, "w") as f:
        f.write(report)
    
    print(f"Report written to {report_path}")
    if not results_df.empty:
        print("\nTop 10 Near-Misses/Results:")
        print(results_df.head(10).to_string(index=False))

if __name__ == "__main__":
    if len(sys.argv) > 1:
        audit_round(int(sys.argv[1]))
    else:
        audit_round(29)
