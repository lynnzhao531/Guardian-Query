import json

REQUIRED_DIMS = {
    "decision",
    "method_rct",
    "method_prepost",
    "method_case_study",
    "method_expert_qual",
    "method_expert_secondary",
    "method_gut"
}

REQUIRED_KEYS = {"score", "p0", "p05", "p1"}
VALID_SCORES = {0.0, 0.5, 1.0}

def validate_nested_schema(json_str: str) -> list[str]:
    """
    Validates the parsed JSON against the strict 7-dimension production schema.
    Returns a list of error tags (empty list if valid).
    """
    errors = []
    
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        return ["invalid_json"]
        
    if not isinstance(data, dict):
        return ["not_json_object"]
        
    keys = set(data.keys())
    
    # Check exact keys
    if keys != REQUIRED_DIMS:
        missing = REQUIRED_DIMS - keys
        extra = keys - REQUIRED_DIMS
        if missing: errors.append(f"missing_dims:_{','.join(missing)}")
        if extra: errors.append(f"extra_dims:_{','.join(extra)}")
        
    # Check each dimension
    for dim in REQUIRED_DIMS:
        if dim not in data: continue
        
        dim_obj = data[dim]
        if not isinstance(dim_obj, dict):
            errors.append(f"dim_not_object_{dim}")
            continue
            
        dim_keys = set(dim_obj.keys())
        if dim_keys != REQUIRED_KEYS:
            errors.append(f"dim_{dim}_bad_keys")
            continue
            
        score = dim_obj["score"]
        p0 = dim_obj["p0"]
        p05 = dim_obj["p05"]
        p1 = dim_obj["p1"]
        
        if score not in VALID_SCORES:
            errors.append(f"dim_{dim}_invalid_score_{score}")
            
        for prob, p_name in [(p0, "p0"), (p05, "p05"), (p1, "p1")]:
            if not isinstance(prob, (int, float)) or not (0.0 <= prob <= 1.0):
                errors.append(f"dim_{dim}_invalid_prob_{p_name}")
                
        # Optional: check approx sum to 1.0
        if isinstance(p0, (int, float)) and isinstance(p05, (int, float)) and isinstance(p1, (int, float)):
            total_prob = p0 + p05 + p1
            if abs(total_prob - 1.0) > 1e-6:
                errors.append(f"dim_{dim}_probs_dont_sum_to_1")
                
    return errors

if __name__ == "__main__":
    # Test valid
    valid_json = '{"decision": {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}, "method_rct": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}, "method_prepost": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}, "method_case_study": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}, "method_expert_qual": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}, "method_expert_secondary": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}, "method_gut": {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}}'
    print(f"Valid test: {validate_nested_schema(valid_json)}")
    
    # Test invalid keys
    inv_keys = '{"decision": {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}}'
    print(f"Missing keys test: {validate_nested_schema(inv_keys)}")
    
    # Test invalid score
    inv_score = valid_json.replace('"score": 1.0', '"score": 0.4')
    print(f"Invalid score test: {validate_nested_schema(inv_score)}")
    
    # Test sum to 1
    inv_sum = valid_json.replace('"p0": 0.0, "p05": 0.05, "p1": 0.95', '"p0": 0.5, "p05": 0.5, "p1": 0.5')
    print(f"Prob sum test: {validate_nested_schema(inv_sum)}")
