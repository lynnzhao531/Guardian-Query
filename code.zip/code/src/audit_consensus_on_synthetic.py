import pandas as pd
import json
import sys
import os
from pathlib import Path

# Add src to path
sys.path.append(os.getcwd())

from src.round_outputs_writer import compute_consensus, check_pass_dec, check_pass_meth

def main():
    pq_path = "reports/synthetic_benchmark_full.parquet"
    if not Path(pq_path).exists():
        print(f"Error: {pq_path} not found. Run eval_synthetic_benchmark.py first.")
        return

    df = pd.read_parquet(pq_path)
    
    # 1. Labels
    # Traps: startswith('f') or gold_dec < 1.0
    df["is_trap"] = df["id"].str.startswith("f") | (df["gold_dec"] < 1.0)
    
    # 2. Apply Consensus logic
    results = []
    for _, row in df.iterrows():
        res = compute_consensus(row)
        passed = (res is not None)
        
        # Diagnostics
        diag = {
            "id": row["id"],
            "is_trap": row["is_trap"],
            "passed": passed,
            "llm_dec_gate": check_pass_dec(row, "llm_final"),
            "m3_meth_gate": check_pass_meth(row, "model3"),
            # Note: Agreement is internal to compute_consensus
        }
        results.append(diag)
        
    res_df = pd.DataFrame(results)
    
    print("\n" + "="*50)
    print("CONSENSUS AUDIT ON SYNTHETIC BENCHMARK")
    print("="*50)
    print(res_df.to_string(index=False))
    
    traps_passed = res_df[res_df["is_trap"] & res_df["passed"]]
    prototypes_passed = res_df[~res_df["is_trap"] & res_df["passed"]]
    
    print(f"\nTraps Passed: {len(traps_passed)}")
    print(f"Prototypes Passed: {len(prototypes_passed)}")
    
    # Assertions per Revision C
    assert len(traps_passed) == 0, f"FAILURE: {len(traps_passed)} traps passed consensus!"
    assert len(prototypes_passed) >= 1, f"FAILURE: Only {len(prototypes_passed)} prototypes passed consensus (expected >= 1)!"
    
    if len(prototypes_passed) < 2:
         print("WARNING: Only 1 prototype passed. Yield is low.")
    else:
         print(f"SUCCESS: {len(prototypes_passed)} prototypes passed. Yield is healthy.")

    print("\nGate Breakdown (Reasons for failure):")
    for _, row in res_df[~res_df["passed"]].iterrows():
        reasons = []
        if not row["llm_dec_gate"]: reasons.append("LLM Decision Gate")
        if not row["m3_meth_gate"]: reasons.append("M3 Method Gate")
        # Agreement is hard to show here without mirroring logic but we know it failed if both gates passed
        if row["llm_dec_gate"] and row["m3_meth_gate"]:
             reasons.append("Method Agreement")
        print(f"{row['id']}: {', '.join(reasons)}")

if __name__ == "__main__":
    main()
