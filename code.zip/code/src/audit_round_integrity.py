import pandas as pd
import json
from pathlib import Path
import sys
import os

def audit_round(round_id):
    print(f"--- Auditing Round {round_id} ---")
    round_dir = Path(f"outputs/rounds/round_{round_id}")
    audit_dir = Path(f"audits/round_{round_id}")
    log_path = Path("outputs/query_log.csv")
    
    # 1. Check Query Log Entry
    if not log_path.exists():
        raise FileNotFoundError("query_log.csv missing.")
    query_log = pd.read_csv(log_path)
    round_log = query_log[query_log["round_id"] == round_id]
    if round_log.empty:
        raise ValueError(f"Invarant Failure: No entry for Round {round_id} in query_log.csv")
    row = round_log.iloc[-1]

    # 2. Check CSV Existence + Rows
    required_csvs = {
        "model1": f"round_{round_id}_model1_papers.csv",
        "model3": f"round_{round_id}_model3_papers.csv",
        "SFT": f"round_{round_id}_SFT_papers.csv",
        "DPO": f"round_{round_id}_DPO_papers.csv",
        "high_relevant": f"round_{round_id}_high_relevant_papers.csv"
    }
    
    results = {}
    for key, filename in required_csvs.items():
        csv_path = round_dir / filename
        if not csv_path.exists():
             raise FileNotFoundError(f"Invarant Failure: Missing {csv_path}")
        df = pd.read_csv(csv_path)
        results[key] = len(df)
        
        # Check mandatory metadata headers
        required_metadata = ["url_canon", "url", "title", "section", "publication_date_utc", "body_text"]
        for col in required_metadata:
            if col not in df.columns:
                raise ValueError(f"Invarant Failure: Missing metadata column {col} in {filename}")

    # 3. CSV Row Counts vs Log Metrics (Parity)
    def check_csv(fname, expected_count):
        csv_path = round_dir / fname
        if expected_count > 0:
            if not csv_path.exists():
                 raise FileNotFoundError(f"Integrity Failure: {fname} missing but log says {expected_count}")
            count = len(pd.read_csv(csv_path))
            if count != expected_count:
                raise RuntimeError(f"Audit Failure: {fname} count ({count}) != log ({expected_count})")
        elif csv_path.exists():
            count = len(pd.read_csv(csv_path))
            if count > 0:
                raise RuntimeError(f"Audit Failure: {fname} has {count} rows but log says 0")

    check_csv(f"round_{round_id}_model1_papers.csv", int(row["high_rel_model1_count"]))
    check_csv(f"round_{round_id}_model3_papers.csv", int(row["high_rel_model3_count"]))
    # Fallback for old rounds that don't have high_rel_llm_sft_count
    sft_expected = int(row.get("high_rel_llm_sft_count", row.get("high_rel_llm_final_count", 0)))
    check_csv(f"round_{round_id}_SFT_papers.csv", sft_expected)
    check_csv(f"round_{round_id}_high_relevant_papers.csv", int(row["consensus_high_rel_count"]))

    # 4. Filtering Sanity
    retrieved = row.get("guardian_candidates_retrieved", 0)
    skipped_live = row.get("skipped_live_count", 0)
    skipped_text = row.get("skipped_missing_text_count", 0)
    remaining = row.get("filtered_remaining_count", 0)
    scored_count = int(row["scored_count"])
    cons_count = int(row["consensus_high_rel_count"])
    
    if (skipped_live + skipped_text + remaining) > retrieved:
         raise RuntimeError(f"Audit Failure: Filtering counts ({skipped_live}+{skipped_text}+{remaining}) exceed retrieved ({retrieved})")

    # 5. Pool Update Sanity
    pool_audit_path = audit_dir / "pool_update_audit.json"
    if not pool_audit_path.exists():
        raise FileNotFoundError(f"Pool update audit missing at {pool_audit_path}")
    
    with open(pool_audit_path, "r") as f:
        pool_audit = json.load(f)
        
    llm_high_count = int(row["high_rel_llm_final_count"])
    appended_llm = pool_audit.get("llm_rows_appended", 0)
    appended_overall = pool_audit.get("overall_rows_appended", 0)
    skipped_dupes = pool_audit.get("duplicates_skipped", 0)
    
    if llm_high_count > 0:
        if appended_llm <= 0 and skipped_dupes <= 0:
             raise RuntimeError(f"Pool Failure: LLM High Rel ({llm_high_count}) but 0 appended/skipped.")
             
    if cons_count > 0:
        if appended_overall <= 0 and skipped_dupes <= 0:
             raise RuntimeError(f"Pool Failure: Consensus High Rel ({cons_count}) but 0 appended/skipped.")

    # 6. Downsampling Sanity
    # Load runner's audit if it exists
    runner_audit_path = audit_dir / "round_integrity_audit.json"
    runner_audit = {}
    if runner_audit_path.exists():
        with open(runner_audit_path, "r") as f:
            runner_audit = json.load(f)

    if remaining > 100:
        if scored_count != 100:
            raise RuntimeError(f"Downsample Failure: filtered_remaining ({remaining}) > 100 but scored_count ({scored_count}) != 100")
        if runner_audit.get("downsampled_to") != 100:
             raise RuntimeError(f"Downsample Failure: Runner audit did not confirm 100 articles.")

    # 7. Write Final Audit Reports
    audit_results = {
        "round_id": int(round_id),
        "timestamp": pd.Timestamp.utcnow().isoformat(),
        "status": "PASS",
        "metrics": {
            "retrieved": int(retrieved),
            "filtered": int(remaining),
            "scored": int(scored_count),
            "consensus": int(cons_count),
            "llm_high": int(llm_high_count)
        },
        "row_counts": {k: int(v) for k, v in results.items()},
        "pool_updates": pool_audit,
        "runner_integrity": runner_audit
    }
    
    with open(audit_dir / "round_integrity_final.json", "w") as f:
        json.dump(audit_results, f, indent=2)
        
    with open(audit_dir / "round_integrity_final.md", "w") as f:
        f.write(f"# Round {round_id} Integrity Audit: PASS\n\n")
        f.write(f"- **Retrieved**: {retrieved}\n")
        f.write(f"- **Filtered Remaining**: {remaining}\n")
        f.write(f"- **Scored**: {scored_count}\n")
        f.write(f"- **Consensus High Rel**: {cons_count}\n")
        f.write("- **Pool Status**: OK\n")
        if runner_audit.get("downsampled_to") == 100:
            f.write(f"- **Downsampling**: Applied ({runner_audit.get('downsampled_from')} -> 100)\n")
            
    print(f"Round {round_id} Audit: PASSED")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python src/audit_round_integrity.py <round_id>")
        sys.exit(1)
    audit_round(int(sys.argv[1]))
