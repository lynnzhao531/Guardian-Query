#!/usr/bin/env python3
"""
Step 8: Monitor fine-tuning jobs — polls status, streams events, checks budgets.
Watches both SFT and DPO jobs.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import yaml
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


def monitor_job(client, job_id: str, label: str, state: dict, ledger: dict,
                cfg: dict, poll_interval: int = 30, max_polls: int = 200):
    """Poll a fine-tuning job until completion or failure."""
    print(f"\n── Monitoring {label}: {job_id} ──")

    for poll in range(max_polls):
        job = client.fine_tuning.jobs.retrieve(job_id)
        status = job.status
        print(f"  [{time.strftime('%H:%M:%S')}] Status: {status}")

        if status == "succeeded":
            model_name = job.fine_tuned_model
            print(f"\n  ✓ {label} SUCCEEDED: {model_name}")
            state["latest_finetuned_model_name"] = model_name

            # Release reserved budget, record actual
            actual_cost = 0  # OpenAI doesn't expose fine-tuning cost via API easily
            # Use our shard estimate as proxy
            if "sft" in label.lower():
                shards = state.get("sft_shards", [])
                actual_cost = shards[0].get("estimated_cost_usd", 0) if shards else 0
            elif "dpo" in label.lower():
                shards = state.get("dpo_shards", [])
                actual_cost = shards[0].get("estimated_cost_usd", 0) if shards else 0

            ledger["total_spent_usd"] = round(ledger["total_spent_usd"] + actual_cost, 2)
            ledger["outstanding_reserved_budget_usd"] = max(
                0, round(ledger["outstanding_reserved_budget_usd"] - actual_cost, 2)
            )
            ledger["remaining_budget_usd"] = round(
                cfg["budget"]["total_cap_usd"] - ledger["total_spent_usd"]
                - ledger["outstanding_reserved_budget_usd"], 2
            )
            ledger["per_step_costs"].append({
                "step": label, "cost_usd": actual_cost,
            })
            save_ledger(ledger)
            save_state(state)
            return model_name

        elif status == "failed":
            print(f"\n  ✗ {label} FAILED")
            if hasattr(job, "error") and job.error:
                print(f"  Error: {job.error}")
            return None

        elif status == "cancelled":
            print(f"\n  ✗ {label} CANCELLED")
            return None

        # Check for budget overrun — pause if needed
        cap = cfg["budget"]["total_cap_usd"]
        if ledger["total_spent_usd"] + ledger["outstanding_reserved_budget_usd"] >= cap:
            print(f"\n  ⚠ BUDGET CAP REACHED — pausing job")
            try:
                client.fine_tuning.jobs.cancel(job_id)
            except Exception as e:
                print(f"  Could not pause/cancel: {e}")
            return None

        # Update temporary progress report
        report_lines = [
            "# Fine-tuning Progress Report (Live Update)",
            f"**Last Sync**: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"## Job: `{job_id}` ({label})",
            f"- Status: **{status}**",
        ]
        try:
            events = client.fine_tuning.jobs.list_events(fine_tuning_job_id=job_id, limit=3)
            if events.data:
                latest = events.data[0]
                report_lines.append(f"- Latest Event: {latest.message}")
        except: pass
        
        report_path = ROOT / "reports" / "finetune_progress_report.md"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text("\n".join(report_lines))

        time.sleep(poll_interval)

    print(f"  ⚠ Max polls ({max_polls}) reached for {label}")
    return None


def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()

    from openai import OpenAI
    client = OpenAI()

    report_lines = ["# Fine-tuning Progress Report\n"]

    # Monitor SFT job
    sft_job_id = state.get("latest_sft_job_id")
    if sft_job_id:
        job = client.fine_tuning.jobs.retrieve(sft_job_id)
        if job.status in ("queued", "validating_files", "running"):
            sft_model = monitor_job(client, sft_job_id, "SFT", state, ledger, cfg)
        elif job.status == "succeeded":
            sft_model = job.fine_tuned_model
            state["latest_finetuned_model_name"] = sft_model
            save_state(state)
            print(f"SFT already succeeded: {sft_model}")
        else:
            sft_model = None
            print(f"SFT job status: {job.status}")

        report_lines.append(f"## SFT Job: `{sft_job_id}`")
        report_lines.append(f"Status: {job.status}")
        if sft_model:
            report_lines.append(f"Model: `{sft_model}`")
        report_lines.append("")
    else:
        print("No SFT job found in state.")

    # Monitor DPO job
    dpo_job_id = state.get("latest_dpo_job_id")
    if dpo_job_id:
        job = client.fine_tuning.jobs.retrieve(dpo_job_id)
        if job.status in ("queued", "validating_files", "running"):
            dpo_model = monitor_job(client, dpo_job_id, "DPO", state, ledger, cfg)
        elif job.status == "succeeded":
            dpo_model = job.fine_tuned_model
            state["latest_finetuned_model_name"] = dpo_model
            save_state(state)
            print(f"DPO already succeeded: {dpo_model}")
        else:
            dpo_model = None
            print(f"DPO job status: {job.status}")

        report_lines.append(f"## DPO Job: `{dpo_job_id}`")
        report_lines.append(f"Status: {job.status}")
        if dpo_model:
            report_lines.append(f"Model: `{dpo_model}`")
        report_lines.append("")
    else:
        print("No DPO job found in state.")

    report_lines.append(f"\n## Budget Status")
    report_lines.append(f"- Total spent: ${ledger['total_spent_usd']:.2f}")
    report_lines.append(f"- Reserved: ${ledger['outstanding_reserved_budget_usd']:.2f}")
    report_lines.append(f"- Remaining: ${ledger['remaining_budget_usd']:.2f}")

    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "finetune_progress_report.md").write_text("\n".join(report_lines))
    print(f"\n✓ Report → {report_dir / 'finetune_progress_report.md'}")


if __name__ == "__main__":
    main()
