import pandas as pd
import numpy as np
import logging
from pathlib import Path
import re

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = ROOT / "outputs" / "master_vector.parquet"
OUTPUT_PATH = ROOT / "project_state" / "fixed_eval_set.parquet"
AUDIT_PATH = ROOT / "audits" / "hypothesis_patch_audit.md"

SEED = 137

METHOD_COLS = [
    "method_rct", "method_prepost", "method_case_study", 
    "method_expert_qual", "method_expert_secondary", "method_gut"
]

GENERIC_EVIDENCE_TERMS = [
    "trial", "pilot", "evaluation", "compare", "experiment", "evidence", "data", "study"
]

def build_eval_set():
    logging.info(f"Loading {INPUT_PATH}...")
    df = pd.read_parquet(INPUT_PATH)
    logging.info(f"Loaded {len(df)} rows.")

    # Data cleaning / filtering
    df = df[df["title"].notna()]
    df = df[df["body"].notna()]
    df["body_text"] = df["body"]
    df = df[df["body_text"].str.len() <= 6000]
    
    # Exclude live/comment (heuristic if columns missing, but they are there)
    if "is_liveblog" in df.columns:
        df = df[df["is_liveblog"] == False]
    if "is_commentisfree" in df.columns:
        df = df[df["is_commentisfree"] == False]

    # Ensure decision is not null for eval
    df = df[df["decision"].notna()]
    
    # ── 1. POS set ───────────────────────────────────────────────────
    # decision==1 AND any(methods == 1)
    # We need to handle nulls in methods
    method_max = df[METHOD_COLS].max(axis=1)
    pos_mask = (df["decision"] == 1.0) & (method_max == 1.0)
    pos_df = df[pos_mask]
    
    # ── 2. HARDNEG set ───────────────────────────────────────────────
    # decision==0 AND (cue terms)
    # Get cue terms from query space logic or common sense keywords
    regex_pattern = "|".join(GENERIC_EVIDENCE_TERMS)
    def contains_cue(text):
        if not text: return False
        return bool(re.search(regex_pattern, text, re.IGNORECASE))
    
    neg_pool = df[df["decision"] == 0.0]
    hardneg_mask = neg_pool["body_text"].apply(contains_cue)
    hardneg_df = neg_pool[hardneg_mask]
    
    # ── 3. NEG set ───────────────────────────────────────────────────
    # decision==0 AND all methods == 0
    # Filter negatives that aren't hardneg
    neg_only_df = neg_pool[~hardneg_mask]
    
    # ── Sampling ─────────────────────────────────────────────────────
    def safe_sample(sub_df, n):
        if len(sub_df) <= n:
            return sub_df
        return sub_df.sample(n=n, random_state=SEED)

    pos_sample = safe_sample(pos_df, 250)
    pos_sample["split_label"] = "POS"
    
    hardneg_sample = safe_sample(hardneg_df, 250)
    hardneg_sample["split_label"] = "HARDNEG"
    
    neg_sample = safe_sample(neg_only_df, 250)
    neg_sample["split_label"] = "NEG"
    
    final_eval_set = pd.concat([pos_sample, hardneg_sample, neg_sample])
    
    # Standardize columns
    keep_cols = [
        "url_canon", "title", "section", "publication_date_utc", "body_text",
        "decision", "split_label"
    ] + METHOD_COLS
    
    # Rename for gold labels if preferred, or keep as is. 
    # Contract says: gold_decision, gold_method_<m>
    rename_map = {"decision": "gold_decision"}
    for m in METHOD_COLS:
        rename_map[m] = f"gold_{m}"
    
    final_eval_set = final_eval_set.rename(columns=rename_map)
    final_eval_set = final_eval_set[[c for c in final_eval_set.columns if c in keep_cols or c in rename_map.values()]]
    
    logging.info(f"Writing {len(final_eval_set)} rows to {OUTPUT_PATH}")
    final_eval_set.to_parquet(OUTPUT_PATH, index=False)
    
    # ── Audit ────────────────────────────────────────────────────────
    counts = final_eval_set["split_label"].value_counts().to_dict()
    audit_lines = [
        "\n## Label Distributions (Final)",
        "| Split | Count |",
        "| :--- | :--- |",
        f"| POS | {counts.get('POS', 0)} |",
        f"| HARDNEG | {counts.get('HARDNEG', 0)} |",
        f"| NEG | {counts.get('NEG', 0)} |",
        f"| **Total** | **{len(final_eval_set)}** |"
    ]
    
    with open(AUDIT_PATH, "a") as f:
        f.write("\n".join(audit_lines) + "\n")
    
    logging.info("Step 1 Complete.")

if __name__ == "__main__":
    build_eval_set()
