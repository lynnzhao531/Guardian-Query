import os
import json
import glob
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

def inspect_job(job_id):
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    job = client.fine_tuning.jobs.retrieve(job_id)
    
    # Read the latest round's dpo_meta.json or STATE.json to find what we're actually using.
    # The prompt asked to check "audits/round_{id}/dpo_meta.json" or STATE.json
    state_path = BASE_DIR / "project_state/STATE.json"
    current_dpo = "UNKNOWN"
    if state_path.exists():
        with open(state_path, "r") as f:
            state = json.load(f)
            current_dpo = state.get("dpo_model_name", "UNKNOWN")
            
    # Try to find a recent dpo_meta
    audit_files = glob.glob(str(BASE_DIR / "audits" / "round_*" / "dpo_meta.json"))
    if audit_files:
        # Sort by round number
        audit_files.sort(key=lambda x: int(Path(x).parent.name.split("_")[1]) if "round_" in Path(x).parent.name else 0)
        latest_dpo_meta = audit_files[-1]
        with open(latest_dpo_meta, "r") as f:
            try:
                meta = json.load(f)
                current_dpo = meta.get("model", current_dpo)
            except:
                pass

    report = []
    report.append("# DPO Job Inspection and Smoke Test Comparison")
    report.append("\n## Job Metadata")
    report.append(f"- **Job ID**: {job_id}")
    report.append(f"- **Base Model**: {job.model}")
    
    if hasattr(job, 'method') and job.method:
        report.append(f"- **Method Type**: {job.method.type}")
    else:
        report.append(f"- **Method Type**: unknown (likely 'dpo' if it's a DPO job)")
        
    report.append(f"- **Training File ID**: {job.training_file}")
    report.append(f"- **Validation File ID**: {job.validation_file}")
    report.append(f"- **Fine-Tuned Model Name**: `{job.fine_tuned_model}`")
    
    report.append("\n## Configuration Check")
    report.append(f"- **Model logged in state/audits**: `{current_dpo}`")
    
    if current_dpo == job.fine_tuned_model:
        report.append("- **Status**: Match.")
    else:
        report.append("- **Status**: **MISCONFIGURATION**. The model name currently used does not match the fine_tuned_model from this job.")

    report_path = BASE_DIR / "reports/dpo_smoke_compare.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(report) + "\n\n")
        
    print(f"Inspection written to {report_path}")

if __name__ == "__main__":
    inspect_job("ftjob-ktnOxIzFH7JMbxzIQDcS59Mq")
