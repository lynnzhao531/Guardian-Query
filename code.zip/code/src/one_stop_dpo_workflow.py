"""
src/one_stop_dpo_workflow.py  —  Unified entrypoint for DPO benchmarking.

Workflow:
  1. Auto-detect round (205 or latest).
  2. Validate round outputs (5-CSV rule).
  3. Run DPO Head-to-Head Benchmark (Main: A vs B).
  4. Run DPO Head-to-Head Benchmark (Swap: B vs A).
  5. Cross-check consistency.
  6. Generate ONE_STOP_SUMMARY.md.
"""

import argparse
import datetime
import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional
from dotenv import load_dotenv

load_dotenv()

# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────
DPO_A_DEFAULT = "ft:gpt-4.1-mini-2025-04-14:personal::DCL5PEgw"
DPO_B_DEFAULT = "ft:gpt-4.1-mini-2025-04-14:personal::DCKp7Qu8"
HOLDOUT_DEFAULT = "archive/stale_rounds_20260222/outputs/master_vector.parquet"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("one_stop")

# ──────────────────────────────────────────────────────────────────────────────
# Steps
# ──────────────────────────────────────────────────────────────────────────────

def run_step(cmd: List[str], log_file: Path, env: Optional[Dict] = None) -> None:
    log.info(f"Running: {' '.join(cmd)}")
    with open(log_file, "w") as f:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env={**os.environ, **(env or {}), "PYTHONPATH": os.environ.get("PYTHONPATH", "") + ":."},
            bufsize=1  # line buffered
        )
        for line in process.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            f.write(line)
            f.flush()
        process.wait()
    
    if process.returncode != 0:
        log.error(f"Step failed with code {process.returncode}. Log: {log_file}")
        sys.exit(process.returncode)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dpo_a", default=DPO_A_DEFAULT)
    parser.add_argument("--dpo_b", default=DPO_B_DEFAULT)
    parser.add_argument("--holdout_parquet", default=HOLDOUT_DEFAULT)
    parser.add_argument("--round_id", type=int)
    parser.add_argument("--benchmark_limit", type=int, help="Limit holdout items per benchmark for fast test")
    parser.add_argument("--strict", action="store_true", default=True)
    parser.add_argument("--run_campaign_after", action="store_true", default=False)
    args = parser.parse_args()

    # Step 0: Preflight
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_root = Path("audits/one_stop_dpo") / ts
    out_root.mkdir(parents=True, exist_ok=False)

    config = {
        "dpo_a": args.dpo_a,
        "dpo_b": args.dpo_b,
        "holdout_parquet": args.holdout_parquet,
        "round_id_override": args.round_id,
        "python_version": sys.version,
    }
    with open(out_root / "config.json", "w") as f:
        json.dump(config, f, indent=2)

    log.info(f"OUT_ROOT={out_root}")
    log.info(f"DPO_A={args.dpo_a}")
    log.info(f"DPO_B={args.dpo_b}")
    log.info(f"HOLDOUT={args.holdout_parquet}")

    # Step 1: Detect Round
    round_id = args.round_id
    if not round_id:
        if Path("outputs/rounds/round_205").exists():
            round_id = 205
        else:
            rounds = []
            rounds_dir = Path("outputs/rounds")
            if rounds_dir.exists():
                for d in rounds_dir.iterdir():
                    if d.is_dir() and d.name.startswith("round_"):
                        try:
                            rounds.append(int(d.name.split("_")[1]))
                        except: pass
            if not rounds:
                log.error("No round directories found in outputs/rounds/")
                sys.exit(10)
            round_id = max(rounds)
    
    log.info(f"Using round_id={round_id} for validation.")

    # Step 2: Validate
    run_step(
        [sys.executable, "-m", "src.validate_round_outputs", "--round_id", str(round_id), "--strict"],
        out_root / "validate_round_outputs.log"
    )

    # Step 3: Thresholds Check (Additive Safety)
    t_path = Path("project_state/PER_MODEL_THRESHOLDS.json")
    t_exists = t_path.exists()
    t_hash = ""
    t_created = False
    
    if not t_exists:
        log.info("project_state/PER_MODEL_THRESHOLDS.json missing. Creating with defaults (ADDITIVE).")
        defaults = {
            "model1": {"t_dec": 0.60, "t_meth": 0.80, "t_conf": 0.0},
            "model3": {"t_dec": 0.60, "t_meth": 0.80, "t_conf": 0.0},
            "llm_final": {"t_dec": 0.60, "t_meth": 0.80, "t_conf": 0.55}
        }
        t_path.parent.mkdir(parents=True, exist_ok=True)
        with open(t_path, "w") as f:
            json.dump(defaults, f, indent=2)
        t_created = True
        log.info(f"Thresholds created at {t_path}")
    
    import hashlib
    t_hash = hashlib.sha256(t_path.read_bytes()).hexdigest()
    
    t_status = {
        "exists": True,
        "path": str(t_path),
        "sha256": t_hash,
        "created_now": t_created
    }
    with open(out_root / "thresholds_presence.json", "w") as f:
        json.dump(t_status, f, indent=2)

    # Step 4: Main Benchmark (A vs B)
    bench_main = out_root / "bench_main"
    main_cmd = [sys.executable, "-u", "-m", "src.dpo_head2head_benchmark", "--dpo_a", args.dpo_a, "--dpo_b", args.dpo_b, "--holdout_parquet", args.holdout_parquet, "--out_dir", str(bench_main), "--strict"]
    if args.benchmark_limit:
        main_cmd += ["--limit", str(args.benchmark_limit)]
        
    run_step(
        main_cmd,
        out_root / "bench_main.log",
        env={"PYTHONHASHSEED": "0"}
    )

    # Step 5: Swap Benchmark (B vs A)
    bench_swap = out_root / "bench_swap"
    swap_cmd = [sys.executable, "-u", "-m", "src.dpo_head2head_benchmark", "--dpo_a", args.dpo_b, "--dpo_b", args.dpo_a, "--holdout_parquet", args.holdout_parquet, "--out_dir", str(bench_swap), "--strict"]
    if args.benchmark_limit:
        swap_cmd += ["--limit", str(args.benchmark_limit)]

    run_step(
        swap_cmd,
        out_root / "bench_swap.log",
        env={"PYTHONHASHSEED": "0"}
    )

    # Step 6: Consistency Check (MODEL_ID MAPPED)
    self_audit = {"validator": "PASS", "swap_consistency": "PASS", "thresholds": "PASS"}
    
    # Load Main
    with open(bench_main / "WINNER.txt") as f: w_main_text = f.read()
    w_main = w_main_text.split("WINNER: ")[1].split("\n")[0].strip()
    with open(bench_main / "metrics.json") as f: m_main = {item["model_id"]: item for item in json.load(f)}
    with open(bench_main / "eval_hashes.json") as f: h_main = json.load(f)
    
    # Load Swap
    with open(bench_swap / "WINNER.txt") as f: w_swap_text = f.read()
    w_swap = w_swap_text.split("WINNER: ")[1].split("\n")[0].strip()
    with open(bench_swap / "metrics.json") as f: m_swap = {item["model_id"]: item for item in json.load(f)}
    with open(bench_swap / "eval_hashes.json") as f: h_swap = json.load(f)

    # 6a. Winner Match
    if w_main != w_swap:
        log.error(f"CONSISTENCY FAILURE: Winner mismatch! Main={w_main}, Swap={w_swap}")
        self_audit["swap_consistency"] = f"FAIL (Winner mismatch: {w_main} vs {w_swap})"
        if args.strict: sys.exit(10)
    
    # 6b. Metric Match (Mapped by Model ID)
    for mid in [args.dpo_a, args.dpo_b]:
        met_m = m_main[mid]
        met_s = m_swap[mid]
        
        # Exact checks
        if met_m["trap_pass_count"] != met_s["trap_pass_count"]:
            err = f"trap_pass_count mismatch for {mid} (Main={met_m['trap_pass_count']}, Swap={met_s['trap_pass_count']})"
            self_audit["swap_consistency"] = f"FAIL ({err})"
            log.error(err)
            if args.strict: sys.exit(10)
        
        # Epsilon checks
        for key in ["precision_p50", "precision_p100", "precision_overall"]:
            delta = abs(met_m[key] - met_s[key])
            if delta > 0.001:
                err = f"{key} mismatch for {mid} (delta={delta:.6f})"
                self_audit["swap_consistency"] = f"FAIL ({err})"
                log.error(err)
                if args.strict: sys.exit(10)
                
    # 6c. Hash Match
    if h_main != h_swap:
        log.error(f"CONSISTENCY FAILURE: Eval hashes mismatch!")
        self_audit["swap_consistency"] = "FAIL (Input hashes changed between runs)"
        if args.strict: sys.exit(10)

    log.info("Consistency check PASSED.")

    # Step 7: Summary Report
    summary_path = out_root / "ONE_STOP_SUMMARY.md"
    winner_id = w_main
    
    with open(summary_path, "w") as f:
        f.write(f"# One-Stop DPO Benchmark Summary\n\n")
        f.write(f"## SELF_AUDIT: { 'PASS' if all(v == 'PASS' for v in self_audit.values()) else 'FAIL' }\n")
        for k, v in self_audit.items():
            f.write(f"- {k}: {v}\n")
        f.write("\n---\n\n")
        f.write(f"- **Validated Round**: {round_id}\n")
        f.write(f"- **Winner Model**: `{winner_id}`\n\n")
        
        f.write("## Model Performance\n\n")
        f.write("| Model ID | Traps | Proto | p@50 | p@100 | Prec (all) | Count |\n")
        f.write("|---|---|---|---|---|---|---|\n")
        for mid in [args.dpo_a, args.dpo_b]:
            m = m_main[mid]
            f.write(f"| {mid} | {m['trap_pass_count']} | {m['prototype_pass_count']} | {m['precision_p50']:.3f} | {m['precision_p100']:.3f} | {m['precision_overall']:.3f} | {m['pass_count']} |\n")
        
        f.write(f"\n## Artifact Paths\n")
        f.write(f"- Main Run: `{bench_main}`\n")
        f.write(f"- Swap Run: `{bench_swap}`\n")
        f.write(f"- Disagreements: `{bench_main}/disagreements_top30.csv`\n\n")
        
        if args.run_campaign_after:
            other = args.dpo_b if winner_id == args.dpo_a else args.dpo_a
            f.write(f"## Optional Campaign\n- Status: Queued/Launched\n- Candidates: `{winner_id}, {other}`\n\n")
        
        f.write(f"FINAL_WINNER={winner_id}\n")

    log.info(f"Report generated: {summary_path}")

    if args.run_campaign_after:
        other = args.dpo_b if winner_id == args.dpo_a else args.dpo_a
        camp_root = f"runs/after_dpo_{ts}"
        run_step([
            sys.executable, "-m", "src.campaign_runner",
            "--max_rounds", "70", "--max_hours", "8", "--chunk_size", "5",
            "--dpo_candidates", f"{winner_id},{other}",
            "--strict", "--append_only_pools", "--run_root", camp_root
        ], out_root / "campaign_after.log")

    log.info("ONE-STOP WORKFLOW COMPLETE.")

if __name__ == "__main__":
    main()
