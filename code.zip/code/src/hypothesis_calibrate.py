import pandas as pd
import numpy as np
import logging
import joblib
import json
from pathlib import Path
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold
from src.hypothesis_verifier import HypothesisVerifier, DIMENSIONS, METHOD_NAMES

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = ROOT / "reports" / "fixed_eval_sft_raw.parquet"
MODEL_DIR = ROOT / "models" / "hypothesis_calibrators"
HYPOTHESES_PATH = ROOT / "knowledge_base" / "hypotheses" / "hypotheses_selected.json"
METRICS_JSON_PATH = ROOT / "reports" / "hypothesis_calibrator_metrics.json"

SEED = 137

def train_calibrators():
    if not INPUT_PATH.exists():
        logging.error(f"Missing {INPUT_PATH}")
        return
        
    df = pd.read_parquet(INPUT_PATH)
    logging.info(f"Loaded {len(df)} rows for calibration.")

    if not HYPOTHESES_PATH.exists():
        logging.error(f"Missing {HYPOTHESES_PATH}")
        return
    with open(HYPOTHESES_PATH, "r") as f:
        selected_hyps = json.load(f)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    
    metrics = {}
    
    for dim in DIMENSIONS:
        logging.info(f"Calibrating {dim}...")
        
        # 1. Prepare Features
        # Target prefix in raw parquet is llm_sft_
        prefix = "llm_sft"
        p1_col = f"{prefix}_{dim}_p1"
        gold_col = f"gold_{dim}"
        
        # Filter rows where gold is not null
        temp_df = df[df[gold_col].notna()].copy()
        if len(temp_df) < 20:
            logging.warning(f"Skipping {dim}: insufficient data ({len(temp_df)} rows).")
            continue
            
        # Compute Hypotheses Support/Trap
        def get_hits(row):
            text = row["body_text"]
            support = 0
            trap = 0
            for h in selected_hyps.get(dim, []):
                if HypothesisVerifier.fires(h, text):
                    if h["kind"] == "HIGH": support += 1
                    elif h["kind"] == "LOW": support -= 1
                    elif h["kind"] == "TRAP": trap += 1
            return support, trap
            
        hits = temp_df.apply(get_hits, axis=1)
        temp_df["support_d"] = [h[0] for h in hits]
        temp_df["trap_d"] = [h[1] for h in hits]
        
        # Logit of raw p1
        temp_df["logit_p1"] = np.log((temp_df[p1_col] + 1e-4) / (1.0 - temp_df[p1_col] + 1e-4))
        
        X = temp_df[["logit_p1", "support_d", "trap_d"]].values
        y = (temp_df[gold_col] == 1.0).astype(int)
        
        if y.nunique() < 2:
            logging.warning(f"Skipping {dim}: only one class present in gold labels.")
            continue
            
        # 2. Fit Model
        model = LogisticRegression(C=1.0, max_iter=2000, class_weight="balanced", solver="lbfgs")
        
        # CV for metrics
        try:
            cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
            scores = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")
            auc = scores.mean()
        except Exception as e:
            logging.warning(f"CV failed for {dim}: {e}")
            auc = 0
            
        model.fit(X, y)
        
        # 3. Save
        joblib.dump(model, MODEL_DIR / f"calib_{dim}.joblib")
        
        metrics[dim] = {
            "auc": float(auc),
            "coef": model.coef_[0].tolist(),
            "intercept": model.intercept_.tolist(),
            "n_samples": len(temp_df)
        }
        
    with open(METRICS_JSON_PATH, "w") as f:
        json.dump(metrics, f, indent=2)
        
    logging.info(f"Calibration complete. Metrics saved to {METRICS_JSON_PATH}")

if __name__ == "__main__":
    train_calibrators()
