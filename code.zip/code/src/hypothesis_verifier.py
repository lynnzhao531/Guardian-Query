import json
import pandas as pd
import numpy as np
import re
import logging
from pathlib import Path
from typing import List, Dict, Any

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
EVALSET_PATH = ROOT / "project_state" / "fixed_eval_set.parquet"
DEDUP_POOL_PATH = ROOT / "knowledge_base/hypotheses/hypotheses_pool_dedup.jsonl"
OUT_JSON_PATH = ROOT / "knowledge_base/hypotheses/hypotheses_selected.json"
OUT_MD_PATH = ROOT / "knowledge_base/hypotheses/hypotheses_selected.md"

DIMENSIONS = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]
METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

class HypothesisVerifier:
    @staticmethod
    def fires(hypothesis: Dict, text: str) -> bool:
        if not text: return False
        for p_reg in hypothesis.get("positive_regex", []):
            try:
                if re.search(p_reg, text, re.IGNORECASE):
                    # Check negative regex
                    ignore = False
                    for n_reg in hypothesis.get("negative_regex", []):
                        if re.search(n_reg, text, re.IGNORECASE):
                            ignore = True
                            break
                    if not ignore:
                        return True
            except re.error:
                continue
        return False

    @staticmethod
    def get_hit_counts(text: str, selected_hypotheses: Dict) -> Dict[str, Dict[str, int]]:
        """Returns {dim: {'high': N, 'low': M, 'trap': K}} for all dimensions."""
        hit_counts = {}
        for dim in DIMENSIONS:
            hi = 0; lo = 0; tr = 0
            dim_hyps = selected_hypotheses.get(dim, [])
            for h in dim_hyps:
                if HypothesisVerifier.fires(h, text):
                    if h["kind"] == "HIGH": hi += 1
                    elif h["kind"] == "LOW": lo += 1
                    elif h["kind"] == "TRAP": tr += 1
            hit_counts[dim] = {"high": hi, "low": lo, "trap": tr}
        return hit_counts

    @staticmethod
    def adjust(text: str, llm_sft_scores: Dict[str, float], selected_hypotheses: Dict, calibrators: Dict = None) -> Dict[str, Any]:
        """
        Adjusts scores based on hypothesis hits.
        llm_sft_scores: {'decision_p1': 0.9, 'method_rct_p1': 0.8, ...}
        """
        adjusted_results = {}
        
        # Try to load frozen grid parameters
        frozen_params = None
        params_path = Path(__file__).resolve().parent.parent / "project_state" / "HYPOTHESIS_ADJUST_PARAMS.json"
        if params_path.exists():
            with open(params_path, "r") as f:
                frozen_params = json.load(f)

        hit_counts = HypothesisVerifier.get_hit_counts(text, selected_hypotheses)
        
        for dim in DIMENSIONS:
            prefix = "decision" if dim == "decision" else dim
            p1_raw = llm_sft_scores.get(f"{prefix}_p1", 0.0)
            
            h_counts = hit_counts.get(dim, {"high": 0, "low": 0, "trap": 0})
            support_d = np.clip(h_counts["high"] - h_counts["low"], -2, 2)
            trap_d = np.clip(h_counts["trap"], 0, 2)
            
            # 1. Calibration / Adjustment
            if frozen_params:
                 a = frozen_params["a"]
                 b = frozen_params["b"]
                 p1_adj = np.clip(p1_raw + a * support_d - b * trap_d, 0, 1)
                 t1 = frozen_params["t1"]
                 t05 = frozen_params["t05"]
                 if p1_adj >= t1: score = 1.0
                 elif p1_adj >= t05: score = 0.5
                 else: score = 0.0
            elif calibrators and dim in calibrators:
                 import joblib
                 model = calibrators[dim]
                 logit_p1 = np.log((p1_raw + 1e-4) / (1.0 - p1_raw + 1e-4))
                 X = np.array([[logit_p1, support_d, trap_d]])
                 p1_adj = model.predict_proba(X)[0, 1]
                 # Default threshold for calibrated
                 if p1_adj >= 0.50: score = 1.0
                 elif p1_adj >= 0.25: score = 0.5
                 else: score = 0.0
            else:
                 # Summer baseline fallback
                 p1_adj = np.clip(p1_raw + 0.10 * support_d - 0.15 * trap_d, 0, 1)
                 if p1_adj >= 0.85: score = 1.0
                 elif p1_adj >= 0.55: score = 0.5
                 else: score = 0.0
            
            adjusted_results[f"{prefix}_p1"] = float(p1_adj)
            adjusted_results[f"{prefix}_score"] = score
            
        return adjusted_results

def select_best():
    if not EVALSET_PATH.exists(): return
    df = pd.read_parquet(EVALSET_PATH)
    
    hypotheses = []
    with open(DEDUP_POOL_PATH, "r") as f:
        for line in f:
            hypotheses.append(json.loads(line))
            
    selected = {}
    
    # Pre-compute firing matrix to speed up
    logging.info(f"Scoring {len(hypotheses)} candidates on {len(df)} articles...")
    
    report_rows = []
    
    for h in hypotheses:
        dim = h["dimension"]
        # Map method names in hypothesis (if they use short names) to canonical
        if dim in METHOD_NAMES:
            dim = f"method_{dim}"
            h["dimension"] = dim
            
        if dim not in DIMENSIONS: continue
        
        kind = h["kind"]
        
        # Define positives/negatives for this dimension
        if dim == "decision":
            df["is_pos"] = df["gold_decision"] == 1.0
        else:
            df["is_pos"] = (df["gold_decision"] == 1.0) & (df[f"gold_{dim}"] == 1.0)
            
        # Filter rows with null gold
        eval_df = df[df[f"gold_{dim}"].notna()] if dim != "decision" else df
        if len(eval_df) < 5: continue
        
        eval_df["fires"] = eval_df["body_text"].apply(lambda x: HypothesisVerifier.fires(h, x))
        
        # Calculate Metrics
        fires_count = eval_df["fires"].sum()
        if fires_count == 0: continue
        
        # Precision: P(pos | fires)
        precision = eval_df[eval_df["fires"]]["is_pos"].mean()
        # Coverage: P(fires | pos)
        pos_df = eval_df[eval_df["is_pos"]]
        coverage = pos_df["fires"].mean() if len(pos_df) > 0 else 0
        # Fires rate on specific sets
        fires_hardneg = eval_df[(eval_df["fires"]) & (eval_df["split_label"] == "HARDNEG")].shape[0] / max(1, eval_df[eval_df["split_label"] == "HARDNEG"].shape[0])
        fires_neg = eval_df[(eval_df["fires"]) & (eval_df["split_label"] == "NEG")].shape[0] / max(1, eval_df[eval_df["split_label"] == "NEG"].shape[0])
        
        h["metrics"] = {
            "precision": float(precision),
            "coverage": float(coverage),
            "fires_hardneg": float(fires_hardneg),
            "fires_neg": float(fires_neg)
        }
        
    # Final Selection
    logging.info("Applying selection criteria...")
    for dim in DIMENSIONS:
        dim_h = [h for h in hypotheses if h.get("dimension") == dim]
        selected[dim] = []
        
        # HIGH: prec >= 0.65, cov >= 0.10. Top 3 by prec.
        highs = [h for h in dim_h if h["kind"] == "HIGH" and h.get("metrics") and h["metrics"]["precision"] >= 0.65 and h["metrics"]["coverage"] >= 0.10]
        highs = sorted(highs, key=lambda x: (x["metrics"]["precision"], x["metrics"]["coverage"]), reverse=True)[:3]
        selected[dim].extend(highs)
        
        # TRAP: prec <= 0.35, fires_hardneg >= 0.05. Top 2 by fires_hardneg.
        traps = [h for h in dim_h if h["kind"] == "TRAP" and h.get("metrics") and h["metrics"]["precision"] <= 0.35 and h["metrics"]["fires_hardneg"] >= 0.05]
        traps = sorted(traps, key=lambda x: x["metrics"]["fires_hardneg"], reverse=True)[:2]
        selected[dim].extend(traps)
        
        # LOW: prec <= 0.35, fires_neg >= 0.05. Top 1 by fires_neg.
        lows = [h for h in dim_h if h["kind"] == "LOW" and h.get("metrics") and h["metrics"]["precision"] <= 0.35 and h["metrics"]["fires_neg"] >= 0.05]
        lows = sorted(lows, key=lambda x: x["metrics"]["fires_neg"], reverse=True)[:1]
        selected[dim].extend(lows)
        
    # Save
    with open(OUT_JSON_PATH, "w") as f:
        json.dump(selected, f, indent=2)
        
    # Generate MD summary
    md = ["# Selected Hypotheses Summary\n"]
    for dim in DIMENSIONS:
        md.append(f"## {dim}")
        dim_s = selected.get(dim, [])
        if not dim_s:
            md.append("*No hypotheses selected.*")
            continue
        for h in dim_s:
            m = h["metrics"]
            md.append(f"- **{h['kind']}**: {h['statement']}")
            md.append(f"  - Precision: {m['precision']:.2f}, Coverage: {m['coverage']:.2f}, Trap Rate (HN): {m['fires_hardneg']:.2f}")
            md.append(f"  - Regex: `{h['positive_regex']}`")
        md.append("")
        
    with open(OUT_MD_PATH, "w") as f:
        f.write("\n".join(md))
        
    logging.info(f"Selected {sum(len(v) for v in selected.values())} hypotheses.")

if __name__ == "__main__":
    select_best()
