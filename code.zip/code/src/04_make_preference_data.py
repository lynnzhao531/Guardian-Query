#!/usr/bin/env python3
"""
Step 4: Create SFT and DPO JSONL datasets (sharded) for OpenAI fine-tuning.
Uses the rubric from Instructions.markdown and long training view.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import tiktoken
import yaml

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


# ── Rubric ────────────────────────────────────────────────────────────

RUBRIC_FILE = ROOT / "Instructions.markdown"

# Aligned with safe_llm_judge.py + llm_judge_router.py
SYSTEM_PROMPT = """Output ONLY JSON. No prose. No markdown. Do not repeat.

CONSERVATIVE SCORING RULES (NON-NEGOTIABLE):
- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.
- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').
- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).
- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present.

Output ONLY valid JSON matching the schema. No prose. No markdown.
"""


def make_user_message(row: dict) -> str:
    """Build user message aligned with safe_llm_judge.py."""
    text = row.get("text_for_model", "")
    return f"Article Text:\n{text[:15000]}"

def get_empty_score(is_high=False):
    if is_high:
        return {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}
    else:
        return {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}

def map_score_to_probs(score):
    if score == 1:
        return {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}
    elif score == 0.5:
        return {"score": 0.5, "p0": 0.2, "p05": 0.6, "p1": 0.2}
    else:
        return {"score": 0.0, "p0": 0.95, "p05": 0.05, "p1": 0.0}

def make_preferred_output(row: dict) -> str:
    """Build correct assistant JSON with 7 dimensions and probabilities."""
    method_type = row.get("method_type", "expert_qual") # default fallback
    
    out = {
        "decision": map_score_to_probs(row["decision_score"])
    }
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    for m in methods:
        if m == method_type:
            out[f"method_{m}"] = map_score_to_probs(row["method_score"])
        else:
            out[f"method_{m}"] = get_empty_score(is_high=False)
            
    return json.dumps(out)

def make_non_preferred_output(row: dict) -> str:
    """Build plausible but wrong assistant JSON with 7 dimensions."""
    # Simplified: just use a lower/different score for the primary dimension
    scores = [0, 0.5, 1]
    wrong_method_score = random.choice([s for s in scores if s != row["method_score"]])
    
    method_type = row.get("method_type", "expert_qual")
    
    out = {
        "decision": map_score_to_probs(row["decision_score"]) # Keep decision correct for primary method focus
    }
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    for m in methods:
        if m == method_type:
            out[f"method_{m}"] = map_score_to_probs(wrong_method_score)
        else:
            out[f"method_{m}"] = get_empty_score(is_high=False)
            
    return json.dumps(out)


def make_sft_line(row: dict) -> dict:
    """SFT JSONL line: messages format."""
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": make_user_message(row)},
            {"role": "assistant", "content": make_preferred_output(row)},
        ]
    }


def make_dpo_line(row: dict) -> dict:
    """DPO JSONL line: input + preferred + non_preferred."""
    return {
        "input": {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": make_user_message(row)},
            ]
        },
        "preferred_output": [
            {"role": "assistant", "content": make_preferred_output(row)},
        ],
        "non_preferred_output": [
            {"role": "assistant", "content": make_non_preferred_output(row)},
        ],
    }


# ── Token estimation ─────────────────────────────────────────────────

def estimate_tokens(text: str, enc) -> int:
    return len(enc.encode(text))


def estimate_sft_line_tokens(line: dict, enc) -> int:
    total = 0
    for msg in line["messages"]:
        total += estimate_tokens(msg["content"], enc) + 4  # message overhead
    return total


def estimate_dpo_line_tokens(line: dict, enc) -> int:
    total = 0
    for msg in line["input"]["messages"]:
        total += estimate_tokens(msg["content"], enc) + 4
    for msg in line["preferred_output"]:
        total += estimate_tokens(msg["content"], enc) + 4
    for msg in line["non_preferred_output"]:
        total += estimate_tokens(msg["content"], enc) + 4
    return total


# ── Sharding ──────────────────────────────────────────────────────────

def write_shards(lines, prefix, out_dir, token_estimator, enc, max_cost, price_per_M) -> list[dict]:
    """Write JSONL lines into shards, each ≤ max_cost."""
    out_dir.mkdir(parents=True, exist_ok=True)
    shard_info = []
    shard_lines = []
    shard_tokens = 0
    shard_num = 1

    for line in lines:
        toks = token_estimator(line, enc)
        cost_if_added = (shard_tokens + toks) / 1_000_000 * price_per_M * 3  # 3 epochs
        if cost_if_added > max_cost and shard_lines:
            # Flush shard
            path = out_dir / f"{prefix}_shard_{shard_num:03d}.jsonl"
            with open(path, "w") as f:
                for sl in shard_lines:
                    f.write(json.dumps(sl) + "\n")
            shard_cost = shard_tokens / 1_000_000 * price_per_M * 3
            shard_info.append({
                "shard": shard_num, "path": str(path),
                "lines": len(shard_lines), "tokens": shard_tokens,
                "estimated_cost_usd": round(shard_cost, 2),
            })
            shard_num += 1
            shard_lines = []
            shard_tokens = 0

        shard_lines.append(line)
        shard_tokens += toks

    # Final shard
    if shard_lines:
        path = out_dir / f"{prefix}_shard_{shard_num:03d}.jsonl"
        with open(path, "w") as f:
            for sl in shard_lines:
                f.write(json.dumps(sl) + "\n")
        shard_cost = shard_tokens / 1_000_000 * price_per_M * 3
        shard_info.append({
            "shard": shard_num, "path": str(path),
            "lines": len(shard_lines), "tokens": shard_tokens,
            "estimated_cost_usd": round(shard_cost, 2),
        })

    return shard_info


# ── main ──────────────────────────────────────────────────────────────

def main():
    cfg = load_config()
    state = load_state()
    random.seed(cfg["splits"]["seed"])

    # Load long view
    long_path = state.get("training_long_path",
                          str(ROOT / "data" / "processed" / "training_long.parquet"))
    df = pd.read_parquet(long_path)
    print(f"Loaded long view: {len(df)} rows")

    # Load article splits
    splits_path = ROOT / "data" / "processed" / "article_splits.json"
    with open(splits_path) as f:
        splits = json.load(f)

    train_df = df[df["article_id"].isin(set(splits["train_articles"]))].copy()
    val_df = df[df["article_id"].isin(set(splits["val_articles"]))].copy()
    print(f"Train: {len(train_df)}, Val: {len(val_df)}")

    # Filter out rows with NaN decision (can't form valid output)
    train_df = train_df[train_df["decision_score"].notna()].copy()
    val_df = val_df[val_df["decision_score"].notna()].copy()
    print(f"After dropping NaN decision → Train: {len(train_df)}, Val: {len(val_df)}")

    # Tiktoken encoder
    enc = tiktoken.encoding_for_model("gpt-4o-mini")

    # Pricing
    price = cfg["pricing_estimates"]["finetune_training_per_1M_tokens"]
    max_shard_cost = cfg["budget"]["finetune_shard_max_usd"]

    out_dir = ROOT / "fine_tune_data"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── SFT lines ─────────────────────────────────────────────────────
    print("\nBuilding SFT lines...")
    sft_train = [make_sft_line(row.to_dict()) for _, row in train_df.iterrows()]
    sft_val = [make_sft_line(row.to_dict()) for _, row in val_df.iterrows()]

    random.shuffle(sft_train)
    sft_shards = write_shards(
        sft_train, "sft_train", out_dir,
        estimate_sft_line_tokens, enc, max_shard_cost, price,
    )
    print(f"SFT train shards: {len(sft_shards)}")
    for s in sft_shards:
        print(f"  shard {s['shard']}: {s['lines']} lines, {s['tokens']} tokens, ~${s['estimated_cost_usd']}")

    # SFT validation file
    sft_val_path = out_dir / "sft_val.jsonl"
    with open(sft_val_path, "w") as f:
        for line in sft_val:
            f.write(json.dumps(line) + "\n")
    val_tokens = sum(estimate_sft_line_tokens(l, enc) for l in sft_val)
    print(f"SFT val: {len(sft_val)} lines, {val_tokens} tokens")

    # ── DPO lines ─────────────────────────────────────────────────────
    print("\nBuilding DPO lines...")
    dpo_train = [make_dpo_line(row.to_dict()) for _, row in train_df.iterrows()]
    dpo_val = [make_dpo_line(row.to_dict()) for _, row in val_df.iterrows()]

    random.shuffle(dpo_train)
    dpo_shards = write_shards(
        dpo_train, "dpo_train", out_dir,
        estimate_dpo_line_tokens, enc, max_shard_cost, price,
    )
    print(f"DPO train shards: {len(dpo_shards)}")
    for s in dpo_shards:
        print(f"  shard {s['shard']}: {s['lines']} lines, {s['tokens']} tokens, ~${s['estimated_cost_usd']}")

    # DPO validation file
    dpo_val_path = out_dir / "dpo_val.jsonl"
    with open(dpo_val_path, "w") as f:
        for line in dpo_val:
            f.write(json.dumps(line) + "\n")

    # ── Audit ─────────────────────────────────────────────────────────
    audit_dir = ROOT / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)
    lines_report = ["# Fine-tune Data Audit\n"]
    lines_report.append("## SFT Shards\n")
    lines_report.append("| Shard | Lines | Tokens | Est. Cost |")
    lines_report.append("|-------|-------|--------|-----------|")
    total_sft_cost = 0
    for s in sft_shards:
        lines_report.append(f"| {s['shard']} | {s['lines']} | {s['tokens']:,} | ${s['estimated_cost_usd']:.2f} |")
        total_sft_cost += s['estimated_cost_usd']
    lines_report.append(f"\n**Total SFT estimated cost**: ${total_sft_cost:.2f}\n")

    lines_report.append("## DPO Shards\n")
    lines_report.append("| Shard | Lines | Tokens | Est. Cost |")
    lines_report.append("|-------|-------|--------|-----------|")
    total_dpo_cost = 0
    for s in dpo_shards:
        lines_report.append(f"| {s['shard']} | {s['lines']} | {s['tokens']:,} | ${s['estimated_cost_usd']:.2f} |")
        total_dpo_cost += s['estimated_cost_usd']
    lines_report.append(f"\n**Total DPO estimated cost**: ${total_dpo_cost:.2f}\n")

    lines_report.append(f"**Combined total**: ${total_sft_cost + total_dpo_cost:.2f}")

    (audit_dir / "finetune_data_audit.md").write_text("\n".join(lines_report))
    print(f"\n✓ Audit → {audit_dir / 'finetune_data_audit.md'}")

    # ── Update state ──────────────────────────────────────────────────
    state["sft_shards"] = sft_shards
    state["dpo_shards"] = dpo_shards
    
    if "steps_completed" not in state:
        state["steps_completed"] = []
    
    if "step_4_finetune_data" not in state["steps_completed"]:
        state["steps_completed"].append("step_4_finetune_data")
    state["current_step"] = "step_4_complete"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  FINE-TUNE DATA COMPLETE")
    print(f"  SFT shards: {len(sft_shards)}, DPO shards: {len(dpo_shards)}")
    print(f"  Estimated total cost: ${total_sft_cost + total_dpo_cost:.2f}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
