import yaml
import os
import sys
from pathlib import Path

import datetime

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "project_state" / "CONFIG.yaml"
CONFIG_V2_PATH = BASE_DIR / "project_state" / "CONFIG_V2.yaml"
AUDIT_PATH = BASE_DIR / "audits" / "config_merge_audit.md"

def load_yaml(path):
    if not path.exists():
        return {}
    with open(path, "r") as f:
        return yaml.safe_load(f) or {}

def get_config():
    """
    Loads CONFIG.yaml and CONFIG_V2.yaml, merges them, and returns the result.
    V2 overrides base config.
    Writes an audit file tracking where keys came from.
    """
    base_config = load_yaml(CONFIG_PATH)
    v2_config = load_yaml(CONFIG_V2_PATH)
    
    merged_config = base_config.copy()
    key_origins = {k: "CONFIG.yaml" for k in base_config}
    
    # Merge V2
    for k, v in v2_config.items():
        merged_config[k] = v
        key_origins[k] = "CONFIG_V2.yaml"
        
    # Validation of required V2 keys
    required_v2_keys = [
        "llm_router_mode", "sft_weight_in_ensemble", "dpo_enabled",
        "dpo_attempt_policy", "dpo_attempt_k", "dpo_attempt_strategy",
        "dpo_schema_strict", "repetition_trigger_token", "repetition_trigger_count",
        "prob_sum_tolerance", "tie_epsilon", "min_total_available",
        "guardian_pages", "guardian_page_size", "skip_long_chars"
    ]
    
    missing_keys = [k for k in required_v2_keys if k not in merged_config]
    
    # Write Audit
    os.makedirs(AUDIT_PATH.parent, exist_ok=True)
    with open(AUDIT_PATH, "w") as f:
        f.write("# Config Merge Audit\n")
        f.write(f"Generated at: {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n\n")
        
        if missing_keys:
            f.write("## ❌ CRITICAL: Missing Required Keys\n")
            for k in missing_keys:
                f.write(f"- {k}\n")
        else:
            f.write("## ✅ All Required Keys Present\n")
            
        f.write("\n## Key Origins\n")
        f.write("| Key | Origin | Value |\n")
        f.write("| --- | --- | --- |\n")
        for k in sorted(merged_config.keys()):
            val = str(merged_config[k]).replace("\n", " ")[:50]
            f.write(f"| {k} | {key_origins.get(k, 'Unknown')} | {val} |\n")
            
    if missing_keys:
        print(f"FATAL: Missing required config keys: {missing_keys}")
        print(f"Check {AUDIT_PATH}")
        sys.exit(1)
        
    return merged_config

if __name__ == "__main__":
    # Test run
    cfg = get_config()
    print("Config loaded successfully. Keys:", len(cfg))
