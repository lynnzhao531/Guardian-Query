import pandas as pd
import numpy as np
import json
import logging
from pathlib import Path
from src.hypothesis_verifier import HypothesisVerifier

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = ROOT / "reports" / "fixed_eval_sft_raw.parquet"
HYPOTHESES_PATH = ROOT / "knowledge_base" / "hypotheses" / "hypotheses_selected.json"
CALIB_DIR = ROOT / "models" / "hypothesis_calibrators"
FINAL_REPORT_PATH = ROOT / "reports" / "hypothesis_fp_reduction_report_calibrated.md"

DIMENSIONS = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]

def verify():
    if not INPUT_PATH.exists(): return
    df = pd.read_parquet(INPUT_PATH)
    
    with open(HYPOTHESES_PATH, "r") as f:
        selected_hyps = json.load(f)
        
    calibrators = {}
    if CALIB_DIR.exists():
        import joblib
        for dim in DIMENSIONS:
            c_path = CALIB_DIR / f"calib_{dim}.joblib"
            if c_path.exists():
                calibrators[dim] = joblib.load(c_path)
                
    logging.info(f"Applying adjustment with {len(calibrators)} calibrators to {len(df)} rows...")
    
    final_results = []
    for _, row in df.iterrows():
        sft_raw_scores = {}
        for dim in DIMENSIONS:
            # prefix in raw parquet is llm_sft_
            sft_raw_scores[f"{dim}_p1"] = row[f"llm_sft_{dim}_p1"]
            
        adjusted = HypothesisVerifier.adjust(row["body_text"], sft_raw_scores, selected_hyps, calibrators)
        
        res = {"url_canon": row["url_canon"]}
        for dim in DIMENSIONS:
            res[f"calib_{dim}_score"] = adjusted[f"{dim}_score"]
            res[f"calib_{dim}_p1"] = adjusted[f"{dim}_p1"]
            res[f"gold_{dim}"] = row[f"gold_{dim}"]
            res[f"raw_{dim}_score"] = row[f"llm_sft_{dim}_score"]
            
        final_results.append(res)
        
    res_df = pd.DataFrame(final_results)
    
    # Compute Metrics
    report = ["# Hypothesis FP Reduction Report (CALIBRATED)\n"]
    
    for prefix, label in [("raw", "Raw SFT"), ("calib", "Calibrated SFT")]:
        report.append(f"### {label}\n")
        metrics_rows = []
        for dim in ["decision", "method_rct", "method_case_study"]:
            gold_col = f"gold_{dim}"
            pred_col = f"{prefix}_{dim}_score"
            
            temp = res_df[res_df[gold_col].notna()]
            y_true = (temp[gold_col] == 1.0).astype(int)
            y_pred = (temp[pred_col] == 1.0).astype(int)
            
            tp = int(((y_true == 1) & (y_pred == 1)).sum())
            fp = int(((y_true == 0) & (y_pred == 1)).sum())
            fn = int(((y_true == 1) & (y_pred == 0)).sum())
            
            p = tp / (tp + fp) if (tp + fp) > 0 else 0
            r = tp / (tp + fn) if (tp + fn) > 0 else 0
            
            metrics_rows.append({"Dimension": dim, "P": p, "R": r, "FP": fp, "TP": tp})
            
        report.append(pd.DataFrame(metrics_rows).to_markdown(index=False) + "\n")

    # Final Verdict on Decision
    def get_dim_metrics(prefix, dim):
        temp = res_df[res_df[f"gold_{dim}"].notna()]
        y_true = (temp[f"gold_{dim}"] == 1.0).astype(int)
        y_pred = (temp[f"{prefix}_{dim}_score"] == 1.0).astype(int)
        tp = int(((y_true == 1) & (y_pred == 1)).sum())
        fp = int(((y_true == 0) & (y_pred == 1)).sum())
        return tp, fp

    raw_tp, raw_fp = get_dim_metrics("raw", "decision")
    cal_tp, cal_fp = get_dim_metrics("calib", "decision")
    
    fp_red = (raw_fp - cal_fp) / raw_fp if raw_fp > 0 else 0
    tp_loss = (raw_tp - cal_tp) / raw_tp if raw_tp > 0 else 0
    
    report.append(f"**Decision FP Reduction**: {fp_red*100:.1f}%\n")
    report.append(f"**Decision TP Loss**: {tp_loss*100:.1f}%\n")
    
    if fp_red >= 0.30 and tp_loss <= 0.15:
        report.append("\n> [!IMPORTANT]\n> TARGETS ACHIEVED: FP Reduction >= 30%, TP Loss <= 15%.")
    else:
        report.append("\n> [!WARNING]\n> TARGETS NOT FULLY ACHIEVED. Manual tuning of calibrator thresholds or tighter hypotheses may be required.")

    with open(FINAL_REPORT_PATH, "w") as f:
        f.write("\n".join(report))
        
    logging.info(f"Verification complete. Report saved to {FINAL_REPORT_PATH}")

if __name__ == "__main__":
    verify()
