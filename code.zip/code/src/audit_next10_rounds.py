import argparse
import os
import json
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def audit_round(round_id: int):
    # 1. Ensure DPO CSV exists
    dpo_csv_path = BASE_DIR / f"outputs/rounds/round_{round_id}/round_{round_id}_DPO_papers.csv"
    if not dpo_csv_path.exists():
        return False, f"Missing {dpo_csv_path.name}"
        
    sft_csv_path = BASE_DIR / f"outputs/rounds/round_{round_id}/round_{round_id}_SFT_papers.csv"
    if not sft_csv_path.exists():
        return False, f"Missing {sft_csv_path.name}"

    try:
        df_dpo = pd.read_csv(dpo_csv_path)
        df_sft = pd.read_csv(sft_csv_path)
    except pd.errors.EmptyDataError:
        df_dpo = pd.DataFrame()
        df_sft = pd.DataFrame()

    # 2. Extract valid counts from scored_results
    scored_path = BASE_DIR / f"outputs/rounds/round_{round_id}/scored_results_full.parquet"
    if not scored_path.exists():
        return False, f"Missing scored_results_full.parquet"
        
    df_scored = pd.read_parquet(scored_path)
    dpo_valid_count = df_scored['dpo_valid'].sum() if 'dpo_valid' in df_scored.columns else 0
    dpo_attempted_count = df_scored['dpo_attempted'].sum() if 'dpo_attempted' in df_scored.columns else 0
    
    cb_triggered = 0
    if 'dpo_circuit_breaker_triggered' in df_scored.columns:
        cb_triggered = df_scored['dpo_circuit_breaker_triggered'].sum()
        
    # 3. Ensure DPO row parity
    dpo_csv_rows = len(df_dpo)
    if dpo_valid_count != dpo_csv_rows:
        return False, f"Row parity fail: {dpo_valid_count} valid in parquet, but {dpo_csv_rows} rows in DPO CSV"
        
    # 4. Ensure DPO model name matches fine_tuned_model
    meta_path = BASE_DIR / f"audits/round_{round_id}/dpo_meta.json"
    actual_dpo_model = "unknown"
    if meta_path.exists():
        with open(meta_path, "r") as f:
            meta = json.load(f)
            actual_dpo_model = meta.get("dpo_model_name", "unknown")
            
    # Read target from state
    target_dpo_model = "unknown"
    state_path = BASE_DIR / "project_state/STATE.json"
    if state_path.exists():
        with open(state_path, "r") as f:
            state = json.load(f)
            target_dpo_model = state.get("dpo_model_name", "unknown")
            
    if actual_dpo_model != target_dpo_model and target_dpo_model != "unknown":
        return False, f"Model mismatch: logged {actual_dpo_model}, expected {target_dpo_model}"

    # Calculate "High" counts
    # DPO High: (llm_dpo_decision_score == 1 OR max(llm_dpo_method_*_score) == 1)
    if 'dpo_valid' in df_scored.columns and len(df_scored[df_scored['dpo_valid'] == True]) > 0:
        dpo_df = df_scored[df_scored['dpo_valid'] == True].copy()
        methods = [c for c in dpo_df.columns if c.startswith('llm_dpo_method_') and c.endswith('_score')]
        if methods:
            dpo_df['max_dpo_method'] = dpo_df[methods].max(axis=1)
            high_dpo = dpo_df[(dpo_df['llm_dpo_decision_score'] == 1) | (dpo_df['max_dpo_method'] == 1)]
            dpo_high_count = len(high_dpo)
        else:
            dpo_high_count = 0
    else:
        dpo_high_count = 0
        
    # Consensus logic check handled by main runner, just report here
    log_path = BASE_DIR / "outputs/query_log.csv"
    consensus_high = 0
    scored_count = len(df_scored)
    if log_path.exists():
        log = pd.read_csv(log_path)
        round_log = log[log['round_id'] == round_id]
        if not round_log.empty:
            consensus_high = round_log.iloc[-1]['consensus_high_rel_count']
            
    # Compile stats
    stats = {
        "round": round_id,
        "scored_count": scored_count,
        "dpo_attempted_count": dpo_attempted_count,
        "dpo_valid_count": dpo_valid_count,
        "valid_rate": dpo_valid_count / dpo_attempted_count if dpo_attempted_count > 0 else 0,
        "circuit_breaker": cb_triggered > 0,
        "dpo_high_count": dpo_high_count,
        "consensus_high": consensus_high
    }
    
    return True, stats

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    args = parser.parse_args()
    
    report = ["# Next 10 DPO Participation Summary\n"]
    report.append("| Round | Scored | Attempted | Valid | Valid Rate | CB Triggered | DPO High | Consensus High |")
    report.append("| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
    
    all_stats = []
    failed = False
    
    for rid in range(args.start, args.end + 1):
        ok, res = audit_round(rid)
        if not ok:
            print(f"AUDIT FAILED on Round {rid}: {res}")
            failed = True
            break
            
        report.append(f"| {res['round']} | {res['scored_count']} | {res['dpo_attempted_count']} | {res['dpo_valid_count']} | {res['valid_rate']:.2%} | {res['circuit_breaker']} | {res['dpo_high_count']} | {res['consensus_high']} |")
        all_stats.append(res)
        
    out_path = BASE_DIR / "reports/next10_dpo_participation_summary.md"
    with open(out_path, "w") as f:
        f.write("\n".join(report))
        
    if failed:
        import sys
        sys.exit(1)
        
    print(f"All audits passed for rounds {args.start} to {args.end}.")
    print(f"Summary written to {out_path}")

if __name__ == "__main__":
    main()
