import json
import tiktoken
from collections import Counter
from pathlib import Path
import sys

BASE_DIR = Path(__file__).resolve().parent.parent

def load_jsonl(path):
    with open(path) as f:
        return [json.loads(line) for line in f]

def extract_labels(json_str):
    try:
        data = json.loads(json_str)
        labels = {}
        labels['decision'] = data.get("decision", {}).get("score", 0)
        for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
            labels[m] = data.get(f"method_{m}", {}).get("score", 0)
        return labels
    except:
        return None

def audit_dataset(lines, name, enc):
    total = len(lines)
    if total == 0:
        return None
        
    schema_valid = 0
    identical_pairs = 0
    exact_one_dim_diff = 0
    
    total_tokens = 0
    label_counts = {k: Counter() for k in ["decision", "rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]}
    
    for row in lines:
        try:
            pref = row["preferred_output"][0]["content"]
            non_pref = row["non_preferred_output"][0]["content"]
            
            p_json = json.loads(pref)
            n_json = json.loads(non_pref)
            
            # schema check (simplified, assuming we check keys exist)
            valid = True
            for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
                if k not in p_json or k not in n_json: valid = False
            
            if valid: schema_valid += 1
            if pref == non_pref: identical_pairs += 1
            
            p_labels = extract_labels(pref)
            n_labels = extract_labels(non_pref)
            
            if p_labels and n_labels:
                diff_count = sum(1 for k in p_labels if p_labels[k] != n_labels[k])
                if diff_count == 1:
                    exact_one_dim_diff += 1
                    
                for k, v in p_labels.items():
                    label_counts[k][v] += 1
            
            prompt = row["input"]["messages"][1]["content"]
            total_tokens += len(enc.encode(prompt + pref + non_pref))
            
        except Exception as e:
            print(f"Error parsing row: {e}")
            pass
            
    return {
        "name": name,
        "total": total,
        "schema_valid_rate": schema_valid / total,
        "identical_pair_rate": identical_pairs / total,
        "exact_one_dim_diff_rate": exact_one_dim_diff / total,
        "avg_tokens": total_tokens / total,
        "label_counts": label_counts
    }

def main():
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    
    train_path = BASE_DIR / "fine_tune_data" / "dpo_train_v2_fast.jsonl"
    val_path = BASE_DIR / "fine_tune_data" / "dpo_val_v2_fast.jsonl"
    
    train_lines = load_jsonl(train_path)
    val_lines = load_jsonl(val_path)
    
    train_stats = audit_dataset(train_lines, "Train", enc)
    val_stats = audit_dataset(val_lines, "Validation", enc)
    
    report = ["# DPO Fast Run Dataset Audit\n"]
    
    passed_all = True
    
    for stats in [train_stats, val_stats]:
        if not stats: continue
        report.append(f"## {stats['name']} Set")
        report.append(f"- **Total Pairs**: {stats['total']}")
        report.append(f"- **Schema Valid Rate**: {stats['schema_valid_rate']:.2%}")
        report.append(f"- **Identical Pair Rate**: {stats['identical_pair_rate']:.2%}")
        report.append(f"- **Hard Negative Diff Rate (exactly 1 dim diff)**: {stats['exact_one_dim_diff_rate']:.2%}")
        report.append(f"- **Avg Tokens per Pair**: {stats['avg_tokens']:.0f}")
        
        # Check assertions
        if stats['schema_valid_rate'] < 1.0: passed_all = False
        if stats['identical_pair_rate'] > 0: passed_all = False
        if stats['exact_one_dim_diff_rate'] < 0.95: passed_all = False
        if stats['avg_tokens'] > 450: passed_all = False
        
        report.append("\n### Label Coverage (Preferred)")
        for k, counts in stats['label_counts'].items():
            report.append(f"- **{k}**: {dict(counts)}")
        report.append("\n")
        
    audit_path = BASE_DIR / "reports/dpo_v2_fast_audit.md"
    audit_path.parent.mkdir(exist_ok=True, parents=True)
    with open(audit_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Audit written to {audit_path}")
    
    if not passed_all:
        print("FAIL: Dataset failed one or more strict audit checks (schema=100%, identical=0, exact_diff>=95%, tokens<=450).")
        sys.exit(1)
    else:
        print("PASS: Dataset passed all strict criteria.")

if __name__ == "__main__":
    main()
