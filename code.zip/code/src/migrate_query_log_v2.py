import pandas as pd
import datetime
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.config_loader import get_config

# Required columns from V2 contract
REQUIRED_COLUMNS = [
    "round_id", "timestamp_utc_iso",
    "query_base", "query_final", "template_id", "target_method", "backoff_level_used",
    "preflight_total_available", "preflight_totals_by_level", 
    "guardian_total_available", "guardian_pages_fetched", "guardian_page_size",
    "guardian_candidates_retrieved", "guardian_requests_this_round", "guardian_keys_used",
    "guardian_candidates_retrieved", "guardian_requests_this_round", "guardian_keys_used",
    "guardian_key_rotations_this_round",
    "skipped_live_count", "skipped_long_count", "skipped_missing_text_count", "filtered_remaining_count",
    "scored_count", "random_seed_used",
    "high_rel_model1_count", "high_rel_model3_count", "high_rel_llm_final_count", "high_rel_dpo_count",
    "consensus_high_rel_count",
    "new_consensus_credit_total", "new_llm_new_total", "duplicate_rate_consensus",
    "new_consensus_credit_rct", "new_consensus_credit_prepost", "new_consensus_credit_case_study",
    "new_consensus_credit_expert_qual", "new_consensus_credit_expert_secondary", "new_consensus_credit_gut",
    "new_llm_rct", "new_llm_prepost", "new_llm_case_study", "new_llm_expert_qual", "new_llm_expert_secondary", "new_llm_gut",
    "reward_R", "reward_V", "reward_U_all", "reward_U_llm", "reward_DUP",
    "reward_weight_alpha", "reward_weight_beta", "reward_weight_gamma", "reward_weight_delta",
    "query_budget_cap_usd", "query_cost_this_round_usd", "query_cost_cumulative_usd",
    # Legacy/Existing columns to keep
    "timestamp", "llm_high_count", "dpo_attempted_count", "dpo_valid_count", "dpo_success_rate", 
    "dpo_high_count", "llm_mode_used_counts", "dpo_fail_reason_counts"
]

DEFAULTS = {
    "query_base": "MIGRATED", "query_final": "MIGRATED", "template_id": "MIGRATED",
    "target_method": "unknown", "backoff_level_used": -1,
    "preflight_total_available": 0, "preflight_totals_by_level": "{}",
    "guardian_total_available": 0,
    "guardian_pages_fetched": 0, "guardian_page_size": 50, "guardian_candidates_retrieved": 0,
    "guardian_requests_this_round": 0, "guardian_keys_used": "unknown",
    "guardian_key_rotations_this_round": 0,
    "skipped_live_count": 0, "skipped_long_count": 0, "skipped_missing_text_count": 0,
    "filtered_remaining_count": 0, "scored_count": 0, "random_seed_used": 0,
    "high_rel_model1_count": 0, "high_rel_model3_count": 0, "high_rel_llm_final_count": 0,
    "high_rel_dpo_count": 0, "consensus_high_rel_count": 0,
    "new_consensus_credit_total": 0.0, "new_llm_new_total": 0, "duplicate_rate_consensus": 0.0,
    "new_consensus_credit_rct": 0.0, "new_consensus_credit_prepost": 0.0, "new_consensus_credit_case_study": 0.0,
    "new_consensus_credit_expert_qual": 0.0, "new_consensus_credit_expert_secondary": 0.0, "new_consensus_credit_gut": 0.0,
    "new_llm_rct": 0, "new_llm_prepost": 0, "new_llm_case_study": 0, "new_llm_expert_qual": 0,
    "new_llm_expert_secondary": 0, "new_llm_gut": 0,
    "reward_R": 0.0, "reward_V": 0.0, "reward_U_all": 0.0, "reward_U_llm": 0.0, "reward_DUP": 0.0,
    "reward_weight_alpha": 0.25, "reward_weight_beta": 0.15, "reward_weight_gamma": 0.60, "reward_weight_delta": 0.20,
    "query_budget_cap_usd": 60.0, "query_cost_this_round_usd": 0.0, "query_cost_cumulative_usd": 0.0
}

def migrate():
    log_path = Path("outputs/query_log.csv")
    backup_path = Path("outputs/query_log.csv.bak")
    audit_path = Path("audits/query_log_migration.md")
    
    if not log_path.exists():
        print("No query_log.csv found. Creating new empty.")
        df = pd.DataFrame(columns=REQUIRED_COLUMNS)
        df.to_csv(log_path, index=False)
        return
        
    df = pd.read_csv(log_path)
    
    # Backup
    import shutil
    shutil.copy(log_path, backup_path)
    
    # Add Missing Cols
    added_cols = []
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            added_cols.append(col)
            default_val = DEFAULTS.get(col, 0)
            df[col] = default_val
            
    # Timestamp Migration
    if "timestamp_utc_iso" in added_cols and "timestamp" in df.columns:
        # Try to migrate timestamp if useful, or just use now
        # Existing timestamp (from Step 0) might be naive ISO, let's keep it if possible or copy
        # For this exercise we just default to current migration time or copy valid strings
        df["timestamp_utc_iso"] = df["timestamp"].fillna(datetime.datetime.now(datetime.timezone.utc).isoformat())
        
    # Reorder
    # Keep existing extra cols if any? Yes, prompt said "Keep the existing 9 columns too" - included in REQUIRED_COLUMNS list above already
    # But just to be safe, we reindex with intersection + missing
    all_cols = REQUIRED_COLUMNS + [c for c in df.columns if c not in REQUIRED_COLUMNS]
    df = df[all_cols]
    
    # Save
    df.to_csv(log_path, index=False)
    
    # Audit
    txt = f"""# Query Log Migration V2 Audit
    
    Timestamp: {datetime.datetime.now(datetime.timezone.utc).isoformat()}
    Original Rows: {len(df)}
    Added Columns: {len(added_cols)}
    
    ## Added Columns:
    {', '.join(added_cols)}
    
    Backup created at {backup_path}
    """
    
    with open(audit_path, "w") as f:
        f.write(txt)
        
    print(f"Migration complete. Added {len(added_cols)} columns.")

if __name__ == "__main__":
    migrate()
