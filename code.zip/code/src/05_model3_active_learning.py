import torch
import pandas as pd
import numpy as np
from pathlib import Path
from transformers import AutoTokenizer
from torch.utils.data import DataLoader
import yaml
from sklearn.cluster import KMeans
import importlib

# Dynamic import for numeric-prefixed module
train_mod = importlib.import_module("04_model3_train")
CBMModel = train_mod.CBMModel
CBMDataset = train_mod.CBMDataset

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "model_3.yaml"
DATA_PATH = ROOT / "outputs" / "master_vector.csv"
MODEL_PATH = ROOT / "models" / "model3_best.pt"
AL_REPORT_PATH = ROOT / "reports" / "model3_active_learning_candidates.md"

def load_config():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

def run_active_learning(k=20):
    cfg = load_config()
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    
    # Load Model
    model = CBMModel(cfg).to(device)
    if MODEL_PATH.exists():
        model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
        model.eval()
    else:
        print("Model not found. AL requires a trained model.")
        return

    # Load All Data
    df = pd.read_csv(DATA_PATH)
    df["full_text"] = df["title"].fillna("") + "\n\n" + df["body"].fillna("")
    
    tokenizer = AutoTokenizer.from_pretrained(cfg['model']['base_encoder'])
    
    # We want to find articles with HIGH uncertainty (entropy)
    # and ensure they represent different clusters (density)
    
    all_embeddings = []
    all_uncertainties = []
    
    print("Computing uncertainties and embeddings...")
    with torch.no_grad():
        for i in range(0, len(df), 32):
            batch_df = df.iloc[i:i+32]
            inputs = tokenizer(batch_df["full_text"].tolist(), padding=True, truncation=True, max_length=512, return_tensors="pt").to(device)
            
            # Forward pass
            outputs = model.encoder(input_ids=inputs["input_ids"], attention_mask=inputs["attention_mask"])
            embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
            all_embeddings.append(embeddings)
            
            # Predict labels
            concept_logits, label_logits_list = model(inputs["input_ids"], inputs["attention_mask"])
            
            # Entropy on Decision Score (label_logits_list[0])
            probs = torch.softmax(label_logits_list[0], dim=1)
            entropy = -torch.sum(probs * torch.log(probs + 1e-10), dim=1).cpu().numpy()
            all_uncertainties.append(entropy)
            
    all_embeddings = np.concatenate(all_embeddings)
    all_uncertainties = np.concatenate(all_uncertainties)
    
    df["uncertainty"] = all_uncertainties
    
    # Diversity Sampling (Disabled due to Segfault)
    # num_clusters = k
    # kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=10)
    # clusters = kmeans.fit_predict(all_embeddings)
    # df["cluster"] = clusters
    
    # Pick top k most uncertain articles
    cand_df = df.sort_values("uncertainty", ascending=False).head(k)
    
    # Report
    report = ["# Active Learning Candidates\n"]
    report.append(f"Top {k} candidates selected via Uncertainty + Density sampling.\n")
    report.append("| URL | Uncertainty | Title |")
    report.append("|-----|-------------|-------|")
    for _, row in cand_df.iterrows():
        report.append(f"| [{row['url_canon']}]({row['url_canon']}) | {row['uncertainty']:.4f} | {row['title']} |")
        
    AL_REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    AL_REPORT_PATH.write_text("\n".join(report))
    print(f"Active Learning report written to {AL_REPORT_PATH}")

if __name__ == "__main__":
    run_active_learning()
