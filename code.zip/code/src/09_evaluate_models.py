#!/usr/bin/env python3
"""
Step 9: Evaluate models — TGML baseline, base generator, SFT, DPO.
On the held-out test set. Writes final_eval_report.md.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import yaml
from dotenv import load_dotenv
from sklearn.metrics import classification_report, confusion_matrix, f1_score

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def check_budget(estimated_cost: float, ledger: dict, cfg: dict) -> bool:
    cap = cfg["budget"]["total_cap_usd"]
    remaining = cap - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"]
    return estimated_cost <= remaining


def evaluate_tgml(test_df: pd.DataFrame, model_dir: Path) -> dict:
    """Evaluate TGML baseline on test set."""
    tfidf = joblib.load(model_dir / "tfidf_vectorizer.joblib")
    results = {}

    # Decision
    dec_clf = joblib.load(model_dir / "decision_ordinal.joblib")
    mask = test_df["decision_score"].notna()
    if mask.sum() > 0:
        X = tfidf.transform(test_df.loc[mask, "text_for_model"].fillna(""))
        y_true = test_df.loc[mask, "decision_score"].values
        y_pred = dec_clf.predict(X)
        str_labels = ["0.0", "0.5", "1.0"]
        f1 = f1_score(
            [str(float(v)) for v in y_true],
            [str(float(v)) for v in y_pred],
            labels=str_labels, average="macro", zero_division=0,
        )
        results["decision"] = {"macro_f1": round(f1, 4), "n": int(mask.sum())}

    # Methods
    for mt in sorted(test_df["method_type"].unique()):
        mt_path = model_dir / f"method_{mt}.joblib"
        if not mt_path.exists():
            continue
        clf = joblib.load(mt_path)
        sub = test_df[test_df["method_type"] == mt]
        if len(sub) == 0:
            continue
        X = tfidf.transform(sub["text_for_model"].fillna(""))
        y_true = sub["method_score"].values
        y_pred = clf.predict(X)
        f1 = f1_score(
            [str(float(v)) for v in y_true],
            [str(float(v)) for v in y_pred],
            labels=["0.0", "0.5", "1.0"], average="macro", zero_division=0,
        )
        results[mt] = {"macro_f1": round(f1, 4), "n": len(sub)}

    return results


def evaluate_llm(test_df: pd.DataFrame, model_name: str, label: str,
                 client, cfg: dict, ledger: dict, max_eval: int = 100) -> dict:
    """Evaluate an LLM model (base/SFT/DPO) on test set."""

    eval_sub = test_df.sample(n=min(max_eval, len(test_df)), random_state=42)
    results = {}
    y_true_dec, y_pred_dec = [], []
    y_true_method, y_pred_method = [], []
    parse_errors = 0

    system = """You are labeling Guardian-style news articles for a research dataset.
Use the scoring rubric exactly. Output ONLY valid JSON matching the schema, no extra keys, no prose.
Output schema: {"decision_score": 0|0.5|1, "method_type": "<type>", "method_score": 0|0.5|1}"""

    for _, row in eval_sub.iterrows():
        user_msg = f"Method type to score: {row['method_type']}\n\nArticle:\n{str(row['text_for_model'])[:3000]}"
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user_msg},
        ]
        try:
            # Use direct caching from step 5 module
            import hashlib
            cache_dir = ROOT / "project_state" / "api_cache"
            key = hashlib.md5(json.dumps({"model": model_name, "messages": messages},
                                          sort_keys=True).encode()).hexdigest()
            cache_file = cache_dir / f"{key}.json"

            if cache_file.exists():
                raw = json.loads(cache_file.read_text())["content"]
            else:
                if not check_budget(0.05, ledger, cfg):
                    print(f"  ⚠ Budget tight, stopping {label} eval early")
                    break
                resp = client.chat.completions.create(
                    model=model_name, messages=messages,
                    temperature=0.0, max_tokens=100,
                )
                raw = resp.choices[0].message.content
                actual_cost = (resp.usage.prompt_tokens / 1e6 * 0.40 +
                               resp.usage.completion_tokens / 1e6 * 1.60)
                ledger["total_spent_usd"] = round(ledger["total_spent_usd"] + actual_cost, 4)
                ledger["remaining_budget_usd"] = round(
                    50.0 - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"], 4)
                ledger["per_step_costs"].append({"step": f"eval_{label}", "cost_usd": round(actual_cost, 4)})
                cache_file.write_text(json.dumps({"model": model_name, "content": raw}, indent=2))

            start = raw.find("{")
            end = raw.rfind("}") + 1
            pred = json.loads(raw[start:end])
            y_true_dec.append(row["decision_score"])
            y_pred_dec.append(pred.get("decision_score", -1))
            y_true_method.append(row["method_score"])
            y_pred_method.append(pred.get("method_score", -1))
        except Exception:
            parse_errors += 1

    if len(y_true_dec) >= 5:
        str_labels = ["0.0", "0.5", "1.0"]
        dec_f1 = f1_score(
            [str(float(v)) for v in y_true_dec],
            [str(float(v)) for v in y_pred_dec],
            labels=str_labels, average="macro", zero_division=0,
        )
        method_f1 = f1_score(
            [str(float(v)) for v in y_true_method],
            [str(float(v)) for v in y_pred_method],
            labels=str_labels, average="macro", zero_division=0,
        )
        results["decision"] = {"macro_f1": round(dec_f1, 4), "n": len(y_true_dec)}
        results["method_overall"] = {"macro_f1": round(method_f1, 4), "n": len(y_true_method)}
        results["parse_errors"] = parse_errors

    save_ledger(ledger)
    return results


def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()

    # Load test data
    df = pd.read_parquet(ROOT / "data" / "processed" / "training_long.parquet")
    with open(ROOT / "data" / "processed" / "article_splits.json") as f:
        splits = json.load(f)
    test_df = df[df["article_id"].isin(set(splits["test_articles"]))].copy()
    print(f"Test set: {len(test_df)} rows")

    report_lines = ["# Final Evaluation Report\n"]

    # ── TGML baseline ─────────────────────────────────────────────────
    print("\n── TGML Baseline ──")
    tgml_dir = ROOT / "models" / "tgml"
    if tgml_dir.exists():
        tgml_results = evaluate_tgml(test_df, tgml_dir)
        print(f"  Results: {tgml_results}")
        report_lines.append("## TGML Baseline (Test Set)\n")
        report_lines.append("| Target | Macro F1 | n |")
        report_lines.append("|--------|----------|---|")
        for k, v in tgml_results.items():
            report_lines.append(f"| {k} | {v['macro_f1']:.3f} | {v['n']} |")
        report_lines.append("")

    # ── LLM models ────────────────────────────────────────────────────
    from openai import OpenAI
    client = OpenAI()

    # Base generator
    print("\n── Base Generator ──")
    base_model = cfg["fixed_models"]["generator_G"]
    base_results = evaluate_llm(test_df, base_model, "base", client, cfg, ledger)
    if base_results:
        report_lines.append(f"## Base Generator: `{base_model}` (Test Set)\n")
        for k, v in base_results.items():
            if isinstance(v, dict):
                report_lines.append(f"- {k}: F1={v['macro_f1']:.3f} (n={v['n']})")
            else:
                report_lines.append(f"- {k}: {v}")
        report_lines.append("")

    # SFT model
    sft_model = state.get("latest_finetuned_model_name")
    if sft_model and "step_6" in str(state.get("steps_completed", [])):
        print(f"\n── SFT Model: {sft_model} ──")
        sft_results = evaluate_llm(test_df, sft_model, "sft", client, cfg, ledger)
        if sft_results:
            report_lines.append(f"## SFT Model: `{sft_model}` (Test Set)\n")
            for k, v in sft_results.items():
                if isinstance(v, dict):
                    report_lines.append(f"- {k}: F1={v['macro_f1']:.3f} (n={v['n']})")
                else:
                    report_lines.append(f"- {k}: {v}")
            report_lines.append("")

    # DPO model
    dpo_job_id = state.get("latest_dpo_job_id")
    if dpo_job_id:
        try:
            dpo_job = client.fine_tuning.jobs.retrieve(dpo_job_id)
            if dpo_job.status == "succeeded" and dpo_job.fine_tuned_model:
                dpo_model = dpo_job.fine_tuned_model
                print(f"\n── DPO Model: {dpo_model} ──")
                dpo_results = evaluate_llm(test_df, dpo_model, "dpo", client, cfg, ledger)
                if dpo_results:
                    report_lines.append(f"## DPO Model: `{dpo_model}` (Test Set)\n")
                    for k, v in dpo_results.items():
                        if isinstance(v, dict):
                            report_lines.append(f"- {k}: F1={v['macro_f1']:.3f} (n={v['n']})")
                        else:
                            report_lines.append(f"- {k}: {v}")
                    report_lines.append("")
        except Exception as e:
            print(f"  Could not check DPO job: {e}")

    # ── Budget ────────────────────────────────────────────────────────
    report_lines.append(f"\n## Budget Status")
    report_lines.append(f"- Total spent: ${ledger['total_spent_usd']:.2f}")
    report_lines.append(f"- Remaining: ${ledger['remaining_budget_usd']:.2f}")

    # ── Save ──────────────────────────────────────────────────────────
    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "final_eval_report.md").write_text("\n".join(report_lines))
    print(f"\n✓ Report → {report_dir / 'final_eval_report.md'}")

    # Update state
    if "step_9_eval" not in state["steps_completed"]:
        state["steps_completed"].append("step_9_eval")
    state["current_step"] = "step_9_complete"
    save_state(state)
    save_ledger(ledger)

    print(f"\n{'='*60}")
    print(f"  EVALUATION COMPLETE")
    print(f"  Cost: ${ledger['total_spent_usd']:.2f} / $50.00")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
