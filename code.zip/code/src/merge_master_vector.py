#!/usr/bin/env python3
"""
merge_master_vector.py
======================
Merge 5 method-coded Guardian CSVs into a single master vector dataset.

Usage:
    python src/merge_master_vector.py --data-dir ./data/raw --out-dir ./outputs --audit-dir ./audits
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# ──────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────

CORE_COLS = ["id", "title", "date", "url", "section", "body", "Method", "Decision"]
METADATA_COLS = ["id", "title", "url", "section", "body", "date"]

METHOD_COL_NAMES = [
    "method_rct",
    "method_prepost",
    "method_case_study",
    "method_expert_qual",
    "method_expert_secondary",
    "method_gut",
]

DATASET_TO_METHOD = {
    "rct": "method_rct",
    "prepost": "method_prepost",
    "case_studies": "method_case_study",
    "quantitative": "method_expert_secondary",
    "gut": "method_gut",
}

ALLOWED_LABELS = {0.0, 0.5, 1.0}

EXPECTED_COUNTS = {
    "rct":           {"rows": 515, "method_nn": 511, "decision_nn": 511},
    "prepost":       {"rows": 92,  "method_nn": 92,  "decision_nn": 92},
    "case_studies":  {"rows": 329, "method_nn": 327, "decision_nn": 326},
    "quantitative":  {"rows": 31,  "method_nn": 31,  "decision_nn": 31},
    "gut":           {"rows": 99,  "method_nn": 99,  "decision_nn": 99},
}

FILE_MAP = {
    "rct": "rct.csv",
    "prepost": "prepost.csv",
    "case_studies": "case studies.csv",
    "quantitative": "quantitative.csv",
    "gut": "gut.csv",
}

TRAINING_KEEP_COLS = [
    "method_category", "title", "source", "url", "url_canon",
    "prototype_score_0to5", "rubric_score_0to5", "notes",
    "bodyText", "bodyText_source", "fetch_status", "error_message",
    "fetched_at_utc",
]


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

def canonicalize_url(s: pd.Series) -> pd.Series:
    """Canonicalize URL: strip, remove query/fragment, remove trailing slash."""
    s = s.str.strip()
    # Remove query string
    s = s.str.replace(r"\?.*$", "", regex=True)
    # Remove fragment
    s = s.str.replace(r"#.*$", "", regex=True)
    # Remove trailing slash
    s = s.str.rstrip("/")
    # Convert empty strings to NA
    s = s.where(s.str.len() > 0, other=pd.NA)
    return s


def validate_labels(df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
    """Coerce Method/Decision to numeric; assert values in {0, 0.5, 1} or NA."""
    df = df.copy()
    for col in ("Method", "Decision"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
        non_null = df[col].dropna()
        bad = non_null[~non_null.isin(ALLOWED_LABELS)]
        if len(bad) > 0:
            raise ValueError(
                f"[{dataset_name}] {col} has invalid values outside {{0,0.5,1}}: "
                f"{bad.unique().tolist()}"
            )
    return df


def convert_keyword_cols(
    df: pd.DataFrame,
    exclude_cols: set[str],
    schema_issues: dict[str, Any],
    dataset_name: str,
) -> pd.DataFrame:
    """Convert keyword/indicator columns to nullable boolean dtype."""
    df = df.copy()
    kw_cols = [c for c in df.columns if c not in exclude_cols]

    for col in kw_cols:
        original = df[col].copy()
        # Map common representations
        mapping = {"True": True, "true": True, "TRUE": True,
                   "False": False, "false": False, "FALSE": False,
                   "1": True, "0": False, "1.0": True, "0.0": False}

        def _convert(v):
            if pd.isna(v):
                return pd.NA
            if isinstance(v, bool):
                return v
            if isinstance(v, (int, float)):
                if v == 1 or v == 1.0:
                    return True
                if v == 0 or v == 0.0:
                    return False
                return pd.NA  # unexpected numeric
            s = str(v).strip()
            if s == "" or s.lower() == "nan":
                return pd.NA
            if s in mapping:
                return mapping[s]
            return pd.NA  # unexpected string

        converted = original.map(_convert)
        # Count unexpected values that became NA but were not originally NA
        was_na = original.isna()
        is_na_now = converted.isna()
        newly_na = (~was_na) & is_na_now
        n_coerced = newly_na.sum()
        if n_coerced > 0:
            key = f"{dataset_name}.{col}"
            schema_issues[key] = int(n_coerced)

        df[col] = converted.astype("boolean")

    return df


def standardize_long(df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
    """Add 6 method columns (NA-initialized), fill exactly one from Method."""
    df = df.copy()

    # Initialize all method columns as NA float
    for mc in METHOD_COL_NAMES:
        df[mc] = pd.array([pd.NA] * len(df), dtype="Float64")

    # Fill the one method column for this dataset
    target_col = DATASET_TO_METHOD[dataset_name]
    df[target_col] = df["Method"].astype("Float64")

    # Rename Decision -> decision (lowercase, standardized output)
    df["decision"] = df["Decision"].astype("Float64")

    df["source_dataset"] = dataset_name

    return df


def first_non_null(series: pd.Series):
    """Return first non-null value from a series, or pd.NA."""
    non_null = series.dropna()
    if len(non_null) > 0:
        return non_null.iloc[0]
    return pd.NA


def tristate_or(series: pd.Series):
    """Tri-state OR: any True -> True, else any False -> False, else NA."""
    if series.any():
        return True
    if (~series.astype("boolean")).any():
        # There is at least one non-NA False
        non_na = series.dropna()
        if len(non_na) > 0:
            return False
    return pd.NA


# ──────────────────────────────────────────────────────────────────────
# Per-url_canon aggregation
# ──────────────────────────────────────────────────────────────────────

def aggregate_master(
    df_long: pd.DataFrame,
    keyword_cols: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Group by url_canon and aggregate into wide master dataset.
    Returns (master_df, decision_conflicts_df, method_conflicts_df).
    """
    decision_conflicts = []
    method_conflicts = []
    records = []

    grouped = df_long.groupby("url_canon", sort=False)

    for url_canon, grp in grouped:
        rec: dict[str, Any] = {"url_canon": url_canon}

        # 8a) Metadata: first non-null
        for col in METADATA_COLS:
            rec[col] = first_non_null(grp[col])

        # 8c) source_datasets
        sources = sorted(grp["source_dataset"].dropna().unique())
        rec["source_datasets"] = ";".join(sources)

        # 8d) Decision conflict detection
        dec_vals = grp["decision"].dropna().unique()
        dec_vals = sorted([float(v) for v in dec_vals])
        if len(dec_vals) == 0:
            rec["decision"] = pd.NA
            rec["decision_conflict"] = False
            rec["decision_values"] = pd.NA
        elif len(dec_vals) == 1:
            rec["decision"] = dec_vals[0]
            rec["decision_conflict"] = False
            rec["decision_values"] = pd.NA
        else:
            rec["decision"] = max(dec_vals)
            rec["decision_conflict"] = True
            rec["decision_values"] = json.dumps(dec_vals)
            decision_conflicts.append({
                "url_canon": url_canon,
                "decision_values": json.dumps(dec_vals),
                "decision_resolved": max(dec_vals),
                "source_datasets": rec["source_datasets"],
                "title": rec["title"],
            })

        # 8e) Method columns aggregation
        for mc in METHOD_COL_NAMES:
            vals = grp[mc].dropna().unique()
            vals = sorted([float(v) for v in vals])
            conflict_col = f"{mc}_conflict"
            values_col = f"{mc}_values"
            if len(vals) == 0:
                rec[mc] = pd.NA
                rec[conflict_col] = False
                rec[values_col] = pd.NA
            elif len(vals) == 1:
                rec[mc] = vals[0]
                rec[conflict_col] = False
                rec[values_col] = pd.NA
            else:
                rec[mc] = max(vals)
                rec[conflict_col] = True
                rec[values_col] = json.dumps(vals)
                method_conflicts.append({
                    "url_canon": url_canon,
                    "method_column": mc,
                    "method_values": json.dumps(vals),
                    "method_resolved": max(vals),
                    "source_datasets": rec["source_datasets"],
                    "title": rec["title"],
                })

        # 8f) Keyword columns: tri-state OR
        for kc in keyword_cols:
            if kc in grp.columns:
                s = grp[kc]
                if s.any():
                    rec[kc] = True
                else:
                    non_na = s.dropna()
                    if len(non_na) > 0:
                        rec[kc] = False
                    else:
                        rec[kc] = pd.NA
            else:
                rec[kc] = pd.NA

        records.append(rec)

    master = pd.DataFrame(records)

    # 8g) Sanity column
    master["num_method_scores_observed"] = master[METHOD_COL_NAMES].notna().sum(axis=1)

    # Convert dtypes
    master["decision"] = master["decision"].astype("Float64")
    for mc in METHOD_COL_NAMES:
        master[mc] = master[mc].astype("Float64")
    for kc in keyword_cols:
        if kc in master.columns:
            master[kc] = master[kc].astype("boolean")

    # Build conflict DataFrames
    dec_conflicts_df = pd.DataFrame(decision_conflicts) if decision_conflicts else pd.DataFrame(
        columns=["url_canon", "decision_values", "decision_resolved", "source_datasets", "title"]
    )
    meth_conflicts_df = pd.DataFrame(method_conflicts) if method_conflicts else pd.DataFrame(
        columns=["url_canon", "method_column", "method_values", "method_resolved", "source_datasets", "title"]
    )

    return master, dec_conflicts_df, meth_conflicts_df


# ──────────────────────────────────────────────────────────────────────
# Training cases (separate)
# ──────────────────────────────────────────────────────────────────────

def process_training_cases(data_dir: Path, out_dir: Path) -> None:
    """Clean Training_cases.csv and write outputs."""
    fpath = data_dir / "Training_cases.csv"
    if not fpath.exists():
        print(f"  ⚠  Training_cases.csv not found at {fpath}, skipping.")
        return

    df = pd.read_csv(
        fpath,
        encoding="utf-8-sig",
        dtype="string",
        keep_default_na=True,
        na_values=["", " "],
    )

    # Strip whitespace from string columns
    for col in df.columns:
        if df[col].dtype == "string":
            df[col] = df[col].str.strip()
            df[col] = df[col].where(df[col].str.len() > 0, other=pd.NA)

    # Canonicalize URL
    if "url" in df.columns:
        df["url_canon"] = canonicalize_url(df["url"])
    else:
        df["url_canon"] = pd.NA

    # Keep only specified columns that exist
    keep = [c for c in TRAINING_KEEP_COLS if c in df.columns]
    df = df[keep]

    df.to_parquet(out_dir / "training_cases_clean.parquet", index=False)
    df.to_csv(out_dir / "training_cases_clean.csv", index=False)
    print(f"  ✓ Training cases: {len(df)} rows → outputs/training_cases_clean.*")


# ──────────────────────────────────────────────────────────────────────
# Main pipeline
# ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Merge Guardian method-coded CSVs")
    parser.add_argument("--data-dir", type=str, default="./data/raw",
                        help="Directory containing input CSVs")
    parser.add_argument("--out-dir", type=str, default="./outputs",
                        help="Directory for output files")
    parser.add_argument("--audit-dir", type=str, default="./audits",
                        help="Directory for audit files")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    audit_dir = Path(args.audit_dir)

    # Create output directories
    out_dir.mkdir(parents=True, exist_ok=True)
    audit_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  GUARDIAN MERGE PIPELINE")
    print("=" * 70)
    print(f"  Data dir : {data_dir.resolve()}")
    print(f"  Output   : {out_dir.resolve()}")
    print(f"  Audits   : {audit_dir.resolve()}")
    print()

    # ── Accumulators ──────────────────────────────────────────────────
    row_counts: dict[str, Any] = {}
    schema_issues: dict[str, Any] = {}
    label_distributions: dict[str, Any] = {}
    all_long_dfs: list[pd.DataFrame] = []
    all_keyword_cols: set[str] = set()

    # Columns that are never keywords
    non_keyword_cols = set(CORE_COLS) | {"url_canon", "source_dataset",
                                         "legacy_method_1", "legacy_decision_1",
                                         "decision"} | set(METHOD_COL_NAMES)

    # ── Process each method-coded CSV ─────────────────────────────────
    for ds_name, filename in FILE_MAP.items():
        fpath = data_dir / filename
        print(f"─── {ds_name} ({filename}) ───")

        if not fpath.exists():
            print(f"  ✗ File not found: {fpath}")
            sys.exit(1)

        # Rule 1: Read with stable dtypes
        df = pd.read_csv(
            fpath,
            encoding="utf-8-sig",
            dtype="string",          # read everything as string first
            keep_default_na=True,
            na_values=["", " "],
        )

        # Strip whitespace from all string columns
        for col in df.columns:
            if df[col].dtype == "string":
                df[col] = df[col].str.strip()
                df[col] = df[col].where(
                    df[col].str.len() > 0, other=pd.NA
                )

        raw_rows = len(df)
        print(f"  Raw rows: {raw_rows}")

        # Rule 4: Case studies special handling
        if ds_name == "case_studies":
            if "method_1" in df.columns:
                df = df.rename(columns={"method_1": "legacy_method_1",
                                        "decision_1": "legacy_decision_1"})
                print("  Renamed method_1 → legacy_method_1, decision_1 → legacy_decision_1")

        # Rule 2: URL canonicalization
        if "url" not in df.columns:
            print(f"  ✗ Missing 'url' column!")
            sys.exit(1)
        df["url_canon"] = canonicalize_url(df["url"])
        before_url_filter = len(df)
        df = df[df["url_canon"].notna()].copy()
        after_url_filter = len(df)
        dropped_url = before_url_filter - after_url_filter
        if dropped_url > 0:
            print(f"  Dropped {dropped_url} rows with missing url_canon")
        print(f"  Rows after URL filter: {after_url_filter}")

        # Rule 3: Label validation
        df = validate_labels(df, ds_name)
        method_nn = int(df["Method"].notna().sum())
        decision_nn = int(df["Decision"].notna().sum())
        print(f"  Method non-null: {method_nn}, Decision non-null: {decision_nn}")

        # Record row counts
        row_counts[ds_name] = {
            "raw_rows": raw_rows,
            "rows_after_drop_missing_url": after_url_filter,
            "method_nonnull": method_nn,
            "decision_nonnull": decision_nn,
        }

        # Hard acceptance checks
        exp = EXPECTED_COUNTS[ds_name]
        warns = []
        if abs(after_url_filter - exp["rows"]) > 3:
            warns.append(f"rows: got {after_url_filter}, expected ~{exp['rows']}")
        if abs(method_nn - exp["method_nn"]) > 3:
            warns.append(f"Method non-null: got {method_nn}, expected ~{exp['method_nn']}")
        if abs(decision_nn - exp["decision_nn"]) > 3:
            warns.append(f"Decision non-null: got {decision_nn}, expected ~{exp['decision_nn']}")
        if warns:
            print(f"  ⚠  COUNT WARNINGS: {'; '.join(warns)}")
            schema_issues[f"{ds_name}_count_warnings"] = warns

        # Label distributions (convert keys to str to avoid NAType in JSON)
        def _safe_value_counts(series: pd.Series) -> dict[str, str]:
            vc = series.value_counts(dropna=False)
            out = {}
            for k, v in vc.items():
                key = "NA" if pd.isna(k) else str(k)
                out[key] = int(v)
            return out

        label_distributions[ds_name] = {
            "Method": _safe_value_counts(df["Method"]),
            "Decision": _safe_value_counts(df["Decision"]),
        }

        # Rule 4 cont: case studies legacy mismatch audit
        if ds_name == "case_studies" and "legacy_method_1" in df.columns:
            mismatch_mask = (
                (df["Method"].isna() & df["legacy_method_1"].notna()) |
                (df["Decision"].isna() & df["legacy_decision_1"].notna())
            )
            mismatch_df = df.loc[mismatch_mask, [
                "url_canon", "Method", "Decision",
                "legacy_method_1", "legacy_decision_1", "title"
            ]].copy()
            mismatch_df.to_csv(audit_dir / "case_studies_legacy_mismatch.csv", index=False)
            print(f"  Legacy mismatch rows: {len(mismatch_df)}")

        # Rule 5: Convert keyword columns to nullable boolean
        exclude_for_kw = non_keyword_cols.copy()
        kw_cols_before = [c for c in df.columns if c not in exclude_for_kw]
        df = convert_keyword_cols(df, exclude_for_kw, schema_issues, ds_name)
        all_keyword_cols.update(kw_cols_before)

        # Rule 6: Standardize to long format
        df = standardize_long(df, ds_name)

        all_long_dfs.append(df)
        print()

    # ── Rule 7: Concatenate ───────────────────────────────────────────
    print("─── CONCATENATION ───")
    df_long = pd.concat(all_long_dfs, ignore_index=True, sort=False)
    print(f"  Concatenated long rows: {len(df_long)}")

    if abs(len(df_long) - 1066) > 10:
        print(f"  ⚠  Expected ~1066 concat rows, got {len(df_long)}")
        schema_issues["concat_row_warning"] = f"Expected ~1066, got {len(df_long)}"

    # Write row counts audit
    with open(audit_dir / "row_counts.json", "w") as f:
        json.dump(row_counts, f, indent=2, default=str)
    print(f"  ✓ audits/row_counts.json written")

    # Duplicate URLs across datasets
    url_ds = df_long[["url_canon", "source_dataset"]].drop_duplicates()
    dup_urls = url_ds.groupby("url_canon").filter(lambda g: len(g) > 1)
    dup_urls = dup_urls.sort_values("url_canon")
    dup_urls.to_csv(audit_dir / "duplicate_urls_across_datasets.csv", index=False)
    print(f"  Duplicate URLs across datasets: {dup_urls['url_canon'].nunique()} url_canons")
    print()

    # ── Rule 8: Aggregate to wide master ──────────────────────────────
    print("─── AGGREGATION (groupby url_canon) ───")
    keyword_cols_list = sorted(all_keyword_cols)
    master, dec_conflicts_df, meth_conflicts_df = aggregate_master(
        df_long, keyword_cols_list
    )

    unique_urls = master["url_canon"].nunique()
    print(f"  Unique url_canon (master rows): {len(master)}")
    if abs(len(master) - 1062) > 10:
        print(f"  ⚠  Expected ~1062 unique urls, got {len(master)}")
        schema_issues["master_row_warning"] = f"Expected ~1062, got {len(master)}"

    # 8b) Parse date
    master["date_utc"] = pd.to_datetime(master["date"], errors="coerce", utc=True)

    # Write conflict audits
    dec_conflicts_df.to_csv(audit_dir / "decision_conflicts.csv", index=False)
    meth_conflicts_df.to_csv(audit_dir / "method_conflicts.csv", index=False)
    print(f"  Decision conflicts: {len(dec_conflicts_df)}")
    if len(dec_conflicts_df) > 0:
        print(f"  Sample decision conflicts:")
        print(dec_conflicts_df.head(5).to_string(index=False))
    print(f"  Method conflicts: {len(meth_conflicts_df)}")
    print()

    # ── Rule 9: Format audit flags ────────────────────────────────────
    print("─── FORMAT AUDIT FLAGS ───")
    title_lower = master["title"].fillna("").str.lower()
    url_str = master["url_canon"].fillna("")

    master["is_liveblog"] = (
        url_str.str.contains("/live/", na=False) |
        title_lower.str.contains("as it happened", na=False)
    )
    master["is_commentisfree"] = url_str.str.contains("/commentisfree/", na=False)

    # Check for nonzero labels on flagged rows
    def _any_method_positive(row):
        for mc in METHOD_COL_NAMES:
            v = row.get(mc)
            if pd.notna(v) and v > 0:
                return True
        return False

    def _build_flag_audit(mask_col: str) -> pd.DataFrame:
        flagged = master[master[mask_col] == True].copy()
        if len(flagged) == 0:
            return pd.DataFrame()
        has_nonzero_decision = flagged["decision"].fillna(0) > 0
        has_nonzero_method = flagged.apply(_any_method_positive, axis=1)
        nonzero = flagged[has_nonzero_decision | has_nonzero_method]
        return nonzero

    lb_nonzero = _build_flag_audit("is_liveblog")
    lb_nonzero.to_csv(audit_dir / "flag_liveblog_nonzero.csv", index=False)
    print(f"  Liveblog rows total: {master['is_liveblog'].sum()}, "
          f"with nonzero labels: {len(lb_nonzero)}")

    cif_nonzero = _build_flag_audit("is_commentisfree")
    cif_nonzero.to_csv(audit_dir / "flag_commentisfree_nonzero.csv", index=False)
    print(f"  Commentisfree rows total: {int(master['is_commentisfree'].sum())}, "
          f"with nonzero labels: {len(cif_nonzero)}")
    print()

    # ── Rule 10: Save outputs ─────────────────────────────────────────
    print("─── SAVING OUTPUTS ───")

    # Order columns for readability
    front_cols = [
        "url_canon", "id", "title", "date", "date_utc", "url", "section",
        "source_datasets", "decision", "decision_conflict", "decision_values",
    ]
    method_and_conflict_cols = []
    for mc in METHOD_COL_NAMES:
        method_and_conflict_cols.append(mc)
        method_and_conflict_cols.append(f"{mc}_conflict")
        method_and_conflict_cols.append(f"{mc}_values")
    sanity_cols = ["num_method_scores_observed", "is_liveblog", "is_commentisfree"]

    ordered = front_cols + method_and_conflict_cols + sanity_cols
    remaining = [c for c in master.columns if c not in ordered and c != "body"]
    final_order = ordered + remaining + ["body"]
    # Only include columns that actually exist
    final_order = [c for c in final_order if c in master.columns]
    master = master[final_order]

    master.to_parquet(out_dir / "master_vector.parquet", index=False, engine="pyarrow")
    master.to_csv(out_dir / "master_vector.csv", index=False)
    print(f"  ✓ outputs/master_vector.parquet ({len(master)} rows, {len(master.columns)} cols)")
    print(f"  ✓ outputs/master_vector.csv")

    # Write remaining audits
    schema_report = {
        "keyword_coercion_issues": schema_issues,
        "expected_vs_actual": {
            ds: {
                "expected": EXPECTED_COUNTS[ds],
                "actual": row_counts[ds],
            }
            for ds in FILE_MAP
        },
        "total_concat_rows": len(df_long),
        "total_master_rows": len(master),
    }
    with open(audit_dir / "schema_report.json", "w") as f:
        json.dump(schema_report, f, indent=2, default=str)

    with open(audit_dir / "label_distributions.json", "w") as f:
        json.dump(label_distributions, f, indent=2, default=str)

    print(f"  ✓ audits/schema_report.json")
    print(f"  ✓ audits/label_distributions.json")
    print()

    # ── Training cases ────────────────────────────────────────────────
    print("─── TRAINING CASES ───")
    process_training_cases(data_dir, out_dir)
    print()

    # ── Final summary ─────────────────────────────────────────────────
    print("=" * 70)
    print("  FINAL SUMMARY")
    print("=" * 70)
    print(f"  Master rows        : {len(master)}")
    print(f"  Master columns     : {len(master.columns)}")
    print(f"  Decision conflicts : {len(dec_conflicts_df)}")
    print(f"  Method conflicts   : {len(meth_conflicts_df)}")
    print()
    print("  Column list:")
    for i, c in enumerate(master.columns):
        print(f"    {i+1:3d}. {c}")
    print()
    print("  Dtypes summary:")
    dtype_summary = master.dtypes.value_counts()
    for dtype, count in dtype_summary.items():
        print(f"    {dtype}: {count} columns")
    print()
    print("  Method score coverage:")
    for mc in METHOD_COL_NAMES:
        nn = int(master[mc].notna().sum())
        print(f"    {mc}: {nn} non-null / {len(master)} rows")
    print()
    print("  Decision distribution:")
    print(master["decision"].value_counts(dropna=False).to_string())
    print()

    # Sanity check: num_method_scores_observed
    zero_methods = int((master["num_method_scores_observed"] == 0).sum())
    if zero_methods > 0:
        print(f"  ⚠  {zero_methods} rows have 0 method scores observed")
    else:
        print("  ✓ All rows have at least 1 method score observed")

    print()
    print("  ✓ Pipeline complete.")


if __name__ == "__main__":
    main()
