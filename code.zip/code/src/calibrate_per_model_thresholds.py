import json
import numpy as np
import pandas as pd
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)

def clamp(val, min_val, max_val):
    return max(min_val, min(val, max_val))

def load_or_dummy(path):
    if not Path(path).exists():
        logging.warning(f"File {path} not found.")
        return pd.DataFrame()
    return pd.read_parquet(path)

def get_llm_final_preds():
    last_rounds = []
    rounds_dir = Path("outputs/rounds")
    if rounds_dir.exists():
        round_dirs = sorted([d for d in rounds_dir.iterdir() if d.is_dir() and d.name.startswith("round_")],
                            key=lambda x: int(x.name.split("_")[1]), reverse=True)
        for rd in round_dirs:
            pq = rd / "scored_results_full.parquet"
            if pq.exists():
                df = pd.read_parquet(pq)
                if "llm_final_decision_score" in df.columns:
                    last_rounds.append(df)
            if len(last_rounds) >= 3:
                break
    if last_rounds:
        return pd.concat(last_rounds)
    return pd.DataFrame()

def compute_thresholds():
    # 1. Base thresholds from validation data
    m1_df = load_or_dummy("reports/model1_val_predictions.parquet")
    if not m1_df.empty:
        pD_1 = m1_df["model1_decision_p1"].dropna().values
        mcols = [c for c in m1_df.columns if c.startswith("model1_method_") and c.endswith("_p1")]
        maxM_1 = m1_df[mcols].max(axis=1).dropna().values if mcols else np.array([0.0])
        t_dec_1 = clamp(np.quantile(pD_1, 0.40), 0.30, 0.90)
        t_meth_1 = clamp(np.quantile(maxM_1, 0.40), 0.30, 0.90)
    else:
        t_dec_1, t_meth_1 = 0.40, 0.40

    m3_df = load_or_dummy("reports/model3_val_predictions.parquet")
    if not m3_df.empty:
        pD_3 = m3_df["model3_decision_p1"].dropna().values
        mcols = [c for c in m3_df.columns if c.startswith("model3_method_") and c.endswith("_p1") and "expert_qual" not in c]
        maxM_3 = m3_df[mcols].max(axis=1).dropna().values if mcols else np.array([0.0])
        t_dec_3 = clamp(np.quantile(pD_3, 0.40), 0.30, 0.90)
        t_meth_3 = clamp(np.quantile(maxM_3, 0.40), 0.30, 0.90)
    else:
        t_dec_3, t_meth_3 = 0.40, 0.40

    llm_df = get_llm_final_preds()
    if not llm_df.empty:
        pD_l = llm_df["llm_final_decision_p1"].dropna().values
        mcols = [c for c in llm_df.columns if c.startswith("llm_final_method_") and c.endswith("_p1")]
        maxM_l = llm_df[mcols].max(axis=1).dropna().values if mcols else np.array([0.0])
        
        t_dec_l = clamp(np.quantile(pD_l, 0.50), 0.40, 0.85)
        t_meth_l = clamp(np.quantile(maxM_l, 0.50), 0.40, 0.85)
    else:
        t_dec_l, t_meth_l = 0.50, 0.50
    t_conf_l = 0.0

    # 2. Trap Constraints from Synthetic Benchmark
    syn_path = "reports/synthetic_benchmark_comparative.csv"
    if Path(syn_path).exists():
        syn_df = pd.read_csv(syn_path)
        # Traps: startswith('f') or gold_dec < 1.0
        traps = syn_df[(syn_df["id"].str.startswith("f")) | (syn_df["gold_dec"] < 1.0)]
        
        if not traps.empty:
            logging.info(f"Checking trap resistance for {len(traps)} items.")
            
            # Revision B: Choice llm_final thresholds such that 0 false positives pass llm_final decision gate
            # AND (ideally) consensus gate.
            # We enforce llm_final_t_dec > max(trap_llm_dec)
            max_trap_dec_l = traps["llm_dec"].max()
            if t_dec_l <= max_trap_dec_l:
                t_dec_l = max_trap_dec_l + 0.01
                logging.info(f"Raised llm_final.t_dec to {t_dec_l} to block traps.")
            
            # Smart check for model3 method gate: only raise if trap passes LLM decision gate
            # Given current traps have llm_dec ~ 0.0, this won't trigger for them.
            # But if a future trap has high llm_dec, model3 can be a second line of defense.
            passing_traps = traps[traps["llm_dec"] >= t_dec_l]
            if not passing_traps.empty:
                max_trap_meth_3 = passing_traps["m3_max_p1"].max()
                if t_meth_3 <= max_trap_meth_3:
                    t_meth_3 = max_trap_meth_3 + 0.01
                    logging.info(f"Raised model3.t_meth to {t_meth_3} to block passing traps.")

    thresholds = {
        "model1": {"t_dec": float(t_dec_1), "t_meth": float(t_meth_1), "t_conf": 0.0},
        "model3": {"t_dec": float(t_dec_3), "t_meth": float(t_meth_3), "t_conf": 0.0},
        "llm_final": {"t_dec": float(t_dec_l), "t_meth": float(t_meth_l), "t_conf": float(t_conf_l)}
    }
    
    with open("project_state/PER_MODEL_THRESHOLDS.json", "w") as f:
        json.dump(thresholds, f, indent=2)

    audit_lines = [
        "# Per-Model Thresholds Calibration (Patch 3 - v2)",
        "",
        "## Model 1",
        f"- t_dec: {t_dec_1:.4f}",
        f"- t_meth: {t_meth_1:.4f}",
        "",
        "## Model 3",
        f"- t_dec: {t_dec_3:.4f}",
        f"- t_meth: {t_meth_3:.4f}",
        "",
        "## LLM Final",
        f"- t_dec: {t_dec_l:.4f} (trap-aware floor applied)",
        f"- t_meth: {t_meth_l:.4f}",
        f"- t_conf: {t_conf_l:.4f}"
    ]
    Path("audits/per_model_thresholds_audit.md").parent.mkdir(parents=True, exist_ok=True)
    Path("audits/per_model_thresholds_audit.md").write_text("\n".join(audit_lines))
    print(f"Calibration finished. See audits/per_model_thresholds_audit.md")

if __name__ == "__main__":
    compute_thresholds()
