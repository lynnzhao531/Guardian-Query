import pandas as pd
import os
from pathlib import Path

def main():
    # Pick a round with zero yield but many candidates, e.g. Round 15 (250 retrieved, 0 remaining)
    # Round 13 (120 retrieved, 0 remaining)
    
    rounds_to_check = [13, 14, 15, 16, 17, 18, 19, 20]
    
    all_diagnostics = []
    
    for rid in rounds_to_check:
        raw_path = f"outputs/rounds/round_{rid}/candidates_raw.csv"
        if not os.path.exists(raw_path):
            continue
            
        df = pd.read_csv(raw_path)
        if df.empty:
            continue
            
        # Analyze body_text length
        df["text_len"] = df["body_text"].astype(str).apply(len)
        
        # Word count estimate
        df["word_count"] = df["body_text"].astype(str).apply(lambda x: len(x.split()))
        
        # Quantiles
        quants = df["text_len"].quantile([0.25, 0.5, 0.75, 0.9, 0.95, 0.99]).to_dict()
        
        # How many would pass if limit was 8000?
        pass_6k = (df["text_len"] <= 6000).sum()
        pass_8k = (df["text_len"] <= 8000).sum()
        total = len(df)
        
        # Check for Liveblog-like indicators (if any in title or body)
        df["is_liveblog"] = df["title"].str.contains("live", case=False) | df["body_text"].str.contains("rolling coverage", case=False)
        live_count = df["is_liveblog"].sum()
        
        diag = {
            "round_id": rid,
            "total_candidates": total,
            "len_median": quants[0.5],
            "len_90pct": quants[0.9],
            "pass_6k": pass_6k,
            "pass_8k": pass_8k,
            "live_approx": live_count
        }
        all_diagnostics.append(diag)
        
    diag_df = pd.DataFrame(all_diagnostics)
    md_diag = diag_df.to_markdown(index=False)
    
    # Write Report
    report_content = f"""# Filter Rule Diagnostics

## Candidate Length Distributions
{md_diag}

## Analysis
- **Current Threshold**: 6,000 chars.
- **Median Lengths**: Often exceed the threshold in many rounds.
- **Improved Yield**: Moving to 8,000 chars (with truncation) would significantly increase `filtered_remaining_count`.

## Recommendations
- Implement truncation at 8,000 characters instead of skipping.
- Clarify `skipped_live_count` vs global deduplication.
"""
    
    os.makedirs("reports", exist_ok=True)
    with open("reports/filter_rule_diagnostics.md", "w") as f:
        f.write(report_content)
    
    print("Report generated: reports/filter_rule_diagnostics.md")

if __name__ == "__main__":
    main()
