#!/usr/bin/env python3
"""
Step 10: Extract query spaces from best hypothesis set + o3-mini expansion.
Writes term files to knowledge_base/query_spaces/ and a report.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


def load_ledger():
    with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
        return json.load(f)


def save_ledger(ledger):
    with open(ROOT / "project_state" / "COST_LEDGER.json", "w") as f:
        json.dump(ledger, f, indent=2)


CATEGORIES = [
    "decision", "common_method",
    "rct", "prepost", "case_studies",
    "expert_qual", "expert_secondary", "gut",
]


def main():
    cfg = load_config()
    state = load_state()
    ledger = load_ledger()

    from openai import OpenAI
    client = OpenAI()

    # Load best hypothesis set
    best_path = ROOT / "knowledge_base" / "best_hypothesis_set.json"
    if not best_path.exists():
        print("No best hypothesis set found. Run Step 5 first.")
        # Fall back to TGML query spaces if available
        tgml_qs = ROOT / "reports" / "query_spaces"
        if tgml_qs.exists():
            print("Using TGML query spaces as fallback.")
        sys.exit(0)

    with open(best_path) as f:
        best = json.load(f)

    hypotheses = best.get("hypotheses", [])
    print(f"Loaded {len(hypotheses)} hypotheses from best set (U={best.get('utility', '?')})")

    # ── Extract indicators per category ───────────────────────────────
    category_terms: dict[str, set[str]] = {cat: set() for cat in CATEGORIES}
    for h in hypotheses:
        cat = h.get("category", "common_method")
        if cat not in category_terms:
            cat = "common_method"
        for term in h.get("positive_indicators", []):
            category_terms[cat].add(term.lower().strip())

    # ── Expand with o3-mini ───────────────────────────────────────────
    print("\n── Expanding query terms with o3-mini ──")

    # Import cached call helper
    from api_helpers import cached_chat, check_budget

    for cat in CATEGORIES:
        existing = sorted(category_terms[cat])
        if not existing:
            continue

        if not check_budget(0.10, ledger, cfg):
            print("  ⚠ Budget tight, skipping expansion")
            break

        messages = [
            {"role": "system", "content": "You are a search query expert for Guardian news articles about policy experiments and evidence-based decisions."},
            {"role": "user", "content": f"""Given these search terms for the category '{cat}':
{json.dumps(existing)}

Propose 10-15 additional synonyms, alternative phrasings, and Guardian-style journalistic phrases for the same concept. These will be used as search queries on the Guardian API.

Output as JSON array of strings. Only the array, no explanation."""},
        ]
        try:
            raw = cached_chat(client, cfg["fixed_models"]["reasoner_R"], messages,
                              cfg, ledger, f"query_expand_{cat}", temperature=0.7, max_tokens=500)
            start = raw.find("[")
            end = raw.rfind("]") + 1
            if start >= 0 and end > start:
                expanded = json.loads(raw[start:end])
                for term in expanded:
                    category_terms[cat].add(term.lower().strip())
                print(f"  {cat}: +{len(expanded)} terms → {len(category_terms[cat])} total")
        except Exception as e:
            print(f"  ⚠ Could not expand {cat}: {e}")

        save_ledger(ledger)

    # ── Write term files ──────────────────────────────────────────────
    qs_dir = ROOT / "knowledge_base" / "query_spaces"
    qs_dir.mkdir(parents=True, exist_ok=True)

    for cat in CATEGORIES:
        terms = sorted(category_terms.get(cat, set()))
        if not terms:
            continue
        # Map category to file name
        fname = f"{cat}_terms.txt"
        (qs_dir / fname).write_text("\n".join(terms) + "\n")
        print(f"  ✓ {fname}: {len(terms)} terms")

    # ── Report ────────────────────────────────────────────────────────
    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    lines = ["# Query Space Report\n"]
    lines.append("## Terms per Category\n")
    lines.append("| Category | Count | Sample Terms |")
    lines.append("|----------|-------|-------------|")
    for cat in CATEGORIES:
        terms = sorted(category_terms.get(cat, set()))
        sample = ", ".join(terms[:5])
        lines.append(f"| {cat} | {len(terms)} | {sample} |")
    lines.append(f"\n**Total cost so far**: ${ledger['total_spent_usd']:.2f}")

    (report_dir / "query_space_report.md").write_text("\n".join(lines))
    print(f"\n✓ Report → {report_dir / 'query_space_report.md'}")

    # Update state
    if "step_10_query_spaces" not in state["steps_completed"]:
        state["steps_completed"].append("step_10_query_spaces")
    state["current_step"] = "step_10_complete"
    save_state(state)
    save_ledger(ledger)

    print(f"\n{'='*60}")
    print(f"  QUERY SPACES COMPLETE")
    print(f"  Cost: ${ledger['total_spent_usd']:.2f} / $50.00")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
