import pandas as pd
import os
from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent

def audit_sequence():
    query_log_path = BASE_DIR / "outputs/query_log.csv"
    if not query_log_path.exists():
        print(f"Error: {query_log_path} not found")
        return

    df = pd.read_csv(query_log_path)
    
    # Sequence A: Sorted by timestamp_utc_iso
    df_a = df.sort_values(by="timestamp_utc_iso")
    
    # Sequence B: Sorted by round_id
    df_b = df.sort_values(by="round_id")
    
    report = []
    report.append("# Round Sequence Audit")
    report.append(f"\nLynn. Auditing sequence for {len(df)} entries.")

    # Check gaps in round_id
    round_ids = sorted(df['round_id'].unique())
    gaps = []
    if round_ids:
        for i in range(len(round_ids) - 1):
            if round_ids[i+1] != round_ids[i] + 1:
                gaps.append(f"{round_ids[i]} -> {round_ids[i+1]}")
    
    report.append("\n## Round ID Gaps")
    if gaps:
        for gap in gaps:
            report.append(f"- Gap: {gap}")
    else:
        report.append("- No gaps found in unique round IDs.")

    # Check duplicates
    duplicates = df[df.duplicated(subset=['round_id'], keep=False)]
    report.append("\n## Duplicate Round IDs")
    if not duplicates.empty:
        report.append("| Round ID | Timestamp |")
        report.append("| --- | --- |")
        for idx, row in duplicates.iterrows():
            report.append(f"| {row['round_id']} | {row['timestamp_utc_iso']} |")
    else:
        report.append("- No duplicate round IDs found.")

    # Check out-of-order timestamps
    report.append("\n## Out-of-order Timestamps")
    out_of_order = []
    prev_ts = None
    for idx, row in df.iterrows():
        ts = row['timestamp_utc_iso']
        if prev_ts and ts < prev_ts:
            out_of_order.append(f"Row {idx}: {ts} < {prev_ts} (Round {row['round_id']})")
        prev_ts = ts
    
    if out_of_order:
        for oo in out_of_order:
            report.append(f"- {oo}")
    else:
        report.append("- Timestamps are strictly chronological in original log.")

    # Ad-hoc/Test Round Check (101, 200)
    report.append("\n## Ad-hoc / Test Round Identification")
    baseline_max = 41
    adhoc_rounds = df[df['round_id'] > baseline_max]
    if not adhoc_rounds.empty:
        report.append("| Round ID | Label | Timestamp |")
        report.append("| --- | --- | --- |")
        for idx, row in adhoc_rounds.iterrows():
            label = "Ad-hoc/Test" if row['round_id'] in [101, 200, 42] else "Unexplained Jump"
            report.append(f"| {row['round_id']} | {label} | {row['timestamp_utc_iso']} |")
    else:
        report.append("- No ad-hoc rounds detected above 41.")

    # Output Directory Audit
    report.append("\n## Output Directory Consistency")
    rounds_dir = BASE_DIR / "outputs"
    existing_dirs = []
    if rounds_dir.exists():
        for d in os.listdir(rounds_dir):
            if d.startswith("round_"):
                try:
                    rid = int(d.split("_")[1])
                    existing_dirs.append(rid)
                except:
                    pass
    
    existing_dirs.sort()
    all_known_ids = sorted(list(set(round_ids + existing_dirs)))
    
    report.append("| Round ID | In Query Log | Dir Exists |")
    report.append("| --- | --- | --- |")
    for rid in all_known_ids:
        in_log = "Yes" if rid in round_ids else "No"
        dir_exists = "Yes" if rid in existing_dirs else "No"
        # Filter for recent/relevant to keep table readable
        if rid >= 20 or rid in [101, 200]:
            report.append(f"| {rid} | {in_log} | {dir_exists} |")

    report_path = BASE_DIR / "reports/round_sequence_audit.md"
    os.makedirs(report_path.parent, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(report))
    
    print(f"Audit report written to {report_path}")

if __name__ == "__main__":
    audit_sequence()
