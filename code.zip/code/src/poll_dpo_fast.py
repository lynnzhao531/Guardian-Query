import os
import sys
import time
from openai import OpenAI
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    api_key = get_api_key()
    client = OpenAI(api_key=api_key)
    
    if len(sys.argv) > 1:
        job_id = sys.argv[1]
    else:
        print("Usage: python poll_dpo_fast.py <job_id>")
        sys.exit(1)
        
    print(f"Polling job {job_id}...")
    while True:
        try:
            job = client.fine_tuning.jobs.retrieve(job_id)
            if job.status in ["succeeded", "failed", "cancelled"]:
                print(f"Job finished with status: {job.status}")
                if job.status == "succeeded":
                    print(f"Model: {job.fine_tuned_model}")
                    # Update STATE.json here
                    import json
                    state_path = BASE_DIR / "project_state/STATE.json"
                    if state_path.exists():
                        with open(state_path, "r") as f:
                            state = json.load(f)
                        state['dpo_model_name'] = job.fine_tuned_model
                        state['latest_dpo_job_id'] = job.id
                        with open(state_path, "w") as f:
                            json.dump(state, f, indent=2)
                        print("Saved new model to STATE.json.")
                break
            time.sleep(30)
        except Exception as e:
            print(f"Error polling: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()
