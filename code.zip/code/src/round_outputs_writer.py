import pandas as pd
import numpy as np
import logging
import json
from pathlib import Path

logger = logging.getLogger(__name__)

# Constants for Schema
REQUIRED_METADATA = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text"
]

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

THRESHOLDS_FILE = Path("project_state/PER_MODEL_THRESHOLDS.json")
THRESHOLDS = {}

def load_thresholds():
    global THRESHOLDS
    if not THRESHOLDS_FILE.exists():
        raise FileNotFoundError(f"CRITICAL: Thresholds file missing: {THRESHOLDS_FILE}")
    with open(THRESHOLDS_FILE, "r") as f:
        THRESHOLDS = json.load(f)
    logger.info(f"Loaded thresholds: {THRESHOLDS}")

def _get_model_score_cols(prefix):
    """Returns list of required score columns for a model prefix."""
    cols = [f"{prefix}_decision_score", f"{prefix}_decision_p1"]
    for m in METHOD_NAMES:
        cols.append(f"{prefix}_method_{m}_score")
        cols.append(f"{prefix}_method_{m}_p1")
    return cols

def _get_all_available_cols(df, prefix):
    """
    Returns all columns in df that start with prefix_, 
    ensuring we capture p0/p05 if they exist, plus our mandatory ones.
    """
    # Mandatory
    mandatory = set(_get_model_score_cols(prefix))
    
    # All matching prefix in df
    available = [c for c in df.columns if c.startswith(f"{prefix}_")]
    
    # Check mandatory presence
    missing = [c for c in mandatory if c not in df.columns]
    
    if prefix in ["model1", "model3", "llm_sft", "llm_final"]:
        if missing:
            logger.warning(f"Missing mandatory columns for {prefix} in parquet: {missing}. Filling with 0.0.")
            # We don't raise anymore. The DataFrame will be filled with NaN when selection occurs, 
            # and we should ensure it's handled or filled later.
            
    # Combine and deduplicate
    final = list(mandatory) + [c for c in available if c not in mandatory]
    # Return as list
    return sorted(final)

def check_pass_dec(row, prefix):
    """
    PASS_dec_j(article) logic:
    - decision_score == 1
    - decision_p1 >= t_dec
    - confidence >= t_conf
    """
    load_thresholds()
    m_cfg = THRESHOLDS.get(prefix, {})
    if not m_cfg:
        logger.warning(f"No threshold config for {prefix}")
        return False

    dec_score = row.get(f"{prefix}_decision_score", 0.0)
    if dec_score < 1.0:
        return False

    dec_p1 = row.get(f"{prefix}_decision_p1", 0.0)
    if dec_p1 < m_cfg.get("t_dec", 1.0):
        return False

    conf = row.get(f"{prefix}_confidence_score", dec_p1)
    if conf < m_cfg.get("t_conf", 0.0):
        return False

    return True

def check_pass_meth(row, prefix):
    """
    PASS_meth_j(article) logic:
    - max_method_p1 >= t_meth
    Special for model3: exclude expert_qual from max calculation.
    """
    load_thresholds()
    m_cfg = THRESHOLDS.get(prefix, {})
    
    methods_to_check = METHOD_NAMES
    if prefix == "model3":
        methods_to_check = [m for m in METHOD_NAMES if m != "expert_qual"]
        
    method_p1s = [row.get(f"{prefix}_method_{m}_p1", 0.0) for m in methods_to_check]
    max_meth_p1 = max(method_p1s) if method_p1s else 0.0
    
    if max_meth_p1 < m_cfg.get("t_meth", 1.0):
        return False
    return True

def check_pass(row, prefix):
    """Ref relevance check: requires both decision AND method pass."""
    return check_pass_dec(row, prefix) and check_pass_meth(row, prefix)

def compute_consensus(row):
    """Revised: avg_dec > 0.8, avg_top3_meth > 0.7, agreement >= 2 models."""
    eps = 0.05 ; prefixes = ["model1", "model3", "llm_final"]
    avg_dec = np.mean([row.get(f"{p}_decision_p1", 0.0) for p in prefixes])
    if avg_dec <= 0.8: return None
    method_avgs = {m: np.mean([row.get(f"{p}_method_{m}_p1", 0.0) for p in prefixes]) for m in METHOD_NAMES}
    avg_scores = sorted(method_avgs.values(), reverse=True)
    top3_avg_mean = np.mean(avg_scores[:3])
    if top3_avg_mean <= 0.7: return None
    pred_m = max(method_avgs, key=method_avgs.get)
    agreement_count = sum(1 for p in prefixes if pred_m in {m for m, v in {mm: row.get(f"{p}_method_{mm}_p1", 0.0) for mm in METHOD_NAMES}.items() if v >= (max({row.get(f"{p}_method_{mm}_p1", 0.0) for mm in METHOD_NAMES}) - eps)})
    if agreement_count < 2: return None
    res = {"avg_decision_p1": avg_dec, "top3_avg_method_mean": top3_avg_mean, "predicted_method": pred_m, "confidence_score": method_avgs[pred_m]/sum(method_avgs.values()) if sum(method_avgs.values())>0 else 0.0, "margin": method_avgs[pred_m]-(avg_scores[1] if len(avg_scores)>1 else 0.0), "agreement_count": agreement_count}
    for m, v in method_avgs.items(): res[f"avg_method_p1_{m}"] = v
    return res

def write_round_outputs(round_id, parquet_path):
    output_dir = Path(parquet_path).parent
    logger.info(f"Writing round outputs to {output_dir}")
    
    # Load thresholds first
    load_thresholds()
    
    df = pd.read_parquet(parquet_path)
    
    if df.empty:
        logger.warning(f"Round {round_id} dataframe is empty. Generating empty CSVs.")
        _write_empty_csvs(round_id, output_dir, df.columns)
        return

    # Ensure all mandatory columns exist for selection logic
    all_prefixes = ["model1", "model3", "llm_sft", "llm_final", "llm_dpo"]
    for p in all_prefixes:
        mandatory = _get_model_score_cols(p)
        for c in mandatory:
            if c not in df.columns:
                df[c] = 0.0

    # Helper
    def write_csv(sub_df, name):
         sub_df.to_csv(output_dir / name, index=False)
         logger.info(f"Wrote {name}: {len(sub_df)} rows")

    # 1. Model 1 — high relevance: decision_score==1 AND max(method_p1) >= 0.80
    def is_high_rel_v2(row, prefix):
        if row.get(f"{prefix}_decision_score", 0.0) < 1.0:
            return False
        max_p1 = max((row.get(f"{prefix}_method_{m}_p1", 0.0) for m in METHOD_NAMES), default=0.0)
        return max_p1 >= 0.80

    m1_cols = [c for c in REQUIRED_METADATA + _get_all_available_cols(df, "model1") if c in df.columns]
    m1_mask = df.apply(lambda x: is_high_rel_v2(x, "model1"), axis=1)
    write_csv(df[m1_mask][m1_cols], f"round_{round_id}_model1_papers.csv")
    
    # 2. Model 3
    m3_cols = [c for c in REQUIRED_METADATA + _get_all_available_cols(df, "model3") if c in df.columns]
    m3_mask = df.apply(lambda x: is_high_rel_v2(x, "model3"), axis=1)
    write_csv(df[m3_mask][m3_cols], f"round_{round_id}_model3_papers.csv")
    
    # 3. SFT file — CONTRACT V2: explicitly labelled 'SFT' even if redundant with 'llm_final'
    sft_prefix = "llm_sft" if "llm_sft_decision_score" in df.columns else "llm_final"
    sft_cols = [c for c in REQUIRED_METADATA + _get_all_available_cols(df, sft_prefix) if c in df.columns]
    sft_mask = df.apply(lambda x: is_high_rel_v2(x, sft_prefix), axis=1)
    write_csv(df[sft_mask][sft_cols], f"round_{round_id}_SFT_papers.csv")

    # 4. DPO file — CONTRACT V2: exists even if SFT is used for it
    dpo_prefix = "llm_dpo" if "llm_dpo_decision_score" in df.columns else "llm_final"
    dpo_cols = [c for c in REQUIRED_METADATA + _get_all_available_cols(df, dpo_prefix) if c in df.columns]
    dpo_mask = df.apply(lambda x: is_high_rel_v2(x, dpo_prefix), axis=1)
    write_csv(df[dpo_mask][dpo_cols], f"round_{round_id}_DPO_papers.csv")
    
    # 4. Consensus high_relevant_papers.csv — CONTRACT V2 required fields
    cons_rows = []
    for idx, row in df.iterrows():
        extra_info = compute_consensus(row)
        if extra_info:
            base = row.to_dict()
            base.update(extra_info)
            cons_rows.append(base)
            
    # Build all required consensus columns
    all_model_cols = []
    for p in ["model1", "model3", "llm_final"]:
        all_model_cols.extend(_get_all_available_cols(df, p))
    if "llm_dpo_decision_score" in df.columns:
        all_model_cols.extend(_get_all_available_cols(df, "llm_dpo"))

    consensus_mandatory_extras = [
        "predicted_method", "confidence_score", "margin", "agreement_count",
        "avg_decision_p1", "top3_avg_method_mean",
    ] + [f"avg_method_p1_{m}" for m in METHOD_NAMES]

    final_cols = REQUIRED_METADATA + list(dict.fromkeys(all_model_cols)) + consensus_mandatory_extras

    if cons_rows:
        cons_df = pd.DataFrame(cons_rows)
        out_cols = [c for c in final_cols if c in cons_df.columns]
        write_csv(cons_df[out_cols], f"round_{round_id}_high_relevant_papers.csv")
    else:
        pd.DataFrame(columns=final_cols).to_csv(
            output_dir / f"round_{round_id}_high_relevant_papers.csv", index=False
        )
        logger.info(f"Wrote round_{round_id}_high_relevant_papers.csv: 0 rows")

def _write_empty_csvs(round_id, output_dir, source_cols):
    # CONTRACT V2: always write exactly these 5 CSV names even when empty
    for fname in ["model1_papers", "model3_papers", "SFT_papers", "DPO_papers"]:
        # Build score columns for each prefix
        prefix = fname.replace("_papers", "").lower()
        if prefix == "sft": prefix = "llm_sft"
        if prefix == "dpo": prefix = "llm_dpo"
        
        cols = list(REQUIRED_METADATA) + _get_model_score_cols(prefix)
        pd.DataFrame(columns=cols).to_csv(
            output_dir / f"round_{round_id}_{fname}.csv", index=False
        )
    
    # Only if source_cols available? Or just use known keys?
    # Use empty dataframe with source columns PLUS extra keys
    extra_keys = [
        "avg_decision_p1", "top3_avg_method_mean", "classified_method", "tied_methods",
        "confidence_score", "agreement_strength"
    ] + [f"avg_method_p1_{m}" for m in METHOD_NAMES]
    
    full_cols = list(source_cols) + extra_keys
    # Remove duplicates if any (though source shouldn't have them)
    full_cols = list(dict.fromkeys(full_cols))
    
    pd.DataFrame(columns=full_cols).to_csv(output_dir / f"round_{round_id}_high_relevant_papers.csv", index=False)

# Backward Compatibility
is_high_rel_single = check_pass
