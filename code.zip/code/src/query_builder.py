
import random
import json
import logging
from pathlib import Path

class QueryBuilder:
    def __init__(self, config, contract, query_spaces_dir, templates):
        self.cfg = config
        self.contract = contract
        self.query_spaces_dir = Path(query_spaces_dir)
        self.templates = templates
        self.logger = logging.getLogger("QueryBuilder")
        
        # Load all spaces eagerly
        self.spaces = {}
        for f in self.query_spaces_dir.glob("*.json"):
            if f.is_file():
                with open(f) as fd:
                    self.spaces[f.stem] = json.load(fd)
        
        # Fixed clauses
        self.POLICY_CONTEXT = '(POLICY OR PROGRAMME OR PROGRAM OR SCHEME OR SERVICE OR MEASURE OR REGULATION OR INITIATIVE OR INTERVENTION OR COUNCIL OR GOVERNMENT OR NHS OR CITY OR "PUBLIC HEALTH" OR EDUCATION OR TRANSPORT OR POLICING)'
        self.ACTOR = '(GOVERNMENT OR MINISTER OR DEPARTMENT OR COUNCIL OR MAYOR OR NHS OR REGULATOR OR AGENCY OR AUTHORITY)'
        self.EVIDENCE = '(EVALUATION OR STUDY OR ANALYSIS OR ASSESSMENT OR REVIEW OR REPORT OR FINDINGS OR DATA OR EVIDENCE)'
        
        self.min_total = contract.get("min_total_available", 20)
        self.max_total = contract.get("max_total_available", 2500)

    def _get_terms(self, space_name, limit=None):
        space = self.spaces.get(space_name, {})
        terms = space.get("include_terms", [])
        if limit and len(terms) > limit:
            return terms[:limit]
        return terms

    def _get_excludes(self, method_name):
        # Global excludes
        global_ex = self.spaces.get("exclude_terms", {}).get("exclude_terms", [])
        
        # Method specific excludes
        method_ex = []
        if method_name == "expert_secondary":
            method_ex = ["randomized", "randomised", "trial", "rct", "placebo", "control group"]
        elif method_name == "gut":
            method_ex = ["trial", "randomized", "randomised", "study", "evaluation", "pilot", "impact assessment", "review"]
            
        # Combine
        return global_ex + method_ex

    def _build_bundle(self, terms):
        if not terms:
            return ""
        # Quote terms unless they contain quotes or parens already
        processed = []
        for t in terms:
            if '"' in t or '(' in t:
                processed.append(t)
            else:
                processed.append(f'"{t}"')
        return "(" + " OR ".join(processed) + ")"

    def build_query(self, target_method, round_id, guardian_client):
        """
        Deterministic refinement loop:
        1. Candidates
        2. Preflight (Collect totals for ALL levels in the strategy)
        3. Returns preflight_totals and let runner choose.
        """
        if target_method == "gut":
            candidate_templates = ["T2", "T1", "T5", "T9"]
        else:
            candidate_templates = ["T4", "T3", "T2", "T1", "T6", "T5", "T10", "T9", "T8", "T7"]
            
        preflight_log = {} 
        
        for t_id in candidate_templates:
            tpl = self.templates.get(t_id)
            if not tpl: continue
            
            # Base components
            m_terms = self._get_terms(f"method_{target_method}", limit=6)
            d_terms = self._get_terms("decision", limit=6)
            base_excludes = self._get_excludes(target_method)
            
            # A) Base Query
            q_base = self._construct_string(tpl, m_terms, d_terms, base_excludes, target_method)
            total_base = self._preflight(q_base, guardian_client)
            preflight_log[f"{t_id}_base_strict"] = {"query": q_base, "total": total_base, "level": 0}
            
            # B) Broaden D
            d_broad = d_terms + self.spaces.get("decision", {}).get("broad_addons", [])[:6]
            q_broad_d = self._construct_string(tpl, m_terms, d_broad, base_excludes, target_method)
            total_broad_d = self._preflight(q_broad_d, guardian_client)
            preflight_log[f"{t_id}_broaden_D"] = {"query": q_broad_d, "total": total_broad_d, "level": 1}
            
            # C) Broaden M
            m_broad = self._get_terms(f"method_{target_method}", limit=10)
            q_broad_m = self._construct_string(tpl, m_broad, d_broad, base_excludes, target_method)
            total_broad_m = self._preflight(q_broad_m, guardian_client)
            preflight_log[f"{t_id}_broaden_M"] = {"query": q_broad_m, "total": total_broad_m, "level": 2}

            # D) Tighten A
            q_tight_a = q_base 
            if "{actor}" not in tpl:
                q_tight_a = f"{q_base} AND {self.ACTOR}"
                total_tight_a = self._preflight(q_tight_a, guardian_client)
                preflight_log[f"{t_id}_tighten_add_A"] = {"query": q_tight_a, "total": total_tight_a, "level": 3}
            
            # E) Tighten G
            q_tight_g = q_tight_a
            if target_method != "gut" and "{evidence}" not in tpl:
                q_tight_g = f"{q_tight_a} AND {self.EVIDENCE}"
                total_tight_g = self._preflight(q_tight_g, guardian_client)
                preflight_log[f"{t_id}_tighten_add_G"] = {"query": q_tight_g, "total": total_tight_g, "level": 4}
            
            # F) Tighten Ultra D
            ultra_d = ["pilot scheme", "rolled out", "trialled", "implemented", "introduced"]
            q_ultra = self._construct_string(tpl, m_terms, ultra_d, base_excludes, target_method)
            if "{actor}" not in tpl: q_ultra += f" AND {self.ACTOR}"
            if target_method != "gut" and "{evidence}" not in tpl: q_ultra += f" AND {self.EVIDENCE}"
            total_ultra = self._preflight(q_ultra, guardian_client)
            preflight_log[f"{t_id}_tighten_ultra_D"] = {"query": q_ultra, "total": total_ultra, "level": 5}

            # Exit on first template that provides ANY results
            if total_base > 0 or total_broad_d > 0 or total_broad_m > 0:
                return self._package_result(q_base, t_id, target_method, 0, total_base, preflight_log)

        # Emergency Exit
        return self._emergency_query(target_method, preflight_log, guardian_client)

    def _construct_string(self, tpl, m_terms, d_terms, excludes, method_name):
        q = tpl.replace("{method_terms}", self._build_bundle(m_terms))
        q = q.replace("{decision_terms}", self._build_bundle(d_terms))
        q = q.replace("{policy_context}", self.POLICY_CONTEXT)
        q = q.replace("{actor}", self.ACTOR)
        q = q.replace("{evidence}", self.EVIDENCE if method_name != 'gut' else "")
        q = q.replace("{excludes}", self._build_bundle(excludes))
        return q

    def _preflight(self, query, client):
        try:
             params = {
                 "q": query, 
                 "page": 1,
                 "page-size": 1, 
                 "show-fields": "bodyText,headline,wordcount,publication,section,sectionId,shortUrl,lastModified",
                 "order-by": "relevance",
                 "lang": "en"
             }
             resp = client.request(params)
             return resp.get("response", {}).get("total", 0)
        except:
             return 0

    def _package_result(self, query, t_id, method, backoff, total, log):
        return {
            "query_base": query,
            "query_final": query,
            "template_id": t_id,
            "target_method": method,
            "backoff_level_used": backoff,
            "preflight_total_available": total,
            "preflight_totals_by_level_json": json.dumps(log),
            "guardian_total_available": total
        }

    def _emergency_query(self, method, log, client):
        q = ""
        if method == "rct":
            q = '("randomised controlled trial" OR "randomized controlled trial" OR "random assignment") AND ("pilot scheme" OR "pilot programme" OR "trialled")'
        elif method == "prepost":
            q = '("before and after" OR "pre and post") AND ("pilot scheme" OR "trialled")'
        elif method == "case_study":
            q = '("case study" OR "case studies") AND ("pilot scheme" OR "pilot programme" OR "trialled" OR "launched" OR "evaluation")'
        elif method == "expert_qual":
            q = '("public inquiry" OR "independent review") AND ("recommendations" OR "report found") AND ("government will" OR "ministers will")'
        elif method == "expert_secondary":
            q = '("statistical analysis" OR "modelling" OR "regression") AND ("study found" OR "report found") AND ("will decide" OR "decision")'
        elif method == "gut":
            q = '("intuition" OR "hunch" OR "instinct") AND ("minister" OR "mayor") AND ("announced" OR "decided")'
            
        total = self._preflight(q, client)
        log["emergency"] = {"query": q, "total": total, "level": 99}
        if total == 0:
            raise RuntimeError(f"FATAL: Emergency query for {method} returned 0 results. Manual intervention required.")
        return self._package_result(q, "EMERGENCY", method, 99, total, log)
