
import os
import sys
import pandas as pd
import subprocess
import json
import logging
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
QUERY_LOG_PATH = BASE_DIR / "outputs/query_log.csv"
REPORTS_DIR = BASE_DIR / "reports"
AUDIT_SCRIPT = BASE_DIR / "src/audit_round_integrity.py"
RUNNER_SCRIPT = BASE_DIR / "src/round_runner.py"

def run_command(cmd):
    """Lynn. Run a command and stream output to stdout/stderr."""
    print(f"Executing: {' '.join(cmd)}")
    result = subprocess.run(cmd) # Remove capture_output
    return result

def get_last_contiguous_round():
    if not QUERY_LOG_PATH.exists():
        return 0
    df = pd.read_csv(QUERY_LOG_PATH)
    if df.empty:
        return 0
    round_ids = sorted(df["round_id"].unique())
    # Start from 1, find the first gap
    last_contiguous = 0
    for rid in round_ids:
        if rid == last_contiguous + 1:
            last_contiguous = rid
        else:
            break
    return last_contiguous

def orchestrate(num_rounds, start_override=None):
    if start_override is not None:
        start_round = start_override
    else:
        # SAFE RESUME: Default to last contiguous + 1 to avoid jumps
        last_contig = get_last_contiguous_round()
        start_round = last_contig + 1
        
    end_round = start_round + num_rounds - 1
    
    print(f"Lynn. Starting stability run: Rounds {start_round} to {end_round}")
    
    summary_data = []
    
    for rid in range(start_round, end_round + 1):
        print(f"\n--- ROUND {rid} START ---")
        
        # 1. Run Round
        run_res = run_command([sys.executable, str(RUNNER_SCRIPT), "--round_id", str(rid)])
        if run_res.returncode != 0:
            print(f"Lynn. Round {rid} failed!")
            print(run_res.stderr)
            break
            
        # 2. Run Audit
        audit_res = run_command([sys.executable, str(AUDIT_SCRIPT), str(rid)])
        if audit_res.returncode != 0:
            print(f"Lynn. Round {rid} Audit failed!")
            print(audit_res.stderr)
            break
            
        # 3. DPO Disabled Check
        df = pd.read_csv(QUERY_LOG_PATH)
        row = df[df["round_id"] == rid].iloc[-1]
        if row.get("dpo_attempted_count", 0) > 0:
            print(f"Lynn. CRITICAL: DPO was attempted in Round {rid}! Stopping.")
            break
        if row.get("dpo_valid_count", 0) > 0:
            print(f"Lynn. CRITICAL: DPO was valid in Round {rid}! Stopping.")
            break

        # 4. SFT Parity Check
        parity_res = run_command([sys.executable, "src/prove_llm_final_sft_parity.py", str(rid)])
        if parity_res.returncode != 0:
            print(f"Lynn. Round {rid} SFT Parity Check failed! Stopping.")
            break

        # 5. Collect Summary Data
        # Read query log and audit json
        df = pd.read_csv(QUERY_LOG_PATH)
        row = df[df["round_id"] == rid].iloc[-1]
        
        audit_json_path = BASE_DIR / f"audits/round_{rid}/round_integrity_audit.json"
        with open(audit_json_path, "r") as f:
            audit = json.load(f)
            
        selection_path = BASE_DIR / f"audits/round_{rid}/supply_band_selection.json"
        with open(selection_path, "r") as f:
            selection = json.load(f)
            
        # Pool update info
        pool_audit_path = BASE_DIR / f"audits/round_{rid}/pool_update_audit.json"
        pool_audit = {}
        if pool_audit_path.exists():
            with open(pool_audit_path, "r") as f:
                pool_audit = json.load(f)
                
        round_summary = {
            "round_id": rid,
            "template_id": row.get("template_id"),
            "backoff_level_used": row.get("backoff_level_used"),
            "supply_band_state": selection.get("supply_band_state"),
            "preflight_total": row.get("preflight_total_available"),
            "retrieved": row.get("guardian_candidates_retrieved"),
            "filtered": row.get("filtered_remaining_count"),
            "downsampled_from": audit.get("downsampled_from"),
            "downsampled_to": audit.get("downsampled_to"),
            "scored": row.get("scored_count"),
            "llm_high": row.get("high_rel_llm_final_count"),
            "consensus_high": row.get("consensus_high_rel_count"),
            "pool_appended": pool_audit.get("overall_rows_appended", 0),
            "llm_pool_appended": pool_audit.get("llm_rows_appended", 0),
            "pool_skipped": pool_audit.get("duplicates_skipped", 0),
            "cost_usd": row.get("query_cost_this_round_usd"),
            "dpo_attempted": row.get("dpo_attempted_count", 0),
            "dpo_valid": row.get("dpo_valid_count", 0)
        }
        summary_data.append(round_summary)
        print(f"Lynn. Round {rid} Complete, Audited, and Verified (DPO=0, SFT Parity=PASS).")

    # Generate Reports
    if summary_data:
        summary_df = pd.DataFrame(summary_data)
        os.makedirs(REPORTS_DIR, exist_ok=True)
        summary_df.to_csv(REPORTS_DIR / "next20_rounds_summary.csv", index=False)
        
        with open(REPORTS_DIR / "next20_rounds_summary.md", "w") as f:
            f.write("# Stability Run Summary (Next 20 Rounds)\n\n")
            f.write("Lynn. Execution summary for the stability run audit.\n\n")
            f.write("## Round Summary Table\n")
            f.write(summary_df[["round_id", "scored", "llm_high", "consensus_high", "pool_appended", "supply_band_state", "cost_usd"]].to_markdown(index=False))
            f.write("\n\n")
            
            f.write("## DPO Disabled Proof Table\n")
            f.write(summary_df[["round_id", "dpo_attempted", "dpo_valid"]].to_markdown(index=False))
            f.write("\n\n")

            # Final line proof
            f.write("## llm_final == SFT Proof\n")
            f.write("- **Status: ALL ROUNDS PASSED** (Verified per round by `src/prove_llm_final_sft_parity.py`)\n\n")
            
            # Count downsampling
            ds_applied = len(summary_df[summary_df["downsampled_from"] > 100])
            in_band = len(summary_df[summary_df["supply_band_state"] == "IN_BAND"])
            too_many = len(summary_df[summary_df["supply_band_state"] == "TOO_MANY_STRICTEST"])
            too_few = len(summary_df[summary_df["supply_band_state"] == "TOO_FEW_BROADEST"])
            
            f.write(f"### Guardrail Summary\n")
            f.write(f"- Rounds applying downsampling: {ds_applied}\n")
            f.write(f"- Supply Band State counts:\n")
            f.write(f"  - IN_BAND: {in_band}\n")
            f.write(f"  - TOO_MANY_STRICTEST (Overbroad): {too_many}\n")
            f.write(f"  - TOO_FEW_BROADEST (Too-few): {too_few}\n")
            
        print("Lynn. Stability run reports generated (next20_rounds_summary).")
    else:
        print("Lynn. No rounds completed.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--start_round_id", type=int, help="Override starting round ID")
    args = parser.parse_args()
    orchestrate(args.rounds, start_override=args.start_round_id)
