import json
import time
import hashlib
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
import requests

class GuardianClient:
    def __init__(self, keys, base_url, state_path, log_path):
        self.keys = keys
        self.base_url = base_url
        self.state_path = Path(state_path)
        self.log_path = Path(log_path)
        
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._load_state()
        self._setup_logger()

    def _get_fingerprint(self, key):
        return hashlib.sha256(key.encode()).hexdigest()[:8]

    def _setup_logger(self):
        self.logger = logging.getLogger("GuardianClient")
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.log_path)
        self.logger.addHandler(handler)

    def _log_event(self, event, key_index, status_code=None, cooldown=None, query_hint="", note=""):
        log_entry = {
            "ts_utc": datetime.now(timezone.utc).isoformat(),
            "event": event,
            "key_index": key_index,
            "key_fingerprint": self._get_fingerprint(self.keys[key_index]),
            "status_code": status_code,
            "cooldown_until_utc": cooldown,
            "query_hint": query_hint,
            "note": note
        }
        self.logger.info(json.dumps(log_entry))

    def _load_state(self):
        if self.state_path.exists():
            try:
                state = json.loads(self.state_path.read_text())
                if state.get("keys_count") == len(self.keys):
                    self.current_index = state.get("current_index", 0)
                    self.key_health = state.get("key_health", [])
                    self.total_requests = state.get("total_requests", 0)
                    self.total_rotations = state.get("total_rotations", 0)
                    return
            except Exception:
                pass
        
        # Default/Reset state
        self.current_index = 0
        self.key_health = [
            {"cooldown_until_utc": None, "recent_failures": 0, "last_error": None}
            for _ in range(len(self.keys))
        ]
        self.total_requests = 0
        self.total_rotations = 0
        self._save_state()

    def _save_state(self):
        state = {
            "keys_count": len(self.keys),
            "current_index": self.current_index,
            "key_health": self.key_health,
            "total_requests": self.total_requests,
            "total_rotations": self.total_rotations
        }
        self.state_path.write_text(json.dumps(state, indent=2))

    def _is_cooling_down(self, index):
        cooldown_str = self.key_health[index]["cooldown_until_utc"]
        if not cooldown_str:
            return False
        
        cooldown_time = datetime.fromisoformat(cooldown_str)
        if datetime.now(timezone.utc) > cooldown_time:
            self.key_health[index]["cooldown_until_utc"] = None
            self._save_state()
            return False
        return True

    def _rotate_key(self, note=""):
        start_index = self.current_index
        n = len(self.keys)
        
        for i in range(1, n + 1):
            next_idx = (start_index + i) % n
            if not self._is_cooling_down(next_idx):
                self._log_event("rate_limit_rotate", start_index, note=f"Rotating from {start_index} to {next_idx}. {note}")
                self.current_index = next_idx
                self.total_rotations += 1
                self._save_state()
                return True
        
        return False

    def request(self, params: dict, timeout=20, max_attempts=6):
        query_hint = f"q={params.get('q', '')[:20]} page={params.get('page','')} size={params.get('page-size','')}"
        
        for attempt in range(max_attempts):
            if self._is_cooling_down(self.current_index):
                if not self._rotate_key("Current key is in cooldown."):
                    wait_times = [datetime.fromisoformat(k["cooldown_until_utc"]) for k in self.key_health if k["cooldown_until_utc"]]
                    resume_time = min(wait_times).isoformat() if wait_times else "unknown"
                    raise RuntimeError(f"All Guardian API keys appear rate-limited. Wait until {resume_time} or add more keys.")

            current_key = self.keys[self.current_index]
            request_params = params.copy()
            request_params["api-key"] = current_key
            
            try:
                self.total_requests += 1
                resp = requests.get(self.base_url, params=request_params, timeout=timeout)
                
                # Success
                if resp.status_code == 200:
                    self._log_event("request_success", self.current_index, status_code=200, query_hint=query_hint)
                    self.key_health[self.current_index]["recent_failures"] = 0
                    self._save_state()
                    return resp.json()
                
                # Rate Limit / Quota (Rotate Trigger)
                if resp.status_code == 429 or (resp.status_code in [401, 403] and "quota" in resp.text.lower()):
                    cooldown_until = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
                    self.key_health[self.current_index]["cooldown_until_utc"] = cooldown_until
                    self.key_health[self.current_index]["last_error"] = f"HTTP {resp.status_code}: {resp.text[:100]}"
                    self._save_state()
                    
                    if not self._rotate_key(f"Received {resp.status_code}"):
                        raise RuntimeError(f"All Guardian API keys exhausted (last error: {resp.status_code}).")
                    continue # Retry with new key
                
                # Non-retryable (Client Error)
                if 400 <= resp.status_code < 500:
                    self._log_event("fatal_error", self.current_index, status_code=resp.status_code, note=f"Non-retryable: {resp.text[:200]}")
                    resp.raise_for_status()
                
                # Transient Error (5xx)
                if 500 <= resp.status_code < 600:
                    raise requests.exceptions.HTTPError(f"Transient {resp.status_code}")

            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as e:
                self.key_health[self.current_index]["recent_failures"] += 1
                self._save_state()
                
                if self.key_health[self.current_index]["recent_failures"] >= 2:
                    self._log_event("transient_retry", self.current_index, note=f"Multiple transient failures: {str(e)}. Rotating once.")
                    if self._rotate_key("Transient failures"):
                        continue
                
                # Exponential backoff with jitter
                wait_time = min(2 ** attempt + (time.time() % 1), 16)
                self._log_event("transient_retry", self.current_index, note=f"Error: {str(e)}. Retrying in {wait_time:.1f}s")
                time.sleep(wait_time)
                
        raise RuntimeError(f"Max attempts ({max_attempts}) reached for Guardian API request.")
