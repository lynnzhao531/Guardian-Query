#!/usr/bin/env python3
"""
Step 3: Train TGML baseline scorer f.
Uses TF-IDF + OrdinalClassifier on the long training view.
Article-level train/val/test split (no leakage).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import yaml
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, f1_score
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


# ── Ordinal classifier ───────────────────────────────────────────────

class OrdinalClassifier:
    """Frank & Hall: K-1 binary classifiers for ordinal targets."""

    def __init__(self, classes=None, **lr_kwargs):
        self.classes = np.array(classes or [0.0, 0.5, 1.0])
        self.lr_kwargs = lr_kwargs
        self.clfs = []

    def fit(self, X, y):
        self.clfs = []
        for k in range(len(self.classes) - 1):
            y_bin = (np.asarray(y, dtype=float) > self.classes[k]).astype(int)
            clf = LogisticRegression(**self.lr_kwargs)
            if len(np.unique(y_bin)) > 1:
                clf.fit(X, y_bin)
            else:
                clf = None
            self.clfs.append(clf)
        return self

    def predict_proba(self, X):
        n = X.shape[0]
        cps = []
        for clf in self.clfs:
            if clf is not None:
                cps.append(clf.predict_proba(X)[:, 1])
            else:
                cps.append(np.zeros(n))
        probs = np.zeros((n, len(self.classes)))
        probs[:, 0] = 1.0 - cps[0]
        for k in range(1, len(self.classes) - 1):
            probs[:, k] = cps[k - 1] - cps[k]
        probs[:, -1] = cps[-1]
        probs = np.clip(probs, 0, 1)
        rs = probs.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        return probs / rs

    def predict(self, X):
        return self.classes[np.argmax(self.predict_proba(X), axis=1)]


# ── main ──────────────────────────────────────────────────────────────

def main():
    cfg = load_config()
    state = load_state()
    seed = cfg["splits"]["seed"]

    # Load long view
    long_path = state.get("training_long_path")
    if not long_path:
        long_path = str(ROOT / "data" / "processed" / "training_long.parquet")
    df = pd.read_parquet(long_path)
    print(f"Loaded long view: {len(df)} rows, {df['article_id'].nunique()} articles")

    # ── Article-level split ───────────────────────────────────────────
    articles = df["article_id"].unique()
    # Stratify on most common decision score per article
    article_dec = df.groupby("article_id")["decision_score"].first().fillna(-1)
    strat_values = article_dec.reindex(articles).values

    # Fall back to non-stratified if any class has <2 members
    from collections import Counter
    counts = Counter(strat_values)
    can_stratify = all(c >= 2 for c in counts.values())

    strat_kw = dict(stratify=strat_values) if can_stratify else {}
    a_train, a_temp = train_test_split(
        articles, test_size=0.30, random_state=seed, **strat_kw,
    )
    if can_stratify:
        dec_temp = article_dec.reindex(a_temp).values
        strat_kw2 = dict(stratify=dec_temp)
    else:
        strat_kw2 = {}
    a_val, a_test = train_test_split(
        a_temp, test_size=0.50, random_state=seed, **strat_kw2,
    )

    train = df[df["article_id"].isin(set(a_train))].copy()
    val = df[df["article_id"].isin(set(a_val))].copy()
    test = df[df["article_id"].isin(set(a_test))].copy()
    print(f"Split → train: {len(train)}, val: {len(val)}, test: {len(test)}")

    # Save split article ids for reproducibility
    split_info = {
        "train_articles": sorted(a_train.tolist()),
        "val_articles": sorted(a_val.tolist()),
        "test_articles": sorted(a_test.tolist()),
    }
    with open(ROOT / "data" / "processed" / "article_splits.json", "w") as f:
        json.dump(split_info, f)

    # ── TF-IDF ────────────────────────────────────────────────────────
    print("Fitting TF-IDF...")
    tfidf = TfidfVectorizer(
        max_features=50_000, ngram_range=(1, 2),
        min_df=2, max_df=0.95, sublinear_tf=True,
    )
    X_train = tfidf.fit_transform(train["text_for_model"].fillna(""))
    X_val = tfidf.transform(val["text_for_model"].fillna(""))
    X_test = tfidf.transform(test["text_for_model"].fillna(""))
    print(f"  TF-IDF features: {X_train.shape[1]}")

    lr_kwargs = dict(solver="saga", max_iter=5000, C=1.0,
                     class_weight="balanced", random_state=seed)

    model_dir = ROOT / "models" / "tgml"
    model_dir.mkdir(parents=True, exist_ok=True)

    # ── Decision model ────────────────────────────────────────────────
    print("\n── Decision model ──")
    dec_mask_tr = train["decision_score"].notna()
    dec_mask_val = val["decision_score"].notna()
    dec_mask_te = test["decision_score"].notna()

    dec_clf = OrdinalClassifier(classes=[0.0, 0.5, 1.0], **lr_kwargs)
    dec_clf.fit(X_train[dec_mask_tr.values], train.loc[dec_mask_tr, "decision_score"].values)
    joblib.dump(dec_clf, model_dir / "decision_ordinal.joblib")

    dec_pred_val = dec_clf.predict(X_val[dec_mask_val.values])
    y_dec_val = val.loc[dec_mask_val, "decision_score"].values
    str_labels = ["0.0", "0.5", "1.0"]
    cr_dec = classification_report(
        [str(float(v)) for v in y_dec_val],
        [str(float(v)) for v in dec_pred_val],
        labels=str_labels, output_dict=True, zero_division=0,
    )
    dec_f1 = cr_dec.get("macro avg", {}).get("f1-score", 0)
    print(f"  Val macro-F1: {dec_f1:.3f}")

    # ── Method models (one per type) ──────────────────────────────────
    method_types = sorted(df["method_type"].unique())
    method_metrics = {}
    for mt in method_types:
        mt_train = train[train["method_type"] == mt]
        mt_val = val[val["method_type"] == mt]
        mt_test = test[test["method_type"] == mt]

        if len(mt_train) < 5:
            print(f"\n── {mt}: only {len(mt_train)} train rows, skipping ──")
            continue

        print(f"\n── {mt} ({len(mt_train)} train, {len(mt_val)} val) ──")

        # Get TF-IDF rows for this method subset
        tr_idx = mt_train.index
        va_idx = mt_val.index
        X_mt_tr = tfidf.transform(mt_train["text_for_model"].fillna(""))
        X_mt_va = tfidf.transform(mt_val["text_for_model"].fillna(""))

        clf = OrdinalClassifier(classes=[0.0, 0.5, 1.0], **lr_kwargs)
        clf.fit(X_mt_tr, mt_train["method_score"].values)
        joblib.dump(clf, model_dir / f"method_{mt}.joblib")

        if len(mt_val) > 0:
            pred = clf.predict(X_mt_va)
            cr = classification_report(
                [str(float(v)) for v in mt_val["method_score"].values],
                [str(float(v)) for v in pred],
                labels=str_labels, output_dict=True, zero_division=0,
            )
            mf1 = cr.get("macro avg", {}).get("f1-score", 0)
            method_metrics[mt] = {"macro_f1": round(mf1, 4), "n_val": len(mt_val)}
            print(f"  Val macro-F1: {mf1:.3f}")
        else:
            method_metrics[mt] = {"macro_f1": None, "n_val": 0}

    # Save TF-IDF vectorizer
    joblib.dump(tfidf, model_dir / "tfidf_vectorizer.joblib")

    # ── Report ────────────────────────────────────────────────────────
    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    lines = ["# TGML Baseline Report\n"]
    lines.append(f"**Training rows**: {len(train)}, **Val**: {len(val)}, **Test**: {len(test)}")
    lines.append(f"**TF-IDF features**: {X_train.shape[1]}\n")
    lines.append("## Decision Model\n")
    lines.append(f"Val macro-F1: **{dec_f1:.3f}**\n")
    lines.append("## Method Models\n")
    lines.append("| Method Type | Val macro-F1 | Val rows |")
    lines.append("|-------------|-------------|----------|")
    for mt, m in method_metrics.items():
        f1_str = f"{m['macro_f1']:.3f}" if m["macro_f1"] is not None else "N/A"
        lines.append(f"| {mt} | {f1_str} | {m['n_val']} |")

    (report_dir / "tgml_baseline_report.md").write_text("\n".join(lines))
    print(f"\n✓ Report → {report_dir / 'tgml_baseline_report.md'}")

    # ── Update state ──────────────────────────────────────────────────
    state["tgml_model_path"] = str(model_dir)
    if "step_3_tgml_baseline" not in state["steps_completed"]:
        state["steps_completed"].append("step_3_tgml_baseline")
    state["current_step"] = "step_3_complete"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  TGML BASELINE COMPLETE")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
