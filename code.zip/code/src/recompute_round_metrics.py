import pandas as pd
import json
import os
import sys
from pathlib import Path
from src.config_loader import get_config
import datetime

BASE_DIR = Path(__file__).resolve().parent.parent

def recompute_round_metrics(round_id):
    """
    Independent strict verification of round outputs.
    Returns dict of recomputed metrics.
    Raises SystemExit if mismatches found.
    """
    round_dir = BASE_DIR / f"outputs/rounds/round_{round_id}"
    log_path = BASE_DIR / "outputs/query_log.csv"
    
    # 1. Load Logs
    if not log_path.exists():
        print(f"FATAL: query_log.csv missing for recompute of round {round_id}")
        sys.exit(1)
        
    log_df = pd.read_csv(log_path)
    if round_id not in log_df["round_id"].values:
        print(f"WARNING: Round {round_id} not found in query_log. Skipping recompute verification.")
        return {"status": "SKIPPED", "mismatches": ["Round detected in FS but missing in Log"]}
        
    row = log_df[log_df["round_id"] == round_id].iloc[0]
    
    # 2. Check Candidate Counts
    raw_path = round_dir / "candidates_raw.csv"
    filt_path = round_dir / "candidates_filtered.csv"
    scored_path = round_dir / "scored_set.csv"
    parquet_path = round_dir / "scored_results_full.parquet"
    
    if not raw_path.exists() or not filt_path.exists() or not scored_path.exists():
        print("FATAL: Missing candidate CSVs for recompute.")
        sys.exit(1)
        
    filt_df = pd.read_csv(filt_path)
    scored_set_df = pd.read_csv(scored_path)
    
    mismatches = []
    # 2. Check Candidate Counts (New Contract bypasses some counts in log)
    def val(k): return row.get(k, 0)
    
    if not pd.isna(row.get("filtered_remaining_count")) and len(filt_df) != row["filtered_remaining_count"]:
        mismatches.append(f"filtered_remaining_count mismatch: log {row['filtered_remaining_count']} vs file {len(filt_df)}")
        
    if len(scored_set_df) != val("scored_count"):
        mismatches.append(f"scored_count mismatch: log {val('scored_count')} vs file {len(scored_set_df)}")

    # 3. Check Scored Results
    if not parquet_path.exists():
        print("FATAL: Parquet missing.")
        sys.exit(1)
        
    res_df = pd.read_parquet(parquet_path)
    
    # Import logic from writer
    from src.round_outputs_writer import is_high_rel_single, compute_consensus, load_thresholds
    
    # Ensure thresholds are loaded for check_pass (which is is_high_rel_single)
    load_thresholds()
    
    # Recompute metrics from parquet
    m1_count = len(res_df[res_df.apply(lambda x: is_high_rel_single(x, "model1"), axis=1)])
    m3_count = len(res_df[res_df.apply(lambda x: is_high_rel_single(x, "model3"), axis=1)])
    # SFT count (uses llm_sft scores)
    sft_count = len(res_df[res_df.apply(lambda x: is_high_rel_single(x, "llm_sft"), axis=1)])
    # Final count (using llm_final scores)
    final_count = len(res_df[res_df.apply(lambda x: is_high_rel_single(x, "llm_final"), axis=1)])
    
    # DPO (matches round_outputs_writer.py logic)
    def is_dpo_high(r):
        d = r.get("llm_dpo_decision_score", 0)
        p1 = r.get("llm_dpo_decision_p1", 0)
        return abs(d - 1.0) < 1e-6 and p1 >= 0.50
        
    if "dpo_valid" in res_df.columns:
        valid_mask = res_df["dpo_valid"] == True
        dpo_mask = valid_mask & res_df.apply(is_dpo_high, axis=1)
        dpo_count = len(res_df[dpo_mask])
    else:
        dpo_count = 0
        
    # Consensus
    cons_count = sum(1 for _, r in res_df.iterrows() if compute_consensus(r))
    
    # 4. Compare with Log (Handle renamed keys: high_rel_llm_final_count -> llm_high_count)
    log_final = row.get("high_rel_llm_final_count")
    if pd.isna(log_final): log_final = row.get("llm_high_count", 0)
    
    if m1_count != val("high_rel_model1_count"):
        mismatches.append(f"high_rel_model1_count mismatch: log {val('high_rel_model1_count')} vs recomputed {m1_count}")
    
    if m3_count != val("high_rel_model3_count"):
        mismatches.append(f"high_rel_model3_count mismatch: log {val('high_rel_model3_count')} vs recomputed {m3_count}")
        
    if final_count != log_final:
        mismatches.append(f"llm_final_count mismatch: log {log_final} vs recomputed {final_count}")

    if dpo_count != val("high_rel_dpo_count"):
        mismatches.append(f"high_rel_dpo_count mismatch: log {val('high_rel_dpo_count')} vs recomputed {dpo_count}")

    if cons_count != val("consensus_high_rel_count"):
        mismatches.append(f"consensus_high_rel_count mismatch: log {val('consensus_high_rel_count')} vs recomputed {cons_count}")

    # 5. Verify Files Exist and match recomputed
    def check_file(name, expected):
        f = round_dir / f"round_{round_id}_{name}_papers.csv"
        if not f.exists():
            return "MISSING" if expected > 0 else "MATCH (absent as expected)"
        count = len(pd.read_csv(f))
        if count != expected:
            return f"MISMATCH: exp {expected} vs act {count}"
        return "MATCH"

    audit_files = {
        "audit_model1": check_file("model1", m1_count),
        "audit_model3": check_file("model3", m3_count),
        "audit_SFT": check_file("SFT", sft_count),
        "audit_DPO": check_file("DPO", dpo_count),
        "audit_high_relevant": check_file("high_relevant", cons_count)
    }
    
    for k, v in audit_files.items():
        if "MISMATCH" in v:
            mismatches.append(f"{k}: {v}")

    # 6. Reward components
    V = row["reward_V"]
    verify_V = min(1.0, row["scored_count"] / 100.0)
    if abs(verify_V - V) > 1e-6:
        mismatches.append(f"Reward V mismatch: log {V} vs calc {verify_V}")

    # 7. Finalize
    audit_data = {
        "round_id": round_id,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "mismatches": mismatches,
        "status": "PASS" if not mismatches else "FAIL"
    }
    
    audit_file = BASE_DIR / f"audits/round_{round_id}/round_{round_id}_recompute_audit.json"
    audit_file.parent.mkdir(parents=True, exist_ok=True)
    with open(audit_file, "w") as f:
        json.dump(audit_data, f, indent=2)
        
    if mismatches:
        print(f"FATAL: Recompute Metrics Mismatch for Round {round_id}")
        for m in mismatches:
            print(f"- {m}")
        sys.exit(1)
        
    print(f"Recompute successful: {audit_file}")
    return audit_data

if __name__ == "__main__":
    if len(sys.argv) > 1:
        recompute_round_metrics(int(sys.argv[1]))
