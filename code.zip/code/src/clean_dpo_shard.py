import json
import os
from pathlib import Path

ROOT = Path("/Users/Mycroft/Desktop/LLM reasoning")

def clean_shard(input_path: Path, output_path: Path):
    if not input_path.exists():
        print(f"Skipping {input_path} as it does not exist.")
        return
        
    kept_lines = 0
    dropped_lines = 0
    
    with open(input_path, "r") as infile, open(output_path, "w") as outfile:
        for line in infile:
            row = json.loads(line)
            pref = row.get("preferred_output", [])
            non_pref = row.get("non_preferred_output", [])
            
            if len(pref) > 0 and len(non_pref) > 0:
                pref_content = pref[0]["content"]
                non_pref_content = non_pref[0]["content"]
                
                if pref_content == non_pref_content:
                    dropped_lines += 1
                    continue
            
            outfile.write(line)
            kept_lines += 1
            
    print(f"Cleaned {input_path.name}: Kept {kept_lines}, Dropped {dropped_lines}")

def main():
    train_in = ROOT / "fine_tune_data/dpo_train_shard_001.jsonl"
    train_out = ROOT / "fine_tune_data/dpo_train_shard_001_clean.jsonl"
    
    val_in = ROOT / "fine_tune_data/dpo_val.jsonl"
    val_out = ROOT / "fine_tune_data/dpo_val_clean.jsonl"
    
    clean_shard(train_in, train_out)
    clean_shard(val_in, val_out)

if __name__ == "__main__":
    main()
