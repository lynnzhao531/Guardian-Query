import json
import pandas as pd
from pathlib import Path
from safe_llm_judge import call_llm_scoring

ROOT = Path("/Users/Mycroft/Desktop/LLM reasoning")

def get_models():
    state_path = ROOT / "project_state/STATE.json"
    with open(state_path) as f:
        st = json.load(f)
    return st.get("sft_model_name"), "ft:gpt-4.1-mini-2025-04-14:personal::DAbS3xSo"

def run_tests():
    sft_model, dpo_model = get_models()
    
    # 1) Build stable smoke set
    scored_csv = ROOT / "outputs/rounds/round_28/scored_set.csv"
    df = pd.read_csv(scored_csv)
    
    # Sample 30 articles
    df_sample = df.sample(n=min(30, len(df)), random_state=42)
    smoke_csv = ROOT / "reports/smoke_set_30.csv"
    df_sample[['url_canon', 'body_text']].to_csv(smoke_csv, index=False)
    
    print(f"Sampled {len(df_sample)} articles. SFT={sft_model}, DPO={dpo_model}")

    def test_model(model_name):
        valid = 0
        failures = []
        for i, row in df_sample.iterrows():
            text = row.get('body_text', '')
            res = call_llm_scoring(model_name=model_name, article_text=text)
            if res['success']:
                valid += 1
            else:
                failures.append({
                    "url": row['url_canon'],
                    "error": res['error'],
                    "raw_text": res['raw_text']
                })
        return valid, failures
        
    sft_valid, sft_failures = test_model(sft_model)
    dpo_valid, dpo_failures = test_model(dpo_model)
    
    n = len(df_sample)
    sft_rate = sft_valid / n if n > 0 else 0
    dpo_rate = dpo_valid / n if n > 0 else 0
    
    report_path = ROOT / "reports/dpo_smoke_compare.md"
    with open(report_path, "a") as f:
        f.write("\n## Smoke Tests\n")
        f.write(f"- **Test Size**: {n} articles\n")
        f.write(f"- **SFT Model (`{sft_model}`) Valid Rate**: {sft_rate*100:.1f}%\n")
        f.write(f"- **DPO Model (`{dpo_model}`) Valid Rate**: {dpo_rate*100:.1f}%\n")
        
        f.write("\n### DPO Failures Diagnosis\n")
        if dpo_failures:
            f.write("Failures encountered. Sample of up to 3:\n")
            for fail in dpo_failures[:3]:
                f.write(f"**Error**: `{fail['error']}`\n")
                f.write(f"**Raw Output snippet**:\n```json\n{fail['raw_text'][:300]}...\n```\n\n")
            
            # Determine if it's schema mismatch or misconfiguration
            if any("OpenAIError" in str(e['error']) or "does not exist" in str(e['error']) for e in dpo_failures):
                f.write("\n**Diagnosis:** Model misconfiguration. The model could not be called.\n")
            elif any("validation_failed" in str(e['error']) or "Expecting value" in str(e['error']) or "Missing dimension" in str(e['error']) for e in dpo_failures):
                f.write("\n**Diagnosis:** Output schema mismatch or format failure (salvageable parsing error vs entirely missing fields).\n")
        else:
            f.write("No failures! 100% valid.\n")

if __name__ == "__main__":
    run_tests()
