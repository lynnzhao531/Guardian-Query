
import torch
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from transformers import AutoTokenizer, AutoModel
import torch.nn as nn
import importlib
import logging
import json
import yaml

# Logger
logger = logging.getLogger(__name__)

# Import TGML module dynamically to support unpickling
try:
    tgml_mod = importlib.import_module("src.03_train_tgml_baseline")
except ImportError:
    logger.warning("Could not import src.03_train_tgml_baseline. Model1 loading might fail if it relies on that class def.")
    tgml_mod = None

from sklearn.base import BaseEstimator, TransformerMixin
from src.tgml.theory_features import TheoryFeaturizer
from src.tgml.models import FeaturePipeline

class InferenceFeaturePipeline:
    def __init__(self, base_pipeline: FeaturePipeline):
        self.base_pipeline = base_pipeline
        
    def transform(self, texts):
        df = pd.DataFrame({
            "title": [t.split("\n\n")[0] if isinstance(t, str) and "\n\n" in t else t for t in texts],
            "body": [t.split("\n\n", 1)[1] if isinstance(t, str) and "\n\n" in t else "" for t in texts],
            "text_for_model": texts,
            "url_canon": ""
        })
        return self.base_pipeline.transform(df)

class Model1ClassifierWrapper:
    def __init__(self, clf):
        self.clf = clf
        self.classes_ = list(clf.classes_)
    
    def predict_proba(self, X):
        probs = self.clf.predict_proba(X)
        out = np.zeros((X.shape[0], 3))
        expected = ["0.0", "0.5", "1.0"]
        for idx, c in enumerate(self.classes_):
            if c in expected:
                out[:, expected.index(c)] = probs[:, idx]
        return out
        
    def predict(self, X):
        probs = self.predict_proba(X)
        classes = np.array([0.0, 0.5, 1.0])
        return classes[np.argmax(probs, axis=1)]

class Model3FeatureExtractor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.theory_feat = TheoryFeaturizer()
        
    def fit(self, X, y=None):
        return self
        
    def transform(self, texts):
        df = pd.DataFrame({
            "title": [t.split("\n\n")[0] if isinstance(t, str) and "\n\n" in t else t for t in texts],
            "body": [t.split("\n\n", 1)[1] if isinstance(t, str) and "\n\n" in t else "" for t in texts],
            "url_canon": ""
        })
        theory_df = self.theory_feat.transform(df)
        X_theory = theory_df.values.astype(np.float64)
        return X_theory

class Model3ClassifierWrapper:
    def __init__(self, clf):
        self.clf = clf
        self.classes_ = list(clf.classes_)
    
    def predict_proba(self, X):
        probs = self.clf.predict_proba(X)
        out = np.zeros((X.shape[0], 3))
        expected = ["0.0", "0.5", "1.0"]
        for idx, c in enumerate(self.classes_):
            if c in expected:
                out[:, expected.index(c)] = probs[:, idx]
        return out
        
    def predict(self, X):
        probs = self.predict_proba(X)
        classes = np.array([0.0, 0.5, 1.0])
        return classes[np.argmax(probs, axis=1)]

# ── Model 3 Definition (Copied for State Dict Loading) ────────────────

class CBMModel(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(cfg['model']['base_encoder'])
        hidden_size = self.encoder.config.hidden_size
        
        self.concept_head = nn.Linear(hidden_size, cfg['model']['num_concepts'])
        
        # Bottleneck: Option B (Soft)
        if cfg['model']['bottleneck_type'] == "soft":
            self.label_head = nn.ModuleList([
                nn.Linear(hidden_size + cfg['model']['num_concepts'], 3)
                for _ in range(cfg['model']['num_labels'])
            ])
        else:
            self.label_head = nn.ModuleList([
                nn.Linear(cfg['model']['num_concepts'], 3)
                for _ in range(cfg['model']['num_labels'])
            ])
            
        self.bottleneck_type = cfg['model']['bottleneck_type']

    def forward(self, input_ids, attention_mask):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :] # CLS token
        
        concept_logits = self.concept_head(pooled_output)
        concept_probs = torch.sigmoid(concept_logits)
        
        if self.bottleneck_type == "soft":
            bottleneck_features = torch.cat([pooled_output, concept_probs], dim=1)
        else:
            bottleneck_features = concept_probs
            
        label_logits = [head(bottleneck_features) for head in self.label_head]
        
        return concept_logits, label_logits

# ── Model 1 Scorer (TGML) ─────────────────────────────────────────────

class Model1Scorer:
    def __init__(self, model_dir):
        self.model_dir = Path(model_dir)
        self.tfidf = None
        self.dec_clf = None
        self.method_clfs = {}
        self.loaded = False
        
    def load(self):
        if self.loaded: return
        print("DEBUG: Model1Scorer.load start")
        try:
            # Force sys.modules injection if needed
            # But importlib should have handled it.
            print(f"DEBUG: Loading tfidf from {self.model_dir / 'tfidf_vectorizer.joblib'}")
            self.tfidf = joblib.load(self.model_dir / "tfidf_vectorizer.joblib")
            print("DEBUG: Loaded tfidf")
            
            self.dec_clf = joblib.load(self.model_dir / "model_decision.joblib")
            print("DEBUG: Loaded dec_clf")
            
            for mt in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
                p = self.model_dir / f"model_method_{mt}.joblib"
                if p.exists():
                    self.method_clfs[mt] = joblib.load(p)
                else:
                    self.method_clfs[mt] = None
                    
            self.loaded = True
            print("DEBUG: Model1Scorer.load success")
        except Exception as e:
            logger.error(f"Failed to load Model1: {e}")
            print(f"DEBUG: Model1 load failed: {e}")
            self.loaded = False

    def score(self, articles):
        """
        articles: list of dicts with 'body_text', 'title'.
        Returns: list of dicts with model1_decision_score, p0, p05, p1 etc.
        """
        print("DEBUG: Model1Scorer.score start")
        if not self.loaded:
            self.load()
        if not self.loaded:
            return [{}] * len(articles)
            
        if not articles:
            print("DEBUG: Model1Scorer received 0 articles. Returning empty.")
            return []

        # Prepare Text
        # TGML trained on "title\n\nbody" usually? 
        # Evaluate script uses "text_for_model". 01_load_and_audit creates this as title + body.
        print("DEBUG: Preparing text")
        texts = []
        for a in articles:
            t = a.get("title", "") or ""
            b = a.get("body_text", "") or ""
            texts.append(f"{t}\n\n{b}")
            
        # TFIDF
        print("DEBUG: Running TFIDF transform")
        try:
            X = self.tfidf.transform(texts)
            print("DEBUG: TFIDF transform done")
        except Exception as e:
             print(f"DEBUG: TFIDF transform failed: {e}")
             raise e
        
        results = [{} for _ in range(len(articles))]
        
        # Helper to format output
        def fill_row(row_idx, prefix, proba):
            # proba is [p0, p05, p1]
            p0, p05, p1 = proba
            # discrete score: max arg
            if p1 >= p0 and p1 >= p05: s = 1.0
            elif p05 >= p0 and p05 >= p1: s = 0.5
            else: s = 0.0
            
            results[row_idx][f"{prefix}_score"] = s
            results[row_idx][f"{prefix}_p0"] = p0
            results[row_idx][f"{prefix}_p05"] = p05
            results[row_idx][f"{prefix}_p1"] = p1

        # Decision
        probs_dec = self.dec_clf.predict_proba(X)
        for i, p in enumerate(probs_dec):
            fill_row(i, "model1_decision", p)
            
        # Methods
        for mt, clf in self.method_clfs.items():
            if clf is not None:
                probs_mt = clf.predict_proba(X)
                for i, p in enumerate(probs_mt):
                    fill_row(i, f"model1_method_{mt}", p)
            else:
                # Fill zeros if model missing
                for i in range(len(articles)):
                    fill_row(i, f"model1_method_{mt}", [1.0, 0.0, 0.0]) # Assume class 0
                    
        return results

# ── Model 3 Scorer (CBM) ──────────────────────────────────────────────

class Model3Scorer:
    def __init__(self, model_path, config_path):
        self.model_path = Path("models/model3/model3_models.joblib")
        self.embedder = None
        self.theory_feat = None
        self.models_dict = None
        self.loaded = False
        self.label_order = ["decision", "method_rct", "method_prepost", "method_case_study", 
                            "method_expert_qual", "method_expert_secondary", "method_gut"]

    def load(self):
        if self.loaded: return
        try:
            from sentence_transformers import SentenceTransformer
            from src.tgml.theory_features import TheoryFeaturizer
            import joblib
            
            logger.info("Loading new Model 3 (SentenceTransformer + LogisticRegression)")
            self.embedder = SentenceTransformer('all-MiniLM-L6-v2')
            self.theory_feat = TheoryFeaturizer()
            self.models_dict = joblib.load(self.model_path)
            
            self.loaded = True
        except Exception as e:
            logger.error(f"Failed to load Model3: {e}")
            self.loaded = False

    def score(self, articles):
        if not self.loaded:
            self.load()
        if not self.loaded:
            return [{}] * len(articles)
            
        if not articles:
            return []
            
        texts = []
        for a in articles:
            t = a.get("title", "") or ""
            b = a.get("body_text", "") or ""
            texts.append(f"{t}\n\n{b}")
            
        df = pd.DataFrame({
            "title": [a.get("title", "") or "" for a in articles],
            "body": [a.get("body_text", "") or "" for a in articles],
            "url_canon": ""
        })
        
        theory_df = self.theory_feat.transform(df)
        X_theory = theory_df.values.astype(np.float64)
        
        embeddings = self.embedder.encode(texts, show_progress_bar=False)
        X = np.hstack([embeddings, X_theory])
        
        results = [{} for _ in range(len(articles))]
        
        for head_name in self.label_order:
            prefix = f"model3_{head_name}"
            if head_name in self.models_dict:
                wrapper = self.models_dict[head_name]
                probs = wrapper.predict_proba(X)
                
                for i, p in enumerate(probs):
                    p0, p05, p1 = p[0], p[1], p[2]
                    if p1 >= p0 and p1 >= p05: s = 1.0
                    elif p05 >= p0 and p05 >= p1: s = 0.5
                    else: s = 0.0
                    
                    results[i][f"{prefix}_score"] = s
                    results[i][f"{prefix}_p0"] = p0
                    results[i][f"{prefix}_p05"] = p05
                    results[i][f"{prefix}_p1"] = p1
            else:
                for i in range(len(articles)):
                    results[i][f"{prefix}_score"] = 0.0
                    results[i][f"{prefix}_p0"] = 1.0
                    results[i][f"{prefix}_p05"] = 0.0
                    results[i][f"{prefix}_p1"] = 0.0
                    
        return results
