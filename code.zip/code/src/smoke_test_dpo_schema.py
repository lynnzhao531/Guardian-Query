import os
import json
import pandas as pd
from openai import OpenAI
from pathlib import Path
from src.safe_llm_judge import call_llm_scoring
from src.llm_output_sanitize import sanitize_model_json
from src.validate_nested_schema import validate_nested_schema

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def format_prompt(title, body):
    # Truncate string matching what the judge router does
    text = f"Title: {title}\nDate: unknown\n\nArticle Text:\n{body}"
    return text[:15000]

def smoke_test(model_name, n_articles=30):
    api_key = get_api_key()
    if not api_key:
        print("Error: OPENAI_API_KEY not found")
        return

    corpus = BASE_DIR / "outputs/master_vector.parquet"
    if not corpus.exists():
        corpus = BASE_DIR / "outputs/training_cases_clean.parquet"
        
    df = pd.read_parquet(corpus)
    # Filter valid text
    df = df[df['body'].notna() & (df['body'] != '')]
    # Sample n_articles
    test_articles = df.sample(min(n_articles, len(df)), random_state=42).to_dict('records')
    
    print(f"Testing {len(test_articles)} articles against model: {model_name}")

    report = [
        "# DPO Fast Smoke Test Report",
        f"\n**Model**: `{model_name}`",
        f"**Articles Tested**: {len(test_articles)}",
    ]
    
    results = []
    failures = []
    attempts = 0
    valid_count = 0
    missing_decision_count = 0
    
    system_prompt = """Output ONLY JSON. No prose. No markdown. Do not repeat.

CONSERVATIVE SCORING RULES (NON-NEGOTIABLE):
- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.
- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').
- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).
- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present.

Output ONLY valid JSON matching the schema. No prose. No markdown.
"""

    for art in test_articles:
        attempts += 1
        url = art.get('url_canon', art.get('url', 'unknown'))
        title = art.get('title', 'unknown')
        text = art.get('body', "")
        
        user_msg = format_prompt(title, text)
        
        dpo_res = call_llm_scoring(
            model_name=model_name,
            article_text=user_msg,
            max_output_tokens=250,
            system_prompt=system_prompt,
            strict_schema=False,
            api_key=api_key,
            mock_response=False
        )
        
        raw_text = dpo_res.get('raw_text', "")
        ok, salvaged_data, reason_tag = sanitize_model_json(raw_text)
        
        # Determine strict validity
        valid_strict = False
        if ok and salvaged_data:
            fail_tags = validate_nested_schema(json.dumps(salvaged_data))
            if not fail_tags:
                valid_strict = True
            else:
                reason_tag = f"schema_error: {fail_tags[0]}"
                if "missing_dims" in fail_tags[0] and "decision" in fail_tags[0]:
                    missing_decision_count += 1
        
        if valid_strict:
            valid_count += 1
            results.append({"url": url, "success": True, "raw": raw_text, "salvaged": salvaged_data})
        else:
            reason = reason_tag or "unknown"
            failures.append({"url": url, "reason": reason, "raw": raw_text})
            results.append({"url": url, "success": False, "raw": raw_text, "reason": reason})
            
    valid_rate = valid_count / attempts if attempts > 0 else 0
    
    report.append(f"- **Valid Count**: {valid_count}")
    report.append(f"- **Valid Rate**: {valid_rate:.2%}")
    report.append(f"- **Missing Decision Count**: {missing_decision_count}")
    
    report.append("\n## Failure Detail")
    reason_counts = pd.Series([r['reason'] for r in results if not r['success']]).value_counts().to_dict()
    report.append(f"```json\n{json.dumps(reason_counts, indent=2)}\n```")
    
    report.append("\n## RAW Failure Excerpts (Up to 5)")
    for i, f in enumerate(failures[:5]):
        report.append(f"### Failure {i+1}: {f['reason']}")
        report.append(f"**URL**: {f['url']}")
        report.append(f"```json\n{f['raw'][:500]}\n```")
        
    report_path = BASE_DIR / "reports/dpo_fast_smoke_test.md"
    os.makedirs(report_path.parent, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Smoke test report written to {report_path}")
    print(f"Final valid rate: {valid_rate:.2%} ({valid_count}/{attempts})")
    print(f"Missing decision count: {missing_decision_count}")
    
    # Check PASS criteria
    passed = True
    if valid_rate < 0.90:
        print("FAIL: valid_rate < 0.90")
        passed = False
    if missing_decision_count > 0:
        print("FAIL: missing decision dimension detected")
        passed = False
        
    if not passed:
        print("STOP")
        sys.exit(1)
        
    print("PASS")

if __name__ == "__main__":
    import sys
    
    # Try reading from state
    state_path = BASE_DIR / "project_state/STATE.json"
    model = "unknown"
    if state_path.exists():
        with open(state_path) as f:
            st = json.load(f)
            model = st.get('dpo_model_name', "unknown")
            
    if len(sys.argv) > 1:
        model = sys.argv[1]
        
    if model == "unknown":
        print("Could not find DPO model in STATE.json.")
        sys.exit(1)
        
    smoke_test(model)
