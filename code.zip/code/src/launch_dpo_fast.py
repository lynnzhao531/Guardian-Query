import os
import sys
from openai import OpenAI
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    api_key = get_api_key()
    client = OpenAI(api_key=api_key)
    
    train_path = BASE_DIR / "fine_tune_data/dpo_train_v2_fast.jsonl"
    val_path = BASE_DIR / "fine_tune_data/dpo_val_v2_fast.jsonl"
    
    print("Uploading fast datasets...")
    with open(train_path, "rb") as f:
        train_file = client.files.create(file=f, purpose="fine-tune")
        
    with open(val_path, "rb") as f:
        val_file = client.files.create(file=f, purpose="fine-tune")
        
    print(f"Train File ID: {train_file.id}")
    print(f"Val File ID: {val_file.id}")
    
    base_model = "ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH"
    
    print("Launching job with 1 epoch...")
    job = client.fine_tuning.jobs.create(
        training_file=train_file.id,
        validation_file=val_file.id,
        model=base_model,
        method={
            "type": "dpo",
            "dpo": {
                "hyperparameters": {
                    "beta": "auto",
                    "n_epochs": 1
                }
            }
        }
    )
    
    print(f"Successfully launched: {job.id}")
    
    report = [
        "# DPO Fast Run Launch",
        "",
        f"- **Job ID**: `{job.id}`",
        f"- **Base Model**: `{job.model}`",
        f"- **Train File**: `{train_file.id}`",
        f"- **Val File**: `{val_file.id}`",
        f"- **Epochs**: `1`",
        f"- **Status**: `{job.status}`"
    ]
    
    out_path = BASE_DIR / "reports/dpo_fast_job_launch.md"
    with open(out_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Report written to {out_path}")

if __name__ == "__main__":
    main()
