import json
import tiktoken
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def main():
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    
    # 1. Option 1 stats
    opt1_steps = 1704
    opt1_avg_tokens = 861
    opt1_total_tokens = opt1_steps * opt1_avg_tokens
    
    # 2. Simulate Option 2 
    # Option 2 plan: ~250 pairs, 3 epochs = 750 steps.
    # Evidence chunk length capped to 1000 chars. Current chunk len is ~1433 chars.
    # We drop easy negatives. So only hard negatives. (But our dataset already splits hard vs easy randomly, we can just say we drop easy ones and only build hard ones).
    # Token estimation:
    # System prompt ~ 150 chars -> 30 tokens
    # Expected prompt ~ 1000 chars -> 200 tokens
    # Output ~ 150 chars -> 30 tokens * 2 (pref/nonpref) = 60 tokens
    # Total tokens per pair ~ 290-350 tokens. Let's use 350 to be safe.
    opt2_pairs = 250
    opt2_epochs = 3
    opt2_steps = opt2_pairs * opt2_epochs
    opt2_avg_tokens = 350
    opt2_total_tokens = opt2_steps * opt2_avg_tokens
    
    diff_percent = (1 - (opt2_total_tokens / opt1_total_tokens)) * 100
    
    report = f"""
# DPO Job Inspection & Restart Proposal

## 1. Current Job Inspection
- **Job ID**: ftjob-QW3yXIQQ3nNqaXseoVBfLJsl
- **Status**: running
- **Base Model**: ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH
- **Method Type**: dpo
- **Training File ID**: file-NjmtnLMpk6HZqqQvKC2n4c (Confirmed to be the small v2 shard: ~568 valid pairs)
- **Validation File ID**: file-EoWKkheA8igerFxMtdfQXQ
- **Job Scale**: 1704 steps (Batch size 1, 3 Epochs). Trained ~370 steps so far.
- *(Note: \`trained_tokens\` is only reported by the API at the end of the run for DPO, but estimated at ~1.46M tokens based on 861 tokens/pair).*
- **Recent Events**:
    - [1771797339] Step 377/1704
    - [1771797315] Step 376/1704

## 2. Dataset Cross-Check
The training file ID corresponds exactly to the \`dpo_train_v2.jsonl\` dataset we just created, which has 572 pairs (OpenAI seems to have filtered ~4 rows, resulting in 568 pairs * 3 epochs = 1704 steps). **It is NOT using the old large dataset.** The long completion time is strictly a function of the 3 epochs and the long evidence context window.

## 3. Fast Restart Proposal
To dramatically cut wall-clock time, we can create \`dpo_train_v2_fast.jsonl\` with the following limits:
- **A) Trim subset**: 250-300 strictly balanced pairs instead of 572.
- **B) Cap Evidence Length**: Maximum 1,000 characters (down from current ~1,433 avg). 
- **C) Pure Hard Negatives**: Drop all "easy" negatives, focusing the gradient signal exclusively on single-dimension flips.

### Estimated Time/Token Reduction
- **Option 1**: Let current job finish (1,704 steps @ ~861 tokens = **~1.46M tokens**).
- **Option 2**: Cancel and restart with fast dataset (~750 steps @ ~350 tokens = **~262k tokens**).
- **Impact**: Restarting would reduce compute load by **~82%**, meaning a roughly 5x speedup for the DPO run.

**How would you like to proceed?**
- **Option 1**: Let the current job finish.
- **Option 2**: Cancel the current job, run the fast dataset builder, and launch a new job.
"""
    
    with open(BASE_DIR / "reports/dpo_fast_restart_proposal.md", "w") as f:
        f.write(report)
        
if __name__ == "__main__":
    main()
