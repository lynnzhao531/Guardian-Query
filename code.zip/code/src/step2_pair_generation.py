import json
import re
import hashlib
from pathlib import Path
import tiktoken
import pandas as pd

BASE_DIR = Path('.').resolve()
enc = tiktoken.encoding_for_model("gpt-4o-mini")

def load_jsonl(path):
    if not path.exists(): return []
    with open(path) as f:
        return [json.loads(line) for line in f]

def extract_scores(json_str):
    try:
        data = json.loads(json_str)
        s = {'decision': data.get('decision', {}).get('score', 0)}
        for m in ['rct', 'prepost', 'case_study', 'expert_qual', 'expert_secondary', 'gut']:
            s[m] = data.get(f'method_{m}', {}).get('score', 0)
        return s
    except: return None

def score_to_probs(score):
    if score == 1.0: return {'score': 1.0, 'p0': 0.0, 'p05': 0.05, 'p1': 0.95}
    if score == 0.5: return {'score': 0.5, 'p0': 0.2, 'p05': 0.6, 'p1': 0.2}
    return {'score': 0.0, 'p0': 0.95, 'p05': 0.05, 'p1': 0.0}

def stable_hash(s):
    return hashlib.sha256(s.encode()).hexdigest()

def truncate_prompt(row, max_tokens):
    line = row['input']['messages']
    prefix_toks = len(enc.encode(line[0]['content'])) + 10
    target = max_tokens - prefix_toks
    text = line[1]['content']
    tokens = enc.encode(text)
    if len(tokens) > target:
        line[1]['content'] = enc.decode(tokens[:target])
    return row

def main():
    with open('fine_tune_data/article_split_strict.json') as f:
        split = json.load(f)
    
    source_all = load_jsonl(Path('fine_tune_data/dpo_train_v2.jsonl')) + load_jsonl(Path('fine_tune_data/dpo_val_v2.jsonl'))
    
    df_chunk = pd.read_parquet('data/processed/evidence_chunks.parquet')
    title_to_url = { str(t).strip(): u for t, u in zip(df_chunk['title'], df_chunk['url_canon']) if t }
    body_map = { str(b)[:200]: u for b, u in zip(df_chunk['body'], df_chunk['url_canon']) if b }
    
    article_gold = {}
    for r in source_all:
        prompt = r['input']['messages'][1]['content']
        tit = None
        mt = re.search(r'Title: (.*?)\nDate:', prompt)
        if mt: tit = mt.group(1).strip()
        url = title_to_url.get(tit)
        if not url:
            snip = prompt.split('Evidence:\n', 1)[-1] if 'Evidence:\n' in prompt else prompt
            url = body_map.get(snip[:200])
        
        if url and url not in article_gold:
            gold_json_str = r['preferred_output'][0]['content']
            gold_scores = extract_scores(gold_json_str)
            if gold_scores:
                article_gold[url] = {'prompt': prompt, 'gold_json': gold_json_str, 'gold_scores': gold_scores, 'raw_row': r}

    results = {'train': [], 'val': []}
    MM = {'rct': 'M1', 'prepost': 'M2', 'case_study': 'M3', 'expert_secondary': 'M4', 'gut': 'M5'}

    for stype in ['train', 'val']:
        for url in split[stype]:
            data = article_gold.get(url)
            if not data: continue
            
            p_text = data['prompt']
            gs = data['gold_scores']
            g_json = json.loads(data['gold_json'])
            
            candidates = []
            
            # Universal D1 Synth (1.0 -> 0.5)
            if gs['decision'] == 1.0:
                npr = json.loads(json.dumps(g_json))
                npr['decision'] = score_to_probs(0.5)
                nr = {
                    'input': {'messages': [{'role': 'system', 'content': data['raw_row']['input']['messages'][0]['content']}, 
                                         {'role': 'user', 'content': p_text}]},
                    'preferred_output': [{'role': 'assistant', 'content': json.dumps(g_json)}],
                    'non_preferred_output': [{'role': 'assistant', 'content': json.dumps(npr)}]
                }
                candidates.append({'row': nr, 'bucket': 'D1', 'url': url})
            
            # Universal D2 Synth (0.5 -> 1.0)
            if gs['decision'] == 0.5:
                npr = json.loads(json.dumps(g_json))
                npr['decision'] = score_to_probs(1.0)
                nr = {
                    'input': {'messages': [{'role': 'system', 'content': data['raw_row']['input']['messages'][0]['content']}, 
                                         {'role': 'user', 'content': p_text}]},
                    'preferred_output': [{'role': 'assistant', 'content': json.dumps(g_json)}],
                    'non_preferred_output': [{'role': 'assistant', 'content': json.dumps(npr)}]
                }
                candidates.append({'row': nr, 'bucket': 'D2', 'url': url})
            
            # Universal Method Flips
            for m_key, b_name in MM.items():
                gold_val = gs.get(f'method_{m_key}', 0.0)
                flip_val = 0.0 if gold_val > 0 else 1.0
                if flip_val == gold_val: continue # Filtered Synthesis fix
                
                npr = json.loads(json.dumps(g_json))
                npr[f'method_{m_key}'] = score_to_probs(flip_val)
                nr = {
                    'input': {'messages': [{'role': 'system', 'content': data['raw_row']['input']['messages'][0]['content']}, 
                                         {'role': 'user', 'content': p_text}]},
                    'preferred_output': [{'role': 'assistant', 'content': json.dumps(g_json)}],
                    'non_preferred_output': [{'role': 'assistant', 'content': json.dumps(npr)}]
                }
                candidates.append({'row': nr, 'bucket': b_name, 'url': url})

            # Scoring and selection
            scored = []
            for cand in candidates:
                conf = 1 if cand['bucket'] in ['D1', 'D2'] else 0
                toks = len(enc.encode(cand['row']['input']['messages'][1]['content']))
                score = 100 * 1 + 10 * conf - 0.01 * toks
                scored.append((score, cand))
            
            scored.sort(key=lambda x: (-x[0], stable_hash(x[1]['bucket'] + url)))
            
            for _, cand in scored[:3]:
                cand['row'] = truncate_prompt(cand['row'], 450)
                results[stype].append(cand)

    with open('fine_tune_data/all_pairs_strict.json', 'w') as f:
        json.dump(results, f)

if __name__ == "__main__":
    main()
