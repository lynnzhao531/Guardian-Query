import pandas as pd
from pathlib import Path
import os
import json
import logging
from src.pool_manager import (
    POOLS_DIR, METHODS, REQUIRED_COLUMNS,
    ensure_pool_files_exist, update_pools, _process_overall_row, _process_llm_row
)

def rebuild_all_pools():
    print("Starting pool rebuild from history...")
    
    # 1. Initialize/Reset Pools (Wipe old malformed ones)
    if POOLS_DIR.exists():
        for f in POOLS_DIR.glob("*.csv"):
            f.unlink()
    ensure_pool_files_exist()
    
    # 2. Find all rounds
    round_dirs = sorted(list(Path("outputs/rounds").glob("round_*")), key=lambda x: int(x.name.split("_")[1]))
    
    rebuild_audit = {
        "timestamp_utc": pd.Timestamp.now(tz='UTC').isoformat(),
        "rounds_processed": [],
        "totals": {
            "overall_appended": 0,
            "llm_appended": 0,
            "duplicates_skipped": 0
        },
        "errors": []
    }
    
    for rd in round_dirs:
        try:
            round_id = int(rd.name.split("_")[1])
            print(f"Processing Round {round_id}...")
            
            # Temporary audit for this round
            tmp_audit = {
                "overall_rows_appended": 0,
                "llm_rows_appended": 0,
                "duplicates_skipped": 0,
                "errors": []
            }
            
            # Use update_pools logic but on historical files
            # Overall
            ov_path = rd / f"round_{round_id}_high_relevant_papers.csv"
            if ov_path.exists():
                df_ov = pd.read_csv(ov_path)
                if not df_ov.empty:
                    if "consensus_pass" in df_ov.columns:
                        df_ov = df_ov[df_ov["consensus_pass"] == True]
                    for _, row in df_ov.iterrows():
                        _process_overall_row(round_id, row, tmp_audit)
            
            # LLM
            sft_path = rd / f"round_{round_id}_SFT_papers.csv"
            # Fallback to high_relevant if SFT missing (per instructions)
            llm_source = pd.DataFrame()
            if sft_path.exists():
                llm_source = pd.read_csv(sft_path)
            
            if llm_source.empty and ov_path.exists():
                 llm_source = pd.read_csv(ov_path)
                 
            if not llm_source.empty:
                # Filter for high rel
                dec_col = None
                for c in ["llm_final_decision_p1", "llm_sft_decision_p1", "llm_final_decision_score", "llm_sft_decision_score"]:
                    if c in llm_source.columns:
                        dec_col = c
                        break
                if dec_col:
                    if "score" in dec_col:
                        high_df = llm_source[llm_source[dec_col] == 1.0]
                    else:
                        high_df = llm_source[llm_source[dec_col] >= 0.5]
                    
                    for _, row in high_df.iterrows():
                        _process_llm_row(round_id, row, tmp_audit)
            
            # Aggregate
            rebuild_audit["rounds_processed"].append(round_id)
            rebuild_audit["totals"]["overall_appended"] += tmp_audit["overall_rows_appended"]
            rebuild_audit["totals"]["llm_appended"] += tmp_audit["llm_rows_appended"]
            rebuild_audit["totals"]["duplicates_skipped"] += tmp_audit["duplicates_skipped"]
            if tmp_audit["errors"]:
                rebuild_audit["errors"].extend([f"Round {round_id}: {e}" for e in tmp_audit["errors"]])
                
        except Exception as e:
            msg = f"Failed to rebuild round {rd}: {e}"
            print(msg)
            rebuild_audit["errors"].append(msg)

    # Write Rebuild Audit
    audit_file = Path("audits/rebuild_pools_audit.json")
    audit_file.parent.mkdir(parents=True, exist_ok=True)
    with open(audit_file, "w") as f:
        json.dump(rebuild_audit, f, indent=2)
        
    print(f"Rebuild finished. Audit saved to {audit_file}")
    print(f"Totals: {rebuild_audit['totals']}")

if __name__ == "__main__":
    rebuild_all_pools()
