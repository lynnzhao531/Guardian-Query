import os
import json
import yaml
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from pathlib import Path
from transformers import AutoTokenizer, AutoModel, get_linear_schedule_with_warmup
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, classification_report
from tqdm import tqdm
import time

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "model_3.yaml"
DATA_PATH = ROOT / "outputs" / "master_vector.csv"
LABELS_PATH = ROOT / "data" / "concept_labels.parquet"
MODEL_SAVE_PATH = ROOT / "models" / "model3_best.pt"
METRICS_PATH = ROOT / "reports" / "model3_metrics.csv"
REPORT_PATH = ROOT / "reports" / "model3_training_report.md"

def load_config():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

# ── Dataset ──────────────────────────────────────────────────────────

class CBMDataset(Dataset):
    def __init__(self, texts, concept_labels, final_labels, tokenizer, max_len=512):
        self.texts = texts
        self.concept_labels = concept_labels
        self.final_labels = final_labels
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = str(self.texts[idx])
        encoding = self.tokenizer(
            text,
            max_length=self.max_len,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'concept_labels': torch.tensor(self.concept_labels[idx], dtype=torch.float),
            'final_labels': torch.tensor(self.final_labels[idx], dtype=torch.long)
        }

# ── Model ─────────────────────────────────────────────────────────────

class CBMModel(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(cfg['model']['base_encoder'])
        hidden_size = self.encoder.config.hidden_size
        
        self.concept_head = nn.Linear(hidden_size, cfg['model']['num_concepts'])
        
        # Bottleneck: Option B (Soft)
        if cfg['model']['bottleneck_type'] == "soft":
            self.label_head = nn.ModuleList([
                nn.Linear(hidden_size + cfg['model']['num_concepts'], 3)
                for _ in range(cfg['model']['num_labels'])
            ])
        else:
            self.label_head = nn.ModuleList([
                nn.Linear(cfg['model']['num_concepts'], 3)
                for _ in range(cfg['model']['num_labels'])
            ])
            
        self.bottleneck_type = cfg['model']['bottleneck_type']

    def forward(self, input_ids, attention_mask):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :] # CLS token
        
        concept_logits = self.concept_head(pooled_output)
        concept_probs = torch.sigmoid(concept_logits)
        
        if self.bottleneck_type == "soft":
            bottleneck_features = torch.cat([pooled_output, concept_probs], dim=1)
        else:
            bottleneck_features = concept_probs
            
        label_logits = [head(bottleneck_features) for head in self.label_head]
        
        return concept_logits, label_logits

# ── Training ──────────────────────────────────────────────────────────

def train():
    cfg = load_config()
    torch.manual_seed(cfg['training']['seed'])
    np.random.seed(cfg['training']['seed'])
    
    # Load Data
    df = pd.read_csv(DATA_PATH)
    labels_df = pd.read_parquet(LABELS_PATH)
    
    # Merge
    full_df = pd.merge(df, labels_df, on="url_canon")
    
    # Text
    full_df["full_text"] = full_df["title"].fillna("") + "\n\n" + full_df["body"].fillna("")
    
    # Concept Label mapping: -1 -> NaN, 1 -> 1, 0 -> 0 (actually our labeling script only did 1 or -1)
    # We'll treat -1 as UNKNOWN (masked loss)
    concept_cols = [c for c in labels_df.columns if c.endswith("_label")]
    concept_labels = full_df[concept_cols].values
    
    # Target mapping: {0:0, 0.5:1, 1:2, NaN:-1}
    label_cols = ["decision", "method_rct", "method_prepost", "method_case_study", 
                  "method_expert_qual", "method_expert_secondary", "method_gut"]
    
    final_labels = []
    for _, row in full_df.iterrows():
        labs = []
        for col in label_cols:
            val = row.get(col, np.nan)
            if pd.isna(val): labs.append(-1)
            elif val == 0.0: labs.append(0)
            elif val == 0.5: labs.append(1)
            elif val == 1.0: labs.append(2)
            else: labs.append(-1)
        final_labels.append(labs)
    final_labels = np.array(final_labels)
    
    # Split Article-Level
    indices = np.arange(len(full_df))
    train_idx, temp_idx = train_test_split(indices, test_size=0.3, random_state=cfg['training']['seed'])
    val_idx, test_idx = train_test_split(temp_idx, test_size=0.5, random_state=cfg['training']['seed'])
    
    tokenizer = AutoTokenizer.from_pretrained(cfg['model']['base_encoder'])
    
    train_ds = CBMDataset(full_df.iloc[train_idx]["full_text"].values, concept_labels[train_idx], final_labels[train_idx], tokenizer)
    val_ds = CBMDataset(full_df.iloc[val_idx]["full_text"].values, concept_labels[val_idx], final_labels[val_idx], tokenizer)
    
    train_loader = DataLoader(train_ds, batch_size=cfg['training']['batch_size'], shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=cfg['training']['batch_size'])
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    model = CBMModel(cfg).to(device)
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(cfg['training']['learning_rate']), weight_decay=cfg['training']['weight_decay'])
    
    num_training_steps = len(train_loader) * cfg['training']['epochs']
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=int(num_training_steps*cfg['training']['warmup_ratio']), num_training_steps=num_training_steps)
    
    best_val_f1 = 0
    patience_counter = 0
    epoch_results = []
    
    for epoch in range(cfg['training']['epochs']):
        model.train()
        train_loss = 0
        for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            c_labels = batch['concept_labels'].to(device)
            f_labels = batch['final_labels'].to(device)
            
            optimizer.zero_grad()
            c_logits, f_logits_list = model(input_ids, attention_mask)
            
            # Concept Loss (Masked BCE)
            mask_c = (c_labels != -1)
            loss_c = F.binary_cross_entropy_with_logits(c_logits[mask_c], c_labels[mask_c]) if mask_c.any() else torch.tensor(0.0).to(device)
            
            # Final Label Loss (Masked CrossEntropy)
            loss_f = 0
            for i, f_logits in enumerate(f_logits_list):
                mask_f = (f_labels[:, i] != -1)
                if mask_f.any():
                    # Corrected indexing: f_labels[mask_f, i] to get 1D target
                    loss_f += F.cross_entropy(f_logits[mask_f], f_labels[mask_f, i])
            
            # Soft Constraints (Implementation simplified)
            loss_cons = 0 # TODO: Implement differentiable constraints from configs
            
            total_loss = loss_f + cfg['model']['lambda_concept'] * loss_c + cfg['model']['lambda_constraint'] * loss_cons
            total_loss.backward()
            optimizer.step()
            scheduler.step()
            train_loss += total_loss.item()
            
        # Validation
        val_f1, val_loss = evaluate_model(model, val_loader, device)
        print(f"Epoch {epoch+1}: Train Loss: {train_loss/len(train_loader):.4f}, Val F1: {val_f1:.4f}, Val Loss: {val_loss:.4f}")
        
        epoch_results.append([epoch+1, train_loss/len(train_loader), val_loss, val_f1])
        
        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            torch.save(model.state_dict(), MODEL_SAVE_PATH)
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= cfg['training']['early_stopping_patience']:
                print("Early stopping triggered.")
                break
                
    # Save metrics
    res_df = pd.DataFrame(epoch_results, columns=["epoch", "train_loss", "val_loss", "val_f1"])
    res_df.to_csv(METRICS_PATH, index=False)
    
def evaluate_model(model, loader, device):
    model.eval()
    val_loss = 0
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for batch in loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            f_labels = batch['final_labels'].to(device)
            
            _, f_logits_list = model(input_ids, attention_mask)
            
            loss_f = 0
            for i, f_logits in enumerate(f_logits_list):
                mask_f = (f_labels[:, i] != -1)
                if mask_f.any():
                    # Corrected indexing: f_labels[mask_f, i] to get 1D target
                    loss_f += F.cross_entropy(f_logits[mask_f], f_labels[mask_f, i])
            val_loss += loss_f.item()
            
            # For metrics, we use Decision Score (first head)
            preds = torch.argmax(f_logits_list[0], dim=1).cpu().numpy()
            targets = f_labels[:, 0].cpu().numpy()
            
            mask = (targets != -1)
            all_preds.extend(preds[mask])
            all_targets.extend(targets[mask])
            
    f1 = f1_score(all_targets, all_preds, average='macro')
    return f1, val_loss / len(loader)

if __name__ == "__main__":
    train()
