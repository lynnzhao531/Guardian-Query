import os
from dotenv import load_dotenv

def load_guardian_keys():
    """
    Loads Guardian API keys from environment variables.
    Checks GUARDIAN_API_KEYS (comma-separated) first, 
    then GUARDIAN_API_KEY_1...10.
    Returns a list of keys.
    """
    load_dotenv()
    keys = []
    
    # 1. Check for single comma-separated variable
    keys_str = os.getenv("GUARDIAN_API_KEYS")
    if keys_str:
        keys = [k.strip() for k in keys_str.split(",") if k.strip()]
    
    # 2. Check for separate variables if no keys found yet
    if not keys:
        for i in range(1, 11):
            key = os.getenv(f"GUARDIAN_API_KEY_{i}")
            if key:
                keys.append(key.strip())
                
    if not keys:
        raise ValueError(
            "No Guardian API keys found. Please set GUARDIAN_API_KEYS "
            "or GUARDIAN_API_KEY_1...10 in your .env file."
        )
        
    return keys

def get_guardian_base_url():
    """Returns the Guardian API base URL from env or default."""
    return os.getenv(
        "GUARDIAN_API_BASE_URL", 
        "https://content.guardianapis.com/search"
    )
