import pandas as pd
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Reuse keywords from evidence extraction
KEYWORDS = {
    "rct_kw": [r"\brandom\w*\b", r"\brct\b", r"\bplacebo\b"],
    "prepost_kw": [r"\bbefore\b", r"\bafter\b", r"\bpre\b", r"\bpost\b", r"\bbaseline\b"],
    "case_study_kw": [r"\bcase study\b", r"\bcase report\b"],
    "expert_qual_kw": [r"\binterview\w*\b", r"\bfocus group\b", r"\bqualitative\b"],
    "expert_secondary_kw": [r"\breview\b", r"\bmeta-analysis\b", r"\bsystematic\b"],
    "gut_kw": [r"\bopinion\b", r"\bfeel\b", r"\bthink\b", r"\banecdote\b"]
}

def compute_micro_labels(df):
    
    for label, patterns in KEYWORDS.items():
        compiled_patterns = [re.compile(p) for p in patterns]
        
        def has_kw(text):
            if not isinstance(text, str): return False
            text = text.lower()
            return any(bool(p.search(text)) for p in compiled_patterns)
            
        df[f'has_{label}'] = df['body'].apply(has_kw)
        
    # Trap tags logic
    def get_trap_tag(row):
        tags = []
        if row.get('has_prepost_kw', False) and not row.get('has_rct_kw', False):
            tags.append("prepost_no_rct")
        if row.get('has_case_study_kw', False) and row.get('has_expert_qual_kw', False):
            tags.append("case_and_qual")
        if row.get('has_gut_kw', False):
            tags.append("opinion_heavy")
        return ",".join(tags) if tags else "none"

    df['trap_tag'] = df.apply(get_trap_tag, axis=1)
    
    # Just need URL and the micro-labels
    cols = ['url_canon', 'trap_tag'] + [f'has_{k}' for k in KEYWORDS.keys()]
    return df[cols]

def main():
    input_file = BASE_DIR / "outputs/master_vector.parquet"
    if not input_file.exists():
        input_file = BASE_DIR / "outputs/training_cases_clean.parquet"
        
    print(f"Loading {input_file}...")
    df = pd.read_parquet(input_file)
    
    print(f"Loaded {len(df)} rows. Computing micro-labels...")
    ml_df = compute_micro_labels(df)
    
    out_dir = BASE_DIR / "data/processed"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    out_file = out_dir / "micro_labels.parquet"
    ml_df.to_parquet(out_file)
    
    print(f"Saved to {out_file}")
    print("Example micro-labels:")
    print(ml_df.head(2))

if __name__ == "__main__":
    main()
