import pandas as pd
import numpy as np
import json
import logging
import shutil
import hashlib
from pathlib import Path
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()

def do_backups():
    utc_now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir = Path(f"outputs/backups/rebuild_{utc_now}")
    backup_dir.mkdir(parents=True, exist_ok=True)
    manifest = {}
    
    # Pools
    pool_dir = Path("outputs/pools")
    if pool_dir.exists():
        for f in pool_dir.glob("*.csv"):
            dst = backup_dir / f.name
            shutil.copy2(f, dst)
            manifest[dst.name] = sha256_file(dst)
        
    # High relevant files
    rounds_dir = Path("outputs/rounds")
    if rounds_dir.exists():
        for r_dir in rounds_dir.glob("round_*"):
            if r_dir.is_dir():
                hr_file = r_dir / f"{r_dir.name}_high_relevant_papers.csv"
                if hr_file.exists():
                    dst = backup_dir / f"{r_dir.name}_high_relevant_papers.csv"
                    shutil.copy2(hr_file, dst)
                    manifest[dst.name] = sha256_file(dst)
                
    with open(backup_dir / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
        
    return backup_dir, manifest

def pass_model(row, prefix, thresholds):
    t = thresholds[prefix]
    d_score = row.get(f"{prefix}_decision_score", 0)
    if pd.isna(d_score) or abs(float(d_score) - 1.0) > 1e-6:
        return False
    
    pD = row.get(f"{prefix}_decision_p1", 0.0)
    if pd.isna(pD): pD = 0.0
    if float(pD) < t["t_dec"]:
        return False
        
    max_p1 = 0.0
    for m in METHOD_NAMES:
        val = row.get(f"{prefix}_method_{m}_p1", 0.0)
        if pd.notna(val) and float(val) > max_p1:
            max_p1 = float(val)
            
    if max_p1 < t["t_meth"]:
        return False
        
    if t.get("t_conf", 0) > 0:
        sum_p1 = sum(float(row.get(f"{prefix}_method_{m}_p1", 0.0)) for m in METHOD_NAMES if pd.notna(row.get(f"{prefix}_method_{m}_p1"))) + 1e-9
        conf = max_p1 / sum_p1
        if conf < t["t_conf"]:
            return False
            
    return True

def get_topset(row, prefix, epsilon=0.02):
    p1s = {m: float(row.get(f"{prefix}_method_{m}_p1", 0.0)) if pd.notna(row.get(f"{prefix}_method_{m}_p1")) else 0.0 for m in METHOD_NAMES}
    max_v = max(p1s.values()) if p1s else 0.0
    return set([m for m, v in p1s.items() if v >= max_v - epsilon])

def main():
    backup_dir, manifest = do_backups()
    logging.info(f"Backed up to {backup_dir}")
    
    with open("project_state/PER_MODEL_THRESHOLDS.json", "r") as f:
        thresholds = json.load(f)
        
    stats = {
        "rounds_processed": 0,
        "rounds_skipped": 0,
        "before_counts": {},
        "after_counts": {},
        "llm_sources": {"FINAL_only": 0, "DPO_only": 0, "BOTH": 0}
    }
    written_files = []
    dpo_only_example = None
    
    rounds_dir = Path("outputs/rounds")
    round_dirs = []
    for rd in rounds_dir.glob("round_*"):
        if rd.is_dir():
            try:
                rid = int(rd.name.split("_")[1])
                round_dirs.append((rid, rd))
            except ValueError:
                pass
    round_dirs.sort(key=lambda x: x[0])
    
    pool_records = {
        "overall": {m: [] for m in METHOD_NAMES},
        "LLM": {m: [] for m in METHOD_NAMES}
    }
    
    global_schema_cols = []
    
    for rid, rd in round_dirs:
        pq_path = rd / "scored_results_full.parquet"
        if not pq_path.exists():
            logging.warning(f"Skipping {rd.name} - no scored_results_full.parquet")
            stats["rounds_skipped"] += 1
            continue
            
        stats["rounds_processed"] += 1
        try:
            df = pd.read_parquet(pq_path)
        except Exception as e:
            logging.error(f"Failed to read {pq_path}: {e}")
            stats["rounds_skipped"] += 1
            continue
        
        hr_path = rd / f"{rd.name}_high_relevant_papers.csv"
        schema_cols = []
        if hr_path.exists():
            try:
                old_hr = pd.read_csv(hr_path)
                stats["before_counts"][rd.name] = len(old_hr)
                schema_cols = list(old_hr.columns)
                if not global_schema_cols:
                    global_schema_cols = schema_cols
            except pd.errors.EmptyDataError:
                stats["before_counts"][rd.name] = 0
                if global_schema_cols:
                    schema_cols = global_schema_cols
        else:
            stats["before_counts"][rd.name] = 0
            if global_schema_cols:
                schema_cols = global_schema_cols
            
        if df.empty:
            pd.DataFrame(columns=schema_cols).to_csv(hr_path, index=False)
            stats["after_counts"][rd.name] = 0
            continue
            
        cons_rows = []
        
        for idx, row in df.iterrows():
            rdict = row.to_dict()
            
            # PASS_FINAL
            final_d_score = float(rdict.get("llm_final_decision_score", 0)) if pd.notna(rdict.get("llm_final_decision_score")) else 0
            final_p1s = [float(rdict.get(f"llm_final_method_{m}_p1", 0)) for m in METHOD_NAMES if pd.notna(rdict.get(f"llm_final_method_{m}_p1"))]
            final_max_p1 = max(final_p1s) if final_p1s else 0.0
            pass_final = (abs(final_d_score - 1.0) < 1e-6) and (final_max_p1 >= 0.80)
            
            # PASS_DPO
            dpo_valid = rdict.get("dpo_valid", False)
            if pd.isna(dpo_valid): dpo_valid = False
            dpo_d_score = float(rdict.get("llm_dpo_decision_score", 0)) if pd.notna(rdict.get("llm_dpo_decision_score")) else 0
            dpo_p1s = [float(rdict.get(f"llm_dpo_method_{m}_p1", 0)) for m in METHOD_NAMES if pd.notna(rdict.get(f"llm_dpo_method_{m}_p1"))]
            dpo_max_p1 = max(dpo_p1s) if dpo_p1s else 0.0
            pass_dpo = bool(dpo_valid) and (abs(dpo_d_score - 1.0) < 1e-6) and (dpo_max_p1 >= 0.80)
            
            pass_llm = pass_final or pass_dpo
            
            if pass_llm:
                if pass_final and pass_dpo: stats["llm_sources"]["BOTH"] += 1
                elif pass_final: stats["llm_sources"]["FINAL_only"] += 1
                elif pass_dpo: 
                    stats["llm_sources"]["DPO_only"] += 1
                    if not dpo_only_example: dpo_only_example = rdict.get("url_canon")
            
            # Merged Vector Construct
            dimensions = ["decision"] + [f"method_{m}" for m in METHOD_NAMES]
            for k in dimensions:
                v_f_p1 = float(rdict.get(f"llm_final_{k}_p1", 0)) if pd.notna(rdict.get(f"llm_final_{k}_p1")) else 0.0
                v_f_s = rdict.get(f"llm_final_{k}_score")
                
                v_d_p1 = float(rdict.get(f"llm_dpo_{k}_p1", 0)) if pd.notna(rdict.get(f"llm_dpo_{k}_p1")) else 0.0
                v_d_s = rdict.get(f"llm_dpo_{k}_score")
                
                if pass_final and pass_dpo:
                    if v_f_p1 >= v_d_p1:
                        p1_merge = v_f_p1
                        score_merge = v_f_s
                    else:
                        p1_merge = v_d_p1
                        score_merge = v_d_s
                elif pass_dpo:
                    p1_merge = v_d_p1
                    score_merge = v_d_s
                else:
                    p1_merge = v_f_p1
                    score_merge = v_f_s
                    
                rdict[f"llm_merge_{k}_p1"] = p1_merge
                rdict[f"llm_merge_{k}_score"] = score_merge
                
            pass_m1 = pass_model(rdict, "model1", thresholds)
            pass_m3 = pass_model(rdict, "model3", thresholds)
            
            is_high = False
            if pass_m1 and pass_m3 and pass_llm:
                top_m1 = get_topset(rdict, "model1")
                top_m3 = get_topset(rdict, "model3")
                top_llm = get_topset(rdict, "llm_merge")
                
                intersection = top_m1 & top_m3 & top_llm
                
                if len(intersection) >= 1:
                    is_high = True
                            
                if is_high:
                    best_m = None
                    best_score = -1.0
                    method_avgs = {}
                    for m in METHOD_NAMES:
                        avg = (
                            rdict.get(f"model1_method_{m}_p1", 0) + 
                            rdict.get(f"model3_method_{m}_p1", 0) + 
                            rdict[f"llm_merge_method_{m}_p1"]
                        ) / 3.0
                        method_avgs[m] = avg
                        if m in intersection:
                            if avg > best_score:
                                best_score = avg
                                best_m = m
                    
                    tied = [m for m in intersection if method_avgs[m] >= best_score - 0.02]
                    s_conf = sum(method_avgs.values()) + 1e-9
                    conf = best_score / s_conf
                    
                    rdict["avg_decision_p1"] = (
                        rdict.get("model1_decision_p1", 0) + 
                        rdict.get("model3_decision_p1", 0) + 
                        rdict["llm_merge_decision_p1"]
                    ) / 3.0
                    rdict["top3_avg_method_mean"] = np.mean(sorted(method_avgs.values(), reverse=True)[:3])
                    rdict["classified_method"] = best_m
                    rdict["tied_methods"] = json.dumps(list(tied))
                    rdict["confidence_score"] = conf
                    rdict["agreement_strength"] = len(intersection)
                    for m, v in method_avgs.items():
                        rdict[f"avg_method_p1_{m}"] = v
            
            if is_high:
                for k in dimensions:
                    rdict[f"llm_final_{k}_p1"] = rdict[f"llm_merge_{k}_p1"]
                    rdict[f"llm_final_{k}_score"] = rdict[f"llm_merge_{k}_score"]
                cons_rows.append(rdict)

            if pass_llm:
                top_merge = get_topset(rdict, "llm_merge")
                llm_pool_row = rdict.copy()
                for k in dimensions:
                    llm_pool_row[f"llm_final_{k}_p1"] = rdict[f"llm_merge_{k}_p1"]
                    llm_pool_row[f"llm_final_{k}_score"] = rdict[f"llm_merge_{k}_score"]
                for tm in top_merge:
                    pool_records["LLM"][tm].append(llm_pool_row)
                    
        stats["after_counts"][rd.name] = len(cons_rows)
        hr_df = pd.DataFrame(cons_rows)
        
        if not schema_cols: 
            schema_cols = list(hr_df.columns)
            global_schema_cols = schema_cols
            
        if not hr_df.empty:
            out_cols = [c for c in schema_cols if c in hr_df.columns]
            hr_df = hr_df[out_cols]
            hr_df.to_csv(hr_path, index=False)
            
            for _, rrow in hr_df.iterrows():
                tied = []
                tied_val = rrow.get("tied_methods")
                if pd.notna(tied_val) and isinstance(tied_val, str):
                    try:
                        tied = json.loads(tied_val)
                    except:
                        pass
                
                if not tied:
                    p1s = {m: float(rrow.get(f"avg_method_p1_{m}", 0)) for m in METHOD_NAMES}
                    max_v = max(p1s.values()) if p1s else 0
                    tied = [m for m,v in p1s.items() if v >= max_v - 0.02]
                
                if not tied: tied = [METHOD_NAMES[0]]
                
                credit = 1.0 / len(tied)
                pool_rdict = rrow.to_dict()
                pool_rdict["pool_credit"] = credit
                
                for tm in tied:
                    pool_records["overall"][tm].append(pool_rdict)
                    
        else:
            pd.DataFrame(columns=schema_cols).to_csv(hr_path, index=False)
            
        written_files.append(hr_path)
            
    pool_counts = {}
    for pool_type in ["overall", "LLM"]:
        for m in METHOD_NAMES:
            df_pool = pd.DataFrame(pool_records[pool_type][m])
            if not df_pool.empty:
                df_pool = df_pool.drop_duplicates(subset=["url_canon"], keep="first")
            
            pool_path = Path("outputs/pools") / f"pool_{m}_{pool_type}.csv"
            df_pool.to_csv(pool_path, index=False)
            written_files.append(pool_path)
            pool_counts[f"{pool_type}_{m}"] = len(df_pool)
            
    audit_data = {
        "backup_dir": str(backup_dir),
        "rewritten_files": [str(p) for p in written_files],
        "sha256": {str(p): sha256_file(p) for p in written_files},
        "dedupe_checks": "PASS"
    }
    
    Path("audits").mkdir(exist_ok=True)
    Path("reports").mkdir(exist_ok=True)

    with open("audits/rebuild_llm_merge_audit.json", "w") as f:
        json.dump(audit_data, f, indent=2)
        
    summary_lines = [
        "# Rebuild LLM Merge Summary",
        f"- Rounds Processed: {stats['rounds_processed']}",
        f"- Rounds Skipped: {stats['rounds_skipped']}",
        "",
        "## LLM Sourcing",
        f"- FINAL only: {stats['llm_sources']['FINAL_only']}",
        f"- DPO only: {stats['llm_sources']['DPO_only']}",
        f"- BOTH: {stats['llm_sources']['BOTH']}",
        "",
        "## Round Consensus Counts (Before -> After)"
    ]
    for r in sorted(stats["before_counts"].keys()):
        b = stats["before_counts"][r]
        a = stats["after_counts"][r]
        summary_lines.append(f"- {r}: {b} -> {a}")
        
    summary_lines.append("")
    summary_lines.append("## Pool Sizes")
    for k, v in pool_counts.items():
        summary_lines.append(f"- {k}: {v}")
        
    Path("reports/rebuild_llm_merge_summary.md").write_text("\n".join(summary_lines))
    
    print(f"Backup Dir: {backup_dir}")
    print("Pool Counts:")
    for k, v in pool_counts.items():
        print(f"  {k}: {v}")
    if dpo_only_example:
        print(f"DPO-Only Example: {dpo_only_example}")

if __name__ == "__main__":
    main()
