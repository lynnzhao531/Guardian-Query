import pandas as pd
from pathlib import Path
import logging
import datetime
import json
import os
import tempfile
import ast

# Configuration
POOLS_DIR = Path("outputs/pools")
METHODS = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

# POSITIONAL SCHEMA IS CRITICAL (12 columns)
REQUIRED_COLUMNS = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text",
    "source_round", "added_ts_utc", "credit", "tied_methods", "classified_method", "confidence_score"
]

def ensure_pool_files_exist():
    """
    Ensures that all 12 pool files exist with the exact canonical header.
    Repairs 0-byte or malformed files by resetting them to empty with header.
    """
    POOLS_DIR.mkdir(parents=True, exist_ok=True)
    
    for m in METHODS:
        for suffix in ["overall", "LLM"]:
            p_path = POOLS_DIR / f"pool_{m}_{suffix}.csv"
            
            needs_init = False
            if not p_path.exists() or p_path.stat().st_size == 0:
                needs_init = True
            else:
                try:
                    # Check first line for header match
                    with open(p_path, 'r') as f:
                        header = f.readline().strip().split(',')
                    if header != REQUIRED_COLUMNS:
                        needs_init = True
                except:
                    needs_init = True
            
            if needs_init:
                logging.info(f"Initializing/Repairing pool file: {p_path}")
                pd.DataFrame(columns=REQUIRED_COLUMNS).to_csv(p_path, index=False)

def update_pools(round_id: int):
    """
    Strict Patch 4 implementation:
    1. Overall: from round_{id}_high_relevant_papers.csv (Consensus)
    2. LLM: from round_{id}_SFT_papers.csv (preferred) OR consensus backup.
    """
    ensure_pool_files_exist()
    
    round_dir = Path(f"outputs/rounds/round_{round_id}")
    audit_dir = Path(f"audits/round_{round_id}")
    audit_dir.mkdir(parents=True, exist_ok=True)
    
    audit = {
        "round_id": round_id,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "overall_rows_appended": 0,
        "llm_rows_appended": 0,
        "duplicates_skipped": 0,
        "errors": []
    }
    
    # 1. Overall Pools (Consensus)
    overall_path = round_dir / f"round_{round_id}_high_relevant_papers.csv"
    if overall_path.exists():
        try:
            df = pd.read_csv(overall_path)
            if not df.empty:
                # Filter for consensus pass if the column exists
                if "consensus_pass" in df.columns:
                    df = df[df["consensus_pass"] == True]
                
                for _, row in df.iterrows():
                    _process_overall_row(round_id, row, audit)
        except Exception as e:
            audit["errors"].append(f"Overall pool update error: {e}")
            
    # 2. LLM Pools — CONTRACT V2: DPO_papers.csv is the LLM slot file (SFT when DPO disabled)
    dpo_path = round_dir / f"round_{round_id}_DPO_papers.csv"
    llm_source_df = pd.DataFrame()
    use_consensus_fallback = False
    
    if dpo_path.exists():
        try:
            llm_source_df = pd.read_csv(dpo_path)
            if llm_source_df.empty:
                use_consensus_fallback = True
        except:
            use_consensus_fallback = True
    else:
        use_consensus_fallback = True
        
    if use_consensus_fallback and overall_path.exists():
        try:
            llm_source_df = pd.read_csv(overall_path)
        except:
            pass

    if not llm_source_df.empty:
        try:
            # Filter for high relevance (decision score 1)
            # Find decision col (llm_final or llm_sft depending on file)
            dec_col = None
            for c in ["llm_final_decision_p1", "llm_sft_decision_p1", "llm_final_decision_score", "llm_sft_decision_score"]:
                if c in llm_source_df.columns:
                    dec_col = c
                    break
            
            if dec_col:
                # Use p1 >= threshold or score == 1? 
                # Patch 4 rule: "high-relevance rows (decision_score=1)" or high p1.
                # Let's use score == 1 if available, else p1 >= 0.5
                if "score" in dec_col:
                    high_df = llm_source_df[llm_source_df[dec_col] == 1.0]
                else:
                    high_df = llm_source_df[llm_source_df[dec_col] >= 0.5] # fallback
                
                for _, row in high_df.iterrows():
                    _process_llm_row(round_id, row, audit)
        except Exception as e:
            audit["errors"].append(f"LLM pool update error: {e}")

    # Write Audit
    with open(audit_dir / "pool_update_audit.json", "w") as f:
        json.dump(audit, f, indent=2)

def _process_overall_row(round_id: int, row, audit):
    # Parse tied_methods
    tied_raw = row.get("tied_methods", "[]")
    try:
        if isinstance(tied_raw, list):
            tied = tied_raw
        elif isinstance(tied_raw, str) and tied_raw.startswith("["):
            tied = ast.literal_eval(tied_raw)
        else:
            tied = [m.strip() for m in str(tied_raw).split(",") if m.strip() in METHODS]
    except:
        tied = []
        
    if not tied and row.get("classified_method") in METHODS:
        tied = [row.get("classified_method")]
        
    valid_tied = [m for m in tied if m in METHODS]
    if not valid_tied:
        return
        
    credit = 1.0 / len(valid_tied)
    
    for m in valid_tied:
        pool_path = POOLS_DIR / f"pool_{m}_overall.csv"
        entry = _build_pool_entry(round_id, row, credit, valid_tied, m)
        if _append_if_new(pool_path, entry):
            audit["overall_rows_appended"] += 1
        else:
            audit["duplicates_skipped"] += 1

def _process_llm_row(round_id: int, row, audit):
    # Epsilon-topset (eps=0.02) using llm_final or llm_sft
    prefix = "llm_final" if "llm_final_method_rct_p1" in row.index else "llm_sft"
    
    scores = {}
    for m in METHODS:
        col = f"{prefix}_method_{m}_p1"
        if col in row:
            scores[m] = float(row[col])
            
    if not scores:
        return
        
    mx = max(scores.values())
    tied = [m for m, v in scores.items() if v >= (mx - 0.02)]
    
    # Contract says: "credit = 1.0 for LLM pool entries"
    # Even if tied, we usually store the tie but classified_method is the top one.
    # Note: the prompt says "fractional split unless you choose tied methods"
    # "Choose tied winner methods using llm_final method p1 with epsilon-topset (eps=0.02) 
    # instead of a single forced winner. credit = 1.0 for LLM pool entries."
    
    for m in tied:
        pool_path = POOLS_DIR / f"pool_{m}_LLM.csv"
        # We use credit=1.0 per APPEND to that specific pool.
        entry = _build_pool_entry(round_id, row, 1.0, tied, m)
        if _append_if_new(pool_path, entry):
            audit["llm_rows_appended"] += 1
        else:
            audit["duplicates_skipped"] += 1

def _build_pool_entry(round_id, row, credit, tied_list, method):
    # Strict 12-column mapping
    return {
        "url_canon": row.get("url_canon"),
        "url": row.get("url"),
        "title": row.get("title"),
        "section": row.get("section"),
        "publication_date_utc": row.get("publication_date_utc"),
        "body_text": str(row.get("body_text", ""))[:100000], # safety cap
        "source_round": round_id,
        "added_ts_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "credit": credit,
        "tied_methods": json.dumps(tied_list),
        "classified_method": method,
        "confidence_score": row.get("confidence_score") if "confidence_score" in row else row.get("llm_final_decision_p1", 0.0)
    }

def _append_if_new(pool_path: Path, entry: dict) -> bool:
    """Atomic deduplicated append."""
    try:
        if not pool_path.exists():
            ensure_pool_files_exist()
            
        # Fast lookup
        # For performance, we could cache this, but for Patch 4 correctness we read.
        existing = pd.read_csv(pool_path, usecols=["url_canon", "classified_method"])
        matches = existing[(existing["url_canon"] == entry["url_canon"]) & 
                           (existing["classified_method"] == entry["classified_method"])]
        if not matches.empty:
            return False
            
        # Read ALL to maintain atomic integrity
        full_df = pd.read_csv(pool_path)
        new_row = pd.DataFrame([entry])[REQUIRED_COLUMNS] # FORCE ORDER
        updated_df = pd.concat([full_df, new_row], ignore_index=True)
        
        # Atomic Write
        with tempfile.NamedTemporaryFile(mode='w', delete=False, dir=POOLS_DIR, suffix='.csv') as tmp:
            updated_df.to_csv(tmp.name, index=False)
            tmp_path = Path(tmp.name)
            
        os.replace(tmp_path, pool_path)
        return True
    except Exception as e:
        logging.error(f"Failed to append to {pool_path}: {e}")
        return False

# ALIAS FOR BACKWARD COMPATIBILITY IF NEEDED
from datetime import timezone
