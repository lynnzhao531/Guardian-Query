"""
Shared helpers for API calls with caching and cost tracking.
Used by multiple pipeline scripts.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "project_state" / "api_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def estimate_cost(input_tokens: int, output_tokens: int, model: str, cfg: dict) -> float:
    p = cfg["pricing_estimates"]
    # Default fallback
    if isinstance(p, float): p = {"gpt_4_1_mini_input": 0.15, "gpt_4_1_mini_output": 0.60}
    
    if "o3-mini" in model:
        return (input_tokens / 1e6) * p.get("o3_mini_input", 1.10) + (output_tokens / 1e6) * p.get("o3_mini_output", 4.40)
    elif "4.1-mini" in model or "4o-mini" in model:
        return (input_tokens / 1e6) * p["gpt_4_1_mini_input"] + (output_tokens / 1e6) * p["gpt_4_1_mini_output"]
    elif "embedding" in model:
        return (input_tokens / 1e6) * p["embedding_small"]
    return 0.01


def check_budget(estimated_cost: float, ledger: dict, cfg: dict) -> bool:
    cap = cfg["budget"]["total_cap_usd"]
    remaining = cap - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"]
    return estimated_cost <= remaining


def record_cost(ledger: dict, step: str, cost: float) -> None:
    ledger["total_spent_usd"] = round(ledger["total_spent_usd"] + cost, 4)
    cap = 50.0
    ledger["remaining_budget_usd"] = round(
        cap - ledger["total_spent_usd"] - ledger["outstanding_reserved_budget_usd"], 4)
    ledger["per_step_costs"].append({"step": step, "cost_usd": round(cost, 4)})


def cached_chat(client, model: str, messages: list[dict], cfg: dict, ledger: dict,
                 step_name: str, temperature: float = 0.7, max_tokens: int = 4096) -> str:
    key = hashlib.md5(json.dumps({"model": model, "messages": messages},
                                  sort_keys=True).encode()).hexdigest()
    cache_file = CACHE_DIR / f"{key}.json"

    if cache_file.exists():
        return json.loads(cache_file.read_text())["content"]

    import tiktoken
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    input_toks = sum(len(enc.encode(m["content"])) + 4 for m in messages)
    est_cost = estimate_cost(input_toks, max_tokens, model, cfg)

    if not check_budget(est_cost, ledger, cfg):
        raise RuntimeError(f"BUDGET EXCEEDED: ${est_cost:.4f} for {step_name}")

    # o3-mini / reasoning models use max_completion_tokens, not max_tokens
    is_reasoning = "o3" in model or "o1" in model
    api_kwargs = dict(model=model, messages=messages)
    if is_reasoning:
        api_kwargs["max_completion_tokens"] = max_tokens
    else:
        api_kwargs["max_tokens"] = max_tokens
        api_kwargs["temperature"] = temperature

    resp = client.chat.completions.create(**api_kwargs)
    content = resp.choices[0].message.content
    actual_cost = estimate_cost(resp.usage.prompt_tokens, resp.usage.completion_tokens, model, cfg)
    record_cost(ledger, step_name, actual_cost)

    cache_file.write_text(json.dumps({
        "model": model, "content": content,
        "prompt_tokens": resp.usage.prompt_tokens,
        "completion_tokens": resp.usage.completion_tokens,
        "cost_usd": actual_cost,
    }, indent=2))

    return content
