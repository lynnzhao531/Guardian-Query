import pandas as pd
import os
from pathlib import Path
import json

POOLS_DIR = Path("outputs/pools")
METHODS = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
REQUIRED_COLUMNS = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text",
    "source_round", "added_ts_utc", "credit", "tied_methods", "classified_method", "confidence_score"
]

def main():
    if not POOLS_DIR.exists():
        print(f"Error: {POOLS_DIR} does not exist.")
        return

    pool_diagnostics = []
    
    for m in METHODS:
        for suffix in ["overall", "LLM"]:
            fname = f"pool_{m}_{suffix}.csv"
            p_path = POOLS_DIR / fname
            
            exists = p_path.exists()
            size = p_path.stat().st_size if exists else 0
            count = 0
            cols_match = False
            first_row_check = "N/A"
            
            if exists and size > 0:
                try:
                    df = pd.read_csv(p_path)
                    count = len(df)
                    cols = list(df.columns)
                    cols_match = (cols == REQUIRED_COLUMNS)
                    if not cols_match:
                         first_row_check = f"Mismatch: {len(cols)} cols found instead of {len(REQUIRED_COLUMNS)}"
                    else:
                         first_row_check = "OK"
                except Exception as e:
                    first_row_check = f"Error: {e}"
            
            pool_diagnostics.append({
                "filename": fname,
                "exists": exists,
                "rows": count,
                "size_kb": round(size / 1024, 2),
                "schema_ok": cols_match,
                "status": first_row_check
            })

    diag_df = pd.DataFrame(pool_diagnostics)
    md_diag = diag_df.to_markdown(index=False)
    
    # Check for recent audits
    audit_files = list(Path("audits").glob("round_*/pool_update_audit.json"))
    audit_status = "No audits found."
    if audit_files:
        audit_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        latest = audit_files[0]
        with open(latest) as f:
            data = json.load(f)
            audit_status = f"Latest Audit (Round {data.get('round_id')}): {len(data.get('errors', []))} errors."
    
    # Write Report
    report_content = f"""# Pool Diagnostics

## Pool File Status
{md_diag}

## Audit Summary
{audit_status}

## Analysis
- **Schema Mismatches**: If `schema_ok` is False, the pool manager failed to normalize the headers or existing legacy data is present.
- **Empty Pools**: If `rows` is 0, recent rounds did not update correctly.
"""
    
    os.makedirs("reports", exist_ok=True)
    with open("reports/pool_diagnostics.md", "w") as f:
        f.write(report_content)
    
    print("Report generated: reports/pool_diagnostics.md")

if __name__ == "__main__":
    main()
