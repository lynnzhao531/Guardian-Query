import pandas as pd
import os
from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent

def audit_dpo_files():
    query_log_path = BASE_DIR / "outputs/query_log.csv"
    if not query_log_path.exists():
        print(f"Error: {query_log_path} not found")
        return

    df_log = pd.read_csv(query_log_path)
    
    rounds_to_check = [24, 25, 35, 38, 40, 41, 42, 101, 200]
    
    report = []
    report.append("# DPO File Presence & Row Parity Audit")
    report.append(f"\nLynn. Auditing specific rounds: {rounds_to_check}")
    
    report.append("\n| Round ID | DPO CSV Exists | Log Valid Count | CSV Row Count | Parity | Note |")
    report.append("| --- | --- | --- | --- | --- | --- |")
    
    for rid in rounds_to_check:
        dpo_csv_path = BASE_DIR / f"outputs/rounds/round_{rid}/round_{rid}_DPO_papers.csv"
        log_val = 0
        if rid in df_log['round_id'].values:
            log_val = df_log[df_log['round_id'] == rid]['dpo_valid_count'].fillna(0).sum()
        
        exists = "Yes" if dpo_csv_path.exists() else "No"
        csv_rows = 0
        header_ok = "N/A"
        parity = "N/A"
        note = ""
        
        if dpo_csv_path.exists():
            try:
                df_csv = pd.read_csv(dpo_csv_path)
                csv_rows = len(df_csv)
                parity = "Yes" if int(log_val) == int(csv_rows) else f"NO ({log_val} != {csv_rows})"
                
                required_cols = ["url_canon", "llm_dpo_decision_score", "llm_dpo_method_expert_qual_score"]
                missing = [c for c in required_cols if c not in df_csv.columns]
                if missing:
                    note = f"Missing cols: {missing}"
            except Exception as e:
                note = f"Error reading CSV: {str(e)[:30]}"
        else:
            parity = "Yes" if int(log_val) == 0 else "NO (Missing File)"
            if int(log_val) > 0:
                note = "CRITICAL: Valid DPO data in log but no CSV!"
        
        report.append(f"| {rid} | {exists} | {log_val} | {csv_rows} | {parity} | {note} |")

    report_path = BASE_DIR / "reports/dpo_file_presence_audit.md"
    os.makedirs(report_path.parent, exist_ok=True)
    with open(report_path, "w") as f:
        f.write("\n".join(report))
    
    print(f"Audit report written to {report_path}")

if __name__ == "__main__":
    audit_dpo_files()
