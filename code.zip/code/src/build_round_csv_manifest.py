import os
import hashlib
import pandas as pd
from pathlib import Path
import sys

def get_header_hash(filepath):
    with open(filepath, 'r') as f:
        header = f.readline().strip()
    return hashlib.sha256(header.encode()).hexdigest()

def build_manifest(start_round, end_round):
    results = []
    file_types = [
        "model1_papers.csv",
        "model3_papers.csv",
        "SFT_papers.csv",
        "DPO_papers.csv",
        "high_relevant_papers.csv"
    ]
    
    for rid in range(start_round, end_round + 1):
        round_dir = Path(f"outputs/rounds/round_{rid}")
        if not round_dir.exists():
            continue
            
        for ft in file_types:
            fname = f"round_{rid}_{ft}"
            fpath = round_dir / fname
            exists = fpath.exists()
            h_hash = ""
            rows = 0
            cols_ok = False
            
            if exists:
                h_hash = get_header_hash(fpath)
                df = pd.read_csv(fpath)
                rows = len(df)
                # Simple check for required columns
                required = ["url", "title", "body_text"]
                cols_ok = all(c in df.columns for c in required)
                
            results.append({
                "round_id": rid,
                "file_type": ft,
                "exists": exists,
                "header_hash": h_hash,
                "data_rows": rows,
                "required_columns_present": cols_ok,
                "parity_ok": exists and cols_ok # Parity check could be more complex
            })
            
    pd.DataFrame(results).to_csv("reports/next20_round_csv_manifest.csv", index=False)
    print("Manifest written to reports/next20_round_csv_manifest.csv")

if __name__ == "__main__":
    # Default to 44-63
    build_manifest(44, 63)
