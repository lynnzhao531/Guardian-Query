import os
import json
import logging
import hashlib
import numpy as np
import pandas as pd
import joblib
from pathlib import Path
from sklearn.model_selection import GroupKFold, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import f1_score, accuracy_score
from sentence_transformers import SentenceTransformer
from src.tgml.theory_features import TheoryFeaturizer
from src.scorers import Model3ClassifierWrapper

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_text(row):
    title = row.get("title", "") or ""
    body = row.get("body", "") or "" # master_vector has 'body' not 'body_text'
    return f"{title}\n\n{body}"

def get_3class_parity_data(X, y, sample_weights):
    """
    Ensure 3-class parity by adding 1 synthetic sample per missing class.
    Synthetic samples use mean feature vector and weight=1e-3.
    """
    classes = [0.0, 0.5, 1.0]
    present_classes = np.unique(y)
    missing_classes = [c for c in classes if c not in present_classes]
    
    if not missing_classes:
        return X, y, sample_weights
    
    X_new = X.copy()
    y_new = y.copy()
    w_new = sample_weights.copy()
    
    mean_vec = X.mean(axis=0).reshape(1, -1)
    
    for c in missing_classes:
        X_new = np.vstack([X_new, mean_vec])
        y_new = np.append(y_new, c)
        w_new = np.append(w_new, 1e-3)
        
    return X_new, y_new, w_new

def train_head(name, X_train, y_train):
    """
    Train a single head using LogisticRegression or DummyClassifier.
    Target {0, 0.5, 1.0}.
    """
    # Filter non-null
    mask = ~pd.isna(y_train)
    X_sub = X_train[mask]
    y_sub = y_train[mask].astype(float)
    
    logger.info(f"Training head {name} with {len(y_sub)} samples.")
    
    if len(y_sub) == 0:
        logger.warning(f"No data for {name}. Using DummyClassifier(constant=0).")
        # Synthetic 3-class data for Dummy
        X_syn = np.zeros((3, X_train.shape[1]))
        y_syn = np.array([0.0, 0.5, 1.0])
        clf = DummyClassifier(strategy="constant", constant=[0.0])
        clf.fit(X_syn, y_syn)
        return clf, "Dummy (0 labels)"
    
    unique_labels = np.unique(y_sub)
    if len(unique_labels) < 2:
        logger.warning(f"Fewer than 2 labels for {name} ({unique_labels}). Using DummyClassifier.")
        X_syn = np.zeros((3, X_train.shape[1]))
        y_syn = np.array([0.0, 0.5, 1.0])
        clf = DummyClassifier(strategy="constant", constant=[unique_labels[0]])
        clf.fit(X_syn, y_syn)
        return clf, f"Dummy (constant={unique_labels[0]})"
    
    # Parity check
    weights = np.ones(len(y_sub))
    X_p, y_p, w_p = get_3class_parity_data(X_sub, y_sub, weights)
    
    try:
        lr = LogisticRegression(class_weight="balanced", solver="saga", max_iter=5000, random_state=42)
        # Use estimator= (sklearn 1.2+) with fallback to base_estimator
        try:
            clf = CalibratedClassifierCV(estimator=lr, method="sigmoid", cv=3)
        except TypeError:
            clf = CalibratedClassifierCV(base_estimator=lr, method="sigmoid", cv=3)
            
        clf.fit(X_p, y_p.astype(str), sample_weight=w_p)
        return clf, "LogisticRegression (Calibrated)"
    except Exception as e:
        logger.error(f"LR fit failed for {name}: {e}. Falling back to Dummy.")
        X_syn = np.zeros((3, X_train.shape[1]))
        y_syn = np.array([0.0, 0.5, 1.0])
        clf = DummyClassifier(strategy="most_frequent")
        clf.fit(X_syn, y_syn) # Use y_syn only to establish classes
        return clf, "Dummy (Fallback)"

def main():
    # 1. Inspect existing artifact structure
    existing_path = "models/model3/model3_models.joblib"
    if os.path.exists(existing_path):
        m = joblib.load(existing_path)
        logger.info(f"Existing artifact keys: {list(m.keys())}")
    
    # 2. Load Data
    data_path = "outputs/master_vector.parquet"
    logger.info(f"Loading data from {data_path}")
    df = pd.read_parquet(data_path)
    
    # article_id / url_canon
    id_col = "url_canon"
    df = df.dropna(subset=["decision"])
    
    # 3. Embeddings
    logger.info("Computing embeddings (MiniLM-L6-v2)")
    embedder = SentenceTransformer('all-MiniLM-L6-v2')
    texts = df.apply(get_text, axis=1).tolist()
    
    # Cache
    cache_path = "outputs/model3_embeddings_cache.joblib"
    df_hash = hashlib.md5(pd.util.hash_pandas_object(df[[id_col]]).values).hexdigest()
    
    if os.path.exists(cache_path):
        cache = joblib.load(cache_path)
        if cache.get("hash") == df_hash:
            logger.info("Loading embeddings from cache.")
            embeddings = cache["embeddings"]
        else:
            logger.info("Hash mismatch. Recomputing embeddings.")
            embeddings = embedder.encode(texts, show_progress_bar=True)
            joblib.dump({"hash": df_hash, "embeddings": embeddings}, cache_path)
    else:
        embeddings = embedder.encode(texts, show_progress_bar=True)
        joblib.dump({"hash": df_hash, "embeddings": embeddings}, cache_path)
    
    # 4. Theory Features
    logger.info("Computing theory features")
    theory_feat = TheoryFeaturizer()
    theory_df = theory_feat.transform(df)
    X_theory = theory_df.values.astype(np.float64)
    
    X = np.hstack([embeddings, X_theory])
    
    # 5. Split (Article Level)
    logger.info("Splitting train/val (Article Level)")
    unique_ids = df[id_col].unique()
    train_ids, val_ids = train_test_split(unique_ids, test_size=0.15, random_state=42)
    
    train_mask = df[id_col].isin(train_ids)
    val_mask = df[id_col].isin(val_ids)
    
    X_train, X_val = X[train_mask], X[val_mask]
    df_train, df_val = df[train_mask], df[val_mask]
    
    # 6. Train Heads
    heads = {}
    head_metadata = {}
    
    # Decision
    heads["decision"], head_metadata["decision"] = train_head("decision", X_train, df_train["decision"])
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    for m in methods:
        target_col = f"method_{m}"
        heads[target_col], head_metadata[target_col] = train_head(target_col, X_train, df_train[target_col])
        
    # 7. Degeneracy Gate
    logger.info("Evaluating degeneracy gate")
    val_probs = []
    trained_methods = []
    for m in methods:
        target_col = f"method_{m}"
        if "Dummy (0 labels)" not in head_metadata[target_col] and target_col != "method_expert_qual":
            clf = heads[target_col]
            # p1 is index 2
            p1 = clf.predict_proba(X_val)[:, 2]
            val_probs.append(p1)
            trained_methods.append(m)
            
    if val_probs:
        max_method_p1 = np.max(np.array(val_probs), axis=0)
        std_val = np.std(max_method_p1)
        logger.info(f"std(max_method_p1) on validation (trained heads: {trained_methods}): {std_val:.4f}")
        
        if std_val < 0.05:
            logger.error("DEGENERACY GATE FAILED: std < 0.05")
            report_msg = f"FAILED: std(max_method_p1) = {std_val:.4f} < 0.05"
        else:
            report_msg = f"PASSED: std(max_method_p1) = {std_val:.4f} >= 0.05"
    else:
        std_val = 0.0
        report_msg = "FAILED: No trained method heads found for evaluation."
        
    # 8. Wrap and Save
    wrapped_heads = {k: Model3ClassifierWrapper(v) for k, v in heads.items()}
    os.makedirs("models/model3", exist_ok=True)
    joblib.dump(wrapped_heads, existing_path)
    logger.info(f"Artifacts saved to {existing_path}")
    
    # 9. Report
    logger.info("Generating report")
    report = []
    report.append("# Model 3 Retrain Report")
    report.append(f"**Dataset Hash:** {df_hash}")
    report.append(f"**Split Seed:** 42")
    report.append(f"**Degeneracy Gate:** {report_msg}")
    report.append("\n## Label Counts & Strategy")
    
    counts_df = []
    for k in ["decision"] + [f"method_{m}" for m in methods]:
        y = df_train[k]
        val_counts = y.value_counts(dropna=False).to_dict()
        strategy = head_metadata[k]
        if k == "method_expert_qual":
             strategy = "UNSUPPORTED (0 labels)"
        counts_df.append({
            "Head": k,
            "Strategy": strategy,
            "0.0": val_counts.get(0.0, 0),
            "0.5": val_counts.get(0.5, 0),
            "1.0": val_counts.get(1.0, 0),
            "NaN": val_counts.get(np.nan, 0)
        })
    report.append(pd.DataFrame(counts_df).to_markdown(index=False))
    
    report.append("\n## Validation Metrics")
    metrics_df = []
    for k in ["decision"] + [f"method_{m}" for m in methods]:
        if "Dummy (0 labels)" in head_metadata[k] or k == "method_expert_qual":
            metrics_df.append({"Head": k, "F1 Macro": "N/A", "Accuracy": "N/A"})
            continue
            
        y_true = df_val[k].dropna().astype(float)
        if len(y_true) == 0:
            metrics_df.append({"Head": k, "F1 Macro": "N/A", "Accuracy": "N/A"})
            continue
            
        mask_sub = df_val[k].notna().fillna(False).values.astype(bool)
        X_sub = X_val[mask_sub]
        y_pred = heads[k].predict(X_sub)
        
        f1 = f1_score(y_true.astype(str), y_pred.astype(str), average="macro")
        acc = accuracy_score(y_true.astype(str), y_pred.astype(str))
        metrics_df.append({"Head": k, "F1 Macro": f"{f1:.3f}", "Accuracy": f"{acc:.3f}"})
        
    report.append(pd.DataFrame(metrics_df).to_markdown(index=False))
    
    # Top errors table (Top 15 where pred != true for method_score == 1.0)
    report.append("\n## Top 15 Method Errors (Ground Truth = 1.0)")
    errors = []
    for m in methods:
        target_col = f"method_{m}"
        if "Dummy" in head_metadata[target_col]: continue
        
        mask = (df_val[target_col] == 1.0).fillna(False)
        if mask.any():
            mask_bool = mask.values.astype(bool)
            X_err = X_val[mask_bool]
            y_pred = heads[target_col].predict(X_err)
            obs_ids = df_val[mask][id_col].values
            
            for idx, p in enumerate(y_pred):
                if p != 1.0:
                    errors.append({
                        "ID": obs_ids[idx],
                        "Method": m,
                        "True": 1.0,
                        "Pred": p
                    })
                    
    if errors:
        err_df = pd.DataFrame(errors).sort_values("ID").head(15)
        report.append(err_df.to_markdown(index=False))
    else:
        report.append("No errors found on Ground Truth 1.0 samples in validation.")
        
    with open("reports/model3_retrain_report.md", "w") as f:
        f.write("\n".join(report))
        
    if std_val < 0.05 and val_probs:
         exit(1)

if __name__ == "__main__":
    main()
