import argparse
import pandas as pd
from pathlib import Path
import json
import numpy as np

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round_from", type=int)
    parser.add_argument("--round_to", type=int)
    parser.add_argument("--last_n", type=int)
    args = parser.parse_args()
    
    # Determine range
    rounds_dir = Path("outputs/rounds")
    all_rounds = sorted([int(d.name.split("_")[1]) for d in rounds_dir.glob("round_*") if d.is_dir()])
    
    if not all_rounds:
        print("No rounds found.")
        return

    if args.last_n:
        target_rounds = all_rounds[-args.last_n:]
    elif args.round_from and args.round_to:
        target_rounds = [r for r in all_rounds if args.round_from <= r <= args.round_to]
    else:
        # Default all
        target_rounds = all_rounds
        
    print(f"Analyzing rounds: {target_rounds}")
    
    stats_list = []
    
    models = ["model1", "model3", "llm_sft", "llm_final", "llm_dpo"]
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    
    for rid in target_rounds:
        pq = rounds_dir / f"round_{rid}" / "scored_results_full.parquet"
        if not pq.exists():
            print(f"Skipping Round {rid} (no parquet)")
            continue
            
        try:
            df = pd.read_parquet(pq)
        except Exception as e:
            print(f"Error reading Round {rid}: {e}")
            continue
            
        if df.empty:
            print(f"Round {rid} is empty.")
            continue
            
        print(f"Processing Round {rid} ({len(df)} rows)...")
        
        # Per Model stats
        for model in models:
            # Check if model columns exist
            dec_col = f"{model}_decision_score"
            if dec_col not in df.columns:
                print(f"WARNING: {dec_col} missing in Round {rid}")
                continue
                
            # Missingness
            missing = df[dec_col].isna().sum()
            if missing > 0:
                print(f"WARNING: {model} has {missing} missing scores in Round {rid}")
            
            # Decision Distribution
            scores = df[dec_col].dropna()
            for val in [0.0, 0.5, 1.0]:
                count = (scores == val).sum()
                stats_list.append({
                    "round_id": rid,
                    "model": model,
                    "metric": f"decision_count_{val}",
                    "value": count
                })
                
            # Agreement Stats
            # Count discrete
            
            # P1 stats
            p1_col = f"{model}_decision_p1"
            if p1_col in df.columns:
                p1s = df[p1_col].dropna()
                stats_list.append({"round_id": rid, "model": model, "metric": "decision_p1_mean", "value": p1s.mean()})
                stats_list.append({"round_id": rid, "model": model, "metric": "pct_p1_ge_80", "value": (p1s >= 0.80).mean()})
                stats_list.append({"round_id": rid, "model": model, "metric": "pct_p1_ge_70", "value": (p1s >= 0.70).mean()})
            
            # Method Stats
            for m in methods:
                m_p1_col = f"{model}_method_{m}_p1"
                if m_p1_col in df.columns:
                    # Max method p1 distribution? No, we want per row max?
                    # "max_method_p1 per row distribution"
                    # Wait, calculating max over ALL methods
                    pass
            
            # Row-wise Max Method P1
            # Which columns? {model}_method_{m}_p1 for all m
            m_cols = [f"{model}_method_{m}_p1" for m in methods if f"{model}_method_{m}_p1" in df.columns]
            if m_cols:
                max_p1 = df[m_cols].max(axis=1)
                stats_list.append({"round_id": rid, "model": model, "metric": "max_method_p1_mean", "value": max_p1.mean()})
                stats_list.append({"round_id": rid, "model": model, "metric": "max_method_p1_median", "value": max_p1.median()})
                
                # Strict High Relevance: Max(Method P1) >= 0.80 AND Decision == 1
                strict_high = ((max_p1 >= 0.80) & (df[dec_col] == 1.0)).sum()
                stats_list.append({"round_id": rid, "model": model, "metric": "strict_high_rel_count", "value": strict_high})
                
                # Soft Indicator: Max(Method P1) >= 0.70 AND Decision P1 >= 0.70
                soft = ((max_p1 >= 0.70) & (df[p1_col] >= 0.70)).sum() if p1_col in df.columns else 0
                stats_list.append({"round_id": rid, "model": model, "metric": "soft_candidate_count", "value": soft})

        # Agreement (Model1, Model3, LLM Final)
        ag_cols = ["model1_decision_score", "model3_decision_score", "llm_final_decision_score"]
        valid_ag = [c for c in ag_cols if c in df.columns]
        if valid_ag:
           agreement = (df[valid_ag] == 1.0).sum(axis=1)
           for i in range(len(valid_ag) + 1):
               count = (agreement == i).sum()
               stats_list.append({"round_id": rid, "model": "CONSENSUS", "metric": f"agreement_{i}", "value": count})
               
    # Output
    out_dir = Path("reports")
    out_dir.mkdir(exist_ok=True)
    summary_csv = out_dir / f"score_distribution.csv"
    pd.DataFrame(stats_list).to_csv(summary_csv, index=False)
    print(f"Summary written to {summary_csv}")
    
    # Simple Markdown Report
    print("\n--- Report Summary ---")
    print(pd.DataFrame(stats_list).groupby(["model", "metric"])["value"].mean().to_string())

if __name__ == "__main__":
    main()
