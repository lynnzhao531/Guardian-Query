import pandas as pd
import numpy as np
import json
import logging
import itertools
from pathlib import Path
from src.hypothesis_verifier import HypothesisVerifier

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = ROOT / "reports" / "fixed_eval_sft_raw.parquet"
HYPOTHESES_PATH = ROOT / "knowledge_base" / "hypotheses" / "hypotheses_selected.json"
OUTPUT_PARAMS_PATH = ROOT / "project_state" / "HYPOTHESIS_ADJUST_PARAMS.json"

DIMENSIONS = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]

def fit_grid():
    if not INPUT_PATH.exists():
        logging.error(f"Input file not found: {INPUT_PATH}")
        return
        
    df = pd.read_parquet(INPUT_PATH)
    with open(HYPOTHESES_PATH, "r") as f:
        selected_hyps = json.load(f)
        
    logging.info(f"Caching hypothesis hits for {len(df)} articles...")
    # Cache support and trap counts per article
    hits_cache = []
    for _, row in df.iterrows():
        text = row.get("body_text", "")
        hits = HypothesisVerifier.get_hit_counts(text, selected_hyps)
        hits_cache.append(hits)
        
    # Baseline Decision
    temp_dec = df[df["gold_decision"].notna()]
    y_true_dec = (temp_dec["gold_decision"] == 1.0).astype(int).values
    sft_p1_dec = temp_dec["llm_sft_decision_p1"].values
    sft_score_dec = (temp_dec["llm_sft_decision_score"] == 1.0).astype(int).values
    
    tp_raw = int((y_true_dec & sft_score_dec).sum())
    fp_raw = int(((y_true_dec == 0) & (sft_score_dec == 1)).sum())
    
    logging.info(f"Baseline Decision: TP={tp_raw}, FP={fp_raw}")
    
    # Grid definition
    grid_a = [0.03, 0.05, 0.07, 0.10]
    grid_b = [0.03, 0.05, 0.07, 0.10]
    grid_t1 = [0.75, 0.80, 0.85]
    grid_t05 = [0.50, 0.55, 0.60]
    
    best_j = -999.0
    best_params = None
    best_metrics = None
    
    configs = list(itertools.product(grid_a, grid_b, grid_t1, grid_t05))
    valid_configs = [c for c in configs if c[3] < c[2]]
    
    logging.info(f"Searching {len(valid_configs)} valid configurations...")
    
    results = []
    for a, b, t1, t05 in valid_configs:
        # Apply formula to Decision subset
        p1_adj_list = []
        for i, row_idx in enumerate(temp_dec.index):
            p1_raw = sft_p1_dec[i]
            hits = hits_cache[row_idx]
            
            # support_d = hits_high - hits_low, clip [-2, 2]
            # trap_d = hits_trap, clip [0, 2]
            # Using decision specific hits if they exist? 
            # No, user says "For each dimension d: support_d = hits_high - hits_low... Apply globally"
            # We use global hit counts for the article.
            
            # HypothesisVerifier.check_hypotheses returns {dim: {high: N, low: M, trap: K}}
            # We use 'decision' hits for decision dimension.
            h = hits.get('decision', {'high': 0, 'low': 0, 'trap': 0})
            sup = np.clip(h['high'] - h['low'], -2, 2)
            trap = np.clip(h['trap'], 0, 2)
            
            p1_adj = np.clip(p1_raw + a * sup - b * trap, 0, 1)
            p1_adj_list.append(p1_adj)
            
        p1_adj_arr = np.array(p1_adj_list)
        y_pred_adj = (p1_adj_arr >= t1).astype(int)
        
        tp_adj = int((y_true_dec & y_pred_adj).sum())
        fp_adj = int(((y_true_dec == 0) & (y_pred_adj == 1)).sum())
        
        tp_loss = (tp_raw - tp_adj) / max(tp_raw, 1)
        fp_red = (fp_raw - fp_adj) / max(fp_raw, 1)
        
        j = fp_red - 0.5 * tp_loss
        
        passed_primary = (tp_loss <= 0.15) and (fp_red >= 0.30)
        passed_fallback = (tp_loss <= 0.15) and (fp_red >= 0.20)
        
        res = {
            'params': (a, b, t1, t05),
            'tp': tp_adj, 'fp': fp_adj,
            'tp_loss': tp_loss, 'fp_red': fp_red,
            'j': j, 'passed_primary': passed_primary, 'passed_fallback': passed_fallback
        }
        results.append(res)
        
    # Selection logic
    primary_candidates = [r for r in results if r['passed_primary']]
    if primary_candidates:
        best = max(primary_candidates, key=lambda x: x['j'])
        status = "PRIMARY_ACHIEVED"
    else:
        fallback_candidates = [r for r in results if r['passed_fallback']]
        if fallback_candidates:
            best = max(fallback_candidates, key=lambda x: x['j'])
            status = "FALLBACK_ACHIEVED"
        else:
            best = max(results, key=lambda x: x['j'])
            status = "FAILED_ALL_CONSTRAINTS"
            
    best_params = {
        "a": best['params'][0],
        "b": best['params'][1],
        "t1": best['params'][2],
        "t05": best['params'][3],
        "status": status,
        "metrics": {
            "tp_adj": best['tp'],
            "fp_adj": best['fp'],
            "tp_loss": best['tp_loss'],
            "fp_red": best['fp_red'],
            "j_score": best['j']
        }
    }
    
    with open(OUTPUT_PARAMS_PATH, "w") as f:
        json.dump(best_params, f, indent=2)
        
    logging.info(f"Optimization complete. Status: {status}")
    logging.info(f"Best Params: {best_params['a']}, {best_params['b']}, t1={best_params['t1']}, t05={best_params['t05']}")
    logging.info(f"Metrics: FP Reduction={best['fp_red']:.1%}, TP Loss={best['tp_loss']:.1%}")

if __name__ == "__main__":
    fit_grid()
