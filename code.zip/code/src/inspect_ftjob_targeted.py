import os
import json
from openai import OpenAI
from pathlib import Path

def get_api_key():
    env_path = Path(".env")
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=get_api_key())
job_id = "ftjob-iEA3z0q21gdqxeHMi2nI0tRH"

try:
    job = client.fine_tuning.jobs.retrieve(job_id)
    events = client.fine_tuning.jobs.list_events(fine_tuning_job_id=job_id, limit=50)
    
    # Essential job info
    job_info = {
        "id": job.id,
        "status": job.status,
        "model": job.model,
        "fine_tuned_model": job.fine_tuned_model,
        "training_file": job.training_file,
        "validation_file": job.validation_file,
        "created_at": job.created_at,
        "finished_at": job.finished_at,
        "method": job.method.model_dump() if job.method else None
    }
    
    # Filter for relevant events
    target_keywords = ["re-enqueued", "created", "enabled", "succeeded", "failed"]
    relevant_events = []
    for event in events.data:
        msg = event.message.lower()
        if any(kw in msg for kw in target_keywords):
            relevant_events.append(event.model_dump())
            
    output = {
        "job_info": job_info,
        "relevant_events": relevant_events
    }
    print(json.dumps(output, indent=2))
except Exception as e:
    print(json.dumps({"error": str(e)}))
