import os
import json
import csv
import re
import time
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "project_state" / "diag_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

# ── Articles Data (from src/12_evaluate_fictional_articles.py) ────────
ARTICLES = [
    {"id": "1A", "type": "rct", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0,
     "title": "Council to randomise neighbourhood patrols in summer pilot to decide citywide policing plan", 
     "body": "..."}, # Full text in actual implementation
    # ... truncate for brevitiy in write_to_file but I will include all or load them
]

# I'll actually copy the full list to stay robust.
ARTICLES = [
    {"id": "1A", "type": "rct", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "Council to randomise neighbourhood patrols in summer pilot to decide citywide policing plan", "body": "A Midlands city council will run a six-month trial that randomly assigns neighbourhoods to two different patrol strategies, in a bid to decide which approach should be adopted across the city next year. Under the plan, 40 neighbourhood clusters will be allocated by lottery to either Strategy A, which increases foot patrols at peak hours, or Strategy B, which shifts resources to rapid response teams. Independent analysts from a local university will track outcomes including reported assaults, burglary, response times and resident perceptions, comparing results across the two groups. Councillors said the trial was designed to avoid 'guesswork' and would be used to make a specific decision in October: whether to fund and roll out Strategy A, Strategy B, or abandon both in favour of a redesigned approach."},
    {"id": "1B", "type": "rct", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "‘Randomised controlled trial’ at centre of courtroom clash over juror selection", "body": "A judge has heard arguments in a high-profile fraud case after defence lawyers compared the prosecution’s juror selection process to a 'randomised controlled trial'. The defence said the jury pool had been 'randomly assigned' in a way that created an unfair 'control group', alleging the process skewed towards certain postcodes. Prosecutors rejected the comparison, calling it 'a metaphor dressed up as statistics'. While the hearing repeatedly referenced 'trial arms', 'controls' and 'randomisation', the dispute concerns legal procedure and the admissibility of evidence."},
    {"id": "1C", "type": "rct", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Random thrills: the five best summer festivals for experimental music", "body": "From warehouse techno to chamber-pop mashups, this year’s festival season is packed with 'experimental' sets. Here are five events to catch, plus the artists turning randomness into an art form."},
    {"id": "2A", "type": "prepost", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "Free school breakfast scheme will expand if ‘before-and-after’ results hold, minister says", "body": "A free breakfast programme piloted in 25 schools will be extended nationwide if early results continue to show improvements, the education minister has said. The department has been tracking attendance, lateness and behaviour before and after the scheme began, using term-by-term records from the same schools. Early figures show fewer late arrivals and a rise in morning attendance compared with the previous year’s baseline. Officials said the analysis will continue through the summer term and will inform a decision in August on whether to fund a broader roll-out and which elements to standardise."},
    {"id": "2B", "type": "prepost", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Before-and-after photos fuel ‘pilot scheme’ backlash over city centre makeover", "body": "A pilot scheme to 'freshen up' a city centre has drawn criticism after residents shared dramatic before-and-after images of a street redesign. Campaigners said the makeover made the area 'unrecognisable', while the council insisted the changes were temporary. No evaluation plan or outcome measures have been published; the debate has centred on aesthetics and social media reaction. Councillors said they would 'review feedback' in due course."},
    {"id": "2C", "type": "prepost", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Before and after: how one chef transformed leftovers into a week of dinners", "body": "A refrigerator clean-out becomes a seven-day menu. Tips, recipes and a surprisingly good lentil stew."},
    {"id": "3A", "type": "case_study", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "One council’s homelessness ‘housing first’ case study prompts national expansion talks", "body": "A government task group is considering expanding a 'housing first' homelessness programme after a detailed case study of its implementation in one coastal council reported sustained reductions in rough sleeping. The council’s report documents how the programme was delivered, the staffing model, and outcomes over 18 months, including housing retention rates and use of emergency services. Officials said the case study was chosen because it captures practical barriers and real-world costs. Ministers said the findings will inform a decision next month on whether to fund similar programmes in ten additional areas."},
    {"id": "3B", "type": "case_study", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Business school ‘case study’ on Apple’s pricing strategy goes viral", "body": "A new MBA case study on Apple’s pricing strategy has become one of the most downloaded teaching materials of the year, prompting debate about profit margins and brand loyalty. The document analyses product launches and consumer reactions over a decade but does not evaluate any policy or intervention, nor does it inform an organisational rollout decision beyond classroom discussion."},
    {"id": "3C", "type": "case_study", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Film review: a gripping case study in heartbreak, but not much else", "body": "A melancholy romance that’s beautifully shot and emotionally distant."},
    {"id": "4A", "type": "expert_qual", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "Expert panel urges tougher heatwave rules for care homes; new standards due this summer", "body": "An independent expert panel has recommended mandatory heatwave standards for care homes after months of evidence sessions with clinicians, providers and families. The panel’s qualitative review draws on testimony, incident reports and site visits, arguing that current guidance is too vague and unevenly applied. It proposes concrete measures—minimum indoor temperature thresholds, staffing triggers, and compulsory cooling plans. The health department said it had commissioned the review to support an imminent policy decision and will publish new national standards by late July."},
    {"id": "4B", "type": "expert_qual", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "‘Consultation’ chaos as fans grill reality-TV panel over finale twist", "body": "A live 'fan consultation' descended into chaos as viewers shouted questions at the show’s celebrity panel, demanding answers about a controversial finale. The producers said they would 'take feedback on board', but no policy, intervention, or organisational decision framework is involved beyond entertainment programming choices."},
    {"id": "4C", "type": "expert_qual", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Ask an expert: how to clean your keyboard without breaking it", "body": "A guide to compressed air, isopropyl alcohol and the art of not losing your keys."},
    {"id": "5A", "type": "expert_secondary", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "Admin data analysis finds youth jobs programme cut reoffending; funding decision expected in September", "body": "A new analysis of administrative data suggests a youth employment programme reduced reoffending, prompting ministers to consider extending funding. Researchers linked probation records with employment and benefits data to compare outcomes for young people who participated with similar individuals in neighbouring areas. Using a difference-in-differences approach, they estimated a fall in reoffending in the year after participation. The justice department said it commissioned the study to decide whether to expand the programme nationally and will make a funding decision in September."},
    {"id": "5B", "type": "expert_secondary", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "‘Regression’ in summer weather sparks complaints as council publishes data dashboard", "body": "A council has launched a new 'administrative data' dashboard showing rainfall totals after residents complained about a 'regression' in summer weather. The dashboard includes charts and trend lines, but it is not an evaluation of a policy or programme and does not inform an imminent organisational decision beyond public communication about weather and infrastructure."},
    {"id": "5C", "type": "expert_secondary", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "On the road: the coastal town where time stands still", "body": "A weekend of sea air, second-hand bookshops and unexpectedly good pastries."},
    {"id": "6A", "type": "gut", "label": "Prototype", "expected_dec": 1.0, "expected_meth": 1.0, "title": "Mayor orders overnight e-scooter ban ‘as a precaution’ despite lack of evidence", "body": "A mayor has ordered an overnight ban on rental e-scooters in the city centre, citing public concern and 'common sense' safety worries, despite officials acknowledging that no evaluation has been conducted. The mayor said the city would act immediately and review the policy later, arguing it was better to 'err on the side of caution' than wait for studies. Transport staff confirmed there is no before-after plan, no pilot comparison, and no external analysis underpinning the decision."},
    {"id": "6B", "type": "gut", "label": "False Positive", "expected_dec": 0.0, "expected_meth": 0.0, "title": "‘Gut feeling’ diet trend returns as influencers urge followers to ignore the data", "body": "A new wave of influencers is promoting 'gut feeling' eating—urging followers to ditch tracking apps and 'stop listening to data'. The movement borrows policy-like language about 'rules' and 'compliance', but it concerns individual lifestyle choices rather than an organisational decision about implementing a policy or programme."},
    {"id": "6C", "type": "gut", "label": "Irrelevant", "expected_dec": 0.0, "expected_meth": 0.0, "title": "Street style: the return of wide-leg trousers", "body": "A new season, a new silhouette: how wide-legs made a comeback."}
]

# ── Structured Output Models ──────────────────────────────────────────

class ScoreVector(BaseModel):
    p0: float = Field(..., description="Probability of score 0")
    p05: float = Field(..., description="Probability of score 0.5")
    p1: float = Field(..., description="Probability of score 1.0")
    score: float = Field(..., description="Weighted average or most likely score")

class EvaluationSchema(BaseModel):
    decision: ScoreVector
    rct: ScoreVector
    prepost: ScoreVector
    case_study: ScoreVector
    expert_qual: ScoreVector
    expert_secondary: ScoreVector
    gut: ScoreVector

# ── Evaluation Logic ──────────────────────────────────────────────────

def call_llm(client: OpenAI, model: str, article: Dict, mode: str):
    label_tag = f"{model[-8:]}_{mode}"
    content = f"Title: {article['title']}\n\nBody: {article['body']}"
    
    # Prompt
    system = """You are a policy analyst scoring articles for experimental evidence.
For each of the 7 categories (decision, rct, prepost, case_study, expert_qual, expert_secondary, gut), provide probabilities (p0, p05, p1) and a final score.
The probabilities MUST sum to 1.0 exactly.
Output ONLY valid JSON."""

    cache_key = hashlib.md5(f"{model}_{mode}_{article['id']}".encode()).hexdigest()
    cache_file = CACHE_DIR / f"{cache_key}.json"
    
    if cache_file.exists():
        return json.loads(cache_file.read_text())

    try:
        if mode == "structured":
            resp = client.beta.chat.completions.parse(
                model=model,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": content}],
                response_format=EvaluationSchema,
                temperature=0.0,
                max_completion_tokens=500
            )
            raw = resp.choices[0].message.content
            # For .parse, the .parsed attribution is available but we might want the raw text for metrics
            parsed_data = resp.choices[0].message.parsed
            result = {
                "raw": raw,
                "parsed": parsed_data.model_dump() if parsed_data else None,
                "success": parsed_data is not None,
                "tokens": resp.usage.completion_tokens,
                "finish_reason": resp.choices[0].finish_reason
            }
        else:
            resp = client.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": content}],
                temperature=0.0,
                max_tokens=400
            )
            raw = resp.choices[0].message.content
            result = {
                "raw": raw,
                "parsed": None,
                "success": False, # Will try to parse manually below if needed
                "tokens": resp.usage.completion_tokens,
                "finish_reason": resp.choices[0].finish_reason
            }
            # Attempt manual parse for comparison
            try:
                start = raw.find("{")
                end = raw.rfind("}") + 1
                if start != -1:
                    data = json.loads(raw[start:end])
                    result["parsed"] = data
                    result["success"] = True
            except:
                pass
        
        cache_file.write_text(json.dumps(result))
        return result
    except Exception as e:
        return {"error": str(e), "success": False, "raw": "", "parsed": None}

def run_diagnostics():
    client = OpenAI()
    models = [
        ("SFT", "ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH"),
        ("DPO_Final", "ft:gpt-4.1-mini-2025-04-14:personal::DAbS3xSo"),
        ("DPO_741", "ft:gpt-4.1-mini-2025-04-14:personal::DAbS3L8b:ckpt-step-741"),
        ("DPO_1482", "ft:gpt-4.1-mini-2025-04-14:personal::DAbS3yIG:ckpt-step-1482")
    ]
    
    results = []
    
    for m_label, m_id in models:
        for mode in ["plain", "structured"]:
            print(f"Evaluating {m_label} in {mode} mode...")
            for art in ARTICLES:
                res = call_llm(client, m_id, art, mode)
                
                # Metrics
                raw_text = res.get("raw", "")
                rep_count = raw_text.count("_score")
                
                valid_psum = True
                parsed = res.get("parsed")
                if parsed and isinstance(parsed, dict):
                    for k in ["decision", "rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
                        vec = parsed.get(k)
                        if isinstance(vec, dict):
                            try:
                                p0 = float(vec.get("p0", 0))
                                p05 = float(vec.get("p05", 0))
                                p1 = float(vec.get("p1", 0))
                                if abs(p0 + p05 + p1 - 1.0) > 0.05:
                                    valid_psum = False
                            except (ValueError, TypeError):
                                valid_psum = False
                        else:
                            valid_psum = False
                else:
                    valid_psum = False
                
                # Accuracy (Decision score)
                acc = 0
                if parsed and isinstance(parsed, dict) and "decision" in parsed:
                    vec = parsed["decision"]
                    pred_dec = -1
                    if isinstance(vec, dict):
                        pred_dec = float(vec.get("score", -1))
                    elif isinstance(vec, (int, float)):
                        pred_dec = float(vec)
                    
                    if pred_dec == art["expected_dec"]:
                        acc = 1
                
                results.append({
                    "model": m_label,
                    "mode": mode,
                    "art_id": art["id"],
                    "success": res.get("success", False),
                    "valid_psum": valid_psum,
                    "repetition_count": rep_count,
                    "tokens": res.get("tokens", 0),
                    "acc": acc,
                    "finish_reason": res.get("finish_reason", "error")
                })

    # Save CSV
    csv_path = ROOT / "reports" / "dpo_diagnostics.csv"
    keys = results[0].keys()
    with open(csv_path, "w", newline="") as f:
        dict_writer = csv.DictWriter(f, keys)
        dict_writer.writeheader()
        dict_writer.writerows(results)
    print(f"✓ Saved diagnostics to {csv_path}")

    # Generate MD Summary
    md_path = ROOT / "reports" / "dpo_diagnostics.md"
    md_content = ["# DPO Model Diagnostics Report\n"]
    
    # Aggregated stats
    summary = {}
    for r in results:
        key = (r["model"], r["mode"])
        if key not in summary:
            summary[key] = {"success": 0, "valid_psum": 0, "reps": 0, "acc": 0, "count": 0}
        s = summary[key]
        s["count"] += 1
        if r["success"]: s["success"] += 1
        if r["valid_psum"]: s["valid_psum"] += 1
        if r["repetition_count"] > 20: s["reps"] += 1
        s["acc"] += r["acc"]

    md_content.append("| Model | Mode | JSON Success | Valid P-Sum | Repetition (>20) | Accuracy (Dec) |")
    md_content.append("| :--- | :--- | :--- | :--- | :--- | :--- |")
    for (m, mode), s in summary.items():
        md_content.append(f"| {m} | {mode} | {s['success']}/{s['count']} | {s['valid_psum']}/{s['count']} | {s['reps']} instances | {s['acc']}/{s['count']} |")
    
    # Recommendation
    md_content.append("\n## Recommendation\n")
    # Rule: Pick highest accuracy DPO model with 0 repetitions and 100% JSON success in structured mode.
    best_model = "SFT (Fallback)"
    best_acc = -1
    for (m, mode), s in summary.items():
        if m.startswith("DPO") and mode == "structured":
            if s["reps"] == 0 and s["success"] == s["count"]:
                if s["acc"] > best_acc:
                    best_acc = s["acc"]
                    best_model = m

    md_content.append(f"Based on the results, the recommended model is: **{best_model}**.")
    
    with open(md_path, "w") as f:
        f.write("\n".join(md_content))
    print(f"✓ Saved diagnostics summary to {md_path}")

if __name__ == "__main__":
    run_diagnostics()
