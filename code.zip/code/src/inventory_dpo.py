
import pandas as pd
import json
import os
import glob
from pathlib import Path

ROOT = Path("/Users/Mycroft/Desktop/LLM reasoning")

def get_dpo_high(row):
    # Pass logic: decision_score==1, decision_p1>=t_dec, max_method_p1>=t_meth, conf>=t_conf
    # Looking at safe_llm_judge and llm_judge_router for thresholds
    t_dec = 0.5
    t_meth = 0.5
    t_conf = 0.5 # Default heuristic
    
    if row.get('llm_dpo_decision_score') != 1:
        return False
    if row.get('llm_dpo_decision_p1', 0) < t_dec:
        return False
    
    methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    max_meth_p1 = max([row.get(f'llm_dpo_method_{m}_p1', 0) for m in methods])
    if max_meth_p1 < t_meth:
        return False
        
    return True

def main():
    query_log_path = ROOT / "outputs" / "query_log.csv"
    query_log = pd.read_csv(query_log_path)
    
    # Last 20 rounds
    last_20 = query_log.tail(20)
    
    results = []
    for _, prow in last_20.iterrows():
        round_id = int(prow['round_id'])
        dpo_csv = ROOT / "outputs" / "rounds" / f"round_{round_id}" / f"round_{round_id}_DPO_papers.csv"
        
        entry = {
            "round_id": round_id,
            "file_path": str(dpo_csv.relative_to(ROOT)) if dpo_csv.exists() else "MISSING",
            "rows": 0,
            "attempted_rows": 0,
            "valid_rows": 0,
            "dpo_high_rows": 0
        }
        
        if dpo_csv.exists():
            df = pd.read_csv(dpo_csv)
            entry["rows"] = len(df)
            if 'dpo_attempted' in df.columns:
                entry["attempted_rows"] = df['dpo_attempted'].sum()
            if 'dpo_valid' in df.columns:
                entry["valid_rows"] = df['dpo_valid'].sum()
            
            if entry["valid_rows"] > 0:
                # Filter valid rows and compute DPO-high
                valid_df = df[df['dpo_valid'] == True]
                entry["dpo_high_rows"] = sum(valid_df.apply(get_dpo_high, axis=1))
        
        results.append(entry)
    
    df_results = pd.DataFrame(results)
    
    report_path = ROOT / "reports" / "dpo_inventory.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(report_path, "w") as f:
        f.write("# DPO Inventory\n\n")
        f.write(df_results.to_markdown(index=False) + "\n\n")
        
        valid_rounds = df_results[df_results["valid_rows"] > 0]
        if not valid_rounds.empty:
            f.write("### Rounds with Valid DPO Rows\n")
            for _, row in valid_rounds.iterrows():
                f.write(f"- Round {row['round_id']}: [{row['file_path']}](../../{row['file_path']})\n")
        else:
            f.write("### Rounds with Valid DPO Rows\nNone found in the last 20 rounds.\n")
            
    print(f"Report written to {report_path}")

if __name__ == "__main__":
    main()
