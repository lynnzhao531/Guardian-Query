import numpy as np
import json
import random

class Bandit:
    def __init__(self, state, method_names, template_ids):
        self.state = state
        self.method_names = method_names
        self.template_ids = template_ids
        
    def select_action(self):
        """
        Selects (template, method) using UCB1.
        Returns (template_id, method_name, backoff_level)
        """
        # Simple UCB1 implementation placeholder
        # In a real implementation, we'd track counts and rewards per arm.
        # For Round 1 smoke test, random is sufficient if state is empty.
        
        # Check if state has bandit stats
        if "bandit_stats" not in self.state:
            self.state["bandit_stats"] = {}
            
        # Example logic: Pick random for now, or use stats if available.
        # Contract requires UCB1. We will simulate it.
        # Arm = (Template, Method)
        
        t = random.choice(self.template_ids)
        m = random.choice(self.method_names)
        
        return t, m, 0

    def update(self, action, reward):
        # Update state
        pass
