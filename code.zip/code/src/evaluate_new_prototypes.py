import os
import json
import pandas as pd
import numpy as np
import joblib
import logging
from pathlib import Path
from sklearn.base import BaseEstimator, TransformerMixin
from sentence_transformers import SentenceTransformer
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# ── Dependencies for Pickle ──────────────────────────────────────────
class DataFrameSelector(BaseEstimator, TransformerMixin):
    def __init__(self, attribute_names):
        self.attribute_names = attribute_names
    def fit(self, X, y=None): return self
    def transform(self, X): return X[self.attribute_names]

def preprocess_numeric(X):
    # Match logic from retrain_model1.py
    X_num = X.apply(pd.to_numeric, errors='coerce').astype(float)
    X_filled = X_num.fillna(-1.0)
    return X_filled.values

# ── Configuration ─────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
ROOT = Path(__file__).resolve().parent.parent
MODEL1_DIR = ROOT / "models" / "tgml"
MODEL3_PATH = ROOT / "models" / "model3" / "model3_models.joblib"
MODEL3_META = ROOT / "models" / "model3" / "model3_meta.json"
THRESHOLDS_FILE = ROOT / "project_state" / "PER_MODEL_THRESHOLDS.json"
INPUT_FILE = ROOT / "knowledge_base" / "evaluation" / "prototypes_v2.jsonl"
OUTPUT_MD = ROOT / "reports" / "prototype_v2_evaluation.md"

TARGETS = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]
METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

# ── Load Models ──────────────────────────────────────────────────────
logging.info("Loading Models...")
models1 = {}
for t in ["decision"] + [f"method_{m}" for m in METHOD_NAMES]:
    fpath = MODEL1_DIR / f"model_{t}.joblib"
    if fpath.exists():
        models1[t] = joblib.load(fpath)
    else:
        logging.warning(f"Model 1 target {t} missing at {fpath}")

with open(MODEL1_DIR / "numeric_features.json", "r") as f:
    NUMERIC_COLS_M1 = json.load(f)

models3 = joblib.load(MODEL3_PATH)
with open(MODEL3_META, "r") as f:
    meta3 = json.load(f)
    EMBEDDER_NAME = meta3["embedder"]
    NUMERIC_COLS_M3 = meta3["numeric_features"]

embedder = SentenceTransformer(EMBEDDER_NAME)

with open(THRESHOLDS_FILE, "r") as f:
    THRESHOLDS = json.load(f)

# ── Prediction Logic ──────────────────────────────────────────────────
def get_model1_preds(df):
    results = {}
    for target in ["decision"] + [f"method_{m}" for m in METHOD_NAMES]:
        if target in models1:
            model = models1[target]
            probs = model.predict_proba(df)
            classes = list(model.classes_)
            p1 = probs[:, classes.index(1)] if 1 in classes else np.zeros(len(df))
            score = model.predict(df)
        else:
            p1 = np.zeros(len(df))
            score = np.zeros(len(df))
        results[f"model1_{target}_p1"] = p1
        results[f"model1_{target}_score"] = score
    return pd.DataFrame(results)

def get_model3_preds(df):
    emb = embedder.encode(df["body"].tolist(), show_progress_bar=False)
    # Mock numeric features as -1.0 for evaluation if missing
    num_vals = np.full((len(df), len(NUMERIC_COLS_M3)), -1.0)
    X = np.hstack([emb, num_vals])
    
    results = {}
    # Model 3 targets might also be subset
    for target in ["decision"] + [f"method_{m}" for m in METHOD_NAMES]:
        if target in models3:
            model = models3[target]
            probs = model.predict_proba(X)
            classes = list(model.classes_)
            p1 = probs[:, classes.index(1)] if 1 in classes else np.zeros(len(df))
            score = model.predict(X)
        else:
            p1 = np.zeros(len(df))
            score = np.zeros(len(df))
        results[f"model3_{target}_p1"] = p1
        results[f"model3_{target}_score"] = score
    return pd.DataFrame(results)

def get_llm_preds(df):
    client = OpenAI()
    # Use SFT as the proxy for "LLM Final" 
    # In a real round, we ensemble, but for diagnostics, FT-mini is the core.
    # We use a simple prompt-based evaluation if not using structured outputs, 
    # but here let's just use the sft model ID if we can find it, 
    # or fallback to a standard gpt-4o-mini call with specific prompt.
    
    # Let's try to find the SFT model from project config or previous diagnostics
    # From test_models_on_synthetic.py: ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH
    SFT_ID = "ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH"
    
    results = []
    for _, row in df.iterrows():
        content = f"Title: {row['title']}\n\nBody: {row['body']}"
        try:
            resp = client.chat.completions.create(
                model=SFT_ID,
                messages=[
                    {"role": "system", "content": "Score 0, 0.5, or 1 for decision and the 6 methods. Output JSON: {\"decision\": score, \"method_rct\": score, ...}"},
                    {"role": "user", "content": content}
                ],
                temperature=0.0,
                response_format={"type": "json_object"}
            )
            data = json.loads(resp.choices[0].message.content)
            res = {}
            for t in TARGETS:
                val = data.get(t, 0)
                res[f"llm_final_{t}_score"] = val
                res[f"llm_final_{t}_p1"] = 1.0 if val == 1.0 else (0.5 if val == 0.5 else 0.0)
            results.append(res)
        except:
            results.append({f"llm_final_{t}_score": 0 for t in TARGETS} | {f"llm_final_{t}_p1": 0 for t in TARGETS})
            
    return pd.DataFrame(results)

# ── Main ─────────────────────────────────────────────────────────────
def main():
    logging.info(f"Loading data from {INPUT_FILE}")
    articles = []
    with open(INPUT_FILE, "r") as f:
        for line in f:
            articles.append(json.loads(line))
    df = pd.DataFrame(articles)
    df["text"] = df["body"] # for model1 selector
    
    # Add dummy numeric cols for Model 1 if they exist in NUMERIC_COLS_M1
    for c in NUMERIC_COLS_M1:
        df[c] = -1.0

    logging.info("Predicting Model 1...")
    p1 = get_model1_preds(df)
    
    logging.info("Predicting Model 3...")
    p3 = get_model3_preds(df)
    
    logging.info("Predicting LLM...")
    pl = get_llm_preds(df)
    
    full_df = pd.concat([df, p1, p3, pl], axis=1)
    
    # ── Consensus & Pass Logic ────────────────────────────────────────
    def check_pass(row, prefix):
        # decision score == 1
        if row.get(f"{prefix}_decision_score", 0) != 1: return False
        
        t = THRESHOLDS.get(prefix if prefix != "llm_sft" else "llm_final", {})
        if not t: return False
        
        # p1 checks
        if row.get(f"{prefix}_decision_p1", 0) < t.get("t_dec", 0.5): return False
        
        max_meth = max(row.get(f"{prefix}_method_{m}_p1", 0) for m in METHOD_NAMES)
        if max_meth < t.get("t_meth", 0.5): return False
        
        return True

    full_df["pass_m1"] = full_df.apply(lambda x: check_pass(x, "model1"), axis=1)
    full_df["pass_m3"] = full_df.apply(lambda x: check_pass(x, "model3"), axis=1)
    full_df["pass_llm"] = full_df.apply(lambda x: check_pass(x, "llm_final"), axis=1)
    full_df["CONSENSUS"] = full_df["pass_m1"] & full_df["pass_m3"] & full_df["pass_llm"]
    
    # ── Report ───────────────────────────────────────────────────────
    report = ["# Prototype V2 Evaluation Report\n"]
    report.append(f"Evaluated 12 exemplars (6 Positives, 6 False Positives).\n")
    
    # Positives
    pos_df = full_df[full_df["expected_dec"] == 1]
    report.append("## 1. True Positives (Expect CONSENSUS=True)\n")
    summary_cols = ["id", "topic", "pass_m1", "pass_m3", "pass_llm", "CONSENSUS"]
    report.append(pos_df[summary_cols].to_markdown(index=False) + "\n")
    
    # Negatives
    neg_df = full_df[full_df["expected_dec"] == 0]
    report.append("## 2. False Positives (Expect CONSENSUS=False)\n")
    report.append(neg_df[summary_cols].to_markdown(index=False) + "\n")
    
    report.append("## 3. Decision P1 Comparison\n")
    p1_cols = ["id", "expected_dec", "model1_decision_p1", "model3_decision_p1", "llm_final_decision_p1"]
    report.append(full_df[p1_cols].to_markdown(index=False) + "\n")

    report.append("## 4. Max Method P1 Comparison\n")
    max_meth_rows = []
    for _, row in full_df.iterrows():
        max_meth_rows.append({
            "id": row["id"],
            "target": row["expected_dec"],
            "m1_max": max(row[f"model1_method_{m}_p1"] for m in METHOD_NAMES),
            "m3_max": max(row[f"model3_method_{m}_p1"] for m in METHOD_NAMES),
            "llm_max": max(row[f"llm_final_method_{m}_p1"] for m in METHOD_NAMES)
        })
    report.append(pd.DataFrame(max_meth_rows).to_markdown(index=False) + "\n")

    with open(OUTPUT_MD, "w") as f:
        f.write("\n".join(report))
        
    logging.info(f"Done. Report saved to {OUTPUT_MD}")

if __name__ == "__main__":
    main()
