#!/usr/bin/env python3
"""
run_all.py — One-command pipeline runner.

Usage:
    python src/run_all.py --max_budget 50

Runs Steps 0 → 10 sequentially, checking budget at each stage.
Steps that require waiting (fine-tuning) will block until complete.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

STEPS = [
    ("Step 0: Setup",                    "src/00_setup_project.py",               False),
    ("Step 1: Data Audit",               "src/01_load_and_audit_data.py",         False),
    ("Step 2: Long Training View",       "src/02_build_long_training_view.py",    False),
    ("Step 3: TGML Baseline",            "src/03_train_tgml_baseline.py",         False),
    ("Step 4: Preference Data",          "src/04_make_preference_data.py",        False),
    ("Step 5: Knowledge Synthesis",      "src/05_stage1_knowledge_synthesis.py",  True),
    ("Step 6: SFT Fine-tuning",          "src/06_stage2_finetune_sft.py",         True),
    ("Step 8a: Monitor SFT",             "src/08_monitor_finetune.py",            True),
    ("Step 7: DPO Fine-tuning",          "src/07_stage2_finetune_dpo.py",         True),
    ("Step 8b: Monitor DPO",             "src/08_monitor_finetune.py",            True),
    ("Step 9: Evaluate Models",          "src/09_evaluate_models.py",             True),
    ("Step 10: Query Spaces",            "src/10_extract_query_spaces.py",        True),
]


def check_budget() -> tuple[float, float]:
    """Return (spent, remaining)."""
    try:
        with open(ROOT / "project_state" / "COST_LEDGER.json") as f:
            ledger = json.load(f)
        return ledger["total_spent_usd"], ledger["remaining_budget_usd"]
    except Exception:
        return 0.0, 50.0


def run_step(name: str, script: str, requires_api: bool, max_budget: float) -> bool:
    """Run a single step. Returns True if succeeded."""
    spent, remaining = check_budget()
    print(f"\n{'='*60}")
    print(f"  {name}")
    print(f"  Budget: ${spent:.2f} spent / ${remaining:.2f} remaining")
    print(f"{'='*60}")

    if requires_api and remaining < 0.50:
        print(f"  ⚠ Budget too low for API step ({name}), skipping.")
        return False

    script_path = ROOT / script
    if not script_path.exists():
        print(f"  ⚠ Script not found: {script_path}")
        return False

    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(ROOT),
        env={**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")},
    )

    if result.returncode != 0:
        print(f"\n  ✗ {name} FAILED (exit code {result.returncode})")
        return False

    return True


def main():
    parser = argparse.ArgumentParser(description="Run the full SSRN-TGML pipeline")
    parser.add_argument("--max_budget", type=float, default=50.0)
    parser.add_argument("--start_step", type=int, default=0,
                        help="Step index to start from (0-indexed)")
    parser.add_argument("--dry_run", action="store_true",
                        help="List steps without running")
    args = parser.parse_args()

    print("="*60)
    print("  SSRN-TGML PIPELINE")
    print(f"  Budget cap: ${args.max_budget:.2f}")
    print("="*60)

    if args.dry_run:
        for i, (name, script, api) in enumerate(STEPS):
            api_tag = " [API]" if api else ""
            print(f"  {i:2d}. {name}{api_tag}  →  {script}")
        return

    for i, (name, script, api) in enumerate(STEPS):
        if i < args.start_step:
            print(f"  Skipping: {name}")
            continue

        success = run_step(name, script, api, args.max_budget)
        if not success:
            print(f"\n⚠ Pipeline stopped at: {name}")
            print(f"  Resume with: python src/run_all.py --start_step {i}")
            break

    # Final summary
    spent, remaining = check_budget()
    print(f"\n{'='*60}")
    print(f"  PIPELINE COMPLETE")
    print(f"  Total spent: ${spent:.2f}")
    print(f"  Remaining: ${remaining:.2f}")
    print(f"{'='*60}")

    # List all artifacts
    print("\n  Artifacts:")
    for d in ["models/tgml", "data/processed", "fine_tune_data",
              "knowledge_base", "reports", "audits", "project_state"]:
        dp = ROOT / d
        if dp.exists():
            files = list(dp.rglob("*"))
            files = [f for f in files if f.is_file()]
            print(f"  {d}/: {len(files)} files")


if __name__ == "__main__":
    main()
