"""
src/validate_round_outputs.py  —  STRICT validator for 5-CSV round output rule.

Checks:
  1. All 5 required CSVs exist in the round directory.
  2. Each CSV contains the 6 REQUIRED_METADATA columns.
  3. Each CSV contains the model-specific score columns if applicable.
  4. Consensus CSV contains agreement metrics.

Exit codes:
  0   — All checks PASSED.
  10  — VALIDATION FAILURE (contract violation).
"""

import argparse
import csv
import sys
from pathlib import Path
from typing import List, Dict

PROJECT_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_METADATA = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text"
]

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

def _get_model_score_cols(prefix: str) -> List[str]:
    cols = [f"{prefix}_decision_score", f"{prefix}_decision_p1"]
    for m in METHOD_NAMES:
        cols.append(f"{prefix}_method_{m}_score")
        cols.append(f"{prefix}_method_{m}_p1")
    return cols

REQUIRED_CONSENSUS_COLS = [
    "predicted_method", "confidence_score", "margin", "agreement_count",
    "avg_decision_p1", "top3_avg_method_mean"
] + [f"avg_method_p1_{m}" for m in METHOD_NAMES]

def validate_round(round_id: int, rounds_dir: Path, strict: bool = True) -> bool:
    round_dir = rounds_dir / f"round_{round_id}"
    if not round_dir.exists():
        print(f"ERROR: Round directory not found: {round_dir}")
        sys.exit(10)

    # 1. Check file existence
    expected_files = {
        "model1": f"round_{round_id}_model1_papers.csv",
        "model3": f"round_{round_id}_model3_papers.csv",
        "sft": f"round_{round_id}_SFT_papers.csv",
        "dpo": f"round_{round_id}_DPO_papers.csv",
        "consensus": f"round_{round_id}_high_relevant_papers.csv",
    }

    missing = []
    for key, fname in expected_files.items():
        if not (round_dir / fname).exists():
            missing.append(fname)
    
    if missing:
        print(f"ERROR [Round {round_id}]: Missing required CSVs: {missing}")
        if strict:
            sys.exit(10)
        return False

    # 2. Check schemas
    failures = []
    
    # Generic check for all 5
    for key, fname in expected_files.items():
        path = round_dir / fname
        try:
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                header = reader.fieldnames or []
                
                # Check metadata
                for col in REQUIRED_METADATA:
                    if col not in header:
                        failures.append(f"{fname}: Missing meta-column '{col}'")
                
                # Check specific columns
                if key == "model1":
                    for col in _get_model_score_cols("model1"):
                        if col not in header:
                            failures.append(f"{fname}: Missing score-column '{col}'")
                elif key == "model3":
                    for col in _get_model_score_cols("model3"):
                        if col not in header:
                            failures.append(f"{fname}: Missing score-column '{col}'")
                elif key == "sft":
                    # SFT slot might be labelled 'llm_sft' or 'llm_final' or 'llm_dpo' in data but file is SFT_papers
                    pass 
                elif key == "dpo":
                    # DPO file might have 'llm_dpo' or 'llm_final'
                    pass
                elif key == "consensus":
                    for col in REQUIRED_CONSENSUS_COLS:
                        if col not in header:
                            failures.append(f"{fname}: Missing consensus-column '{col}'")
        except Exception as e:
            failures.append(f"{fname}: Could not read or parse: {e}")

    if failures:
        print(f"ERROR [Round {round_id}]: Schema violations detected:")
        for f in failures:
            print(f"  - {f}")
        if strict:
            sys.exit(10)
        return False

    print(f"OK: Round {round_id} outputs validated (required 5 CSVs found, schemas correct). Extras ignored.")
    return True

def main():
    parser = argparse.ArgumentParser(description="Strict Round Output Validator")
    parser.add_argument("--round_id", type=int, required=True)
    parser.add_argument("--rounds_dir", type=str, default="outputs/rounds")
    parser.add_argument("--strict", action="store_true", default=True)
    args = parser.parse_args()

    validate_round(args.round_id, Path(args.rounds_dir), args.strict)

if __name__ == "__main__":
    main()
