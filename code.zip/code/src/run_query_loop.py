
# src/run_query_loop.py

import argparse
import sys
import os
import pandas as pd
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.config_loader import get_config
from src.framework_hashes_check import check_immutable_hashes
from src.round_runner import run_round
import pytest
import numpy as np
from sklearn.linear_model import LogisticRegression

# HARDCODED CLASS TO FIX PICKLE LOADING
class OrdinalClassifier:
    """Frank & Hall: K-1 binary classifiers for ordinal targets."""

    def __init__(self, classes=None, **lr_kwargs):
        self.classes = np.array(classes or [0.0, 0.5, 1.0])
        self.lr_kwargs = lr_kwargs
        self.clfs = []

    def fit(self, X, y):
        self.clfs = []
        for k in range(len(self.classes) - 1):
            y_bin = (np.asarray(y, dtype=float) > self.classes[k]).astype(int)
            clf = LogisticRegression(**self.lr_kwargs)
            if len(np.unique(y_bin)) > 1:
                clf.fit(X, y_bin)
            else:
                clf = None
            self.clfs.append(clf)
        return self

    def predict_proba(self, X):
        n = X.shape[0]
        cps = []
        for clf in self.clfs:
            if clf is not None:
                cps.append(clf.predict_proba(X)[:, 1])
            else:
                cps.append(np.zeros(n))
        probs = np.zeros((n, len(self.classes)))
        probs[:, 0] = 1.0 - cps[0]
        for k in range(1, len(self.classes) - 1):
            probs[:, k] = cps[k - 1] - cps[k]
        probs[:, -1] = cps[-1]
        probs = np.clip(probs, 0, 1)
        rs = probs.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        return probs / rs

    def predict(self, X):
        return self.classes[np.argmax(self.predict_proba(X), axis=1)]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max_rounds", type=int, default=120)
    parser.add_argument("--budget_usd", type=float, default=60.0)
    parser.add_argument("--resume", action="store_true", default=True)
    parser.add_argument("--dry_run", action="store_true")
    
    args = parser.parse_args()
    
    # 1. Config Load & Audit
    cfg = get_config()
    
    # 2. Hash Check
    if check_immutable_hashes():
        # Contract changed!
        print("CRITICAL: CONTRACT.json has changed since last run.")
        pass
        
    # 3. Run Tests
    print("Running pre-flight tests...")
    # Skip test_recompute if no output exists yet (handled in test)
    retcode = pytest.main(["-q", "tests"])
    if retcode != 0:
        print("Tests failed! Stopping.")
        sys.exit(1)
        
    if args.dry_run:
        print("Starting DRY RUN (1 round)...")
        run_round(1, dry_run=True)
        print("Dry run complete.")
        return

    # Real Loop
    print(f"Starting loop max_rounds={args.max_rounds} budget=${args.budget_usd}")
    
    start_round = 1
    log_path = Path("outputs/query_log.csv")
    if args.resume and log_path.exists():
        try:
            df = pd.read_csv(log_path)
            if not df.empty:
                start_round = int(df["round_id"].max()) + 1
                print(f"Resuming from Round {start_round}")
        except Exception as e:
            print(f"Error reading query log for resume: {e}")
            
    current_round = start_round
    while current_round <= args.max_rounds:
        print(f"=== ROUND {current_round} ===")
        run_round(current_round, dry_run=False)
        current_round += 1
        
    print("Loop complete.")

if __name__ == "__main__":
    main()
