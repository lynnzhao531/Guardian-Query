import argparse
import pandas as pd
import numpy as np
from pathlib import Path
import logging

def audit_round(round_id, outputs_dir_str):
    outputs_dir = Path(outputs_dir_str)
    round_dir = outputs_dir / f"round_{round_id}"
    
    if not round_dir.exists():
        print(f"Round {round_id} directory not found at {round_dir}")
        return

    # Files to audit
    files = {
        "model1": round_dir / f"round_{round_id}_model1_papers.csv",
        "model3": round_dir / f"round_{round_id}_model3_papers.csv",
        "llm_sft": round_dir / f"round_{round_id}_SFT_papers.csv",
        "llm_dpo": round_dir / f"round_{round_id}_DPO_papers.csv"
    }

    warnings = []
    summary_stats = []
    top_rows_info = []

    for model, fpath in files.items():
        if not fpath.exists():
            print(f"Skipping {model}: {fpath.name} not found.")
            continue
            
        try:
            df = pd.read_csv(fpath)
            if df.empty:
                print(f"Skipping {model}: Empty file.")
                continue
                
            # Detect Method P1 Columns
            # Pattern: matches "*_method_*_p1"
            # BUT: model1 columns are like "model1_method_rct_p1".
            # llm_sft columns are like "llm_sft_method_rct_p1".
            # We filter cols ending in "_p1" and containing "method".
            # And also filter "decision_p1" out.
            
            p1_cols = [c for c in df.columns if "_p1" in c and "method" in c]
            
            if not p1_cols:
                warnings.append(f"Model {model}: No method_p1 columns found.")
                continue

            # Check Degeneracy
            all_degenerate = True
            
            for col in p1_cols:
                vals = df[col].dropna()
                if vals.empty:
                    unique_count = 0
                    mean = 0.0
                    std = 0.0
                else:
                    unique_count = vals.nunique()
                    mean = vals.mean()
                    std = vals.std()
                    if np.isnan(std): std = 0.0
                
                summary_stats.append({
                    "model": model,
                    "column": col,
                    "min": vals.min() if not vals.empty else 0,
                    "max": vals.max() if not vals.empty else 0,
                    "mean": mean,
                    "std": std,
                    "unique": unique_count
                })
                
                # Degeneracy Condition: std < 1e-6 OR (unique <= 2 AND mean approx 0.5)
                is_degenerate = (std < 1e-6) or (unique_count <= 2 and 0.49 < mean < 0.51)
                if not is_degenerate:
                    all_degenerate = False
            
            if all_degenerate:
                warnings.append(f"WARNING: Model {model} has DEGENERATE method scores (all constant or default 0.5).")
            
            # Special Check for DPO
            if model == "llm_dpo":
                # Compute per-row max stats
                row_maxs = df[p1_cols].max(axis=1)
                median_max = row_maxs.median()
                std_max = row_maxs.std()
                if 0.49 < median_max < 0.51 and std_max < 1e-6:
                     warnings.append(f"WARNING: LLM DPO Max Method P1 is exactly 0.5 (median) with 0 variance. DPO failure?")

            # Compute Max Method P1 per row
            df["max_method_p1"] = df[p1_cols].max(axis=1)
            # Identify which method was max
            df["top_method_name"] = df[p1_cols].idxmax(axis=1)

            # Summarize High Scores
            total = len(df)
            pct_70 = (df["max_method_p1"] >= 0.70).mean()
            pct_80 = (df["max_method_p1"] >= 0.80).mean()
            pct_90 = (df["max_method_p1"] >= 0.90).mean()
            
            summary_stats.append({
                "model": model,
                "column": "AGG_ROW_MAX",
                "min": df["max_method_p1"].min(),
                "max": df["max_method_p1"].max(),
                "mean": df["max_method_p1"].mean(),
                "std": df["max_method_p1"].std(),
                "unique": df["max_method_p1"].nunique(),
                "pct_ge_70": pct_70,
                "pct_ge_80": pct_80,
                "pct_ge_90": pct_90
            })
            
            # Top 20 Rows
            # Needed columns: title, url, decision_score, decision_p1, max_method_p1, top_method_name, method_p1 vector
            
            # Normalize column names for "decision_score" etc.
            # model1_decision_score vs just decision_score?
            # In round_{id}_model1_papers.csv, usually columns are prefixed?
            # Or simplified?
            # Looking at previous audits, they have prefixes.
            # But let's look for likely candidates.
            
            dec_col = next((c for c in df.columns if "decision_score" in c), "N/A")
            dec_p1_col = next((c for c in df.columns if "decision_p1" in c), "N/A")
            
            top_rows = df.nlargest(20, "max_method_p1")
            for _, row in top_rows.iterrows():
                # Form vector string
                vec = {c.replace(f"{model}_method_", "").replace("_p1", ""): round(row[c], 3) for c in p1_cols}
                
                top_rows_info.append({
                    "model": model,
                    "title": str(row.get("title", ""))[:30],
                    "url": row.get("url", ""),
                    "decision_score": row.get(dec_col, "N/A"),
                    "decision_p1": round(row.get(dec_p1_col, 0), 3) if dec_p1_col != "N/A" else "N/A",
                    "max_method_p1": round(row["max_method_p1"], 3),
                    "top_method": str(row["top_method_name"]).replace(f"{model}_method_", "").replace("_p1", ""),
                    "vector": str(vec)
                })

        except Exception as e:
            print(f"Error processing {model}: {e}")
            warnings.append(f"Error processing {model}: {e}")

    # Output CSV
    out_dir = Path("reports")
    out_dir.mkdir(exist_ok=True)
    csv_path = out_dir / f"method_p1_sanity_round_{round_id}.csv"
    pd.DataFrame(summary_stats).to_csv(csv_path, index=False)
    print(f"Saved stats to {csv_path}")

    # Output Markdown
    audit_dir = Path("audits")
    audit_dir.mkdir(exist_ok=True)
    md_path = audit_dir / f"method_p1_sanity_round_{round_id}.md"
    
    with open(md_path, "w") as f:
        f.write(f"# Method P1 Sanity Check - Round {round_id}\n\n")
        f.write(f"## Warnings\n")
        if warnings:
            for w in warnings:
                f.write(f"- {w}\n")
        else:
            f.write("- No warnings.\n")
            
        f.write("\n## Summary Stats (Max P1)\n")
        agg = [s for s in summary_stats if s["column"] == "AGG_ROW_MAX"]
        if agg:
            f.write(pd.DataFrame(agg)[["model", "mean", "max", "pct_ge_70", "pct_ge_80"]].to_markdown(index=False))
        
        f.write("\n\n## Top 20 Rows by Max Method P1\n")
        if top_rows_info:
             f.write(pd.DataFrame(top_rows_info).to_markdown(index=False))
        else:
             f.write("No rows found.")
             
    print(f"Saved audit to {md_path}")
    return md_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--round_id", type=int, default=12)
    parser.add_argument("--outputs_dir", type=str, default="outputs/rounds")
    args = parser.parse_args()
    
    audit_round(args.round_id, args.outputs_dir)
