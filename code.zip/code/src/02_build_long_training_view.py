#!/usr/bin/env python3
"""
Step 2: Build the "long view" training table.
Each row = (article, method_type) where method_score IS observed.
Produces data/processed/training_long.parquet + audit.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "project_state" / "CONFIG.yaml") as f:
        return yaml.safe_load(f)


def load_state():
    with open(ROOT / "project_state" / "STATE.json") as f:
        return json.load(f)


def save_state(state):
    with open(ROOT / "project_state" / "STATE.json", "w") as f:
        json.dump(state, f, indent=2)


# ── keyword sentence extraction ──────────────────────────────────────

def _extract_keyword_sentences(text: str, seed_terms: list[str], max_sents: int) -> str:
    """Pick up to `max_sents` sentences containing any seed term."""
    if not text:
        return ""
    sents = re.split(r'(?<=[.!?])\s+', text)
    pattern = re.compile(
        "|".join(re.escape(t) for t in seed_terms), re.IGNORECASE
    )
    hits = [s for s in sents if pattern.search(s)]
    return " ".join(hits[:max_sents])


def build_text_for_model(row, cfg) -> str:
    """Combine title + body excerpt + keyword sentences, respecting max_chars."""
    tcfg = cfg["text_for_model"]
    max_chars = tcfg["max_chars"]
    seed_terms = tcfg["seed_terms"]
    max_sents = tcfg["keyword_sentences_max"]

    title = str(row.get("title", "")) if pd.notna(row.get("title")) else ""
    body = str(row.get("body", "")) if pd.notna(row.get("body")) else ""

    # Start with title
    parts = [title]

    # Add first portion of body
    body_budget = max_chars - len(title) - 200  # reserve 200 for keyword sents
    if body and body_budget > 0:
        parts.append(body[:body_budget])

    # Add keyword sentences from remainder of body
    if body and len(body) > body_budget:
        remainder = body[body_budget:]
        kw_sents = _extract_keyword_sentences(remainder, seed_terms, max_sents)
        if kw_sents:
            parts.append("[key excerpts] " + kw_sents)

    text = "\n\n".join(p for p in parts if p)
    return text[:max_chars]


# ── main ──────────────────────────────────────────────────────────────

def main():
    cfg = load_config()
    state = load_state()

    data_path = ROOT / cfg["data"]["merged_dataset"]
    df = pd.read_parquet(data_path)
    print(f"Loaded: {len(df)} rows from {data_path}")

    article_id_col = cfg["data"]["article_id_column"]
    decision_col = cfg["data"]["decision_column"]
    method_cols = cfg["data"]["method_columns"]  # {key: colname}

    # ── Build long view ───────────────────────────────────────────────
    slices = []
    for method_key, method_colname in method_cols.items():
        if method_colname not in df.columns:
            print(f"  ⚠ Column {method_colname} not found, skipping {method_key}")
            continue
        mask = df[method_colname].notna()
        sub = df[mask].copy()
        if len(sub) == 0:
            print(f"  {method_key}: 0 rows (all NA)")
            continue

        sub_long = pd.DataFrame({
            "article_id": sub[article_id_col].values,
            "method_type": method_key,
            "method_score": sub[method_colname].values,
            "decision_score": sub[decision_col].values,
            "title": sub["title"].values,
            "body": sub["body"].values,
            "source_method_label_column": method_colname,
        })
        slices.append(sub_long)
        print(f"  {method_key}: {len(sub_long)} rows")

    df_long = pd.concat(slices, ignore_index=True)
    print(f"\nConcatenated long view: {len(df_long)} rows")

    # ── Build text_for_model ──────────────────────────────────────────
    print("Building text_for_model (this may take a moment)...")
    df_long["text_for_model"] = df_long.apply(
        lambda row: build_text_for_model(row, cfg), axis=1
    )
    avg_len = df_long["text_for_model"].str.len().mean()
    print(f"  Average text_for_model length: {avg_len:.0f} chars")

    # ── Validate ──────────────────────────────────────────────────────
    assert df_long["method_score"].isna().sum() == 0, "method_score has NaN in long view!"
    allowed = set(cfg["data"]["allowed_scores"])
    bad = df_long[~df_long["method_score"].isin(allowed)]
    assert len(bad) == 0, f"Invalid method_score values: {bad['method_score'].unique()}"

    # ── Save ──────────────────────────────────────────────────────────
    out_dir = ROOT / "data" / "processed"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "training_long.parquet"
    df_long.to_parquet(out_path, index=False)
    print(f"✓ Saved to {out_path}")

    # ── Audit report ──────────────────────────────────────────────────
    audit_dir = ROOT / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)
    lines = ["# Training Long View Audit\n"]
    lines.append(f"**Total rows**: {len(df_long):,}")
    lines.append(f"**Unique articles**: {df_long['article_id'].nunique():,}")
    lines.append(f"**Missing method_score**: {int(df_long['method_score'].isna().sum())}")
    lines.append(f"**Average text_for_model length**: {avg_len:.0f} chars\n")

    lines.append("## Counts per method_type\n")
    lines.append("| method_type | count |")
    lines.append("|-------------|-------|")
    for mt, cnt in df_long["method_type"].value_counts().sort_index().items():
        lines.append(f"| {mt} | {cnt} |")

    lines.append("\n## Method score distribution by method_type\n")
    for mt in sorted(df_long["method_type"].unique()):
        sub = df_long[df_long["method_type"] == mt]
        vc = sub["method_score"].value_counts().sort_index()
        lines.append(f"### {mt}")
        lines.append("| Score | Count |")
        lines.append("|-------|-------|")
        for sc, cnt in vc.items():
            lines.append(f"| {sc} | {cnt} |")
        lines.append("")

    lines.append("## Decision score distribution (overall)\n")
    lines.append("| Score | Count |")
    lines.append("|-------|-------|")
    dec_vc = df_long["decision_score"].value_counts(dropna=False).sort_index()
    for sc, cnt in dec_vc.items():
        lines.append(f"| {sc} | {cnt} |")

    lines.append("\n## Articles appearing in multiple method types\n")
    per_article = df_long.groupby("article_id")["method_type"].nunique()
    multi = per_article[per_article > 1]
    lines.append(f"Articles with >1 method type: {len(multi)}")

    (audit_dir / "training_long_audit.md").write_text("\n".join(lines))
    print(f"✓ Audit written to {audit_dir / 'training_long_audit.md'}")

    # ── Update state ──────────────────────────────────────────────────
    state["training_long_path"] = str(out_path)
    if "step_2_long_view" not in state["steps_completed"]:
        state["steps_completed"].append("step_2_long_view")
    state["current_step"] = "step_2_complete"
    save_state(state)

    print(f"\n{'='*60}")
    print(f"  LONG VIEW COMPLETE: {len(df_long):,} rows")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
