import json
import tiktoken
from collections import Counter
from pathlib import Path
from validate_nested_schema import validate_nested_schema

BASE_DIR = Path(__file__).resolve().parent.parent

def load_jsonl(path):
    lines = []
    if path.exists():
        with open(path, "r") as f:
            for line in f:
                lines.append(json.loads(line))
    return lines

def estimate_tokens(text, enc):
    return len(enc.encode(text))

def get_dimension_diffs(pref_json, nonpref_json):
    """
    Returns a list of dimensions where the scores differ.
    """
    try:
        pref = json.loads(pref_json)
        non = json.loads(nonpref_json)
    except:
        return []
        
    diffs = []
    for dim in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
        if pref.get(dim, {}).get("score") != non.get(dim, {}).get("score"):
            diffs.append(dim)
    return diffs

def audit_dataset(lines, meta_lines, name, enc):
    total = len(lines)
    if total == 0:
        return None
        
    schema_valid_pref = 0
    schema_valid_non = 0
    identical_pairs = 0
    
    flip_logic_passed = 0
    flip_errors = []
    
    total_prompt_chars = 0
    total_tokens = 0
    
    label_counts = {
        "decision": Counter(), "method_rct": Counter(), "method_prepost": Counter(), 
        "method_case_study": Counter(), "method_expert_qual": Counter(), 
        "method_expert_secondary": Counter(), "method_gut": Counter()
    }
    
    for i, row in enumerate(lines):
        pref = row["preferred_output"][0]["content"]
        non_pref = row["non_preferred_output"][0]["content"]
        
        # Schema checks
        if not validate_nested_schema(pref): schema_valid_pref += 1
        if not validate_nested_schema(non_pref): schema_valid_non += 1
        
        if pref == non_pref: identical_pairs += 1
        
        # Flip logic check
        meta = meta_lines[i] if i < len(meta_lines) else {"pair_kind": "unknown"}
        diffs = get_dimension_diffs(pref, non_pref)
        
        if meta.get("pair_kind") == "hard":
            if len(diffs) == 1:
                flip_logic_passed += 1
            else:
                flip_errors.append(f"Hard neg row {i}: expected 1 diff, got {len(diffs)} ({diffs})")
        elif meta.get("pair_kind") == "easy":
            if len(diffs) >= 2:
                flip_logic_passed += 1
            else:
                flip_errors.append(f"Easy neg row {i}: expected >=2 diffs, got {len(diffs)} ({diffs})")
        else:
            flip_logic_passed += 1 # ignore if unknown
        
        prompt = row["input"]["messages"][1]["content"]
        total_prompt_chars += len(prompt)
        total_tokens += estimate_tokens(prompt + pref + non_pref, enc)
        
        # Histograms
        try:
            p_data = json.loads(pref)
            for k in label_counts.keys():
                label_counts[k][p_data.get(k, {}).get("score", 0)] += 1
        except:
            pass
            
    return {
        "name": name,
        "total": total,
        "schema_valid_pref": schema_valid_pref,
        "schema_valid_non": schema_valid_non,
        "identical_pairs": identical_pairs,
        "flip_logic_passed": flip_logic_passed,
        "flip_errors": flip_errors,
        "avg_prompt_chars": total_prompt_chars / total,
        "avg_tokens": total_tokens / total,
        "label_counts": label_counts
    }

def main():
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    train_path = BASE_DIR / "fine_tune_data" / "dpo_train_v2.jsonl"
    train_meta_path = BASE_DIR / "fine_tune_data" / "dpo_train_v2.meta.jsonl"
    val_path = BASE_DIR / "fine_tune_data" / "dpo_val_v2.jsonl"
    
    # Val doesn't have a direct meta sidecar in the current script output, so we just use empty dicts to skip flip checks for val or recreate it perfectly.
    # Actually, the previous step did create a shared pool then split. Let's see if we have val meta.
    # No, we didn't write val_meta separately in the earlier script by accident, we just split it. Let's check. 
    # Ah, I see: there is no val_meta in the previous step. It wasn't requested explicitly.
    # We will ignore flip checks for val if meta is missing, but check train deeply.
    
    train_lines = load_jsonl(train_path)
    train_meta = load_jsonl(train_meta_path)
    val_lines = load_jsonl(val_path)
    
    train_stats = audit_dataset(train_lines, train_meta, "Train", enc)
    val_stats = audit_dataset(val_lines, [], "Validation", enc)
    
    report = ["# DPO v2 Readiness Audit Report\n"]
    passed_all = True
    
    for stats in [train_stats, val_stats]:
        if not stats: continue
        report.append(f"## {stats['name']} Set")
        report.append(f"- **Total Pairs**: {stats['total']}")
        
        pref_rate = stats['schema_valid_pref'] / stats['total']
        non_rate = stats['schema_valid_non'] / stats['total']
        report.append(f"- **Preferred Schema Valid Rate**: {pref_rate:.2%} ({stats['schema_valid_pref']}/{stats['total']})")
        report.append(f"- **Non-Preferred Schema Valid Rate**: {non_rate:.2%} ({stats['schema_valid_non']}/{stats['total']})")
        
        ident_rate = stats['identical_pairs'] / stats['total']
        report.append(f"- **Identical Pair Rate**: {ident_rate:.2%} ({stats['identical_pairs']}/{stats['total']})")
        
        flip_rate = stats['flip_logic_passed'] / stats['total'] if stats['total'] > 0 else 1.0
        # If we didn't feed it meta (i.e. val set), this will be 100% implicitly
        if len(stats['flip_errors']) > 0 or stats['name'] == 'Train':
            report.append(f"- **Single-Dimension Flip Logic Pass Rate**: {flip_rate:.2%} ({stats['flip_logic_passed']}/{stats['total']})")
            
        report.append(f"- **Avg Prompt Length (chars)**: {stats['avg_prompt_chars']:.0f}")
        report.append(f"- **Avg Tokens per Pair**: {stats['avg_tokens']:.0f}")
        
        report.append("\n### Label Histograms (Preferred Output)")
        for k, counts in stats['label_counts'].items():
            report.append(f"- **{k}**: " + ", ".join([f"{sc}: {counts[sc]}" for sc in sorted(counts.keys())]))
        report.append("")
        
        if pref_rate < 1.0 or non_rate < 1.0 or ident_rate > 0.0 or flip_rate < 1.0:
            passed_all = False
            if stats['flip_errors']:
                report.append(f"### Flip Errors (first 5)")
                for e in stats['flip_errors'][:5]:
                    report.append(f"- {e}")
            
    out_dir = BASE_DIR / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "dpo_v2_readiness_audit.md"
    
    with open(out_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Audit Complete. Wrote {out_path}.")
    if not passed_all:
        print("AUDIT FAILED! See report for details.")
        exit(1)
    else:
        print("AUDIT PASSED 100%. Ready for retrain.")

if __name__ == "__main__":
    main()
