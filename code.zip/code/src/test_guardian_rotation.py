import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
import requests
import json

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from config_env import load_guardian_keys, get_guardian_base_url
from guardian_client import GuardianClient

def test_rotation():
    print("── Testing Guardian API Rotation ──")
    
    # 1. Load keys (will use the ones verified earlier)
    try:
        keys = load_guardian_keys()
        print(f"Loaded {len(keys)} keys.")
    except Exception as e:
        print(f"Failed to load keys: {e}")
        return

    base_url = get_guardian_base_url()
    state_path = ROOT / "project_state" / "guardian_key_state.json"
    log_path = ROOT / "audits" / "guardian_api_rotation.log"
    
    # Ensure clean state for test if desired, but here we'll just use it
    client = GuardianClient(keys, base_url, state_path, log_path)
    
    # 2. Test Harmless Request (Page Size 1)
    print("\n[Test 1] Real harmless request...")
    try:
        res = client.request({"q": "policy", "page-size": 1})
        print(f"Success! Status: {res.get('response', {}).get('status')}")
        print(f"Current key index: {client.current_index}")
    except Exception as e:
        print(f"Request failed: {e}")

    # 3. Simulate Rotation (Mocked 429)
    print("\n[Test 2] Simulating 429 Rate Limit...")
    with patch("requests.get") as mock_get:
        # Mock a series of responses: 429 then 200
        mock_429 = MagicMock()
        mock_429.status_code = 429
        mock_429.text = "Too Many Requests"
        
        mock_200 = MagicMock()
        mock_200.status_code = 200
        mock_200.json.return_value = {"response": {"status": "ok"}}
        
        mock_get.side_effect = [mock_429, mock_200]
        
        initial_index = client.current_index
        try:
            res = client.request({"q": "test-rotation", "page-size": 1})
            new_index = client.current_index
            print(f"Rotation triggered! Index moved from {initial_index} to {new_index}")
            print(f"Mocked Success: {res.get('response', {}).get('status')}")
        except Exception as e:
            print(f"Rotation test failed: {e}")

    print("\n── Audit Log Check ──")
    if log_path.exists():
        last_lines = log_path.read_text().splitlines()[-3:]
        for line in last_lines:
            print(f"Audit: {line}")

if __name__ == "__main__":
    test_rotation()
