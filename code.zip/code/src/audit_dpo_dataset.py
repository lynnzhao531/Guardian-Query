import json
import random
import pandas as pd
import tiktoken
from collections import Counter
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def load_jsonl(path):
    lines = []
    if path.exists():
        with open(path, "r") as f:
            for line in f:
                lines.append(json.loads(line))
    return lines

def estimate_tokens(text, enc):
    return len(enc.encode(text))

def parse_labels(json_str):
    try:
        data = json.loads(json_str)
        return {
            "decision": data.get("decision", {}).get("score", 0),
            "rct": data.get("method_rct", {}).get("score", 0),
            "prepost": data.get("method_prepost", {}).get("score", 0),
            "case_study": data.get("method_case_study", {}).get("score", 0),
            "expert_qual": data.get("method_expert_qual", {}).get("score", 0),
            "expert_secondary": data.get("method_expert_secondary", {}).get("score", 0),
            "gut": data.get("method_gut", {}).get("score", 0),
        }
    except:
        return {}

def audit_dataset(lines, name, enc):
    total = len(lines)
    if total == 0:
        return None
        
    schema_valid = 0
    identical_pairs = 0
    
    total_prompt_chars = 0
    total_tokens = 0
    
    label_counts = {
        "decision": Counter(), "rct": Counter(), "prepost": Counter(), 
        "case_study": Counter(), "expert_qual": Counter(), 
        "expert_secondary": Counter(), "gut": Counter()
    }
    
    for row in lines:
        try:
            pref = row["preferred_output"][0]["content"]
            non_pref = row["non_preferred_output"][0]["content"]
            
            # schema check
            pref_json = json.loads(pref)
            valid = True
            for k in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
                if k not in pref_json: valid = False
            
            if valid: schema_valid += 1
            if pref == non_pref: identical_pairs += 1
            
            prompt = row["input"]["messages"][1]["content"]
            total_prompt_chars += len(prompt)
            
            # fast token estimate (just the prompt, not full template)
            total_tokens += estimate_tokens(prompt + pref + non_pref, enc)
            
            # Update histograms
            labels = parse_labels(pref)
            for k, cat in label_counts.items():
                cat[labels.get(k, 0)] += 1
                
        except Exception as e:
            print(f"Error parsing row: {e}")
            pass
            
    return {
        "name": name,
        "total": total,
        "schema_valid": schema_valid,
        "schema_valid_rate": schema_valid / total,
        "identical_pairs": identical_pairs,
        "identical_pair_rate": identical_pairs / total,
        "avg_prompt_chars": total_prompt_chars / total,
        "avg_tokens": total_tokens / total,
        "label_counts": label_counts
    }

def main():
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    
    train_path = BASE_DIR / "fine_tune_data" / "dpo_train_v2.jsonl"
    val_path = BASE_DIR / "fine_tune_data" / "dpo_val_v2.jsonl"
    
    train_lines = load_jsonl(train_path)
    val_lines = load_jsonl(val_path)
    
    all_lines = train_lines + val_lines
    
    train_stats = audit_dataset(train_lines, "Train", enc)
    val_stats = audit_dataset(val_lines, "Validation", enc)
    
    report = ["# DPO v2 Data Audit Report\n"]
    
    for stats in [train_stats, val_stats]:
        if not stats: continue
        report.append(f"## {stats['name']} Set")
        report.append(f"- **Total Pairs**: {stats['total']}")
        report.append(f"- **Schema Valid Rate**: {stats['schema_valid_rate']:.2%} ({stats['schema_valid']}/{stats['total']})")
        report.append(f"- **Identical Pair Rate**: {stats['identical_pair_rate']:.2%} ({stats['identical_pairs']}/{stats['total']})")
        report.append(f"- **Avg Prompt Length (chars)**: {stats['avg_prompt_chars']:.0f}")
        report.append(f"- **Avg Tokens per Pair**: {stats['avg_tokens']:.0f}")
        
        report.append("\n### Label Histograms (Preferred Output)")
        for k, counts in stats['label_counts'].items():
            report.append(f"- **{k}**: " + ", ".join([f"{sc}: {counts[sc]}" for sc in sorted(counts.keys())]))
        report.append("")
        
        # Stop condition checks
        if stats['schema_valid_rate'] < 1.0 or stats['identical_pair_rate'] > 0:
            print(f"AUDIT FAILED on {stats['name']} set!")

    report.append("## Random Samples (10)\n")
    if all_lines:
        samples = random.sample(all_lines, min(10, len(all_lines)))
        for i, s in enumerate(samples):
            report.append(f"### Sample {i+1}")
            prompt_snip = s["input"]["messages"][1]["content"][:300].replace("\n", " ") + "..."
            pref_snip = s["preferred_output"][0]["content"]
            non_pref_snip = s["non_preferred_output"][0]["content"]
            
            report.append(f"**Input (truncated)**: {prompt_snip}")
            report.append(f"**Preferred**: `{pref_snip}`")
            report.append(f"**Non-Preferred**: `{non_pref_snip}`\n")
            
    out_dir = BASE_DIR / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "dpo_v2_data_audit.md"
    
    with open(out_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Audit complete. Report written to {out_path}")

if __name__ == "__main__":
    main()
