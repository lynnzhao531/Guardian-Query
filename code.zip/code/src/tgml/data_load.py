"""Data loading, validation, and splitting."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from . import config as C


# ── Load ──────────────────────────────────────────────────────────────

def load_master_vector(path: str | Path) -> pd.DataFrame:
    """Load master_vector.parquet and run basic checks."""
    df = pd.read_parquet(path)
    print(f"Loaded master_vector: {df.shape[0]} rows × {df.shape[1]} cols")
    return df


def load_training_cases(path: str | Path) -> pd.DataFrame:
    """Load training_cases_clean.parquet, filter to fetch_status==ok."""
    df = pd.read_parquet(path)
    df = df[df["fetch_status"] == "ok"].copy()
    # Rename bodyText -> body for feature pipeline compatibility
    if "bodyText" in df.columns:
        df = df.rename(columns={"bodyText": "body"})
    print(f"Training cases (fetch_status=ok): {len(df)} rows")
    return df


# ── Validation ────────────────────────────────────────────────────────

def validate_labels(df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate all target label values are in {0, 0.5, 1} or NA.
    Returns DataFrame of violations (should be empty).
    """
    targets = [C.TARGET_DECISION] + C.TARGET_METHODS
    violations = []
    for t in targets:
        if t not in df.columns:
            continue
        col = pd.to_numeric(df[t], errors="coerce")
        non_null = col.dropna()
        bad = non_null[~non_null.isin(C.LABEL_VALUES)]
        if len(bad) > 0:
            for idx, val in bad.items():
                violations.append({"column": t, "row_index": idx, "value": val})
    viol_df = pd.DataFrame(violations)
    if len(viol_df) > 0:
        raise ValueError(
            f"Label violations found ({len(viol_df)} rows)! "
            "Fix data before training."
        )
    return viol_df


def print_label_distributions(df: pd.DataFrame) -> dict:
    """Print and return label distributions for all target columns."""
    targets = [C.TARGET_DECISION] + C.TARGET_METHODS
    distributions: dict = {}
    for t in targets:
        if t not in df.columns:
            continue
        nn = df[t].notna().sum()
        if nn == 0:
            distributions[t] = {"non_null": 0}
            print(f"  {t}: 0 non-null (all NA)")
            continue
        vc = df[t].dropna().value_counts().sort_index()
        dist = {str(k): int(v) for k, v in vc.items()}
        dist["non_null"] = int(nn)
        distributions[t] = dist
        print(f"  {t}: {nn} non-null → {dict(vc)}")
    return distributions


# ── Splits ────────────────────────────────────────────────────────────

def create_splits(
    df: pd.DataFrame,
    seed: int = C.RANDOM_SEED,
) -> dict[str, list[str]]:
    """
    Split by url_canon into train/val/test (70/15/15).
    Stratified on decision (using binned labels for stratification).
    Returns {train: [urls], val: [urls], test: [urls]}.
    """
    urls = df["url_canon"].values
    # Stratify on decision; fill NA with -1 for stratification purposes
    strat = df[C.TARGET_DECISION].fillna(-1).values

    train_urls, temp_urls, _, strat_temp = train_test_split(
        urls, strat,
        test_size=(C.VAL_RATIO + C.TEST_RATIO),
        random_state=seed,
        stratify=strat,
    )
    val_frac = C.VAL_RATIO / (C.VAL_RATIO + C.TEST_RATIO)
    val_urls, test_urls, _, _ = train_test_split(
        temp_urls, strat_temp,
        test_size=(1 - val_frac),
        random_state=seed,
        stratify=strat_temp,
    )

    splits = {
        "train": sorted(train_urls.tolist()),
        "val": sorted(val_urls.tolist()),
        "test": sorted(test_urls.tolist()),
    }
    print(f"  Split sizes: train={len(splits['train'])}, "
          f"val={len(splits['val'])}, test={len(splits['test'])}")
    return splits


def split_df(df: pd.DataFrame, splits: dict) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return (train_df, val_df, test_df) from url-based splits."""
    train = df[df["url_canon"].isin(set(splits["train"]))].copy()
    val = df[df["url_canon"].isin(set(splits["val"]))].copy()
    test = df[df["url_canon"].isin(set(splits["test"]))].copy()
    return train, val, test


# ── Keyword columns ──────────────────────────────────────────────────

def get_keyword_columns(df: pd.DataFrame) -> list[str]:
    """Identify boolean keyword columns (excluding targets/metadata)."""
    kw_cols = []
    for col in df.columns:
        if col in C.EXCLUDE_FROM_KEYWORDS:
            continue
        if df[col].dtype == "boolean" or df[col].dtype == "bool":
            kw_cols.append(col)
    return sorted(kw_cols)


def keyword_tristate(df: pd.DataFrame, kw_cols: list[str]) -> np.ndarray:
    """Convert keyword boolean columns to tri-state: True→1, False→0, NA→-1.
    Missing columns are treated as all-NA (-1)."""
    out = np.full((len(df), len(kw_cols)), -1.0)
    for j, col in enumerate(kw_cols):
        if col not in df.columns:
            continue  # leave as -1 (all NA)
        series = df[col]
        # True → 1
        mask_true = series.fillna(False).astype(bool)
        out[mask_true.values, j] = 1.0
        # False → 0 (only where not NA)
        not_na = series.notna()
        not_true = ~mask_true
        mask_false = not_na & not_true
        out[mask_false.values, j] = 0.0
        # NA stays -1
    return out


# ── Schema audits ────────────────────────────────────────────────────

def write_schema_audits(
    df: pd.DataFrame,
    distributions: dict,
    viol_df: pd.DataFrame,
    audit_dir: Path,
) -> None:
    """Write schema_summary.json, label_distributions.json, label_value_violations.csv."""
    audit_dir.mkdir(parents=True, exist_ok=True)

    # Schema summary
    schema = {
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "columns": list(df.columns),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "pct_missing_body": round(100 * df["body"].isna().mean(), 2),
        "pct_missing_title": round(100 * df["title"].isna().mean(), 2),
    }
    with open(audit_dir / "schema_summary.json", "w") as f:
        json.dump(schema, f, indent=2)

    # Label distributions
    with open(audit_dir / "label_distributions.json", "w") as f:
        json.dump(distributions, f, indent=2)

    # Violations
    viol_df.to_csv(audit_dir / "label_value_violations.csv", index=False)

    print(f"  ✓ Schema audits written to {audit_dir}/")
