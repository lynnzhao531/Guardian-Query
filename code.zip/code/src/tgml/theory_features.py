"""Theory-guided feature engineering: regex-based domain features."""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


# ── Pattern dictionaries ─────────────────────────────────────────────

DECISION_PATTERNS = {
    "has_org_actor": r"\b(government|council|NHS|minister|department|regulator|agency|company|firm|hospital|trust|university|school)\b",
    "has_scale_action": r"\b(roll(?:ed)?\s*out|pilot(?:ed)?|trial(?:led)?|expand(?:ed)?|extend(?:ed)?|scale[d]?\s*up|nationwide|scrap(?:ped)?|ban(?:ned)?|approv(?:ed|e)|fund(?:ed)?|mandat(?:ed|e)|introduc(?:ed|e)|implement(?:ed)?)\b",
    "has_evidence_link": r"\b(evaluation|evidence|study\s+found|analysis\s+show(?:ed|s)|results\s+show(?:ed|s)|data\s+suggest(?:ed|s)|review\s+found)\b",
    "temporal_urgency": r"\b(this\s+year|next\s+year|within\s+months|immediately|set\s+to|will\s+be)\b",
}

METHOD_PATTERNS = {
    "rct_cues": r"\b(randomi[sz]ed|randomly\s+assigned|control\s+group|placebo|trial\s+arm|cluster\s+randomi[sz]ed|double[\s-]blind|RCT)\b",
    "prepost_cues": r"\b(before\s+and\s+after|pre[\s-]+and[\s-]+post|baseline|follow[\s-]up|post[\s-]?implementation|switched\s+everyone\s+to)\b",
    "case_cues": r"\b(case\s+stud(?:y|ies)|in\s+one\s+city|in\s+one\s+hospital|one\s+council|lessons?\s+learn(?:ed|t)|pilot\s+site)\b",
    "secondary_data_cues": r"\b(administrative\s+data|observational|retrospective|registry\s+data|regression|difference[\s-]in[\s-]differences?|econometric)\b",
    "expert_qual_cues": r"\b(expert\s+panel|consultation|inquiry|review\s+by\s+experts?|commission\s+report|advisory\s+group|taskforce|task[\s-]force)\b",
    "gut_cues": r"\b(without\s+evidence|no\s+data|despite\s+lack\s+of\s+evidence|on\s+a\s+hunch|leaders?\s+believe|intuitively)\b",
}

FORMAT_PATTERNS = {
    "is_liveblog_text": r"\b(as\s+it\s+happened|live\s+blog|liveblog|rolling\s+updates?)\b",
}


# ── Featurizer ────────────────────────────────────────────────────────

class TheoryFeaturizer:
    """Compute regex-based theory features from title + body + url."""

    ALL_PATTERNS = {**DECISION_PATTERNS, **METHOD_PATTERNS, **FORMAT_PATTERNS}

    FEATURE_FAMILIES = {
        "decision": list(DECISION_PATTERNS.keys()),
        "method_rct": ["rct_cues"],
        "method_prepost": ["prepost_cues"],
        "method_case_study": ["case_cues"],
        "method_expert_secondary": ["secondary_data_cues"],
        "method_expert_qual": ["expert_qual_cues"],
        "method_gut": ["gut_cues"],
        "format": ["is_liveblog_text"],
    }

    def __init__(self):
        self._compiled = {
            name: re.compile(pat, re.IGNORECASE)
            for name, pat in self.ALL_PATTERNS.items()
        }

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Return a DataFrame with one column per theory feature (int: count of matches)."""
        text = self._get_text(df)
        url = df["url_canon"].fillna("") if "url_canon" in df.columns else pd.Series([""] * len(df))

        records = []
        for i in range(len(df)):
            row = {}
            t = text.iloc[i]
            u = url.iloc[i]

            for name, pat in self._compiled.items():
                # Count matches in text
                hits = len(pat.findall(t))
                row[f"theory__{name}"] = hits

            # URL-derived features
            row["theory__url_has_live"] = int("/live/" in u)
            row["theory__url_has_commentisfree"] = int("/commentisfree/" in u)

            records.append(row)

        return pd.DataFrame(records, index=df.index)

    def get_feature_names(self) -> list[str]:
        names = [f"theory__{n}" for n in self.ALL_PATTERNS]
        names += ["theory__url_has_live", "theory__url_has_commentisfree"]
        return names

    @staticmethod
    def _get_text(df: pd.DataFrame) -> pd.Series:
        title = df["title"].fillna("")
        body = df["body"].fillna("") if "body" in df.columns else pd.Series([""] * len(df), index=df.index)
        return title.str.cat(body, sep="\n\n")

    def compute_coverage(self, df: pd.DataFrame) -> dict:
        """Return % of rows with ≥1 hit per feature family."""
        feat_df = self.transform(df)
        coverage = {}
        for family, members in self.FEATURE_FAMILIES.items():
            cols = [f"theory__{m}" for m in members if f"theory__{m}" in feat_df.columns]
            if cols:
                has_hit = (feat_df[cols].sum(axis=1) > 0).mean()
                coverage[family] = round(float(has_hit) * 100, 2)
            else:
                coverage[family] = 0.0
        return coverage

    def write_coverage_audit(self, df: pd.DataFrame, report_dir: Path) -> None:
        coverage = self.compute_coverage(df)
        report_dir.mkdir(parents=True, exist_ok=True)
        with open(report_dir / "theory_feature_coverage.json", "w") as f:
            json.dump(coverage, f, indent=2)
        print("  Theory feature coverage (% rows with ≥1 hit):")
        for k, v in coverage.items():
            print(f"    {k}: {v}%")
