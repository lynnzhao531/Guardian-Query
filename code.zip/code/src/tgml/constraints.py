"""Hard and soft constraints for theory-guided inference."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from . import config as C


# ── Detection ─────────────────────────────────────────────────────────

def is_non_substantive(df: pd.DataFrame) -> pd.Series:
    """Return boolean mask: True for liveblog or commentisfree rows."""
    url = df["url_canon"].fillna("") if "url_canon" in df.columns else pd.Series([""] * len(df))
    title = df["title"].fillna("").str.lower()
    section = df["section"].fillna("").str.lower() if "section" in df.columns else pd.Series([""] * len(df))

    is_lb = url.str.contains("/live/", na=False) | title.str.contains("as it happened", na=False)
    is_cif = url.str.contains("/commentisfree/", na=False) | (section == "commentisfree")
    return is_lb | is_cif


# ── Hard constraint ──────────────────────────────────────────────────

def apply_hard_constraints(
    preds: dict[str, np.ndarray],
    df: pd.DataFrame,
) -> dict[str, np.ndarray]:
    """
    Force predictions to 0 for non-substantive formats.
    preds: {target_name: array of predicted labels}
    Returns modified preds dict + count of changes.
    """
    mask = is_non_substantive(df).values
    n_changed = 0
    for key in preds:
        before = preds[key].copy()
        preds[key][mask] = 0.0
        n_changed += int((before != preds[key]).sum())
    return preds, n_changed


def apply_hard_constraints_proba(
    probas: dict[str, np.ndarray],
    df: pd.DataFrame,
) -> dict[str, np.ndarray]:
    """
    Force probability of class 0 to 1.0 for non-substantive formats.
    probas: {target_name: array shape (n, 3) for ordinal classes [0, 0.5, 1]}
    """
    mask = is_non_substantive(df).values
    for key in probas:
        probas[key][mask] = [1.0, 0.0, 0.0]  # all probability on class 0
    return probas


# ── Soft constraint ──────────────────────────────────────────────────

def apply_soft_constraints(
    decision_proba: np.ndarray,
    method_probas: dict[str, np.ndarray],
    threshold: float = C.SOFT_CONSTRAINT_DECISION_THRESHOLD,
    cap_factor: float = C.SOFT_CONSTRAINT_METHOD_CAP_FACTOR,
) -> dict[str, np.ndarray]:
    """
    When P(decision==1) is very low, reduce method P(==1) to suppress
    high method scores without a strong decision link.

    decision_proba: shape (n, 3) — columns for classes [0, 0.5, 1]
    method_probas: {name: shape (n, 3)}
    """
    p_dec_1 = decision_proba[:, 2]  # P(decision==1)
    low_decision = p_dec_1 < threshold

    for key in method_probas:
        proba = method_probas[key].copy()
        # Reduce P(method==1) by cap_factor for low-decision rows
        proba[low_decision, 2] *= cap_factor
        # Re-normalize
        row_sums = proba.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums == 0, 1, row_sums)
        method_probas[key] = proba / row_sums

    return method_probas


# ── Audit ─────────────────────────────────────────────────────────────

def audit_non_substantive_labels(
    df: pd.DataFrame,
    audit_dir: Path,
) -> int:
    """
    Write rows where is_liveblog/commentisfree AND any label > 0.
    Does NOT modify labels.
    """
    mask = is_non_substantive(df)
    targets = [C.TARGET_DECISION] + C.TARGET_METHODS
    target_cols = [t for t in targets if t in df.columns]

    flagged = df[mask].copy()
    if len(flagged) == 0:
        pd.DataFrame().to_csv(audit_dir / "non_substantive_labeled_nonzero.csv", index=False)
        return 0

    # Check if any label > 0
    has_nonzero = pd.Series(False, index=flagged.index)
    for t in target_cols:
        has_nonzero = has_nonzero | (flagged[t].fillna(0) > 0)

    violations = flagged[has_nonzero]
    cols_to_write = ["url_canon", "title", "section", "is_liveblog", "is_commentisfree"] + target_cols
    cols_to_write = [c for c in cols_to_write if c in violations.columns]
    violations[cols_to_write].to_csv(
        audit_dir / "non_substantive_labeled_nonzero.csv", index=False
    )
    print(f"  Non-substantive rows with nonzero labels: {len(violations)}")
    return len(violations)


def write_constraint_effects(
    n_hard_changed: int,
    n_soft_changed: int,
    report_dir: Path,
) -> None:
    report_dir.mkdir(parents=True, exist_ok=True)
    effects = {
        "hard_constraint_predictions_changed": n_hard_changed,
        "soft_constraint_predictions_changed": n_soft_changed,
    }
    with open(report_dir / "constraint_effects.json", "w") as f:
        json.dump(effects, f, indent=2)
