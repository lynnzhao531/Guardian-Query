"""Theory-Guided ML pipeline for Guardian article scoring."""
