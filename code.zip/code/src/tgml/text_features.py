"""TF-IDF text feature extraction."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.sparse import spmatrix
from sklearn.feature_extraction.text import TfidfVectorizer

from . import config as C


class TextFeaturizer:
    """TF-IDF vectorizer on title + body text."""

    def __init__(
        self,
        max_features: int = C.TFIDF_MAX_FEATURES,
        ngram_range: tuple = C.TFIDF_NGRAM_RANGE,
        min_df: int = C.TFIDF_MIN_DF,
        max_df: float = C.TFIDF_MAX_DF,
    ):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=min_df,
            max_df=max_df,
            sublinear_tf=True,
            strip_accents="unicode",
            token_pattern=r"(?u)\b\w\w+\b",
        )

    @staticmethod
    def _combine_text(df: pd.DataFrame) -> list[str]:
        """Combine title + body, handling missing body gracefully."""
        texts = []
        for _, row in df.iterrows():
            title = row.get("title")
            body = row.get("body")
            title_str = str(title) if pd.notna(title) else ""
            body_str = str(body) if pd.notna(body) else ""
            if body_str:
                texts.append(f"{title_str}\n\n{body_str}")
            else:
                texts.append(title_str)
        return texts

    def fit(self, df: pd.DataFrame) -> "TextFeaturizer":
        texts = self._combine_text(df)
        self.vectorizer.fit(texts)
        print(f"  TF-IDF fitted: {len(self.vectorizer.vocabulary_)} features")
        return self

    def transform(self, df: pd.DataFrame) -> spmatrix:
        texts = self._combine_text(df)
        return self.vectorizer.transform(texts)

    def get_feature_names(self) -> list[str]:
        return [f"tfidf__{n}" for n in self.vectorizer.get_feature_names_out()]
