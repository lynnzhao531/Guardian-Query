"""Export top query terms / feature weights from trained models."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np

from . import config as C
from .models import OrdinalClassifier


# Which model contributes to which query space
QUERY_SPACE_MAP = {
    "decision": "decision",
    "method_rct": "method_rct",
    "method_prepost": "method_prepost",
    "method_case_study": "method_case_study",
    "method_expert_secondary": "method_expert_secondary",
    "method_expert_qual": "method_expert_qual",
    "method_gut": "method_gut",
}

# Generic evidence terms go here
COMMON_METHOD_TERMS = {
    "evaluation", "study", "trial", "evidence", "analysis", "research",
    "findings", "results", "assessment", "review", "report", "data",
    "experiment", "survey", "investigation",
}


def _extract_top_features(
    clf,
    feature_names: list[str],
    model_name: str,
    top_n: int = 50,
) -> tuple[list[dict], list[dict]]:
    """
    Extract top positive and negative features from a model.
    Returns (positive_terms, negative_terms).
    """
    if isinstance(clf, OrdinalClassifier):
        # Use the highest-threshold classifier (P(Y > 0.5) = P(Y=1))
        coefs = clf.get_coefs()
        if coefs and coefs[-1] is not None:
            weights = coefs[-1]
        elif coefs and coefs[0] is not None:
            weights = coefs[0]
        else:
            return [], []
    elif hasattr(clf, "coef_"):
        # Binary or multi-class: use last class coefficients
        w = clf.coef_
        weights = w[-1] if w.ndim > 1 else w[0]
    else:
        return [], []

    if len(weights) != len(feature_names):
        # Feature count mismatch — truncate to safe length
        n = min(len(weights), len(feature_names))
        weights = weights[:n]
        feature_names = feature_names[:n]

    # Sort by weight
    order = np.argsort(weights)
    top_pos_idx = order[-top_n:][::-1]
    top_neg_idx = order[:top_n]

    def _classify_source(fname: str) -> str:
        if fname.startswith("tfidf__"):
            return "tfidf"
        elif fname.startswith("theory__"):
            return "theory"
        elif fname.startswith("kw__"):
            return "keyword"
        return "unknown"

    def _make_entry(idx: int, is_positive: bool) -> dict:
        fname = feature_names[idx]
        clean_name = fname.split("__", 1)[-1] if "__" in fname else fname
        source = _classify_source(fname)
        w = float(weights[idx])
        entry = {
            "term": clean_name,
            "feature_source": source,
            "model_name": model_name,
            "weight": round(w, 4),
        }
        # Warn about generic terms
        if clean_name.lower() in COMMON_METHOD_TERMS and is_positive:
            entry["do_not_use_if"] = "too generic — also appears in common_method terms"
        return entry

    positive = [_make_entry(i, True) for i in top_pos_idx if weights[i] > 0]
    negative = [_make_entry(i, False) for i in top_neg_idx if weights[i] < 0]

    return positive, negative


def main() -> None:
    parser = argparse.ArgumentParser(description="Export query term suggestions")
    parser.add_argument("--modeldir", type=str, default="models")
    parser.add_argument("--outdir", type=str, default="reports/query_spaces")
    parser.add_argument("--top-n", type=int, default=50)
    parser.add_argument("--show-n", type=int, default=15,
                        help="Number of top terms to print")
    args = parser.parse_args()

    model_dir = Path(args.modeldir)
    out_dir = Path(args.outdir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  QUERY TERM EXPORT")
    print("=" * 70)

    # Load feature pipeline for feature names
    feat_pipeline = joblib.load(model_dir / "feature_pipeline.joblib")
    feature_names = feat_pipeline.get_feature_names()
    print(f"  Total features: {len(feature_names)}")

    # Collect common method terms across all method models
    all_common_positive = []

    for model_name, space_name in QUERY_SPACE_MAP.items():
        model_path = model_dir / f"{model_name}.joblib"
        if not model_path.exists():
            print(f"\n  ⚠ {model_name}.joblib not found, skipping.")
            continue

        clf = joblib.load(model_path)
        positive, negative = _extract_top_features(
            clf, feature_names, model_name, top_n=args.top_n,
        )

        # Separate common method terms from model-specific
        model_specific_pos = []
        for entry in positive:
            clean = entry["term"].lower()
            if clean in COMMON_METHOD_TERMS and model_name != "decision":
                all_common_positive.append(entry)
            else:
                model_specific_pos.append(entry)

        query_space = {
            "model": model_name,
            "query_space": space_name,
            "positive_terms": model_specific_pos[:args.top_n],
            "exclude_terms": negative[:args.top_n],
        }

        with open(out_dir / f"{space_name}.json", "w") as f:
            json.dump(query_space, f, indent=2)

        # Print top N
        print(f"\n  ── {space_name} (top {args.show_n} positive) ──")
        for i, entry in enumerate(model_specific_pos[:args.show_n]):
            src = entry["feature_source"]
            w = entry["weight"]
            note = f"  ⚠ {entry['do_not_use_if']}" if "do_not_use_if" in entry else ""
            print(f"    {i+1:2d}. {entry['term']:<40s} [{src}] w={w:+.4f}{note}")

        if negative:
            print(f"  Top {min(5, len(negative))} exclude terms:")
            for entry in negative[:5]:
                print(f"    ✗ {entry['term']:<40s} [{entry['feature_source']}] w={entry['weight']:+.4f}")

    # Write common method terms
    if all_common_positive:
        # Deduplicate by term
        seen = set()
        unique = []
        for entry in all_common_positive:
            if entry["term"] not in seen:
                seen.add(entry["term"])
                unique.append(entry)
        common_space = {
            "description": "Generic evidence terms shared across method models",
            "positive_terms": unique,
        }
        with open(out_dir / "common_method.json", "w") as f:
            json.dump(common_space, f, indent=2)
        print(f"\n  ── common_method ({len(unique)} terms) ──")
        for entry in unique[:args.show_n]:
            print(f"    {entry['term']:<40s} [{entry['feature_source']}]")

    print("\n" + "=" * 70)
    print(f"  ✓ Query spaces written to {out_dir}/")
    print("=" * 70)


if __name__ == "__main__":
    main()
