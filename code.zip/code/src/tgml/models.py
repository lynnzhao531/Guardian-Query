"""Model definitions: Ordinal classifier + feature pipeline."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.linear_model import LogisticRegression

from . import config as C
from .data_load import get_keyword_columns, keyword_tristate
from .text_features import TextFeaturizer
from .theory_features import TheoryFeaturizer


# ── Ordinal Classifier (Frank & Hall) ─────────────────────────────────

class OrdinalClassifier(BaseEstimator, ClassifierMixin):
    """
    Ordinal regression via K-1 cumulative binary classifiers.
    For classes [0, 0.5, 1]:
      clf_0: P(Y > 0)   i.e. Y ∈ {0.5, 1} vs Y = 0
      clf_1: P(Y > 0.5) i.e. Y = 1 vs Y ∈ {0, 0.5}
    """

    def __init__(self, base_estimator=None, classes=None):
        self.base_estimator = base_estimator or LogisticRegression(
            solver="saga", max_iter=C.LR_MAX_ITER, C=C.LR_C,
            class_weight="balanced", random_state=C.RANDOM_SEED,
        )
        self.classes = classes or C.ORDINAL_CLASSES

    def fit(self, X, y):
        self.classes_ = np.array(sorted(self.classes))
        self.n_classes_ = len(self.classes_)
        self.clfs_ = []

        for k in range(self.n_classes_ - 1):
            threshold = self.classes_[k]
            y_bin = (np.array(y, dtype=float) > threshold).astype(int)
            clf = clone(self.base_estimator)

            if len(np.unique(y_bin)) > 1:
                clf.fit(X, y_bin)
                self.clfs_.append(clf)
            else:
                # Degenerate: all same class
                self.clfs_.append(None)

        return self

    def predict_proba(self, X):
        n = X.shape[0]
        cum_probs = []

        for clf in self.clfs_:
            if clf is not None:
                p = clf.predict_proba(X)[:, 1]  # P(Y > threshold)
            else:
                p = np.zeros(n)
            cum_probs.append(p)

        probs = np.zeros((n, self.n_classes_))
        probs[:, 0] = 1.0 - cum_probs[0]
        for k in range(1, self.n_classes_ - 1):
            probs[:, k] = cum_probs[k - 1] - cum_probs[k]
        probs[:, -1] = cum_probs[-1]

        # Clip & normalize
        probs = np.clip(probs, 0, 1)
        row_sums = probs.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums == 0, 1, row_sums)
        probs = probs / row_sums
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]

    def get_coefs(self) -> list[np.ndarray | None]:
        """Return coefficient arrays from each binary classifier."""
        coefs = []
        for clf in self.clfs_:
            if clf is not None and hasattr(clf, "coef_"):
                coefs.append(clf.coef_[0])
            else:
                coefs.append(None)
        return coefs


# ── Feature Pipeline ──────────────────────────────────────────────────

class FeaturePipeline:
    """
    Combines TF-IDF + theory features + keyword tri-state into one
    sparse feature matrix.
    """

    def __init__(self):
        self.text_feat = TextFeaturizer()
        self.theory_feat = TheoryFeaturizer()
        self.keyword_cols: list[str] = []
        self._fitted = False

    def fit(self, df: pd.DataFrame) -> "FeaturePipeline":
        # Fit TF-IDF on training text
        self.text_feat.fit(df)
        # Discover keyword columns
        self.keyword_cols = get_keyword_columns(df)
        print(f"  Keyword columns: {len(self.keyword_cols)}")
        self._fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> sparse.spmatrix:
        """Return combined sparse feature matrix."""
        # TF-IDF (sparse)
        X_text = self.text_feat.transform(df)

        # Theory features (dense → sparse)
        theory_df = self.theory_feat.transform(df)
        X_theory = sparse.csr_matrix(theory_df.values.astype(np.float64))

        # Keyword tri-state (dense → sparse)
        kw_array = keyword_tristate(df, self.keyword_cols)
        X_kw = sparse.csr_matrix(kw_array)

        return sparse.hstack([X_text, X_theory, X_kw], format="csr")

    def get_feature_names(self) -> list[str]:
        names = self.text_feat.get_feature_names()
        names += self.theory_feat.get_feature_names()
        names += [f"kw__{c}" for c in self.keyword_cols]
        return names

    def n_features(self) -> int:
        return len(self.get_feature_names())
