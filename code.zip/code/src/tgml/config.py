"""Central configuration for the TGML pipeline."""
from __future__ import annotations

RANDOM_SEED = 42

# ── Label schema ─────────────────────────────────────────────────────
LABEL_VALUES = {0.0, 0.5, 1.0}
ORDINAL_CLASSES = [0.0, 0.5, 1.0]

TARGET_DECISION = "decision"
TARGET_METHODS = [
    "method_rct",
    "method_prepost",
    "method_case_study",
    "method_expert_qual",
    "method_expert_secondary",
    "method_gut",
]

# Methods trainable from master_vector (expert_qual uses training_cases)
TRAINABLE_METHODS = [m for m in TARGET_METHODS if m != "method_expert_qual"]

# ── Splits ───────────────────────────────────────────────────────────
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15

# ── TF-IDF ───────────────────────────────────────────────────────────
TFIDF_MAX_FEATURES = 100_000
TFIDF_NGRAM_RANGE = (1, 2)
TFIDF_MIN_DF = 2
TFIDF_MAX_DF = 0.95

# ── Constraints ──────────────────────────────────────────────────────
SOFT_CONSTRAINT_DECISION_THRESHOLD = 0.1
SOFT_CONSTRAINT_METHOD_CAP_FACTOR = 0.7

# ── Expert-qual probability → score thresholds ───────────────────────
EXPERT_QUAL_THRESHOLD_LOW = 0.33
EXPERT_QUAL_THRESHOLD_HIGH = 0.66

# ── Evaluation ───────────────────────────────────────────────────────
PRECISION_AT_K_VALUES = [25, 50, 100]
SMALL_DATASET_THRESHOLD = 50  # use CV-only below this

# ── Columns to EXCLUDE from keyword features ─────────────────────────
METADATA_COLS = {
    "url_canon", "id", "title", "date", "date_utc", "url", "section", "body",
    "source_datasets", "decision", "decision_conflict", "decision_values",
    "num_method_scores_observed", "is_liveblog", "is_commentisfree",
}
# Also exclude all method target columns and their conflict/values columns
_method_related = set()
for _m in TARGET_METHODS:
    _method_related |= {_m, f"{_m}_conflict", f"{_m}_values"}
EXCLUDE_FROM_KEYWORDS = METADATA_COLS | _method_related

# ── Logistic regression ──────────────────────────────────────────────
LR_MAX_ITER = 5000
LR_C = 1.0
