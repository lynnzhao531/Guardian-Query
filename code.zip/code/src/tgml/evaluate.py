"""Evaluation CLI: load saved models, predict, apply constraints, compute metrics."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix

from . import config as C
from .constraints import (
    apply_hard_constraints,
    apply_soft_constraints,
    write_constraint_effects,
)
from .data_load import load_master_vector, split_df, validate_labels


def _precision_at_k(y_true, proba_class1, k: int) -> float:
    if len(y_true) < k:
        k = len(y_true)
    if k == 0:
        return 0.0
    order = np.argsort(-proba_class1)[:k]
    return float((np.array(y_true)[order] == 1.0).mean())


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate TGML models")
    parser.add_argument("--data", type=str, default="outputs/master_vector.parquet")
    parser.add_argument("--modeldir", type=str, default="models")
    parser.add_argument("--reportdir", type=str, default="reports")
    parser.add_argument("--auditdir", type=str, default="audits")
    args = parser.parse_args()

    model_dir = Path(args.modeldir)
    report_dir = Path(args.reportdir)
    audit_dir = Path(args.auditdir)
    for d in [report_dir, audit_dir]:
        d.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  TGML EVALUATION PIPELINE")
    print("=" * 70)

    # ── Load data ─────────────────────────────────────────────────────
    df = load_master_vector(args.data)
    validate_labels(df)

    # Load splits
    with open(model_dir / "split_urls.json") as f:
        splits = json.load(f)
    _, _, test_df = split_df(df, splits)
    print(f"  Test set: {len(test_df)} rows")

    # ── Load models ───────────────────────────────────────────────────
    feat_pipeline = joblib.load(model_dir / "feature_pipeline.joblib")
    X_test = feat_pipeline.transform(test_df)

    all_preds: dict[str, np.ndarray] = {}
    all_probas: dict[str, np.ndarray] = {}

    # Decision model
    dec_path = model_dir / "decision.joblib"
    if dec_path.exists():
        dec_clf = joblib.load(dec_path)
        all_probas["decision"] = dec_clf.predict_proba(X_test)
        all_preds["decision"] = dec_clf.predict(X_test)
    else:
        print("  ⚠ decision model not found")

    # Method models
    for method in C.TARGET_METHODS:
        mpath = model_dir / f"{method}.joblib"
        if mpath.exists():
            clf = joblib.load(mpath)
            if method == "method_expert_qual":
                # Binary classifier → convert to 3-class probabilities
                p = clf.predict_proba(X_test)[:, 1]
                scores = np.where(
                    p < C.EXPERT_QUAL_THRESHOLD_LOW, 0.0,
                    np.where(p < C.EXPERT_QUAL_THRESHOLD_HIGH, 0.5, 1.0),
                )
                all_preds[method] = scores
                # Build pseudo 3-class proba for constraint pipeline
                proba_3 = np.zeros((len(test_df), 3))
                proba_3[:, 0] = 1 - p
                proba_3[:, 2] = p
                proba_3[:, 1] = 0  # no 0.5 class in binary
                all_probas[method] = proba_3
            else:
                all_probas[method] = clf.predict_proba(X_test)
                all_preds[method] = clf.predict(X_test)

    # ── Apply constraints ─────────────────────────────────────────────
    print("\n─── APPLYING CONSTRAINTS ───")

    # Soft constraints
    n_soft = 0
    if "decision" in all_probas:
        method_probas = {k: v for k, v in all_probas.items() if k != "decision"}
        before_preds = {k: v.copy() for k, v in all_preds.items() if k != "decision"}
        method_probas = apply_soft_constraints(all_probas["decision"], method_probas)
        # Re-derive predictions from constrained probas
        for k in method_probas:
            new_pred = np.array(C.ORDINAL_CLASSES)[np.argmax(method_probas[k], axis=1)]
            if k in before_preds:
                n_soft += int((before_preds[k] != new_pred).sum())
            all_preds[k] = new_pred
    print(f"  Soft constraint changed {n_soft} method predictions")

    # Hard constraints
    all_preds, n_hard = apply_hard_constraints(all_preds, test_df)
    print(f"  Hard constraint changed {n_hard} predictions total")

    write_constraint_effects(n_hard, n_soft, report_dir)

    # ── Compute metrics ───────────────────────────────────────────────
    print("\n─── TEST SET METRICS ───")

    eval_results = {}

    for target_name, preds in all_preds.items():
        if target_name in test_df.columns:
            mask = test_df[target_name].notna()
            n_eval = int(mask.sum())
        else:
            # expert_qual has no labels in master_vector
            n_eval = 0

        if n_eval == 0:
            print(f"\n  {target_name}: no labeled test rows, skipping eval.")
            eval_results[target_name] = {"n_eval": 0}
            continue

        y_true = test_df.loc[mask, target_name].values
        y_pred = preds[mask.values]

        print(f"\n  ── {target_name} ({n_eval} test rows) ──")

        if target_name == "method_expert_qual":
            labels = [0, 1]
            str_labels = ["0", "1"]
        else:
            labels = C.ORDINAL_CLASSES
            str_labels = [str(c) for c in C.ORDINAL_CLASSES]

        y_true_s = np.array([str(float(v)) for v in y_true])
        y_pred_s = np.array([str(float(v)) for v in y_pred])

        cr = classification_report(
            y_true_s, y_pred_s, labels=str_labels,
            output_dict=True, zero_division=0,
        )
        macro_f1 = cr.get("macro avg", {}).get("f1-score", 0)
        prec1 = cr.get("1.0", cr.get("1", {})).get("precision", 0)
        print(f"  Macro-F1: {macro_f1:.3f}")
        print(f"  Precision(class=1): {prec1:.3f}")

        # Precision@K using probabilities
        if target_name in all_probas:
            p1 = all_probas[target_name][mask.values, -1]  # P(highest class)
            p_at_k = {}
            for k in C.PRECISION_AT_K_VALUES:
                p_at_k[f"precision@{k}"] = round(_precision_at_k(y_true, p1, k), 4)
            print(f"  Precision@K: {p_at_k}")
        else:
            p_at_k = {}

        # Confusion matrix
        cm_path = report_dir / "confusion_matrices" / f"eval_{target_name}.csv"
        cm_path.parent.mkdir(parents=True, exist_ok=True)
        cm = confusion_matrix(y_true_s, y_pred_s, labels=str_labels)
        pd.DataFrame(
            cm, index=[f"true_{c}" for c in str_labels],
            columns=[f"pred_{c}" for c in str_labels],
        ).to_csv(cm_path)

        eval_results[target_name] = {
            "n_eval": n_eval,
            "macro_f1": macro_f1,
            "precision_class_1": prec1,
            "precision_at_k": p_at_k,
        }

        # Save individual metrics
        with open(report_dir / f"eval_metrics_{target_name}.json", "w") as f:
            json.dump(eval_results[target_name], f, indent=2)

    # Save combined eval
    with open(report_dir / "eval_summary.json", "w") as f:
        json.dump(eval_results, f, indent=2)

    print("\n" + "=" * 70)
    print("  EVALUATION COMPLETE")
    print("=" * 70)
    print()


if __name__ == "__main__":
    main()
