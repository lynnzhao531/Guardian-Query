"""Training CLI: fit all models and write reports."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    precision_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_predict

from . import config as C
from .constraints import audit_non_substantive_labels
from .data_load import (
    create_splits,
    load_master_vector,
    load_training_cases,
    print_label_distributions,
    split_df,
    validate_labels,
    write_schema_audits,
)
from .models import FeaturePipeline, OrdinalClassifier
from .theory_features import TheoryFeaturizer


def _save_confusion_matrix(y_true, y_pred, classes, path: Path) -> None:
    cm = confusion_matrix(y_true, y_pred, labels=classes)
    df_cm = pd.DataFrame(cm, index=[f"true_{c}" for c in classes],
                         columns=[f"pred_{c}" for c in classes])
    path.parent.mkdir(parents=True, exist_ok=True)
    df_cm.to_csv(path)


def _precision_at_k(y_true, proba_class1, k: int) -> float:
    """Precision@K: among top-K by P(class=1), how many are truly class 1."""
    if len(y_true) < k:
        k = len(y_true)
    if k == 0:
        return 0.0
    order = np.argsort(-proba_class1)[:k]
    return float((np.array(y_true)[order] == 1.0).mean())


def _train_one_model(
    name: str,
    X_train, y_train,
    X_val, y_val,
    model_dir: Path,
    report_dir: Path,
) -> dict:
    """Train ordinal classifier, evaluate on val, save model, return metrics."""
    print(f"\n  ── Training {name} ──")
    print(f"  Train: {len(y_train)} rows, class dist: {pd.Series(y_train).value_counts().sort_index().to_dict()}")

    clf = OrdinalClassifier()
    clf.fit(X_train, y_train)

    # Save model
    model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, model_dir / f"{name}.joblib")

    # Evaluate on val
    metrics = {}
    if len(y_val) > 0:
        y_pred = clf.predict(X_val)
        proba = clf.predict_proba(X_val)
        p_class1 = proba[:, 2]  # P(class=1)

        # Convert to strings so sklearn doesn't confuse 0.5 as "continuous"
        str_labels = [str(c) for c in C.ORDINAL_CLASSES]
        y_val_s = np.array([str(float(v)) for v in y_val])
        y_pred_s = np.array([str(float(v)) for v in y_pred])

        cr = classification_report(
            y_val_s, y_pred_s, labels=str_labels,
            output_dict=True, zero_division=0,
        )
        metrics["classification_report"] = cr
        metrics["macro_f1"] = cr.get("macro avg", {}).get("f1-score", 0)

        # Precision for class 1
        prec1 = cr.get("1.0", {}).get("precision", 0)
        metrics["precision_class_1"] = prec1
        print(f"  Val macro-F1: {metrics['macro_f1']:.3f}, precision(class=1): {prec1:.3f}")

        # Precision@K
        p_at_k = {}
        for k in C.PRECISION_AT_K_VALUES:
            p_at_k[f"precision@{k}"] = round(_precision_at_k(y_val, p_class1, k), 4)
        metrics["precision_at_k"] = p_at_k
        print(f"  Precision@K: {p_at_k}")

        # Confusion matrix
        _save_confusion_matrix(
            y_val_s, y_pred_s, str_labels,
            report_dir / "confusion_matrices" / f"{name}.csv",
        )

        # Precision@K file
        pak_dir = report_dir / "precision_at_k"
        pak_dir.mkdir(parents=True, exist_ok=True)
        with open(pak_dir / f"{name}.json", "w") as f:
            json.dump(p_at_k, f, indent=2)
    else:
        print("  (no val data)")

    # Save metrics
    with open(report_dir / f"metrics_{name}.json", "w") as f:
        json.dump(metrics, f, indent=2, default=str)

    return metrics


def _train_expert_qual(
    tc_df: pd.DataFrame,
    feat_pipeline: FeaturePipeline,
    model_dir: Path,
    report_dir: Path,
) -> None:
    """Train binary expert_qual classifier from training_cases using CV."""
    print("\n  ── Training method_expert_qual (from training_cases) ──")

    if len(tc_df) == 0:
        print("  ⚠ No training cases available, skipping.")
        return

    # Create binary label
    y = (tc_df["method_category"] == "Expert_Qualitative").astype(int).values
    print(f"  Rows: {len(tc_df)}, positive: {y.sum()}, negative: {(1-y).sum()}")

    # Build features using same pipeline
    X = feat_pipeline.transform(tc_df)

    # Cross-val for metrics (5-fold, or fewer if very small)
    n_folds = min(5, min(int(y.sum()), int((1 - y).sum())))
    if n_folds < 2:
        n_folds = 2

    clf = LogisticRegression(
        solver="saga", max_iter=C.LR_MAX_ITER, C=C.LR_C,
        class_weight="balanced", random_state=C.RANDOM_SEED,
    )
    cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=C.RANDOM_SEED)
    y_pred_cv = cross_val_predict(clf, X, y, cv=cv)

    cr = classification_report(y, y_pred_cv, output_dict=True, zero_division=0)
    print(f"  CV macro-F1: {cr.get('macro avg', {}).get('f1-score', 0):.3f}")
    print(f"  CV precision(expert_qual): {cr.get('1', {}).get('precision', 0):.3f}")

    metrics = {"cv_classification_report": cr, "cv_folds": n_folds}
    with open(report_dir / "metrics_method_expert_qual.json", "w") as f:
        json.dump(metrics, f, indent=2, default=str)

    _save_confusion_matrix(
        y, y_pred_cv, [0, 1],
        report_dir / "confusion_matrices" / "method_expert_qual.csv",
    )

    # Train on ALL data for inference model
    clf.fit(X, y)
    model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, model_dir / "method_expert_qual.joblib")
    print(f"  ✓ Saved method_expert_qual model (trained on all {len(tc_df)} rows)")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train TGML models")
    parser.add_argument("--data", type=str, default="outputs/master_vector.parquet")
    parser.add_argument("--training-cases", type=str,
                        default="outputs/training_cases_clean.parquet")
    parser.add_argument("--outdir", type=str, default="models")
    parser.add_argument("--reportdir", type=str, default="reports")
    parser.add_argument("--auditdir", type=str, default="audits")
    args = parser.parse_args()

    model_dir = Path(args.outdir)
    report_dir = Path(args.reportdir)
    audit_dir = Path(args.auditdir)
    for d in [model_dir, report_dir, audit_dir]:
        d.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  TGML TRAINING PIPELINE")
    print("=" * 70)

    # ── Load & validate ───────────────────────────────────────────────
    print("\n─── DATA LOADING ───")
    df = load_master_vector(args.data)
    viol = validate_labels(df)
    print("\nLabel distributions:")
    distributions = print_label_distributions(df)
    write_schema_audits(df, distributions, viol, audit_dir)

    pct_body = 100 * df["body"].isna().mean()
    pct_title = 100 * df["title"].isna().mean()
    print(f"\n  Body missing: {pct_body:.1f}%, Title missing: {pct_title:.1f}%")

    # ── Constraint audit ──────────────────────────────────────────────
    print("\n─── CONSTRAINT AUDIT ───")
    audit_non_substantive_labels(df, audit_dir)

    # ── Split ─────────────────────────────────────────────────────────
    print("\n─── SPLITTING ───")
    splits = create_splits(df)
    # Save splits for reproducibility
    with open(model_dir / "split_urls.json", "w") as f:
        json.dump(splits, f, indent=2)
    train_df, val_df, test_df = split_df(df, splits)

    # ── Feature pipeline ──────────────────────────────────────────────
    print("\n─── FEATURE PIPELINE ───")
    feat_pipeline = FeaturePipeline()
    feat_pipeline.fit(train_df)

    # Theory feature coverage audit
    theory = TheoryFeaturizer()
    theory.write_coverage_audit(df, report_dir)

    X_train = feat_pipeline.transform(train_df)
    X_val = feat_pipeline.transform(val_df)
    print(f"  Train features: {X_train.shape}, Val features: {X_val.shape}")

    # Save feature pipeline
    joblib.dump(feat_pipeline, model_dir / "feature_pipeline.joblib")
    print("  ✓ Feature pipeline saved")

    # ── Train decision model ──────────────────────────────────────────
    print("\n─── MODEL TRAINING ───")
    # Decision model: all rows with non-null decision
    dec_train_mask = train_df[C.TARGET_DECISION].notna()
    dec_val_mask = val_df[C.TARGET_DECISION].notna()
    _train_one_model(
        "decision",
        X_train[dec_train_mask.values],
        train_df.loc[dec_train_mask, C.TARGET_DECISION].values,
        X_val[dec_val_mask.values],
        val_df.loc[dec_val_mask, C.TARGET_DECISION].values,
        model_dir, report_dir,
    )

    # ── Train method models ───────────────────────────────────────────
    for method in C.TRAINABLE_METHODS:
        train_mask = train_df[method].notna()
        val_mask = val_df[method].notna()
        n_train = int(train_mask.sum())
        n_val = int(val_mask.sum())

        if n_train < 5:
            print(f"\n  ⚠ {method}: only {n_train} training rows, skipping model.")
            continue

        if n_train < C.SMALL_DATASET_THRESHOLD:
            # Use full dataset with CV instead of train/val split
            print(f"\n  ── {method} (small dataset: {n_train} train, using CV) ──")
            full_mask = df[method].notna()
            X_full = feat_pipeline.transform(df[full_mask])
            y_full = df.loc[full_mask, method].values

            clf = OrdinalClassifier()
            n_folds = min(5, int(min(pd.Series(y_full).value_counts().min(), 3)))
            if n_folds < 2:
                n_folds = 2

            # StratifiedKFold needs string labels (not float with 0.5)
            y_full_str = np.array([str(float(v)) for v in y_full])
            cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=C.RANDOM_SEED)

            # Manual CV for ordinal classifier
            y_pred_cv = np.full_like(y_full, np.nan)
            for fold_train, fold_val in cv.split(X_full, y_full_str):
                fold_clf = OrdinalClassifier()
                fold_clf.fit(X_full[fold_train], y_full[fold_train])
                y_pred_cv[fold_val] = fold_clf.predict(X_full[fold_val])

            valid = ~np.isnan(y_pred_cv)
            str_labels = [str(c) for c in C.ORDINAL_CLASSES]
            y_full_s = np.array([str(float(v)) for v in y_full[valid]])
            y_pred_cv_s = np.array([str(float(v)) for v in y_pred_cv[valid]])
            cr = classification_report(
                y_full_s, y_pred_cv_s,
                labels=str_labels, output_dict=True, zero_division=0,
            )
            print(f"  CV macro-F1: {cr.get('macro avg', {}).get('f1-score', 0):.3f}")
            metrics = {"cv_classification_report": cr, "cv_folds": n_folds}
            with open(report_dir / f"metrics_{method}.json", "w") as f:
                json.dump(metrics, f, indent=2, default=str)

            _save_confusion_matrix(
                y_full_s, y_pred_cv_s, str_labels,
                report_dir / "confusion_matrices" / f"{method}.csv",
            )

            # Train on ALL for inference
            clf.fit(X_full, y_full)
            joblib.dump(clf, model_dir / f"{method}.joblib")
            print(f"  ✓ Saved {method} (trained on all {n_train + n_val} labeled rows)")
        else:
            _train_one_model(
                method,
                X_train[train_mask.values],
                train_df.loc[train_mask, method].values,
                X_val[val_mask.values],
                val_df.loc[val_mask, method].values,
                model_dir, report_dir,
            )

    # ── Expert qualitative (from training_cases) ──────────────────────
    try:
        tc_df = load_training_cases(args.training_cases)
        _train_expert_qual(tc_df, feat_pipeline, model_dir, report_dir)
    except FileNotFoundError:
        print("  ⚠ training_cases not found, skipping expert_qual model.")

    # ── Summary ───────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  TRAINING COMPLETE")
    print("=" * 70)
    saved = list(model_dir.glob("*.joblib"))
    print(f"  Models saved: {len(saved)}")
    for p in sorted(saved):
        print(f"    {p.name}")
    reports_saved = list(report_dir.glob("metrics_*.json"))
    print(f"  Metric reports: {len(reports_saved)}")
    print()


if __name__ == "__main__":
    main()
