import os
import re
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Keywords to surface relevant sentences
KEYWORDS = {
    "decision": [
        r"\bstudy\b", r"\bresearch\b", r"\bexperiment\b", r"\btrial\b", 
        r"\bsurvey\b", r"\breport\b", r"\bfindings\b", r"\bdata\b", 
        r"\bscientists\b", r"\bresearchers\b", r"\bevidence\b", 
        r"\bsignificant\b", r"\beffect\b", r"\boutcome\b", r"\bresult\b"
    ],
    "method_rct": [
        r"\brandom\w*\b", r"\brct\b", r"\bplacebo\b", r"\bblind\w*\b", r"\bassign\w*\b", r"\bcontrol group\b"
    ],
    "method_prepost": [
        r"\bbefore\b", r"\bafter\b", r"\bpre\b", r"\bpost\b", r"\bbaseline\b", r"\bintervention\b", r"\bcompared to\b"
    ],
    "method_case_study": [
        r"\bcase study\b", r"\bcase report\b", r"\bscenario\b"
    ],
    "method_expert_qual": [
        r"\binterview\w*\b", r"\bfocus group\b", r"\bqualitative\b", r"\bthematic\b"
    ],
    "method_expert_secondary": [
        r"\breview\b", r"\bmeta-analysis\b", r"\bsystematic\b", r"\bliterature\b"
    ],
    "method_gut": [
        r"\bopinion\b", r"\bfeel\b", r"\bthink\b", r"\banecdote\b"
    ]
}

def split_sentences(text):
    if not isinstance(text, str):
        return []
    # Simple regex split on punctuation followed by space
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 10]

def extract_evidence(text, max_chars=1800):
    if not isinstance(text, str):
        return ""
        
    sentences = split_sentences(text)
    
    scored_sentences = []
    for s in sentences:
        s_lower = s.lower()
        score = 0
        match_cats = []
        for cat, patterns in KEYWORDS.items():
            for p in patterns:
                if re.search(p, s_lower):
                    score += 1
                    match_cats.append(cat)
                    break # score once per category
        if score > 0:
            scored_sentences.append((score, s, match_cats))
            
    # Sort by score descending, then by appearance (stable sort essentially if we don't care about appearance)
    # Actually, chronological order might be better for reading, so we just filter the top K and keep their order
    
    # We want sentences with highest scores
    # Also want to include at least the first 2 sentences for context
    
    keep_indices = set()
    if len(sentences) > 0: keep_indices.add(0)
    if len(sentences) > 1: keep_indices.add(1)
    
    # Sort indices of sentences based on score
    scored_indices = []
    for i, s in enumerate(sentences):
        s_lower = s.lower()
        score = sum(1 for p in KEYWORDS["decision"] if re.search(p, s_lower)) * 0.5
        for cat in [c for c in KEYWORDS if c != "decision"]:
            score += sum(1 for p in KEYWORDS[cat] if re.search(p, s_lower))
        if score > 0:
            scored_indices.append((score, i))
            
    scored_indices.sort(key=lambda x: x[0], reverse=True)
    
    for score, i in scored_indices:
        keep_indices.add(i)
        
    # Reconstruct text in order, up to max_chars
    final_sentences = []
    current_chars = 0
    for i in sorted(list(keep_indices)):
        s = sentences[i]
        if current_chars + len(s) + 1 <= max_chars:
            final_sentences.append(s)
            current_chars += len(s) + 1
            
    if not final_sentences:
        # Fallback if no keywords matched
        return text[:max_chars]
        
    return " ".join(final_sentences)

def main():
    input_file = BASE_DIR / "outputs/master_vector.parquet"
    if not input_file.exists():
        input_file = BASE_DIR / "outputs/training_cases_clean.parquet"
        
    print(f"Loading {input_file}...")
    df = pd.read_parquet(input_file)
    
    print(f"Loaded {len(df)} rows. Extracting evidence chunks...")
    
    df['evidence_text'] = df['body'].apply(lambda x: extract_evidence(x, max_chars=1800))
    
    out_dir = BASE_DIR / "data/processed"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    out_file = out_dir / "evidence_chunks.parquet"
    df.to_parquet(out_file)
    
    print(f"Saved to {out_file}")
    print("Example chunk:")
    print(df['evidence_text'].iloc[0])

if __name__ == "__main__":
    main()
