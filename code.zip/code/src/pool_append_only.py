"""
src/pool_append_only.py  —  STRICT append-only pool update.

Contract guarantees:
  - Existing rows are NEVER modified or reordered.
  - New rows appended if and only if (url_canon, classified_method) not already present.
  - After append, immutability of existing rows is verified by re-reading and comparing.
  - On any violation -> raises PoolImmutabilityError (caller must sys.exit(3)).
  - Audit JSON written to audits/pools/<poolname>_append_audit_round_<id>.json.
"""

import csv
import hashlib
import json
import os
import tempfile
import datetime
from pathlib import Path
from typing import List, Dict, Optional

REQUIRED_COLUMNS = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text",
    "source_round", "added_ts_utc", "credit", "tied_methods", "classified_method", "confidence_score"
]

POOLS_DIR = Path("outputs/pools")
AUDIT_DIR = Path("audits/pools")


class PoolImmutabilityError(RuntimeError):
    """Raised when an existing pool row has been modified or deleted."""
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def update_pool_append_only(
    pool_path: Path,
    new_rows_df,          # pandas DataFrame
    key_cols: List[str] = None,
    round_id: Optional[int] = None,
    run_root: Optional[Path] = None,
) -> Dict:
    """
    Strictly append new_rows_df rows to pool_path, deduplicating by key_cols.
    Returns audit dict.
    Raises PoolImmutabilityError if verification fails.
    """
    import pandas as pd

    if key_cols is None:
        key_cols = ["url_canon", "classified_method"]

    pool_path = Path(pool_path)
    audit = {
        "pool_path": str(pool_path),
        "round_id": round_id,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "old_row_count": 0,
        "new_rows_candidate_count": len(new_rows_df),
        "appended_count": 0,
        "duplicates_skipped": 0,
        "header_verified": False,
        "immutability_verified": False,
        "violations": [],
        "success": False,
    }

    # ── 1. Read existing file ──────────────────────────────────────────────────
    if pool_path.exists() and pool_path.stat().st_size > 0:
        old_sha = _sha256(pool_path)

        with open(pool_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            existing_header = reader.fieldnames or []
            existing_rows = list(reader)

        audit["old_row_count"] = len(existing_rows)
        audit["header_verified"] = (list(existing_header) == REQUIRED_COLUMNS)

        if not audit["header_verified"]:
            audit["violations"].append(
                f"Header mismatch: expected {REQUIRED_COLUMNS}, got {list(existing_header)}"
            )
            _write_audit(audit, pool_path, round_id, run_root)
            raise PoolImmutabilityError(f"Pool {pool_path} header mismatch. Stopping.")

        existing_keys = set(
            (r.get("url_canon", ""), r.get("classified_method", ""))
            for r in existing_rows
        )
    else:
        # Pool missing or empty — create with header
        old_sha = None
        existing_rows = []
        existing_keys = set()
        audit["old_row_count"] = 0
        audit["header_verified"] = True
        if not pool_path.exists():
            pool_path.parent.mkdir(parents=True, exist_ok=True)
            with open(pool_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=REQUIRED_COLUMNS)
                writer.writeheader()

    # ── 2. Filter to new-only rows ─────────────────────────────────────────────
    rows_to_append = []
    for _, row in new_rows_df.iterrows():
        key = (str(row.get("url_canon", "")), str(row.get("classified_method", "")))
        if key in existing_keys:
            audit["duplicates_skipped"] += 1
        else:
            rows_to_append.append(row)
            existing_keys.add(key)  # prevent within-batch duplicates

    audit["appended_count"] = len(rows_to_append)

    if not rows_to_append:
        audit["immutability_verified"] = True
        audit["success"] = True
        _write_audit(audit, pool_path, round_id, run_root)
        return audit

    # ── 3. Append new rows (direct file append, not full rewrite) ─────────────
    add_ts = datetime.datetime.now(datetime.timezone.utc).isoformat()

    with open(pool_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=REQUIRED_COLUMNS, extrasaction="ignore")
        for row in rows_to_append:
            entry = {col: row.get(col, "") for col in REQUIRED_COLUMNS}
            # Inject metadata if not present
            if not entry.get("source_round") and round_id is not None:
                entry["source_round"] = round_id
            if not entry.get("added_ts_utc"):
                entry["added_ts_utc"] = add_ts
            writer.writerow(entry)

    # ── 4. Verify immutability ────────────────────────────────────────────────
    with open(pool_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        new_header = reader.fieldnames or []
        new_rows_all = list(reader)

    expected_new_count = len(existing_rows) + len(rows_to_append)

    if list(new_header) != REQUIRED_COLUMNS:
        audit["violations"].append(f"Post-append header changed: {list(new_header)}")
        _write_audit(audit, pool_path, round_id, run_root)
        raise PoolImmutabilityError(f"Pool {pool_path} header changed after append.")

    if len(new_rows_all) != expected_new_count:
        audit["violations"].append(
            f"Row count mismatch: expected {expected_new_count}, got {len(new_rows_all)}"
        )
        _write_audit(audit, pool_path, round_id, run_root)
        raise PoolImmutabilityError(f"Pool {pool_path} row count wrong after append.")

    # Verify existing rows byte-identical
    for i, (orig, after) in enumerate(zip(existing_rows, new_rows_all)):
        if orig != after:
            audit["violations"].append(f"Row {i} changed: was {orig!r}, now {after!r}")
            _write_audit(audit, pool_path, round_id, run_root)
            raise PoolImmutabilityError(
                f"Pool {pool_path} row {i} modified during append. IMMUTABILITY VIOLATION."
            )

    audit["immutability_verified"] = True
    audit["success"] = True
    _write_audit(audit, pool_path, round_id, run_root)
    return audit


def _write_audit(audit: Dict, pool_path: Path, round_id: Optional[int], run_root: Optional[Path]):
    """Write per-pool per-round audit JSON."""
    if run_root is not None:
        audit_dir = Path(run_root) / "audits" / "pools"
    else:
        audit_dir = AUDIT_DIR
    audit_dir.mkdir(parents=True, exist_ok=True)

    pool_name = pool_path.stem
    rid_part = f"_round_{round_id}" if round_id is not None else ""
    fname = f"{pool_name}_append_audit{rid_part}.json"
    with open(audit_dir / fname, "w") as f:
        json.dump(audit, f, indent=2)
