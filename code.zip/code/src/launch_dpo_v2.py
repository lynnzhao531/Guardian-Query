import os
import sys
import json
import time
from pathlib import Path
from openai import OpenAI

BASE_DIR = Path(__file__).resolve().parent.parent

def get_api_key():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def main():
    api_key = get_api_key()
    if not api_key:
        print("Error: OPENAI_API_KEY not found")
        sys.exit(1)
        
    client = OpenAI(api_key=api_key)
    
    sft_model = "ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH"
    train_path = BASE_DIR / "fine_tune_data/dpo_train_v2.jsonl"
    val_path = BASE_DIR / "fine_tune_data/dpo_val_v2.jsonl"
    
    if not train_path.exists() or not val_path.exists():
        print("Error: DPO files not found.")
        sys.exit(1)
        
    print("Uploading DPO training file...")
    with open(train_path, "rb") as f:
        train_file = client.files.create(file=f, purpose="fine-tune")
        
    print("Uploading DPO validation file...")
    with open(val_path, "rb") as f:
        val_file = client.files.create(file=f, purpose="fine-tune")
        
    print(f"Train File ID: {train_file.id}")
    print(f"Val File ID:   {val_file.id}")
    
    print(f"Starting DPO job on base model {sft_model}...")
    
    # We use explicit DPO hyperparameters as used previously
    job = client.fine_tuning.jobs.create(
        model=sft_model,
        training_file=train_file.id,
        validation_file=val_file.id,
        method={
            "type": "dpo",
            "dpo": {
                "hyperparameters": {
                    "beta": 0.1,
                    "batch_size": 1,
                    "learning_rate_multiplier": 1.0,
                    "n_epochs": 3
                }
            }
        }
    )
    
    print(f"Job ID: {job.id}")
    print(f"Status: {job.status}")
    
    report = [
        "# DPO v2 Job Launch",
        f"- **Job ID**: `{job.id}`",
        f"- **Base Model**: `{sft_model}`",
        f"- **Training File**: `fine_tune_data/dpo_train_v2.jsonl` (ID: {train_file.id})",
        f"- **Validation File**: `fine_tune_data/dpo_val_v2.jsonl` (ID: {val_file.id})",
        "- **Status**: `validating_files`"
    ]
    
    rep_path = BASE_DIR / "reports/dpo_job_launch.md"
    with open(rep_path, "w") as f:
        f.write("\n".join(report))
        
    print(f"Launch report written to {rep_path}.")
    print("Run `python src/poll_dpo_job.py` or similar to track progress.")

if __name__ == "__main__":
    main()
