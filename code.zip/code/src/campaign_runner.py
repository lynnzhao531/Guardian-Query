"""
src/campaign_runner.py  —  Strict 8hr/70-round campaign runner with DPO gating.

Usage:
  python -m src.campaign_runner \\
    --max_rounds 70 --max_hours 8 --chunk_size 5 \\
    --dpo_candidates "dpo_a,dpo_b" \\
    --strict --append_only_pools

Exit codes:
  0  — clean exit (time or round limit reached)
  1  — internal error (should not happen; all failures are caught and mapped)
  2  — validator failure or anomaly
  3  — pool immutability violation
  4  — required output missing
"""

from __future__ import annotations

import argparse
import csv
import datetime
import glob
import json
import logging
import os
import re
import shutil
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ──────────────────────────────────────────────────────────────────────────────
# Project root on sys.path
# ──────────────────────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve()
PROJECT_ROOT = _HERE.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ──────────────────────────────────────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("campaign_runner")

# ──────────────────────────────────────────────────────────────────────────────
# Column contract for pool files
# ──────────────────────────────────────────────────────────────────────────────
REQUIRED_POOL_COLS = [
    "url_canon", "url", "title", "section", "publication_date_utc", "body_text",
    "source_round", "added_ts_utc", "credit", "tied_methods", "classified_method", "confidence_score"
]

# CSV names that must exist every round (relative to round output dir)
REQUIRED_ROUND_CSVS = [
    "round_{rid}_model1_papers.csv",
    "round_{rid}_model3_papers.csv",
    "round_{rid}_DPO_papers.csv",
    "round_{rid}_high_relevant_papers.csv",
]
REQUIRED_ROUND_PARQUET = "scored_results_full.parquet"


# ══════════════════════════════════════════════════════════════════════════════
# RoundIdManager
# ══════════════════════════════════════════════════════════════════════════════

class RoundIdManager:
    """
    Determines the next round id for this campaign run.

    Strategy (non-destructive):
      1. Read working/outputs/query_log.csv → find max valid round_id.
      2. Scan working/outputs/rounds/ for directories → find max from dir names.
      3. If the two agree and there are no gaps > 5 → use max+1 as next_id.
      4. If they disagree or significant gaps detected:
           - do NOT repair old logs
           - start campaign-local sequence from max(both_sources)+1
           - write campaign log to run_root/working/outputs/query_log_campaign.csv
           - use campaign_round_id in filenames (e.g. round_201)
    """

    def __init__(self, working_dir: Path, run_root: Path):
        self.working_dir = working_dir
        self.run_root = run_root
        self.use_campaign_log = False
        self.campaign_log_path = run_root / "working" / "outputs" / "query_log_campaign.csv"
        self.next_round_id: int = 1

    def resolve(self) -> int:
        log_path = self.working_dir / "outputs" / "query_log.csv"
        rounds_dir = self.working_dir / "outputs" / "rounds"

        max_log = self._max_from_log(log_path)
        max_dirs = self._max_from_dirs(rounds_dir)

        log.info(f"RoundIdManager: max_log={max_log} max_dirs={max_dirs}")

        discrepancy = abs((max_log or 0) - (max_dirs or 0)) > 5

        if discrepancy:
            log.warning(
                f"RoundIdManager: discrepancy detected (log={max_log}, dirs={max_dirs}). "
                f"Starting fresh campaign log."
            )
            self.use_campaign_log = True
            self.next_round_id = max((max_log or 0), (max_dirs or 0)) + 1
        else:
            max_id = max((max_log or 0), (max_dirs or 0))
            self.next_round_id = max_id + 1

        log.info(
            f"RoundIdManager: next_round_id={self.next_round_id}, "
            f"use_campaign_log={self.use_campaign_log}"
        )
        return self.next_round_id

    def _max_from_log(self, log_path: Path) -> Optional[int]:
        if not log_path.exists() or log_path.stat().st_size == 0:
            return None
        try:
            import pandas as pd
            df = pd.read_csv(log_path, usecols=["round_id"])
            if df.empty:
                return None
            return int(df["round_id"].max())
        except Exception as e:
            log.warning(f"RoundIdManager: failed to read {log_path}: {e}")
            return None

    def _max_from_dirs(self, rounds_dir: Path) -> Optional[int]:
        if not rounds_dir.exists():
            return None
        rids = []
        for d in rounds_dir.iterdir():
            m = re.match(r"^round_(\d+)$", d.name)
            if m:
                rids.append(int(m.group(1)))
        return max(rids) if rids else None


# ══════════════════════════════════════════════════════════════════════════════
# Preflight checks
# ══════════════════════════════════════════════════════════════════════════════

def preflight_checks(working_dir: Path, strict: bool) -> None:
    """Hard stop on failure (sys.exit(2))."""

    # 1. round_outputs_writer imported by round_runner
    _check_module_import("src.round_outputs_writer", "write_round_outputs")

    # 2. framework_contract validators available
    _check_module_import("src.framework_contract", "validate_repo_structure")

    # 3. Pool files exist and have correct header
    pools_dir = working_dir / "outputs" / "pools"
    if pools_dir.exists():
        for pool_file in pools_dir.glob("*.csv"):
            _check_pool_header(pool_file, strict)

    log.info("Preflight: ALL checks PASSED")


def _check_module_import(module: str, attr: str) -> None:
    try:
        import importlib
        m = importlib.import_module(module)
        if not hasattr(m, attr):
            _fatal(f"Module {module} missing attribute {attr}", exit_code=2)
        log.info(f"Preflight: {module}.{attr} OK")
    except ImportError as e:
        _fatal(f"Cannot import {module}: {e}", exit_code=2)


def _check_pool_header(pool_file: Path, strict: bool) -> None:
    try:
        with open(pool_file, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            header = next(reader, None)
        if header is None:
            log.warning(f"Pool file {pool_file} is empty (no header). Will init on first use.")
            return
        if list(header) != REQUIRED_POOL_COLS:
            msg = f"Pool {pool_file} header mismatch. Expected {REQUIRED_POOL_COLS}, got {header}"
            if strict:
                _fatal(msg, exit_code=2)
            else:
                log.warning(msg)
    except Exception as e:
        _fatal(f"Cannot read pool file {pool_file}: {e}", exit_code=2)


# ══════════════════════════════════════════════════════════════════════════════
# Round output validation
# ══════════════════════════════════════════════════════════════════════════════

def validate_round_outputs_strict(round_id: int, output_dir: Path, strict: bool) -> None:
    """Verify all 4 required CSVs and the parquet exist. sys.exit(4) if missing."""
    missing = []
    for tmpl in REQUIRED_ROUND_CSVS:
        fname = tmpl.format(rid=round_id)
        if not (output_dir / fname).exists():
            missing.append(fname)
    if not (output_dir / REQUIRED_ROUND_PARQUET).exists():
        missing.append(REQUIRED_ROUND_PARQUET)

    if missing:
        msg = f"Round {round_id}: missing required outputs: {missing}"
        if strict:
            _fatal(msg, exit_code=4)
        else:
            log.error(msg)


def validate_round_id_monotonic(round_id: int, prev_round_id: Optional[int], strict: bool) -> None:
    if prev_round_id is not None and round_id <= prev_round_id:
        msg = f"Non-monotonic round_id: {round_id} <= {prev_round_id}"
        if strict:
            _fatal(msg, exit_code=2)
        else:
            log.error(msg)


# ══════════════════════════════════════════════════════════════════════════════
# Pool append helper
# ══════════════════════════════════════════════════════════════════════════════

def pool_append_from_round(
    round_id: int,
    output_dir: Path,
    pools_dir: Path,
    run_root: Path,
    strict: bool,
    append_only: bool,
) -> Dict[str, int]:
    """
    Read round CSVs and append new rows into pool files.
    Returns dict of {pool_name: rows_appended}.
    """
    if not append_only:
        # Fall back to existing pool_manager
        from src.pool_manager import update_pools
        update_pools(round_id)
        return {}

    from src.pool_append_only import update_pool_append_only, PoolImmutabilityError
    import pandas as pd

    appended = {}

    # Consensus (overall pool)
    cons_csv = output_dir / f"round_{round_id}_high_relevant_papers.csv"
    overall_pool = pools_dir / "pool_overall.csv"
    if cons_csv.exists():
        try:
            df = pd.read_csv(cons_csv)
            if not df.empty:
                audit = update_pool_append_only(
                    overall_pool, df, round_id=round_id, run_root=run_root
                )
                appended["pool_overall"] = audit["appended_count"]
        except PoolImmutabilityError as e:
            _fatal(str(e), exit_code=3)
        except Exception as e:
            _fatal(f"Pool update error (overall): {e}", exit_code=2)

    # LLM/DPO pool (from DPO_papers.csv)
    dpo_csv = output_dir / f"round_{round_id}_DPO_papers.csv"
    llm_pool = pools_dir / "pool_llm.csv"
    if dpo_csv.exists():
        try:
            df = pd.read_csv(dpo_csv)
            if not df.empty:
                # Filter for high-relevance rows
                dec_cols = [c for c in df.columns if "_decision_score" in c]
                if dec_cols:
                    col = dec_cols[0]
                    df = df[df[col] == 1.0]
                if not df.empty:
                    # Add required pool columns if not already present
                    if "classified_method" not in df.columns:
                        df = df.copy()
                        df["classified_method"] = "unknown"
                    if "credit" not in df.columns:
                        df["credit"] = 1.0
                    if "tied_methods" not in df.columns:
                        df["tied_methods"] = ""
                    if "confidence_score" not in df.columns:
                        df["confidence_score"] = 0.0
                    audit = update_pool_append_only(
                        llm_pool, df, round_id=round_id, run_root=run_root
                    )
                    appended["pool_llm"] = audit["appended_count"]
        except PoolImmutabilityError as e:
            _fatal(str(e), exit_code=3)
        except Exception as e:
            _fatal(f"Pool update error (llm): {e}", exit_code=2)

    return appended


# ══════════════════════════════════════════════════════════════════════════════
# Query log append
# ══════════════════════════════════════════════════════════════════════════════

def append_campaign_log(
    round_id: int,
    metrics: Dict,
    use_campaign_log: bool,
    campaign_log_path: Path,
    working_log_path: Path,
) -> None:
    """Write one row to the active campaign query log."""
    import pandas as pd

    row = {
        "round_id": round_id,
        "timestamp_utc_iso": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        **metrics,
    }
    new_df = pd.DataFrame([row])

    target = campaign_log_path if use_campaign_log else working_log_path
    target.parent.mkdir(parents=True, exist_ok=True)

    if target.exists() and target.stat().st_size > 0:
        existing = pd.read_csv(target)
        existing = existing[existing["round_id"] != round_id]
        final = pd.concat([existing, new_df], ignore_index=True).sort_values("round_id")
        final.to_csv(target, index=False)
    else:
        new_df.to_csv(target, index=False)


# ══════════════════════════════════════════════════════════════════════════════
# Setup helpers
# ══════════════════════════════════════════════════════════════════════════════

def setup_run_root(run_root: Optional[str], strict: bool) -> Path:
    """Create run_root, snapshot originals, set up working dirs."""
    if run_root:
        root = Path(run_root)
    else:
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        root = PROJECT_ROOT / "runs" / f"run_{ts}_strict70"

    root.mkdir(parents=True, exist_ok=True)
    log.info(f"Run root: {root}")

    # Snapshot
    snap = root / "snapshots"
    snap.mkdir(exist_ok=True)
    _safe_copy_tree(PROJECT_ROOT / "project_state", snap / "project_state")
    query_log = PROJECT_ROOT / "outputs" / "query_log.csv"
    if query_log.exists():
        shutil.copy2(query_log, snap / "query_log.csv")
    _safe_copy_tree(PROJECT_ROOT / "outputs" / "pools", snap / "pools")

    # Working directory
    working = root / "working"
    working.mkdir(exist_ok=True)
    _safe_copy_tree(PROJECT_ROOT / "project_state", working / "project_state")
    _safe_copy_tree(PROJECT_ROOT / "outputs", working / "outputs")

    log.info(f"Snapshots in: {snap}")
    log.info(f"Working dir: {working}")
    return root


def _safe_copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    if src.is_file():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    else:
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)


# ══════════════════════════════════════════════════════════════════════════════
# Fatal helper
# ══════════════════════════════════════════════════════════════════════════════

def _fatal(msg: str, exit_code: int = 2) -> None:
    log.error(f"FATAL [exit {exit_code}]: {msg}")
    sys.exit(exit_code)


# ══════════════════════════════════════════════════════════════════════════════
# Main loop
# ══════════════════════════════════════════════════════════════════════════════

def run_campaign(args) -> None:
    start_time = time.time()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # ── 0. Create run root & snapshot ─────────────────────────────────────────
    run_root = setup_run_root(args.run_root, args.strict)
    working = run_root / "working"
    working_outputs = working / "outputs"
    working_pools = working_outputs / "pools"

    print(f"\n{'='*70}")
    print(f"CAMPAIGN RUNNER  {timestamp}")
    print(f"  run_root       : {run_root}")
    print(f"  working        : {working}")
    print(f"  max_rounds     : {args.max_rounds}")
    print(f"  max_hours      : {args.max_hours}")
    print(f"  chunk_size     : {args.chunk_size}")
    print(f"  dpo_candidates : {args.dpo_candidates}")
    print(f"  strict         : {args.strict}")
    print(f"  append_only    : {args.append_only_pools}")
    print(f"{'='*70}\n")

    # ── 1. Preflight ──────────────────────────────────────────────────────────
    preflight_checks(working, args.strict)

    # ── 2. RoundIdManager ──────────────────────────────────────────────────────
    rim = RoundIdManager(working, run_root)
    next_rid = rim.resolve()
    use_campaign_log = rim.use_campaign_log
    campaign_log_path = rim.campaign_log_path
    working_log_path = working_outputs / "query_log.csv"

    dpo_candidates = [c.strip() for c in args.dpo_candidates.split(",")]
    log.info(f"DPO candidates: {dpo_candidates}")

    # Track active llm_final override
    active_dpo: Optional[str] = None
    baseline_proto_pass = 0  # updated after first successful gate

    rounds_run = 0
    prev_round_id: Optional[int] = None
    campaign_summary: Dict = {
        "start_time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "run_root": str(run_root),
        "rounds": [],
        "dpo_gates": [],
        "errors": [],
    }

    # ── 3. Main loop ──────────────────────────────────────────────────────────
    current_rid = next_rid

    while True:
        elapsed_h = (time.time() - start_time) / 3600
        if elapsed_h >= args.max_hours:
            log.info(f"Time limit {args.max_hours}h reached. Stopping.")
            break
        if rounds_run >= args.max_rounds:
            log.info(f"Round limit {args.max_rounds} reached. Stopping.")
            break

        log.info(f"\n{'─'*60}\nROUND {current_rid} (run #{rounds_run + 1})\n{'─'*60}")

        # Monotonicity check
        validate_round_id_monotonic(current_rid, prev_round_id, args.strict)

        # Round output dir (in working)
        round_out_dir = working_outputs / "rounds" / f"round_{current_rid}"
        round_out_dir.mkdir(parents=True, exist_ok=True)

        # Apply DPO override to state if active
        if active_dpo:
            _apply_dpo_override(working, active_dpo)

        # ── Run round ────────────────────────────────────────────────────────
        round_audit: Dict = {
            "round_id": current_rid,
            "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "round_out_dir": str(round_out_dir),
        }

        try:
            metrics = _run_single_round(current_rid, working, run_root)
            round_audit["metrics"] = metrics
            round_audit["success"] = True
        except SystemExit as e:
            _fatal(f"round_runner sys.exit({e.code}) in round {current_rid}", exit_code=int(e.code or 2))
        except Exception as e:
            tb = traceback.format_exc()
            log.error(f"Round {current_rid} exception: {e}\n{tb}")
            if args.strict:
                _fatal(f"Round {current_rid} failed: {e}", exit_code=2)
            else:
                round_audit["success"] = False
                round_audit["error"] = str(e)

        # ── Validate outputs ─────────────────────────────────────────────────
        validate_round_outputs_strict(current_rid, round_out_dir, args.strict)

        # ── Pool update (append-only) ─────────────────────────────────────────
        pool_counts = pool_append_from_round(
            current_rid, round_out_dir, working_pools, run_root,
            args.strict, args.append_only_pools
        )
        round_audit["pool_appended"] = pool_counts

        # ── Per-round audit JSON ──────────────────────────────────────────────
        audit_dir = run_root / "audits" / f"round_{current_rid}"
        audit_dir.mkdir(parents=True, exist_ok=True)
        with open(audit_dir / "round_campaign_audit.json", "w") as f:
            json.dump(round_audit, f, indent=2, default=str)

        # ── Append query log ──────────────────────────────────────────────────
        if round_audit.get("metrics"):
            append_campaign_log(
                current_rid, round_audit["metrics"],
                use_campaign_log, campaign_log_path, working_log_path
            )

        # ── Print per-round summary ───────────────────────────────────────────
        m = round_audit.get("metrics", {})
        print(
            f"  [R{current_rid}] "
            f"pages={m.get('guardian_pages_fetched', '?')} "
            f"candidates={m.get('guardian_candidates_retrieved', '?')} "
            f"scored={m.get('scored_count', '?')} "
            f"m1_high={m.get('high_rel_model1_count', '?')} "
            f"m3_high={m.get('high_rel_model3_count', '?')} "
            f"dpo_high={m.get('high_rel_dpo_count', '?')} "
            f"consensus={m.get('consensus_high_rel_count', '?')} "
            f"pool_appended={pool_counts} "
            f"cost=${m.get('query_cost_this_round_usd', 0):.4f}"
        )

        campaign_summary["rounds"].append(round_audit)
        prev_round_id = current_rid
        rounds_run += 1
        current_rid += 1

        # ── DPO gate every chunk_size rounds ──────────────────────────────────
        if rounds_run % args.chunk_size == 0:
            chunk_id = rounds_run // args.chunk_size
            log.info(f"Chunk {chunk_id} complete. Running DPO gate...")

            from src.dpo_gate import run_dpo_gate
            try:
                selected = run_dpo_gate(
                    candidates=dpo_candidates,
                    chunk_id=chunk_id,
                    run_root=run_root,
                    baseline_prototype_pass=baseline_proto_pass,
                )
            except Exception as e:
                log.error(f"DPO gate exception at chunk {chunk_id}: {e}")
                selected = None

            gate_result = {
                "chunk_id": chunk_id,
                "rounds_completed": rounds_run,
                "selected_model": selected,
            }
            campaign_summary["dpo_gates"].append(gate_result)

            if selected:
                log.info(f"DPO gate PASSED: switching llm_final to {selected}")
                active_dpo = selected
                print(f"  [DPO GATE chunk {chunk_id}] SELECTED: {selected}")
            else:
                log.info(f"DPO gate: no candidate passed. Remaining on current llm_final.")
                print(f"  [DPO GATE chunk {chunk_id}] No candidate passed. Using SFT.")

            # Write chunk audit
            chunk_audit_dir = run_root / "audits"
            chunk_audit_dir.mkdir(exist_ok=True)
            with open(chunk_audit_dir / f"chunk_{chunk_id}_audit.json", "w") as f:
                json.dump(gate_result, f, indent=2)

    # ── 4. Final summary ──────────────────────────────────────────────────────
    elapsed_h = (time.time() - start_time) / 3600
    campaign_summary["end_time_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    campaign_summary["elapsed_hours"] = round(elapsed_h, 4)
    campaign_summary["rounds_run"] = rounds_run
    campaign_summary["final_active_dpo"] = active_dpo

    summary_path = run_root / "audits" / "campaign_summary.json"
    summary_path.parent.mkdir(exist_ok=True)
    with open(summary_path, "w") as f:
        json.dump(campaign_summary, f, indent=2, default=str)

    print(f"\n{'='*70}")
    print(f"CAMPAIGN COMPLETE")
    print(f"  rounds_run  : {rounds_run}")
    print(f"  elapsed_hrs : {elapsed_h:.2f}")
    print(f"  active_dpo  : {active_dpo or 'SFT baseline'}")
    print(f"  summary     : {summary_path}")
    print(f"{'='*70}\n")


def _apply_dpo_override(working: Path, dpo_model: str) -> None:
    """Write LLM_FINAL_OVERRIDE.json into working/project_state so round_runner picks it up."""
    override = {
        "active_llm_final": dpo_model,
        "set_by": "campaign_runner",
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    override_path = working / "project_state" / "LLM_FINAL_OVERRIDE.json"
    override_path.parent.mkdir(parents=True, exist_ok=True)
    with open(override_path, "w") as f:
        json.dump(override, f, indent=2)
    log.debug(f"DPO override written: {override_path}")


def _run_single_round(round_id: int, working: Path, run_root: Path) -> Dict:
    """
    Call run_round() with working directory overrides.
    Returns metrics dict extracted from query log rows.
    """
    import importlib

    # Change working directory temporarily so relative paths in round_runner resolve
    original_cwd = os.getcwd()
    working_outputs = working / "outputs"
    working_outputs.mkdir(parents=True, exist_ok=True)

    # Symlink or copy project_state into cwd if not already there
    # We stay in PROJECT_ROOT but override the output paths by patching env
    os.chdir(PROJECT_ROOT)  # round_runner uses relative paths from PROJECT_ROOT

    # Override STATE.json location: round_runner reads project_state/STATE.json relative to BASE_DIR
    # The working/project_state copy is our active state; we patch the STATE_PATH in round_runner
    import src.round_runner as rr
    original_state_path = rr.STATE_PATH

    working_state = working / "project_state" / "STATE.json"
    if working_state.exists():
        rr.STATE_PATH = working_state
    else:
        rr.STATE_PATH = original_state_path

    # Override query_log path to write to working outputs
    # (append_query_log uses a hardcoded relative path; we redirect via monkey-patch)
    original_append_log = rr.append_query_log

    def patched_append_log(rid, metrics):
        import pandas as pd
        path = working_outputs / "query_log.csv"
        row = {
            "round_id": rid,
            "timestamp_utc_iso": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            **metrics,
        }
        new_df = pd.DataFrame([row])
        if path.exists() and path.stat().st_size > 0:
            existing = pd.read_csv(path)
            existing = existing[existing["round_id"] != rid]
            final = pd.concat([existing, new_df], ignore_index=True).sort_values("round_id")
            final.to_csv(path, index=False)
        else:
            new_df.to_csv(path, index=False)

    rr.append_query_log = patched_append_log

    # Also check for LLM_FINAL_OVERRIDE and inject into state
    override_path = working / "project_state" / "LLM_FINAL_OVERRIDE.json"
    if override_path.exists():
        try:
            with open(override_path) as f:
                override = json.load(f)
            effective_dpo = override.get("active_llm_final")
            if effective_dpo:
                # Patch STATE.json temporarily to reflect the active model
                if working_state.exists():
                    with open(working_state) as f:
                        state = json.load(f)
                    state["dpo_model_name"] = effective_dpo
                    with open(working_state, "w") as f:
                        json.dump(state, f, indent=2)
                    log.info(f"Injected DPO override '{effective_dpo}' into working STATE.json")
        except Exception as e:
            log.warning(f"Could not apply DLM_FINAL_OVERRIDE: {e}")

    try:
        rr.run_round(round_id, dry_run=False)
    finally:
        # Restore
        rr.STATE_PATH = original_state_path
        rr.append_query_log = original_append_log
        os.chdir(original_cwd)

    # Extract metrics from working log
    working_log = working_outputs / "query_log.csv"
    if working_log.exists():
        try:
            import pandas as pd
            df = pd.read_csv(working_log)
            row = df[df["round_id"] == round_id]
            if not row.empty:
                return row.iloc[0].to_dict()
        except Exception:
            pass
    return {}


# ══════════════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Strict campaign runner: 8hr / 70 rounds with DPO gating."
    )
    parser.add_argument("--max_rounds", type=int, default=70)
    parser.add_argument("--max_hours", type=float, default=8.0)
    parser.add_argument("--chunk_size", type=int, default=5)
    parser.add_argument("--run_root", type=str, default=None,
                        help="Path to run root. Default: runs/run_TIMESTAMP_strict70/")
    parser.add_argument("--dpo_candidates", type=str, default="dpo_a,dpo_b",
                        help="Comma-separated DPO model IDs to evaluate at each chunk.")
    parser.add_argument("--strict", action="store_true", default=True,
                        help="Strict mode: stop on any anomaly.")
    parser.add_argument("--append_only_pools", action="store_true", default=True,
                        help="Use strict append-only pool update.")
    args = parser.parse_args()

    run_campaign(args)


if __name__ == "__main__":
    main()
