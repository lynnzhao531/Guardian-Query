import pandas as pd
import numpy as np
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INPUT_CSV = ROOT / "outputs" / "master_vector.csv"
REPORT_PATH = ROOT / "reports" / "model3_data_audit_report.md"

def audit():
    print(f"Loading {INPUT_CSV}...")
    df = pd.read_csv(INPUT_CSV)
    
    # 1. Schema check
    cols = df.columns.tolist()
    
    # Canonical labels
    label_cols = [
        "decision",
        "method_rct",
        "method_prepost",
        "method_case_study",
        "method_expert_qual",
        "method_expert_secondary",
        "method_gut"
    ]
    
    # Handle expert_secondary alias
    if "method_expert_corr" in df.columns and "method_expert_secondary" not in df.columns:
        print("Renaming expert_corr -> expert_secondary")
        df["method_expert_secondary"] = df["method_expert_corr"]
    
    # Text fields
    text_fields = ["title", "body"]
    if "bodyText" in df.columns and "body" not in df.columns:
        df["body"] = df["bodyText"]
    
    # Unique articles
    id_col = "url_canon" if "url_canon" in df.columns else "id"
    unique_articles = df[id_col].nunique()
    dupes = df.duplicated(subset=[id_col]).sum()
    
    # 2. Label normalization & validation
    valid_values = {0.0, 0.5, 1.0}
    
    audit_lines = [
        "# Model 3 Data Audit Report",
        f"\n**File**: {INPUT_CSV.name}",
        f"**Shape**: {df.shape}",
        f"**Unique Articles ({id_col})**: {unique_articles}",
        f"**Duplicates**: {dupes}\n",
        "## Schema",
        f"- **ID column**: {id_col}",
        f"- **Text columns**: {text_fields}",
        f"- **Label columns**: {label_cols}\n",
        "## Missingness & Distribution"
    ]
    
    audit_lines.append("| Column | Missing Rate | 0.0 | 0.5 | 1.0 | Other |")
    audit_lines.append("|--------|--------------|-----|-----|-----|-------|")
    
    for col in label_cols:
        if col not in df.columns:
            audit_lines.append(f"| {col} | 100% | - | - | - | - |")
            continue
            
        # Convert to numeric, handle errors
        df[col] = pd.to_numeric(df[col], errors='coerce')
        
        missing_rate = df[col].isna().mean()
        counts = df[col].value_counts(dropna=False).to_dict()
        
        c0 = counts.get(0.0, 0)
        c05 = counts.get(0.5, 0)
        c1 = counts.get(1.0, 0)
        
        # Check for invalid values
        other = []
        for val, count in counts.items():
            if not np.isnan(val) and val not in valid_values:
                other.append(f"{val} ({count})")
        
        other_str = ", ".join(other) if other else "-"
        
        audit_lines.append(f"| {col} | {missing_rate:.1%} | {c0} | {c05} | {c1} | {other_str} |")
        
        if other:
            print(f"ERROR: Invalid labels found in {col}: {other_str}")
            # we don't sys.exit(1) here yet, just report
            
    # Example rows
    audit_lines.append("\n## Example Rows (Sample)")
    sample = df.sample(min(5, len(df)))
    cols_to_show = [id_col] + text_fields + label_cols
    audit_lines.append(sample[cols_to_show].to_markdown())
    
    # Save report
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\n".join(audit_lines))
    print(f"Report written to {REPORT_PATH}")

if __name__ == "__main__":
    audit()
