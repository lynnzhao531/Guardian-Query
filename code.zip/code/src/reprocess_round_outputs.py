import pandas as pd
from pathlib import Path
from src.round_outputs_writer import write_round_outputs

def reprocess_round(round_id):
    parquet_path = f"outputs/rounds/round_{round_id}/scored_results_full.parquet"
    if not Path(parquet_path).exists():
        print(f"Error: {parquet_path} missing.")
        return
        
    print(f"Reprocessing Round {round_id}...")
    write_round_outputs(round_id, parquet_path)
    print("Done.")

if __name__ == "__main__":
    import sys
    rid = int(sys.argv[1]) if len(sys.argv) > 1 else 28
    reprocess_round(rid)
