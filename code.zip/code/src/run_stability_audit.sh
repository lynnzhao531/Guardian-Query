#!/bin/bash
set -e

NEXT_ID=30
END_ID=39

echo "Starting Stability Run for Rounds $NEXT_ID to $END_ID..."

for i in $(seq $NEXT_ID $END_ID)
do
    echo "========================================"
    echo "RUNNING ROUND $i"
    echo "========================================"
    export PYTHONPATH=$PYTHONPATH:.
    python src/round_runner.py --round_id $i
    
    echo "AUDITING ROUND $i..."
    python src/audit_round_integrity.py $i
done

echo "STABILITY RUN COMPLETE. GENERATING REPORTS..."
python src/generate_summary_reports.py

echo "ALL DONE."
