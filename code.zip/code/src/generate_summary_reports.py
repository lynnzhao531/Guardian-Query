import pandas as pd
import json
from pathlib import Path
import os

def generate_reports(start_id, end_id):
    print(f"Generating Summary Reports for Rounds {start_id} to {end_id}...")
    
    query_log = pd.read_csv("outputs/query_log.csv")
    rounds_range = list(range(start_id, end_id + 1))
    
    # Filter for the stability run rounds
    # We take the LAST entry for each round_id in case of re-runs
    stable_log = query_log[query_log["round_id"].isin(rounds_range)].drop_duplicates(subset=["round_id"], keep="last")
    
    # Collect Pool Stats
    pool_rows = []
    for rid in rounds_range:
        audit_path = Path(f"audits/round_{rid}/pool_update_audit.json")
        if audit_path.exists():
            with open(audit_path, "r") as f:
                audit = json.load(f)
            pool_rows.append({
                "round_id": rid,
                "overall_rows_appended": audit.get("overall_appended", 0),
                "llm_rows_appended": audit.get("llm_appended", 0),
                "duplicates_skipped": audit.get("duplicates_skipped", 0)
            })
        else:
            pool_rows.append({
                "round_id": rid,
                "overall_rows_appended": 0,
                "llm_rows_appended": 0,
                "duplicates_skipped": 0
            })
    
    pool_df = pd.DataFrame(pool_rows)
    
    # Merge
    summary_df = stable_log.merge(pool_df, on="round_id", how="left")
    
    # Select Columns for CSV
    summary_cols = [
        "round_id", "template_id", "target_method", "backoff_level_used",
        "guardian_total_available", "skipped_live_count", "skipped_long_count", "skipped_missing_text_count",
        "scored_count", "high_rel_llm_final_count", "consensus_high_rel_count",
        "overall_rows_appended", "llm_rows_appended", "duplicates_skipped",
        "query_cost_this_round_usd"
    ]
    # Filter for columns that actually exist
    final_cols = [c for c in summary_cols if c in summary_df.columns]
    
    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)
    
    summary_df[final_cols].to_csv(reports_dir / "next10_rounds_summary.csv", index=False)
    
    # Generate Markdown Table
    md_table = summary_df[final_cols].to_markdown(index=False)
    
    with open(reports_dir / "next10_rounds_summary.md", "w") as f:
        f.write("# Stability Run Summary - 10 Rounds\n\n")
        f.write(md_table)
        f.write("\n\n## Yield Interpretation\n")
        f.write("- **Stable Yield**: Scored count consistency.\n")
        f.write("- **Consensus Quality**: Consensus vs LLM high-rel ratio.\n")
        f.write("- **Pool Saturation**: Growth and duplicates.\n")

    # Step 4: Manual Audit Sample
    sample_rows = []
    for rid in rounds_range:
        pq_path = Path(f"outputs/rounds/round_{rid}/scored_results_full.parquet")
        if not pq_path.exists(): continue
        
        df = pd.read_parquet(pq_path)
        if df.empty: continue
        
        from src.round_outputs_writer import compute_consensus, check_pass_dec, check_pass_meth
        
        # Consensus Items
        df["is_consensus"] = df.apply(lambda r: compute_consensus(r) is not None, axis=1)
        consensus_items = df[df["is_consensus"]].sort_values("llm_final_decision_p1", ascending=False).head(3)
        for _, r in consensus_items.iterrows():
            sample_rows.append({
                "round_id": rid,
                "type": "CONSENSUS",
                "title": r["title"],
                "url": r["url_canon"],
                "section": r["section"],
                "classified_method": r.get("classified_method", "unknown"), # compute_consensus result? 
                "confidence_score": r["llm_final_decision_p1"],
                "reason": "Passed all gates"
            })
            
        # Near Misses
        # high llm_final_decision_p1 but blocked
        llm_pass_dec = df[df["llm_final_decision_score"] == 1.0]
        near_misses = llm_pass_dec[~df["is_consensus"]].sort_values("llm_final_decision_p1", ascending=False).head(3)
        for _, r in near_misses.iterrows():
            # Determine reason
            m3_meth_pass = check_pass_meth(r, "model3")
            # topset check? 
            # for now simplify
            reason = "Blocked by Model3 Meth" if not m3_meth_pass else "Blocked by Agreement"
            sample_rows.append({
                "round_id": rid,
                "type": "NEAR-MISS",
                "title": r["title"],
                "url": r["url_canon"],
                "section": r["section"],
                "classified_method": "N/A",
                "confidence_score": r["llm_final_decision_p1"],
                "reason": reason
            })
            
    pd.DataFrame(sample_rows).to_csv(reports_dir / "next10_manual_audit_sample.csv", index=False)
    print("Reports generated successfully.")

if __name__ == "__main__":
    generate_reports(30, 39)
