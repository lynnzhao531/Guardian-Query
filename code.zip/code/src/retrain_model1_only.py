import pandas as pd
import numpy as np
import joblib
import json
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from scipy.sparse import hstack, csr_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score

from src.tgml.theory_features import TheoryFeaturizer
from src.scorers import InferenceFeaturePipeline
from src.tgml.models import OrdinalClassifier
from src.my_model1_feature_pipeline import MyFeaturePipeline

if __name__ == "__main__":
    print("Loading data...")
    df = pd.read_parquet("outputs/master_vector.parquet")
    df["text_for_model"] = df["title"].fillna("") + "\n\n" + df["body"].fillna("")
    
    # Clean rows without targets
    df = df.dropna(subset=["decision"])
    
    train_df, val_df = train_test_split(df, test_size=0.15, random_state=42)
    
    print("Fitting TF-IDF...")
    word_tfidf = TfidfVectorizer(ngram_range=(1,2), lowercase=True, strip_accents="unicode", sublinear_tf=True)
    word_tfidf.fit(train_df["text_for_model"])
    
    char_tfidf = TfidfVectorizer(analyzer="char_wb", ngram_range=(3,5), lowercase=True, strip_accents="unicode", sublinear_tf=True)
    char_tfidf.fit(train_df["text_for_model"])
    
    print("Extracting theory features...")
    theory_feat = TheoryFeaturizer()
    theory_train_df = theory_feat.transform(train_df)
    theory_col_order = list(theory_train_df.columns)
    
    my_pipe = MyFeaturePipeline(word_tfidf, char_tfidf, theory_col_order)
    
    print("Transforming train and val...")
    X_train = my_pipe.transform(train_df)
    X_val = my_pipe.transform(val_df)
    
    # Save inference artifact explicitly importing itself so module refs hold.
    pipeline_obj = InferenceFeaturePipeline(my_pipe)
    os.makedirs("models/tgml", exist_ok=True)
    joblib.dump(pipeline_obj, "models/tgml/tfidf_vectorizer.joblib")
    
    base_lr = LogisticRegression(class_weight="balanced", solver="saga", max_iter=5000)
    
    print("Training Decision...")
    dec_clf = OrdinalClassifier(base_estimator=base_lr, classes=[0.0, 0.5, 1.0])
    dec_clf.fit(X_train, train_df["decision"])
    joblib.dump(dec_clf, "models/tgml/model_decision.joblib")
    
    val_preds = dec_clf.predict(X_val)
    # Cast to string for F1 to avoid "continuous" type detection
    y_true_str = [str(v) for v in val_df["decision"]]
    y_pred_str = [str(v) for v in val_preds]
    val_dec_f1 = f1_score(y_true_str, y_pred_str, average="macro")
    val_dec_acc = accuracy_score(y_true_str, y_pred_str)
    
    # Test degeneracy (mean probability of 1)
    val_probs_dec = dec_clf.predict_proba(X_val)
    mean_p1_dec = val_probs_dec[:, 2].mean()
    
    METHODS = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
    val_metrics = {}
    m_probs_list = []
    
    for m in METHODS:
        col = f"method_{m}"
        mask_train = train_df[col].notna()
        mask_val = val_df[col].notna()
        
        if mask_train.sum() > 0:
            print(f"Training {col}...")
            clf = OrdinalClassifier(base_estimator=base_lr, classes=[0.0, 0.5, 1.0])
            clf.fit(X_train[mask_train], train_df.loc[mask_train, col])
            joblib.dump(clf, f"models/tgml/model_method_{m}.joblib")
            
            if mask_val.sum() > 0:
                preds = clf.predict(X_val[mask_val])
                y_true_m = [str(v) for v in val_df.loc[mask_val, col]]
                y_pred_m = [str(v) for v in preds]
                val_metrics[col] = {
                    "f1": float(f1_score(y_true_m, y_pred_m, average="macro")),
                    "acc": float(accuracy_score(y_true_m, y_pred_m))
                }
                
            # Keep predictions over the entire val set for degeneracy check
            m_probs = clf.predict_proba(X_val)[:, 2]
            m_probs_list.append(m_probs)
        else:
            print(f"Skipping {col} - no train data")
            if os.path.exists(f"models/tgml/model_method_{m}.joblib"):
                 os.remove(f"models/tgml/model_method_{m}.joblib")
            
    m_probs_arr = np.array(m_probs_list)
    max_method_p1 = m_probs_arr.max(axis=0) if len(m_probs_list) > 0 else np.zeros(len(val_df))
    std_max_method_p1 = max_method_p1.std()
    
    print("\n--- Writing Reports ---")
    report = f"""# Model 1 Retraining Report

## Data Splits
- **Train Size:** {len(train_df)}
- **Validation Size:** {len(val_df)}

## Dimensionality
- **Word TF-IDF Features:** {len(word_tfidf.vocabulary_)}
- **Char TF-IDF Features:** {len(char_tfidf.vocabulary_)}
- **Theory Features:** {len(theory_col_order)}
- **Total Dimensions:** {X_train.shape[1]}

## Performance (Validation Set)
### Decision Classifier
- **Macro F1:** {val_dec_f1:.3f}
- **Accuracy:** {val_dec_acc:.3f}
- **Calibration Mean P(1):** {mean_p1_dec:.3f}

### Method Classifiers
"""
    for m in val_metrics:
        report += f"- **{m}**: Macro F1 {val_metrics[m]['f1']:.3f} | Accuracy {val_metrics[m]['acc']:.3f}\n"

    report += f"""
## Degeneracy Diagnostics
- **Std Dev of Max_Method P1 on Val:** {std_max_method_p1:.4f}  (Must not be ~0)
"""
    os.makedirs("reports", exist_ok=True)
    with open("reports/model1_retrain_report.md", "w") as f:
        f.write(report)
        
    print("Done!")
