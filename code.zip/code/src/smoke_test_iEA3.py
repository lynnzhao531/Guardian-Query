import os
import sys
import json
import pandas as pd
from openai import OpenAI
from pathlib import Path

# Add project root to sys.path
sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.llm_output_sanitize import sanitize_model_json
from src.validate_nested_schema import validate_nested_schema

# Configuration
MODEL_NAME = "ft:gpt-4.1-mini-2025-04-14:personal::DCEHUg6q"
CSV_PATH = "reports/smoke_set_30.csv"
REPORT_PATH = "reports/ftjob_iEA3_smoke.md"
DECISION_PATH = "reports/ftjob_iEA3_decision.md"

def get_api_key():
    env_path = Path(".env")
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip()
    return os.getenv("OPENAI_API_KEY")

def run_test():
    api_key = get_api_key()
    client = OpenAI(api_key=api_key)
    
    df = pd.read_csv(CSV_PATH)
    articles = df.to_dict("records")
    
    results = []
    
    system_prompt = """Output ONLY JSON. No prose. No markdown. Do not repeat.

CONSERVATIVE SCORING RULES (NON-NEGOTIABLE):
- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.
- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').
- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).
- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present.

Output ONLY valid JSON matching the schema. No prose. No markdown.
"""

    for art in articles:
        url = art["url_canon"]
        text = art["body_text"][:15000] # Standard truncation
        
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Evidence:\n{text}"}
                ],
                max_tokens=250,
                temperature=0
            )
            raw_text = response.choices[0].message.content
            ok, data, reason = sanitize_model_json(raw_text)
            
            # Strict schema validation
            schema_errors = []
            if ok:
                schema_errors = validate_nested_schema(json.dumps(data))
                if schema_errors:
                    ok = False
                    reason = f"schema_error: {schema_errors[0]}"
            
            results.append({
                "url": url,
                "success": ok,
                "data": data if ok else None,
                "raw": raw_text,
                "reason": reason
            })
        except Exception as e:
            results.append({
                "url": url,
                "success": False,
                "data": None,
                "raw": str(e),
                "reason": "api_error"
            })

    valid_count = sum(1 for r in results if r["success"])
    valid_rate = valid_count / len(results)
    
    # Analyze failures
    failure_reasons = {}
    missing_decision = False
    for r in results:
        if not r["success"]:
            reason = r["reason"]
            failure_reasons[reason] = failure_reasons.get(reason, 0) + 1
            if "missing_dims" in reason and "decision" in reason:
                missing_decision = True
                
    # Generate smoke report
    smoke_report = [
        "# DPO Smoke Test: `ft:gpt-4.1-mini-2025-04-14:personal::DCEHUg6q`",
        f"\n- **Valid Rate**: {valid_rate:.2%}",
        "\n## Top Failure Reasons",
        f"```json\n{json.dumps(failure_reasons, indent=2)}\n```"
    ]
    
    smoke_report.append("\n## Valid Outputs (3)")
    valid_samples = [r for r in results if r["success"]][:3]
    for i, s in enumerate(valid_samples):
        smoke_report.append(f"### Valid {i+1}\n**URL**: {s['url']}\n```json\n{json.dumps(s['data'], indent=2)}\n```")
        
    smoke_report.append("\n## Failure Excerpts (3)")
    failure_samples = [r for r in results if not r["success"]][:3]
    for i, f in enumerate(failure_samples):
        smoke_report.append(f"### Failure {i+1}: {f['reason']}\n**URL**: {f['url']}\n```\n{f['raw'][:500]}\n```")
        
    with open(REPORT_PATH, "w") as f:
        f.write("\n".join(smoke_report))
        
    # Generate Decision Memo
    if valid_rate >= 0.8 and not missing_decision:
        memo = "PASS: The model meets the minimum reliability threshold and correctly implements the required decision dimension. I recommend adding it as an 'alternate DPO model' for shadow comparison only (not production) to further evaluate its performance against the current primary model in a non-critical environment."
    else:
        fail_reason = "low valid rate" if valid_rate < 0.8 else "missing decision dimension"
        memo = f"FAIL: The model did not meet the required standards due to {fail_reason}. I recommend never using this model as it may lead to pipeline failures or inconsistent scoring."
        
    with open(DECISION_PATH, "w") as f:
        f.write("# Decision Memo: `ftjob-iEA3` Inspection\n\n" + memo + "\n")
        
    print(f"DONE. Valid rate: {valid_rate:.2%}")

if __name__ == "__main__":
    run_test()
