import pandas as pd
from pathlib import Path
import datetime
import json
import logging
import shutil
import sys

# Setup
logging.basicConfig(level=logging.INFO)
BASE_DIR = Path(__file__).resolve().parent.parent
LOG_PATH = BASE_DIR / "outputs/query_log.csv"
CONTRACT_PATH = BASE_DIR / "project_state/CONTRACT.json"
AUDIT_REPORT_PATH = BASE_DIR / "audits/query_log_repair_audit.md"

def get_current_contract_hash():
    # Only if we track hash calculation here? 
    # Actually, the log contains "contract_sha256". 
    # We should match it against the current calculated hash or just the text in CONTRACT if stored?
    # The log has the hash. We should re-calculate current contract hash.
    # But for now, we trust the log's valid rows are those that match the *latest* valid state?
    # User said: "keep only rows that... have contract_sha256 matching current CONTRACT.json"
    # This implies we must compute the hash of the current CONTRACT.json to filter.
    
    # We need the hashing logic. 
    # It seems to be in src/framework_hashes_check.py or similar?
    # Let's import if possible, or re-implement simple sha256 of file content.
    import hashlib
    with open(CONTRACT_PATH, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def validate_row_logic(row):
    # Re-implement strict logic checks from contract (as we can't easily call contract function on row obj without adapting)
    # 1. REPAIRED Check
    if row.get("query_final") == "REPAIRED_LOG_ENTRY":
        return False, "REPAIRED_LOG_ENTRY placeholder"
        
    # 2. Pages/Candidates
    p = row.get("guardian_pages_fetched", 0)
    c = row.get("guardian_candidates_retrieved", 0)
    if p == 0 and c > 0:
        return False, f"Impossible state: pages=0, candidates={c}"
        
    # 3. Supply Band in RUN mode? 
    # We are cleaning up. If a row violates supply band but is recorded (halted=True?), we keep it? 
    # If it violates supply band (total > 2500) and scored_count > 0, it's a violation.
    # We should drop it? 
    # User said: "keep only rows that pass validate_query_log()".
    # validate_query_log calls validate_query_final_constraints.
    # So yes, supply band violation rows should be dropped.
    
    total = row.get("guardian_total_available", 0)
    scored = row.get("scored_count", 0)
    
    # We need to know if it was run in RUN mode? Config changes. 
    # But the validator checks config.current. 
    # If we are in RUN mode NOW, previous DEV rows might fail?
    # User said "In RUN mode: ... halt". 
    # If we are cleaning up, we assume we want a clean log compliant with CURRENT standards.
    # If total > 2500 and scored > 0, it's bad data (contract violation).
    if total > 2500 and scored > 0:
         return False, f"Supply band violation: total={total}, scored={scored}"
         
    return True, "Valid"

def fix_query_log():
    if not LOG_PATH.exists():
        logging.info("Query log not found. Nothing to fix.")
        return

    # 1. Archive
    ts = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    archive_path = BASE_DIR / f"outputs/query_log_archive_{ts}.csv"
    shutil.copy(LOG_PATH, archive_path)
    logging.info(f"Archived query log to {archive_path}")
    
    # 2. Load
    try:
        df = pd.read_csv(LOG_PATH)
    except Exception as e:
        logging.error(f"Failed to read query log: {e}")
        return

    current_hash = get_current_contract_hash()
    logging.info(f"Current Contract Hash: {current_hash}")
    
    clean_rows = []
    dropped_count = 0
    reasons = {}
    
    for idx, row in df.iterrows():
        # Check Contract Hash
        r_hash = row.get("contract_sha256")
        if r_hash != current_hash:
            dropped_count += 1
            reasons["stale_contract"] = reasons.get("stale_contract", 0) + 1
            continue
            
        # Check Integrity
        is_valid, reason = validate_row_logic(row)
        if not is_valid:
            dropped_count += 1
            reasons[reason] = reasons.get(reason, 0) + 1
            continue
            
        clean_rows.append(row)
        
    # 3. Write Clean
    if clean_rows:
        clean_df = pd.DataFrame(clean_rows)
        # Ensure round_id sort
        if "round_id" in clean_df.columns:
            clean_df = clean_df.sort_values("round_id")
        
        clean_df.to_csv(LOG_PATH, index=False)
    else:
        # Empty? 
        # Write empty with headers if possible, or just delete/create fresh
        # Better to keep headers from original
        pd.DataFrame(columns=df.columns).to_csv(LOG_PATH, index=False)
        
    logging.info(f"Cleanup complete. Kept {len(clean_rows)}, Dropped {dropped_count}.")
    
    # 4. Audit Report
    report = f"""# Query Log Repair Audit
**Timestamp:** {datetime.datetime.now().isoformat()}
**Archive:** `{archive_path.name}`

## Summary
- **Original Rows:** {len(df)}
- **Clean Rows:** {len(clean_rows)}
- **Dropped Rows:** {dropped_count}

## Drop Reasons
"""
    for r, c in reasons.items():
        report += f"- **{r}**: {c}\n"
        
    with open(AUDIT_REPORT_PATH, "w") as f:
        f.write(report)

if __name__ == "__main__":
    fix_query_log()
