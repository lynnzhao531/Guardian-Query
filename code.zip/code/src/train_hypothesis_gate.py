import pandas as pd
import numpy as np
import json
import joblib
from pathlib import Path
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, precision_score, recall_score, f1_score

def train_gate():
    repo_root = Path(__file__).resolve().parent.parent
    data_path = repo_root / "reports/fixed_eval_sft_raw.parquet"
    model_path = repo_root / "models/hypothesis_gate.joblib"
    metrics_json_path = repo_root / "reports/hypothesis_gate_metrics.json"
    metrics_md_path = repo_root / "reports/hypothesis_gate_report.md"
    
    # ensure directories exist
    model_path.parent.mkdir(parents=True, exist_ok=True)
    
    if not data_path.exists():
        print(f"Error: {data_path} not found.")
        return

    df = pd.read_parquet(data_path)
    
    # ── FEATURE ENGINEERING ──────────────────────────────────────────
    # target y: POS=1, HARDNEG/NEG=0
    # based on parquet: gold_decision == 1.0 is POS
    df['y'] = (df['gold_decision'] == 1.0).astype(int)
    
    # Engineer support/trap counts if not present
    if 'support_count_decision' not in df.columns:
        # We can approximate from llm_final adjustment or assume 0 if missing
        # However, we should try to get them if possible. 
        # For now, let's use the scores we have.
        df['support_count_decision'] = 0
        df['trap_count_decision'] = 0
        df['support_count_top_method'] = 0
        df['trap_count_top_method'] = 0

    if 'llm_final_confidence_score' not in df.columns:
        df['llm_final_confidence_score'] = 0.5 # default

    # multi_method_count
    method_cols_sft = [c for c in df.columns if c.startswith('llm_sft_method_') and c.endswith('_p1')]
    df['llm_sft_multi_method_count'] = (df[method_cols_sft] >= 0.8).sum(axis=1) if method_cols_sft else 0
    
    # max_method_p1
    df['llm_sft_max_method_p1'] = df[method_cols_sft].max(axis=1) if method_cols_sft else 0.0
    df['llm_final_max_method_p1'] = df[[c for c in df.columns if c.startswith('llm_final_method_') and c.endswith('_p1')]].max(axis=1)

    features = [
        'llm_sft_decision_p1',
        'llm_sft_max_method_p1',
        'llm_sft_multi_method_count',
        'llm_final_decision_p1',
        'llm_final_max_method_p1',
        'llm_final_confidence_score',
        'support_count_decision',
        'trap_count_decision',
        'support_count_top_method',
        'trap_count_top_method'
    ]
    
    # ensure all features exist or fill with 0
    for col in features:
        if col not in df.columns:
            df[col] = 0.0
            
    X = df[features]
    y = df['y']
    
    # ── TRAINING ─────────────────────────────────────────────────────
    # model: LogisticRegression(lbfgs, C=1.0, class_weight=balanced)
    # split: stratified 80/20 seed=137
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=137
    )
    
    model = LogisticRegression(solver='lbfgs', C=1.0, class_weight='balanced', max_iter=1000)
    model.fit(X_train, y_train)
    
    # Save model
    joblib.dump(model, model_path)
    
    # ── EVALUATION ───────────────────────────────────────────────────
    y_probs = model.predict_proba(X_test)[:, 1]
    
    thresholds = np.arange(0.05, 1.0, 0.05)
    metrics_list = []
    
    for t in thresholds:
        y_pred = (y_probs >= t).astype(int)
        p, r, f, _ = precision_recall_fscore_support(y_test, y_pred, average='binary', zero_division=0)
        metrics_list.append({
            "threshold": round(float(t), 2),
            "precision": round(float(p), 4),
            "recall": round(float(r), 4),
            "f1": round(float(f), 4)
        })
        
    # Baseline at 0.5
    y_pred_50 = (y_probs >= 0.5).astype(int)
    p50, r50, f50, _ = precision_recall_fscore_support(y_test, y_pred_50, average='binary', zero_division=0)
    
    final_metrics = {
        "baseline_50": {
            "precision": round(float(p50), 4),
            "recall": round(float(r50), 4),
            "f1": round(float(f50), 4)
        },
        "threshold_sweep": metrics_list
    }
    
    # Save JSON
    with open(metrics_json_path, 'w') as f:
        json.dump(final_metrics, f, indent=2)
        
    # ── REPORTING ────────────────────────────────────────────────────
    with open(metrics_md_path, 'w') as f:
        f.write("# Hypothesis Gate Training Report\n\n")
        f.write(f"Target: POS=1 vs HARDNEG/NEG=0\n")
        f.write(f"Model: LogisticRegression(C=1.0, class_weight=balanced)\n")
        f.write(f"Features: {', '.join(features)}\n\n")
        
        f.write("## Baseline Metrics (Threshold 0.5)\n")
        f.write(f"- **Precision**: {p50:.4f}\n")
        f.write(f"- **Recall**: {r50:.4f}\n")
        f.write(f"- **F1**: {f50:.4f}\n\n")
        
        f.write("## Threshold Sweep\n")
        f.write("| Threshold | Precision | Recall | F1 |\n")
        f.write("| :--- | :--- | :--- | :--- |\n")
        for m in metrics_list:
            f.write(f"| {m['threshold']:.2f} | {m['precision']:.4f} | {m['recall']:.4f} | {m['f1']:.4f} |\n")
            
    print(f"Gate training complete. Model saved to {model_path}")

if __name__ == "__main__":
    train_gate()
