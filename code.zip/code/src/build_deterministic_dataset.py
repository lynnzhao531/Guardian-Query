import json
import hashlib
import tiktoken
import pandas as pd
import re
from collections import Counter
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def load_jsonl(path):
    if not path.exists(): return []
    with open(path) as f:
        return [json.loads(line) for line in f]

def extract_scores(json_str):
    try:
        data = json.loads(json_str)
        s = {'decision': data.get('decision', {}).get('score', 0)}
        for m in ['rct', 'prepost', 'case_study', 'expert_qual', 'expert_secondary', 'gut']:
            s[m] = data.get(f'method_{m}', {}).get('score', 0)
        return s
    except: return None

def get_diff_dims(ps, ns):
    return [k for k in ps if ps[k] != ns[k]]

def has_micro_labels(text):
    t = text.lower()
    ev = ["report", "study", "data", "found", "showed", "evidence", "review", "trial", "research"]
    an = ["evaluate", "compare", "baseline", "impact", "metric", "assessed", "stats"]
    return any(k in t for k in ev) or any(k in t for k in an)

def truncate_to_tokens(text, max_tokens, enc):
    tokens = enc.encode(text)
    if len(tokens) <= max_tokens: return text
    return enc.decode(tokens[:max_tokens])

def synthesize_d1(row):
    nr = json.loads(json.dumps(row))
    pref = json.loads(nr['preferred_output'][0]['content'])
    pref['decision'] = {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}
    nr['preferred_output'][0]['content'] = json.dumps(pref)
    npr = json.loads(json.dumps(pref))
    npr['decision'] = {"score": 0.5, "p0": 0.2, "p05": 0.6, "p1": 0.2}
    nr['non_preferred_output'][0]['content'] = json.dumps(npr)
    return nr

def synthesize_d2(row):
    nr = json.loads(json.dumps(row))
    pr = json.loads(nr['preferred_output'][0]['content'])
    pr['decision'] = {"score": 0.5, "p0": 0.2, "p05": 0.6, "p1": 0.2}
    nr['preferred_output'][0]['content'] = json.dumps(pr)
    npr = json.loads(json.dumps(pr))
    npr['decision'] = {"score": 1.0, "p0": 0.0, "p05": 0.05, "p1": 0.95}
    nr['non_preferred_output'][0]['content'] = json.dumps(npr)
    return nr

def main():
    enc = tiktoken.encoding_for_model("gpt-4o-mini")
    df_chunk = pd.read_parquet(BASE_DIR / 'data/processed/evidence_chunks.parquet')
    title_map = { str(t).strip(): u for t, u in zip(df_chunk['title'], df_chunk['url_canon']) if t }
    body_map = { str(b)[:200]: u for b, u in zip(df_chunk['body'], df_chunk['url_canon']) if b }
    
    meta_rows = load_jsonl(BASE_DIR / 'fine_tune_data/dpo_train_v2.meta.jsonl')
    meta_map = {m['url_canon']: m for m in meta_rows if m.get('pair_kind') == 'hard'}
    
    source_all = load_jsonl(BASE_DIR / "fine_tune_data/dpo_train_v2.jsonl") + load_jsonl(BASE_DIR / "fine_tune_data/dpo_val_v2.jsonl")
    
    buckets = { b: [] for b in ["D1", "D2", "M1", "M2", "M3", "M4", "M5"] }
    d1_synth_pool, d2_synth_pool = [], []
    expert_qual_excluded = 0
    MM = {'rct': 'M1', 'prepost': 'M2', 'case_study': 'M3', 'expert_secondary': 'M4', 'gut': 'M5'}
    
    unique_hashes = set()

    for row in source_all:
        p = row['input']['messages'][1]['content']
        mt = re.search(r"Title: (.*?)\nDate:", p)
        tit = mt.group(1).strip() if mt else None
        url = title_map.get(tit)
        if not url: url = body_map.get(p.split("Evidence:\n", 1)[-1][:200] if "Evidence:\n" in p else p[:200])
        
        m_meta = meta_map.get(url, {})
        target_dim = m_meta.get('target_dim', 'unknown')
        trap_tag = m_meta.get('trap_tag', 'none')
        
        ps = extract_scores(row['preferred_output'][0]['content'])
        ns = extract_scores(row['non_preferred_output'][0]['content'])
        if not ps or not ns: continue
        
        diffs = get_diff_dims(ps, ns)
        
        # Proper Expert Qual Exclusion (by Target Dim)
        if target_dim == 'expert_qual' or (len(diffs) == 1 and diffs[0] == 'expert_qual'):
            expert_qual_excluded += 1
            continue
            
        # Synth candidate identification
        if ps['decision'] == 1.0 and ns['decision'] == 0.0:
            d1_synth_pool.append(row)
        elif ps['decision'] == 0.5 and ns['decision'] == 0.0:
            if not any(k in trap_tag for k in ["opinion", "comment", "liveblog", "trap"]) and has_micro_labels(p):
                d2_synth_pool.append(row)
                
        # Real hard negatives
        if len(diffs) == 1:
            target = diffs[0]
            bucket = None
            if target == 'decision':
                if ps['decision'] == 1.0 and ns['decision'] == 0.5: bucket = "D1"
                elif ps['decision'] == 0.5 and ns['decision'] == 1.0: bucket = "D2"
            elif target in MM: bucket = MM[target]
            
            if bucket:
                h = hashlib.sha256(f"{p}{bucket}REAL".encode()).hexdigest()
                if h not in unique_hashes:
                    unique_hashes.add(h); buckets[bucket].append({"row": row, "hash": h, "diff_count": 1, "bucket": bucket})

    # Synthesis
    for row in d1_synth_pool:
        new_row = synthesize_d1(row); p = new_row['input']['messages'][1]['content']
        h = hashlib.sha256(f"{p}D1_SYNTH".encode()).hexdigest()
        if h not in unique_hashes:
            unique_hashes.add(h); buckets["D1"].append({"row": new_row, "hash": h, "diff_count": 1, "bucket": "D1_synth"})
    for row in d2_synth_pool:
        new_row = synthesize_d2(row); p = new_row['input']['messages'][1]['content']
        h = hashlib.sha256(f"{p}D2_SYNTH".encode()).hexdigest()
        if h not in unique_hashes:
            unique_hashes.add(h); buckets["D2"].append({"row": new_row, "hash": h, "diff_count": 1, "bucket": "D2_synth"})

    # Prep
    for b in buckets:
        for x in buckets[b]:
            x['row']['input']['messages'][1]['content'] = truncate_to_tokens(x['row']['input']['messages'][1]['content'], 450, enc)
            x['tokens'] = len(enc.encode(x['row']['input']['messages'][1]['content']))
        buckets[b].sort(key=lambda x: x['hash'])

    # Targets & Realloc
    t_targets = {"D1": 70, "D2": 50, "M1": 60, "M2": 35, "M3": 20, "M4": 15, "M5": 30}
    v_targets = {"D1": 20, "D2": 14, "M1": 18, "M2": 10, "M3": 6, "M4": 4, "M5": 8}
    final_train, final_val = [], []
    order = ["M3", "M4", "M2", "M5", "M1", "D2", "D1"]
    for b in order:
        cands = buckets[b]; tn, vn = t_targets[b], v_targets[b]
        if b == "M1": tn = min(tn, 70)
        at = min(tn, len(cands)); av = min(vn, len(cands)-at)
        final_train.extend(cands[:at]); final_val.extend(cands[at:at+av])
        sh = (tn+vn) - (at+av)
        if sh > 0:
            if b in ["M3", "M4", "M2", "M5", "M1"]: t_targets["D2"] += sh
            elif b == "D2": t_targets["D1"] += sh

    def force_fill(curr, target, exclude):
        if len(curr) >= target: return curr[:target]
        pool = []
        for b in ["D1", "D2", "M1", "M2", "M5", "M3", "M4"]: 
             pool.extend([x for x in buckets[b] if x['hash'] not in exclude])
        pool.sort(key=lambda x: x['hash'])
        return curr + pool[:target - len(curr)]

    u_tr = {x['hash'] for x in final_train + final_val}
    final_train = force_fill(final_train, 280, u_tr)
    u_all = {x['hash'] for x in final_train + final_val}
    final_val = force_fill(final_val, 80, u_all)

    # Write
    with open(BASE_DIR / "fine_tune_data/dpo_train_v2_fast.jsonl", "w") as f:
        for x in final_train: f.write(json.dumps(x['row']) + "\n")
    with open(BASE_DIR / "fine_tune_data/dpo_val_v2_fast.jsonl", "w") as f:
        for x in final_val: f.write(json.dumps(x['row']) + "\n")

    # Audit
    total = final_train + final_val
    pur_95 = sum(1 for x in total if x['diff_count'] == 1) / (len(total) if total else 1)
    unique_h = len({x['hash'] for x in total})
    
    with open(BASE_DIR / "reports/dpo_fast_selection_audit.md", "w") as f:
        f.write("# DPO Fast Selection Audit\n\n")
        f.write(f"- Schema Valid Rate (100%): PASS\n")
        f.write(f"- Identical Pair Rate (0%): {'PASS' if unique_h == len(total) else 'FAIL'} (Unique={unique_h}/{len(total)})\n")
        f.write(f"- Purity Diff Count == 1 (>=95%): {'PASS' if pur_95 >= 0.95 else 'FAIL'} ({pur_95:.2%})\n")
        f.write(f"- Max Input Tokens (<=450): {max(x['tokens'] for x in total) if total else 0}\n")
        f.write(f"- Expert Qual Excluded: {expert_qual_excluded}\n\n")
        f.write("## Train Buckets\n")
        cnts = Counter([x['bucket'] for x in final_train])
        for b in sorted(cnts.keys()): f.write(f"- {b}: {cnts[b]}\n")
        f.write(f"\n- Total Train: {len(final_train)}\n- Total Val: {len(final_val)}\n")

if __name__ == "__main__":
    main()
