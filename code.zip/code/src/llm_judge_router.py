import numpy as np
import pandas as pd
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
from typing import List, Dict, Any, Optional
import datetime
from src.safe_llm_judge import call_llm_scoring
from src.config_loader import get_config
from src.llm_output_sanitize import sanitize_model_json
import logging

def check_model_blacklist(model_name: str):
    blacklist_path = BASE_DIR / "project_state/LLM_MODEL_BLACKLIST.json"
    if not blacklist_path.exists():
        return
    with open(blacklist_path, "r") as f:
        blacklist = json.load(f)
    if model_name in blacklist.get("blocked_models", []):
        reason = blacklist.get("reason", {}).get(model_name, "No reason provided")
        logging.error(f"FATAL: Model {model_name} is BLACKLISTED. Reason: {reason}")
        raise RuntimeError(f"Model {model_name} is BLACKLISTED. Stopping execution.")

def score_articles(
    articles: List[Dict[str, Any]], 
    state: Dict[str, Any],
    round_id: Optional[int] = None,
    mock_llm: bool = False
) -> List[Dict[str, Any]]:
    cfg = get_config()
    sft_model = state.get("sft_model_name")
    dpo_model = state.get("dpo_model_name")
    
    # Enforce blacklist
    if sft_model: check_model_blacklist(sft_model)
    if dpo_model: check_model_blacklist(dpo_model)
    
    if round_id is not None:
        log_dpo_meta(round_id, dpo_model, sft_model)

    # 1. Compute SFT for ALL
    sft_outputs = {}
    for art in articles:
        url = art['url_canon']
        text = art.get('body_text', '')
        res = call_llm_scoring(
            model_name=sft_model,
            article_text=text,
            max_output_tokens=cfg.get("sft_max_output_tokens", 500),
            strict_schema=True,
            api_key=os.getenv("OPENAI_API_KEY"),
            mock_response=mock_llm
        )
        sft_outputs[url] = res
        
    # DPO Disabling Guard (Patch 6)
    dpo_enabled = cfg.get("dpo_enabled", True)
    policy = cfg.get("dpo_attempt_policy", "subset_hybrid")
    to_attempt_urls = set()
    
    if not dpo_enabled or not dpo_model or policy == "none":
        # Hard-stop DPO selection
        logging.info("DPO is DISABLED or MISSING. Forcing SFT-only routing.")
    else:
        # 1. Select DPO subset
        dpo_candidates = []
        for art in articles:
            url = art['url_canon']
            res = sft_outputs[url]
            if not res['success']: continue
            data = res['data']
            dec_p1 = data['decision']['p1']
            methods = [k for k in data if k.startswith("method_")]
            max_meth_p1 = max((data[m]['p1'] for m in methods), default=0)
            dpo_candidates.append({
                 "url": url, "dec_p1": dec_p1, "max_meth_p1": max_meth_p1,
                 "proxy_high": dec_p1 * max_meth_p1
            })
            
        k_attempt = cfg.get("dpo_attempt_k", 30)
        if policy == "all":
            to_attempt_urls = {c['url'] for c in dpo_candidates}
        elif policy == "subset_hybrid":
            sorted_high = sorted(dpo_candidates, key=lambda x: x['proxy_high'], reverse=True)
            k_high = k_attempt // 2
            high_set = sorted_high[:k_high]
            uncertain = [c for c in dpo_candidates if (0.3 <= c['dec_p1'] <= 0.7) or (0.3 <= c['max_meth_p1'] <= 0.7)]
            existing_urls = {x['url'] for x in high_set}
            uncertain_filtered = [c for c in uncertain if c['url'] not in existing_urls]
            k_unc = k_attempt - len(high_set)
            unc_set = uncertain_filtered[:k_unc]
            to_attempt_urls = existing_urls.union({x['url'] for x in unc_set})
            
    # ── DPO EXPANSION GATING (Patch 5) ──────────────────────────
    # rolling_valid_rate over last 3 rounds, require >= 15 attempts and >= 0.8 rate
    if cfg.get("dpo_expansion_enabled", True) and not to_attempt_urls:
        # Check rolling history if we haven't already decided on targets
        # For simplicity in this script, we'll look for recent logs
        try:
            log_path = Path("outputs/query_log.csv")
            if log_path.exists():
                hist = pd.read_csv(log_path)
                if len(hist) >= 3:
                    recent = hist.tail(3)
                    total_att = recent['dpo_attempted_count'].sum()
                    total_val = recent['dpo_valid_count'].sum()
                    if total_att >= 15 and (total_val / total_att) >= 0.8:
                        # Expand k up to 100
                        k_attempt = 100
                        # Re-calculate to_attempt_urls with k=100
                        sorted_high = sorted(dpo_candidates, key=lambda x: x['proxy_high'], reverse=True)
                        k_high = k_attempt // 2
                        high_set = sorted_high[:k_high]
                        uncertain = [c for c in dpo_candidates if (0.3 <= c['dec_p1'] <= 0.7) or (0.3 <= c['max_meth_p1'] <= 0.7)]
                        existing_urls = {x['url'] for x in high_set}
                        uncertain_filtered = [c for c in uncertain if c['url'] not in existing_urls]
                        k_unc = k_attempt - len(high_set)
                        unc_set = uncertain_filtered[:k_unc]
                        to_attempt_urls = existing_urls.union({x['url'] for x in unc_set})
        except Exception as e:
            logging.error(f"DPO expansion check failed: {e}")
            
    # ── HYPOTHESIS INTEGRATION SETUP ────────────────────────────
    from src.hypothesis_verifier import HypothesisVerifier
    hyp_json_path = Path(__file__).resolve().parent.parent / "knowledge_base/hypotheses/hypotheses_selected.json"
    selected_hyps = {}
    if hyp_json_path.exists():
        with open(hyp_json_path, "r") as f:
            selected_hyps = json.load(f)
    
    calib_dir = Path(__file__).resolve().parent.parent / "models/hypothesis_calibrators"
    calibrators = {}
    if cfg.get("hypothesis_calibrator_mode") != "grid_adjust_only" and calib_dir.exists():
        import joblib
        for dim in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
            c_path = calib_dir / f"calib_{dim}.joblib"
            if c_path.exists():
                calibrators[dim] = joblib.load(c_path)

    final_results = []
    for art in articles:
        url = art['url_canon']
        text = art.get('body_text', '')
        sft_res = sft_outputs[url]
        
        row = {
            "url_canon": url,
            "dpo_attempted": False,
            "dpo_valid": False,
            "model_used": "sft_only",
            "dpo_fail_reason": None,
            "total_tokens_in": 0,
            "total_tokens_out": 0
        }
        
        # Ensure mandatory columns exist even if scoring fails
        for p in ["llm_sft", "llm_final", "llm_dpo"]:
            flatten_scores(row, {}, p)
        
        if sft_res.get('usage'):
            row['total_tokens_in'] += sft_res['usage'].get('prompt_tokens', 0)
            row['total_tokens_out'] += sft_res['usage'].get('completion_tokens', 0)

        if sft_res['success']:
            flatten_scores(row, sft_res['data'], prefix="llm_sft")
            
            # ── HYPOTHESIS ADJUSTMENT ────────────────────────────────
            sft_raw_scores = {'decision_p1': sft_res['data']['decision']['p1']}
            for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
                dim_m = f"method_{m}"
                sft_raw_scores[f"{dim_m}_p1"] = sft_res['data'][dim_m]['p1'] if dim_m in sft_res['data'] else 0.0
            
            adjusted = HypothesisVerifier.adjust(text, sft_raw_scores, selected_hyps, calibrators)
            
            final_data = {}
            for dim in ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]:
                p1 = adjusted.get(f"{dim}_p1", 0.0)
                final_data[dim] = {
                    "score": adjusted.get(f"{dim}_score", 0.0),
                    "p1": p1, "p05": 0.05, "p0": max(0, 1.0 - p1 - 0.05)
                }
            flatten_scores(row, final_data, prefix="llm_final")
        else:
            row['llm_sft_error'] = sft_res['error']

        # 3. DPO Blend
        dpo_circuit_breaker = False
        dpo_attempted_round = 0
        dpo_valid_round = 0

        # Note: We need to track round-level stats during the loop for the circuit breaker.
        # However, score_articles is called once per round with all articles.
        # So we can track internally.
        
        # Determine total possible DPO attempts to initialize metrics
        dpo_round_attempted = 0
        dpo_round_valid = 0

        if url in to_attempt_urls and sft_res['success']:
            # Circuit breaker check: attempted >= 5 and valid_rate < 0.2
            current_att = sum(1 for r in final_results if r.get('dpo_attempted'))
            current_val = sum(1 for r in final_results if r.get('dpo_valid'))
            
            if current_att >= 5 and (current_val / current_att) < 0.2:
                row['dpo_fail_reason'] = "circuit_breaker_triggered"
                row['dpo_circuit_breaker_triggered'] = 1
            else:
                row['dpo_attempted'] = True
                # Tighten parameters for DPO
                dpo_res = call_llm_scoring(
                    model_name=dpo_model,
                    article_text=text,
                    max_output_tokens=250, # Tightened
                    system_prompt="Output ONLY JSON. No prose. No markdown. Do not repeat.",
                    strict_schema=False,    # We will use our salvage parser
                    api_key=os.getenv("OPENAI_API_KEY"),
                    mock_response=mock_llm
                )
                if dpo_res.get('usage'):
                    row['total_tokens_in'] += dpo_res['usage'].get('prompt_tokens', 0)
                    row['total_tokens_out'] += dpo_res['usage'].get('completion_tokens', 0)
                
                # Salvage Parser Integration
                ok, salvaged_data, reason_tag = sanitize_model_json(dpo_res.get('raw_text', ""))
                
                if ok:
                    row['dpo_valid'] = True
                    flatten_scores(row, salvaged_data, prefix="llm_dpo")
                    
                    if cfg.get("dpo_shadow_mode", False):
                        row['model_used'] = f"sft_only (shadow dpo: {reason_tag})"
                        # Do not blend, leave llm_final as SFT-only
                    else:
                        row['model_used'] = f"sft+dpo_ensemble ({reason_tag})"
                        w = cfg.get("sft_weight_in_ensemble", 0.85)
                        blended = blend_outputs(final_data, salvaged_data, w)
                        flatten_scores(row, blended, prefix="llm_final")
                else:
                    row['dpo_fail_reason'] = f"validation_failed: {reason_tag}"
                    log_dpo_failure(round_id, url, reason_tag, dpo_res.get('raw_text', ""), dpo_model)
        
        final_results.append(row)
    return final_results

def flatten_scores(row, data, prefix):
    dims = ["decision", "method_rct", "method_prepost", "method_case_study", "method_expert_qual", "method_expert_secondary", "method_gut"]
    # Initialize defaults
    for d in dims:
        if f"{prefix}_{d}_score" not in row: row[f"{prefix}_{d}_score"] = 0.0
        if f"{prefix}_{d}_p0" not in row: row[f"{prefix}_{d}_p0"] = 0.0
        if f"{prefix}_{d}_p05" not in row: row[f"{prefix}_{d}_p05"] = 0.0
        if f"{prefix}_{d}_p1" not in row: row[f"{prefix}_{d}_p1"] = 0.0
        
    for dim, vals in data.items():
        # Map "method_X" or just "X"? 
        # The writer expects "method_X" for methods, and "decision" for decision.
        # But data from LLM might have "method_rct" already.
        row[f"{prefix}_{dim}_score"] = vals['score']
        row[f"{prefix}_{dim}_p0"] = vals['p0']
        row[f"{prefix}_{dim}_p05"] = vals['p05']
        row[f"{prefix}_{dim}_p1"] = vals['p1']

def validate_dpo(data, raw_text, cfg):
    tol = cfg.get("prob_sum_tolerance", 0.02)
    for dim, vals in data.items():
        s = vals['p0'] + vals['p05'] + vals['p1']
        if abs(s - 1.0) > tol: return False
    trig = cfg.get("repetition_trigger_token", "_score")
    limit = cfg.get("repetition_trigger_count", 20)
    if raw_text.count(trig) > limit: return False
    return True

def log_dpo_meta(round_id, dpo_model, sft_model):
    if round_id is None: return
    audit_dir = BASE_DIR / f"audits/round_{round_id}"
    audit_dir.mkdir(parents=True, exist_ok=True)
    
    meta = {
        "round_id": round_id,
        "dpo_model_name": dpo_model,
        "sft_model_name": sft_model,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    
    with open(audit_dir / "dpo_meta.json", "w") as f:
        json.dump(meta, f, indent=2)

def log_dpo_failure(round_id, url, reason, raw_output, model_name):
    if round_id is None: return
    audit_dir = BASE_DIR / f"audits/round_{round_id}"
    audit_dir.mkdir(parents=True, exist_ok=True)
    
    failure_entry = {
        "url_canon": url,
        "reason": reason,
        "raw_output_excerpt": raw_output[:500] if raw_output else "",
        "model_name": model_name,
        "attempt_ts": datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    
    log_path = audit_dir / "dpo_failures.jsonl"
    with open(log_path, "a") as f:
        f.write(json.dumps(failure_entry) + "\n")

def blend_outputs(sft, dpo, w):
    blended = {}
    for dim in sft:
        s, d = sft[dim], dpo[dim]
        p0 = w*s['p0'] + (1-w)*d['p0']
        p05 = w*s['p05'] + (1-w)*d['p05']
        p1 = w*s['p1'] + (1-w)*d['p1']
        total = p0+p05+p1
        if total > 0: p0/=total; p05/=total; p1/=total
        if p1 >= p0 and p1 >= p05: sc = 1
        elif p05 >= p0 and p05 >= p1: sc = 0.5
        else: sc = 0
        blended[dim] = {"score": sc, "p0": p0, "p05": p05, "p1": p1}
    return blended
