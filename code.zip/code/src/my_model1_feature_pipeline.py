import pandas as pd
import numpy as np
from scipy.sparse import hstack, csr_matrix
from src.tgml.theory_features import TheoryFeaturizer

class MyFeaturePipeline:
    def __init__(self, word_tfidf, char_tfidf, theory_col_order):
        self.word_tfidf = word_tfidf
        self.char_tfidf = char_tfidf
        self.theory_col_order = theory_col_order

    def transform(self, df):
        text_for_model = df["title"].fillna("") + "\n\n" + df["body"].fillna("")
        X_word = self.word_tfidf.transform(text_for_model)
        X_char = self.char_tfidf.transform(text_for_model)
        
        theory_feat = TheoryFeaturizer()
        theory_df = theory_feat.transform(df)
        X_theory = csr_matrix(theory_df[self.theory_col_order].fillna(0).values.astype(float))
        return hstack([X_word, X_char, X_theory], format="csr")
