import json
import pandas as pd
import random
from pathlib import Path
import os
import re

BASE_DIR = Path(__file__).resolve().parent.parent

# ── 1. PROMPTS & TEMPLATES ──────────────────────────────────────────
SYSTEM_PROMPT = """Output ONLY JSON. No prose. No markdown. Do not repeat.

CONSERVATIVE SCORING RULES (NON-NEGOTIABLE):
- Do NOT assign decision_score=1 unless the article clearly describes a concrete action/decision (approve/ban/rollout/implement/fund/mandate/scrap) AND ties it to evidence, evaluation, a report, or study findings.
- Do NOT assign any method score=1 unless the article explicitly describes an evaluation design or analysis (not just vague 'experts said' or 'data shows').
- If the article is about politics/process/opinion/controversy without evidence informing an implementable decision, decision_score must be 0 or 0.5 (not 1).
- It is normal for most methods to be 0. Do not 'spread' high scores across multiple methods unless multiple methods are explicitly present.

Output ONLY valid JSON matching the schema. No prose. No markdown.
"""

def map_score_to_probs(score):
    if score == 1: return {"score": 1, "p0": 0.05, "p05": 0.05, "p1": 0.90}
    elif score == 0.5: return {"score": 0.5, "p0": 0.05, "p05": 0.90, "p1": 0.05}
    else: return {"score": 0, "p0": 0.90, "p05": 0.05, "p1": 0.05}

def build_gold_pref(row):
    out = {"decision": map_score_to_probs(row.get("decision", 0))}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        out[f"method_{m}"] = map_score_to_probs(row.get(f"method_{m}", 0))
    return json.dumps(out, separators=(',', ':'))

def build_hard_neg(row, flip_type):
    out = {"decision": map_score_to_probs(row.get("decision", 0))}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        out[f"method_{m}"] = map_score_to_probs(row.get(f"method_{m}", 0))
    
    if flip_type == 'decision':
        # Flip decision
        current_dec = row.get("decision", 0)
        # 1 <-> 0.5 flip logic: if it's 1, make it 0.5. If it's 0.5, make it 1. If it's 0, make it 0.5.
        if current_dec == 1:
            out["decision"] = map_score_to_probs(0.5)
        elif current_dec == 0.5:
            out["decision"] = map_score_to_probs(1)
        else:
            out["decision"] = map_score_to_probs(0.5)
            
    elif flip_type == 'method':
        # Flip exactly one method
        methods = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]
        has_method = any(row.get(f"method_{m}", 0) == 1 for m in methods)
        
        if has_method:
            # Drop a method
            active_methods = [m for m in methods if row.get(f"method_{m}", 0) == 1]
            out[f"method_{active_methods[0]}"] = map_score_to_probs(0)
        else:
            # Trap tags
            trap = row.get('trap_tag', 'none')
            if 'prepost' in trap:
                out["method_prepost"] = map_score_to_probs(1.0)
            elif 'case' in trap:
                out["method_case_study"] = map_score_to_probs(1.0)
            elif 'opinion' in trap:
                out["method_gut"] = map_score_to_probs(1.0)
            else:
                out["method_expert_qual"] = map_score_to_probs(1.0)
                
    return json.dumps(out, separators=(',', ':'))

def split_sentences(text):
    text = re.sub(r'\n+', ' ', text)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 10]

def extract_evidence(text, max_chars=1000):
    if not isinstance(text, str):
        return ""
    
    # Very simple extraction cap to 1000
    if len(text) <= max_chars:
        return text
    
    sentences = split_sentences(text)
    final_text = ""
    for s in sentences:
        if len(final_text) + len(s) + 1 <= max_chars:
            final_text += s + " "
        else:
            if not final_text:
                final_text = s[:max_chars]
            break
            
    return final_text.strip()

def format_openai_chat_dpo(title, chunk, pref_json, non_pref_json):
    user_msg = f"Title: {title}\nDate: unknown\n\nArticle Text:\n{chunk}"
    
    dpo_format = {
        "input": {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg}
            ]
        },
        "preferred_output": [{"role": "assistant", "content": pref_json}],
        "non_preferred_output": [{"role": "assistant", "content": non_pref_json}]
    }
    return dpo_format

def main():
    import numpy as np
    random.seed(42)
    np.random.seed(42)
    
    # Read articles with gold labels and text
    master_path = BASE_DIR / "outputs/master_vector.parquet"
    if not master_path.exists():
        master_path = BASE_DIR / "outputs/training_cases_clean.parquet"
    
    df = pd.read_parquet(master_path)
    
    # We also need the micro-labels to power the traps
    micro_path = BASE_DIR / "data/processed/micro_labels.parquet"
    if micro_path.exists():
        df_micro = pd.read_parquet(micro_path)
        df = df.merge(df_micro, on='url_canon', how='left')
    
    # Filter out missing text
    df = df[df['body'].notna() & (df['body'] != '')]
    
    # Fill NAs in score columns to prevent TypeError
    score_cols = ["decision"] + [f"method_{m}" for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]]
    for c in score_cols:
        if c in df.columns:
            df[c] = df[c].fillna(0)
    
    # Prepare DPO pairs
    decision_candidates = []
    method_candidates = []
    
    for _, row in df.iterrows():
        pref = build_gold_pref(row)
        
        # Determine valid flips
        # Every article can have a decision flip
        dec_non_pref = build_hard_neg(row, 'decision')
        # Every article can have a method flip
        meth_non_pref = build_hard_neg(row, 'method')
        
        if pref != dec_non_pref:
            decision_candidates.append((row, dec_non_pref))
            
        if pref != meth_non_pref:
            method_candidates.append((row, meth_non_pref))
            
    random.shuffle(decision_candidates)
    random.shuffle(method_candidates)
    
    # Train: 140 decision, 140 method
    # Val: 40 decision, 40 method
    train_dec = decision_candidates[:140]
    val_dec = decision_candidates[140:180]
    
    train_meth = method_candidates[:140]
    val_meth = method_candidates[140:180]
    
    train_set = train_dec + train_meth
    val_set = val_dec + val_meth
    
    random.shuffle(train_set)
    random.shuffle(val_set)
    
    def process_set(dataset):
        out = []
        for row, non_pref in dataset:
            pref = build_gold_pref(row)
            title = str(row.get('title', 'unknown'))[:50]
            body = row['body']
            # Hard cap 50 to meet 450 token constraint
            chunk = extract_evidence(body, 50)
            dpo_row = format_openai_chat_dpo(title, chunk, pref, non_pref)
            out.append(dpo_row)
        return out
        
    train_dpo = process_set(train_set)
    val_dpo = process_set(val_set)
    
    out_dir = BASE_DIR / "fine_tune_data"
    out_dir.mkdir(exist_ok=True, parents=True)
    
    def write_jsonl(path, data):
        with open(path, "w") as f:
            for item in data:
                f.write(json.dumps(item) + "\n")
                
    write_jsonl(out_dir / "dpo_train_v2_fast.jsonl", train_dpo)
    write_jsonl(out_dir / "dpo_val_v2_fast.jsonl", val_dpo)
    
    print(f"Train set: {len(train_dpo)} pairs")
    print(f"Val set: {len(val_dpo)} pairs")

if __name__ == "__main__":
    main()
