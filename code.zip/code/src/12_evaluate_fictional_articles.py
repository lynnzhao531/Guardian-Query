import os
import json
import yaml
import torch
import joblib
import pandas as pd
import numpy as np
from pathlib import Path
from openai import OpenAI
from transformers import AutoTokenizer
from dotenv import load_dotenv

load_dotenv()
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Import Model 3 architecture
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from config_env import load_guardian_keys
from guardian_client import GuardianClient

# We need CBMModel from 04_model3_train
import importlib
train_mod = importlib.import_module("04_model3_train")
CBMModel = train_mod.CBMModel

# ── Articles Data ─────────────────────────────────────────────────────
ARTICLES = [
    # 1) RCT
    {"id": "1A", "type": "rct", "label": "Prototype", "title": "Council to randomise neighbourhood patrols in summer pilot to decide citywide policing plan", 
     "body": "A Midlands city council will run a six-month trial that randomly assigns neighbourhoods to two different patrol strategies, in a bid to decide which approach should be adopted across the city next year. Under the plan, 40 neighbourhood clusters will be allocated by lottery to either Strategy A, which increases foot patrols at peak hours, or Strategy B, which shifts resources to rapid response teams. Independent analysts from a local university will track outcomes including reported assaults, burglary, response times and resident perceptions, comparing results across the two groups. Councillors said the trial was designed to avoid 'guesswork' and would be used to make a specific decision in October: whether to fund and roll out Strategy A, Strategy B, or abandon both in favour of a redesigned approach."},
    {"id": "1B", "type": "rct", "label": "False Positive", "title": "‘Randomised controlled trial’ at centre of courtroom clash over juror selection", 
     "body": "A judge has heard arguments in a high-profile fraud case after defence lawyers compared the prosecution’s juror selection process to a 'randomised controlled trial'. The defence said the jury pool had been 'randomly assigned' in a way that created an unfair 'control group', alleging the process skewed towards certain postcodes. Prosecutors rejected the comparison, calling it 'a metaphor dressed up as statistics'. While the hearing repeatedly referenced 'trial arms', 'controls' and 'randomisation', the dispute concerns legal procedure and the admissibility of evidence."},
    {"id": "1C", "type": "rct", "label": "Irrelevant", "title": "Random thrills: the five best summer festivals for experimental music", 
     "body": "From warehouse techno to chamber-pop mashups, this year’s festival season is packed with 'experimental' sets. Here are five events to catch, plus the artists turning randomness into an art form."},
    
    # 2) Pre-Post
    {"id": "2A", "type": "prepost", "label": "Prototype", "title": "Free school breakfast scheme will expand if ‘before-and-after’ results hold, minister says", 
     "body": "A free breakfast programme piloted in 25 schools will be extended nationwide if early results continue to show improvements, the education minister has said. The department has been tracking attendance, lateness and behaviour before and after the scheme began, using term-by-term records from the same schools. Early figures show fewer late arrivals and a rise in morning attendance compared with the previous year’s baseline. Officials said the analysis will continue through the summer term and will inform a decision in August on whether to fund a broader roll-out and which elements to standardise."},
    {"id": "2B", "type": "prepost", "label": "False Positive", "title": "Before-and-after photos fuel ‘pilot scheme’ backlash over city centre makeover", 
     "body": "A pilot scheme to 'freshen up' a city centre has drawn criticism after residents shared dramatic before-and-after images of a street redesign. Campaigners said the makeover made the area 'unrecognisable', while the council insisted the changes were temporary. No evaluation plan or outcome measures have been published; the debate has centred on aesthetics and social media reaction. Councillors said they would 'review feedback' in due course."},
    {"id": "2C", "type": "prepost", "label": "Irrelevant", "title": "Before and after: how one chef transformed leftovers into a week of dinners", 
     "body": "A refrigerator clean-out becomes a seven-day menu. Tips, recipes and a surprisingly good lentil stew."},
    
    # 3) Case Study
    {"id": "3A", "type": "case_study", "label": "Prototype", "title": "One council’s homelessness ‘housing first’ case study prompts national expansion talks", 
     "body": "A government task group is considering expanding a 'housing first' homelessness programme after a detailed case study of its implementation in one coastal council reported sustained reductions in rough sleeping. The council’s report documents how the programme was delivered, the staffing model, and outcomes over 18 months, including housing retention rates and use of emergency services. Officials said the case study was chosen because it captures practical barriers and real-world costs. Ministers said the findings will inform a decision next month on whether to fund similar programmes in ten additional areas."},
    {"id": "3B", "type": "case_study", "label": "False Positive", "title": "Business school ‘case study’ on Apple’s pricing strategy goes viral", 
     "body": "A new MBA case study on Apple’s pricing strategy has become one of the most downloaded teaching materials of the year, prompting debate about profit margins and brand loyalty. The document analyses product launches and consumer reactions over a decade but does not evaluate any policy or intervention, nor does it inform an organisational rollout decision beyond classroom discussion."},
    {"id": "3C", "type": "case_study", "label": "Irrelevant", "title": "Film review: a gripping case study in heartbreak, but not much else", 
     "body": "A melancholy romance that’s beautifully shot and emotionally distant."},
    
    # 4) Expert Qual
    {"id": "4A", "type": "expert_qual", "label": "Prototype", "title": "Expert panel urges tougher heatwave rules for care homes; new standards due this summer", 
     "body": "An independent expert panel has recommended mandatory heatwave standards for care homes after months of evidence sessions with clinicians, providers and families. The panel’s qualitative review draws on testimony, incident reports and site visits, arguing that current guidance is too vague and unevenly applied. It proposes concrete measures—minimum indoor temperature thresholds, staffing triggers, and compulsory cooling plans. The health department said it had commissioned the review to support an imminent policy decision and will publish new national standards by late July."},
    {"id": "4B", "type": "expert_qual", "label": "False Positive", "title": "‘Consultation’ chaos as fans grill reality-TV panel over finale twist", 
     "body": "A live 'fan consultation' descended into chaos as viewers shouted questions at the show’s celebrity panel, demanding answers about a controversial finale. The producers said they would 'take feedback on board', but no policy, intervention, or organisational decision framework is involved beyond entertainment programming choices."},
    {"id": "4C", "type": "expert_qual", "label": "Irrelevant", "title": "Ask an expert: how to clean your keyboard without breaking it", 
     "body": "A guide to compressed air, isopropyl alcohol and the art of not losing your keys."},
    
    # 5) Expert Secondary
    {"id": "5A", "type": "expert_secondary", "label": "Prototype", "title": "Admin data analysis finds youth jobs programme cut reoffending; funding decision expected in September", 
     "body": "A new analysis of administrative data suggests a youth employment programme reduced reoffending, prompting ministers to consider extending funding. Researchers linked probation records with employment and benefits data to compare outcomes for young people who participated with similar individuals in neighbouring areas. Using a difference-in-differences approach, they estimated a fall in reoffending in the year after participation. The justice department said it commissioned the study to decide whether to expand the programme nationally and will make a funding decision in September."},
    {"id": "5B", "type": "expert_secondary", "label": "False Positive", "title": "‘Regression’ in summer weather sparks complaints as council publishes data dashboard", 
     "body": "A council has launched a new 'administrative data' dashboard showing rainfall totals after residents complained about a 'regression' in summer weather. The dashboard includes charts and trend lines, but it is not an evaluation of a policy or programme and does not inform an imminent organisational decision beyond public communication about weather and infrastructure."},
    {"id": "5C", "type": "expert_secondary", "label": "Irrelevant", "title": "On the road: the coastal town where time stands still", 
     "body": "A weekend of sea air, second-hand bookshops and unexpectedly good pastries."},
    
    # 6) Gut
    {"id": "6A", "type": "gut", "label": "Prototype", "title": "Mayor orders overnight e-scooter ban ‘as a precaution’ despite lack of evidence", 
     "body": "A mayor has ordered an overnight ban on rental e-scooters in the city centre, citing public concern and 'common sense' safety worries, despite officials acknowledging that no evaluation has been conducted. The mayor said the city would act immediately and review the policy later, arguing it was better to 'err on the side of caution' than wait for studies. Transport staff confirmed there is no before-after plan, no pilot comparison, and no external analysis underpinning the decision."},
    {"id": "6B", "type": "gut", "label": "False Positive", "title": "‘Gut feeling’ diet trend returns as influencers urge followers to ignore the data", 
     "body": "A new wave of influencers is promoting 'gut feeling' eating—urging followers to ditch tracking apps and 'stop listening to data'. The movement borrows policy-like language about 'rules' and 'compliance', but it concerns individual lifestyle choices rather than an organisational decision about implementing a policy or programme."},
    {"id": "6C", "type": "gut", "label": "Irrelevant", "title": "Street style: the return of wide-leg trousers", 
     "body": "A new season, a new silhouette: how wide-legs made a comeback."}
]

# ── Ordinal Classifier Definition (for joblib unpickling) ────────────────
class OrdinalClassifier:
    """Frank & Hall: K-1 binary classifiers for ordinal targets."""
    def __init__(self, classes=None, **lr_kwargs):
        self.classes = np.array(classes or [0.0, 0.5, 1.0])
        self.lr_kwargs = lr_kwargs
        self.clfs = []
    def fit(self, X, y):
        from sklearn.linear_model import LogisticRegression
        self.clfs = []
        for k in range(len(self.classes) - 1):
            y_bin = (np.asarray(y, dtype=float) > self.classes[k]).astype(int)
            clf = LogisticRegression(**self.lr_kwargs)
            if len(np.unique(y_bin)) > 1:
                clf.fit(X, y_bin)
            else:
                clf = None
            self.clfs.append(clf)
        return self
    def predict_proba(self, X):
        n = X.shape[0]
        cps = []
        for clf in self.clfs:
            if clf is not None:
                cps.append(clf.predict_proba(X)[:, 1])
            else:
                cps.append(np.zeros(n))
        probs = np.zeros((n, len(self.classes)))
        probs[:, 0] = 1.0 - cps[0]
        for k in range(1, len(self.classes) - 1):
            probs[:, k] = cps[k - 1] - cps[k]
        probs[:, -1] = cps[-1]
        probs = np.clip(probs, 0, 1)
        rs = probs.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1
        return probs / rs
    def predict(self, X):
        return self.classes[np.argmax(self.predict_proba(X), axis=1)]

# ── Model Loading ─────────────────────────────────────────────────────

def load_model1():
    model_dir = ROOT / "models" / "tgml"
    tfidf = joblib.load(model_dir / "tfidf_vectorizer.joblib")
    
    # Decision model
    dec_clf = joblib.load(model_dir / "decision_ordinal.joblib")
    
    # Method models
    method_clfs = {}
    for mt in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        m_name = f"method_{mt}"
        # Model 1 uses 'case_studies' in filename for case_study
        fname = "method_case_studies.joblib" if mt == "case_study" else f"{m_name}.joblib"
        path = model_dir / fname
        if path.exists():
            method_clfs[mt] = joblib.load(path)
            
    return tfidf, dec_clf, method_clfs

def load_model3():
    with open(ROOT / "configs" / "model_3.yaml") as f:
        cfg = yaml.safe_load(f)
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    model = CBMModel(cfg).to(device)
    model_path = ROOT / "models" / "model3_best.pt"
    if model_path.exists():
        model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    tokenizer = AutoTokenizer.from_pretrained(cfg['model']['base_encoder'])
    return model, tokenizer, device

def load_openai_models():
    with open(ROOT / "project_state" / "STATE.json") as f:
        state = json.load(f)
    
    # SFT is the first successful ft job
    sft_model = "ft:gpt-4.1-mini-2025-04-14:personal::DAMjnKOH" # Fallback to known SFT
    
    # Check progress report for DPO
    dpo_model = None
    rep_path = ROOT / "reports" / "finetune_progress_report.md"
    if rep_path.exists():
        text = rep_path.read_text()
        import re
        s = re.search(r"## SFT Job:.*?\nStatus: succeeded\nModel: `(.*?)`", text, re.DOTALL)
        if s: sft_model = s.group(1)
        
        m = re.search(r"## DPO Job:.*?\nStatus: succeeded\nModel: `(.*?)`", text, re.DOTALL)
        if m: dpo_model = m.group(1)
            
    return sft_model, dpo_model, OpenAI()

# ── Prediction Logic ──────────────────────────────────────────────────

def predict_model1(tfidf, dec_clf, method_clfs, article):
    text = f"{article['title']}\n\n{article['body']}"
    X = tfidf.transform([text])
    
    dec_score = dec_clf.predict(X)[0]
    
    # Method score for THIS article's type
    mt = article["type"]
    if mt in method_clfs:
        method_score = method_clfs[mt].predict(X)[0]
    else:
        method_score = 0.0 # Default if no model
        
    return dec_score, method_score

def predict_model3(model, tokenizer, device, article):
    text = f"{article['title']}\n\n{article['body']}"
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512).to(device)
    
    with torch.no_grad():
        _, f_logits_list = model(inputs['input_ids'], inputs['attention_mask'])
        
    # logits shape: [1, 3] for each head
    # 0: decision, 1: rct, 2: prepost, 3: case_study, 4: expert_qual, 5: expert_secondary, 6: gut
    head_map = {
        "rct": 1, "prepost": 2, "case_study": 3, 
        "expert_qual": 4, "expert_secondary": 5, "gut": 6
    }
    
    dec_idx = torch.argmax(f_logits_list[0], dim=1).item()
    dec_val = [0.0, 0.5, 1.0][dec_idx]
    
    mt = article["type"]
    m_idx = head_map.get(mt)
    if m_idx is not None:
        meth_idx = torch.argmax(f_logits_list[m_idx], dim=1).item()
        meth_val = [0.0, 0.5, 1.0][meth_idx]
    else:
        meth_val = 0.0
        
    return dec_val, meth_val

def predict_openai(client, model_name, article, label_tag=""):
    if not model_name: return np.nan, np.nan
    
    import hashlib
    # Simple disk cache
    cache_dir = ROOT / "project_state" / "fictional_eval_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    
    text = f"{article['title']}\n\n{article['body']}"
    cache_key = hashlib.md5(f"{model_name}_{article['id']}_{text}".encode()).hexdigest()
    cache_file = cache_dir / f"{cache_key}.json"
    
    if cache_file.exists():
        data = json.loads(cache_file.read_text())
        return data.get("decision_score"), data.get("method_score")

    system = """You are labeling Guardian-style news articles for a research dataset.
Use the scoring rubric exactly. Output ONLY valid JSON matching the schema, no extra keys, no prose.
Output schema: {"decision_score": 0|0.5|1, "method_type": "<type>", "method_score": 0|0.5|1}"""

    user_msg = f"Method type to score: {article['type']}\n\nArticle:\n{article['title']}\n\n{article['body']}"
    
    print(f"      - Requesting {label_tag} ({model_name[-8:]})...")
    try:
        is_reasoning = "o3" in model_name or "o1" in model_name or "4.1" in model_name
        api_kwargs = {
            "model": model_name,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user_msg}],
            "temperature": 0.0,
            "timeout": 30
        }
        
        if is_reasoning:
            api_kwargs["max_completion_tokens"] = 100
        else:
            api_kwargs["max_tokens"] = 100

        resp = client.chat.completions.create(**api_kwargs)
        raw = resp.choices[0].message.content
        if not raw:
            raise ValueError("Empty response from model")
            
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start != -1 and end > start:
                data = json.loads(raw[start:end])
            else:
                # Fallback: model might just output "1.0" or similar
                # If we only have one score, we can't be sure, but let's try to find numbers
                import re
                nums = re.findall(r"\b(0\.0|0\.5|1\.0|0|1)\b", raw)
                if len(nums) >= 2:
                    data = {"decision_score": float(nums[0]), "method_score": float(nums[1])}
                elif len(nums) == 1:
                    data = {"decision_score": float(nums[0]), "method_score": float(nums[0])}
                else:
                    raise ValueError(f"No scores found in output: {raw}")
        except Exception as e:
            # Final fallback: check for lone numbers
            print(f"      - Parse warning on {article['id']}: {e}. Raw: {raw}")
            raise e
        
        cache_file.write_text(json.dumps(data))
        return data.get("decision_score"), data.get("method_score")
    except Exception as e:
        print(f"OpenAI error on {article['id']} ({model_name}): {e}")
        return np.nan, np.nan

# ── Main ─────────────────────────────────────────────────────────────

def main():
    print("Loading models...")
    t1, d1, m1 = load_model1()
    m3, tok3, dev3 = load_model3()
    sft_name, dpo_name, client = load_openai_models()
    
    print(f"Evaluating 18 articles using:\n - Model 1 (Baseline)\n - Model 3 (CBM)\n - SFT: {sft_name}\n - DPO: {dpo_name or 'N/A'}\n")
    
    results = []
    for art in ARTICLES:
        print(f"Scoring {art['id']} / 18...")
        r1_d, r1_m = predict_model1(t1, d1, m1, art)
        r3_d, r3_m = predict_model3(m3, tok3, dev3, art)
        rsft_d, rsft_m = predict_openai(client, sft_name, art, "SFT")
        rdpo_d, rdpo_m = predict_openai(client, dpo_name, art, "DPO")
        
        results.append({
            "Article": f"{art['id']} ({art['type']})",
            "Label": art["label"],
            "M1_Dec": r1_d, "M1_Meth": r1_m,
            "M3_Dec": r3_d, "M3_Meth": r3_m,
            "SFT_Dec": rsft_d, "SFT_Meth": rsft_m,
            "DPO_Dec": rdpo_d, "DPO_Meth": rdpo_m
        })
        
    df = pd.DataFrame(results)
    
    # ── Report Generation ─────────────────────────────────────────────
    report = ["# Fictional Article Evaluation Report\n"]
    report.append("Comparison of 4 models on 18 test cases across 6 method types.\n")
    
    report.append("| Article | Label | Model 1 | Model 3 | SFT | DPO |")
    report.append("| :--- | :--- | :--- | :--- | :--- | :--- |")
    
    def fmt(d, m):
        if pd.isna(d) or pd.isna(m): return "N/A"
        return f"{float(d):.1f}/{float(m):.1f}"

    for _, row in df.iterrows():
        m1 = fmt(row['M1_Dec'], row['M1_Meth'])
        m3 = fmt(row['M3_Dec'], row['M3_Meth'])
        sft = fmt(row['SFT_Dec'], row['SFT_Meth'])
        dpo = fmt(row['DPO_Dec'], row['DPO_Meth'])
        report.append(f"| {row['Article']} | {row['Label']} | {m1} | {m3} | {sft} | {dpo} |")
        
    out_path = ROOT / "reports" / "fictional_eval_report.md"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(report))
    print(f"\n✓ Report written to {out_path}")

if __name__ == "__main__":
    main()
