import sys
from pathlib import Path
import hashlib

BASE_DIR = Path(__file__).resolve().parent
CODE_DIRS = ["src", "project_state"]

print("--- Debugging Hash Mismatch (Fixed) ---")
print(f"Base Dir: {BASE_DIR}")

def compute_code_bundle_hash_debug():
    """Hashes all .py files in src and project_state JSON/YAMLs."""
    hashes = []
    # Source files
    for d in CODE_DIRS:
        dir_path = BASE_DIR / d
        if dir_path.exists():
            for f in sorted(dir_path.rglob("*")):
                if f.is_file() and (f.suffix in [".py", ".json", ".yaml"]):
                    # Exclude dynamic state files and authorized audits
                    if any(x in str(f) for x in ["cache", "audit", ".DS_Store", "LOCKDOWN", "STATE.json", "guardian_state.json", "COST_LEDGER.json", "guardian_key_state.json", "QUERY_SPACES_HASH.json", "IMMUTABLE_HASHES.json"]):
                        print(f"Skipping: {f.name}")
                        continue
                    print(f"Including: {f.name}")
                    
compute_code_bundle_hash_debug()
