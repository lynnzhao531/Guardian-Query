# Minimal Reproducible Case

- **Repro Script**: `src/step2_pair_generation.py` (modified to accept filters)
- **Repro Inputs**: `data/processed/repro_inputs.json` (15 articles)
- **Smallest Failing Subset**: Articles where `target_gold_score == 0.0`.

## Repro Command
```bash
# To repro the issue on the tiny set:
python src/step2_pair_generation.py --repro data/processed/repro_inputs.json
python -c "import json; d=json.load(open('fine_tune_data/all_pairs_strict.json')); print([len([k for k in json.loads(x['row']['preferred_output'][0]['content']) if json.loads(x['row']['preferred_output'][0]['content'])[k] != json.loads(x['row']['non_preferred_output'][0]['content'])[k]]) for x in d['train']])"
```

## Expected Failure
Pairs in the `Train` output will show `diff_count == 0` for the repro articles.

## Isolation Rationale
This repro set includes 10 articles known to have `gold_method == 0.0`, triggering the "null flip" bug in the universal synthesis logic, and 5 passing articles to ensure the fix doesn't break valid generation.
