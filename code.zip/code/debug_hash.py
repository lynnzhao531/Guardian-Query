import sys
from pathlib import Path
import hashlib

# Add src to path
sys.path.append(str(Path.cwd()))
from src.hash_guard import compute_code_bundle_hash, get_files_for_bundle

print("--- Debugging Hash Mismatch ---")
files = get_files_for_bundle()
print(f"Files included in bundle ({len(files)}):")
for f in sorted(files):
    print(f"  {f}")

h = compute_code_bundle_hash()
print(f"\nCurrent Hash: {h}")
