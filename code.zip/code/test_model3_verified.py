import json
import logging
import sys
import os
import pandas as pd
import numpy as np
import joblib

# Ensure path availability
sys.path.append(os.getcwd())

from src.scorers import Model3Scorer

logging.basicConfig(level=logging.INFO)

# Load thresholds
with open("project_state/PER_MODEL_THRESHOLDS.json") as f:
    t = json.load(f)

# Load test articles
articles = []
with open("test_articles.jsonl") as f:
    for line in f:
        if line.strip():
            articles.append(json.loads(line))

print(f"Loaded {len(articles)} articles.")

# Initialize production scorer
# Note: config_path is not used by load() in current src/scorers.py but passed to __init__
scorer = Model3Scorer("models/model3/model3_models.joblib", None)

print("\n--- Model 3 Scoring (Updated) ---")
results = scorer.score(articles)

for i, res in enumerate(results):
    a = articles[i]
    d_p1 = res.get("model3_decision_p1", 0.0)
    
    m_probs = {m: res.get(f"model3_method_{m}_p1", 0.0) for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]}
    
    # Identify top method
    sorted_methods = sorted(m_probs.items(), key=lambda x: x[1], reverse=True)
    top_m, top_p = sorted_methods[0]
    
    max_m = max(m_probs.values()) if m_probs else 0.0
    passed = d_p1 >= t['model3']['t_dec'] and max_m >= t['model3']['t_meth']
    
    print(f"\nArticle {i+1}: {a['url_canon']}")
    print(f"  Decision P(1): {d_p1:.4f}")
    print(f"  Top Method: {top_m} ({top_p:.4f})")
    print(f"  PASS: {passed}")
    for m, p in m_probs.items():
        print(f"    {m}: {p:.4f}")

# Check for collapse
all_top_methods = []
for res in results:
    m_probs = {m: res.get(f"model3_method_{m}_p1", 0.0) for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]}
    top_m = max(m_probs, key=m_probs.get)
    all_top_methods.append(top_m)

from collections import Counter
counts = Counter(all_top_methods)
print("\n--- Confusion/Collapse Check ---")
print("Top Method distribution across types:")
for m, c in counts.items():
    print(f"  {m}: {c}")
