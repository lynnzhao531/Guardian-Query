import pandas as pd
import json
from pathlib import Path
import os

LOG_PATH = Path("outputs/query_log.csv")
STATE_PATH = Path("project_state/STATE.json")

def clean_log():
    if not LOG_PATH.exists():
        print("Log not found.")
        return

    print("--- Cleaning Query Log ---")
    df = pd.read_csv(LOG_PATH)
    print(f"Original shape: {df.shape}")
    print(f"Original round_ids: {df['round_id'].unique()}")
    
    # Coerce to numeric
    df['round_id'] = pd.to_numeric(df['round_id'], errors='coerce')
    
    # Drop NaNs in round_id
    df = df.dropna(subset=['round_id'])
    
    # Filter
    df = df[df['round_id'] < 900]
    
    print(f"Cleaned shape: {df.shape}")
    print(f"Cleaned round_ids: {df['round_id'].unique()}")
    
    df.to_csv(LOG_PATH, index=False)
    print("Saved cleaned log.")

def clean_state():
    if not STATE_PATH.exists():
        print("State not found.")
        return

    print("--- Cleaning State ---")
    with open(STATE_PATH, "r") as f:
        state = json.load(f)
        
    rid = state.get("round_id")
    print(f"Current State round_id: {rid}")
    
    if rid and rid > 900:
        print("Resetting state round_id to 15")
        state["round_id"] = 15
        with open(STATE_PATH, "w") as f:
            json.dump(state, f, indent=2)
    else:
        print("State round_id is okay or missing.")

def clean_dirs():
    print("--- Cleaning Round Dirs ---")
    rounds_dir = Path("outputs/rounds")
    for d in rounds_dir.glob("round_*"):
        try:
            rid = int(d.name.split("_")[1])
            if rid > 900:
                print(f"Removing invalid round dir: {d}")
                # os.rmdir is risky if not empty, use shutil if needed
                import shutil
                shutil.rmtree(d)
        except:
            pass

if __name__ == "__main__":
    clean_log()
    clean_state()
    clean_dirs()
