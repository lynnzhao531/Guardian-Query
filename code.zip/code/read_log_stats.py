
import pandas as pd
import json

try:
    df = pd.read_csv("outputs/query_log.csv")
    row = df.iloc[-1]
    
    print("--- LOG STATS ---")
    print(f"Round: {row['round_id']}")
    print(f"Pages Fetched: {row['guardian_pages_fetched']}")
    print(f"Total Available: {row['guardian_total_available']}")
    print(f"Backoff Level: {row.get('backoff_level_used', 'N/A')}")
    print(f"Preflight Totals: {row.get('preflight_totals_by_level_json', '{}')}")
    print(f"Target Method: {row['target_method']}")
    print(f"Template ID: {row['template_id']}")
    print(f"Scored Count: {row['scored_count']}")
    print(f"Filtered Count: {row['filtered_remaining_count']}")
    
except Exception as e:
    print(f"Error reading log: {e}")
