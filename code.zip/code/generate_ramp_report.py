
import pandas as pd
import json

def get_json_stats(json_str):
    try:
        return json.loads(json_str) if isinstance(json_str, str) else {}
    except:
        return {}

try:
    df = pd.read_csv("outputs/query_log.csv")
    
    # Filter for rounds 1-5
    df = df[df['round_id'].isin([1, 2, 3, 4, 5])]
    
    print("# Ramp Up 5 Rounds Summary")
    print(f"**Total Rounds:** {len(df)}")
    print(f"**Total Budget Used:** ${df['query_cost_cumulative_usd'].max():.2f}")
    print(f"**Total Scored:** {df['scored_count'].sum()}")
    print(f"**Total New High Rel (Consensus):** {df['consensus_high_rel_count'].sum()}")
    
    print("\n## Per Round Details")
    print("| Round | Query | Template | Method | Backoff | Avail | Scored | Skip Long | Reward |")
    print("| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
    
    for _, row in df.iterrows():
        q_final = (row['query_final'][:20] + '...') if len(row['query_final']) > 20 else row['query_final']
        bk = row.get('backoff_level_used', 'N/A')
        print(f"| {row['round_id']} | `{q_final}` | {row['template_id']} | {row['target_method']} | {bk} | {row['guardian_total_available']} | {row['scored_count']} | {row['skipped_long_count']} | {row['reward_R']:.2f} |")

    print("\n## Pool Growth")
    print(f"- **New Consensus Credits:** {df['new_consensus_credit_total'].sum():.1f}")
    print(f"- **New LLM Items:** {df['new_llm_new_total'].sum()}")
    print(f"- **Avg Duplicate Rate:** {df['duplicate_rate_consensus'].mean():.1%}")

    print("\n## Method Distribution (New Items)")
    cols = [c for c in df.columns if 'new_consensus_credit_' in c and 'total' not in c]
    for c in cols:
        method = c.replace('new_consensus_credit_', '')
        val = df[c].sum()
        if val > 0:
            print(f"- **{method}:** {val:.1f}")

    print("\n## DPO Router Health")
    dpo_att = df['dpo_attempted_count'].sum()
    dpo_val = df['dpo_valid_count'].sum()
    rate = (dpo_val / dpo_att * 100) if dpo_att > 0 else 0
    print(f"- **Attempted:** {dpo_att}")
    print(f"- **Valid:** {dpo_val}")
    print(f"- **Success Rate:** {rate:.1f}%")
    
except Exception as e:
    print(f"Error: {e}")
