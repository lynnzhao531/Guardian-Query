import json
import logging
import sys
import numpy as np
import pandas as pd
import joblib

logging.basicConfig(level=logging.ERROR)

articles = []
with open("test_articles.jsonl") as f:
    for line in f:
        if not line.strip(): continue
        a = json.loads(line)
        articles.append({
            "url_canon": a["url_canon"],
            "title": a["title"],
            "section": a["section"],
            "body_text": a["body"],
            "publication_date_utc": "2026-02-21T00:00:00Z"
        })

print(f"Loaded {len(articles)} articles.")

# Load models natively
# Model 1 commented out
m3_dict = joblib.load("models/model3/model3_models.joblib")
m3_dec = m3_dict["decision"]

m3_methods = {}
for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
    k = f"method_{m}"
    if k in m3_dict:
        m3_methods[m] = m3_dict[k]
    else:
        m3_methods[m] = None

with open("project_state/PER_MODEL_THRESHOLDS.json") as f:
     t = json.load(f)

# Evaluate
print("Extracting features manually for M3 validation...")

import src.tgml.theory_features as tf
theory_feat = tf.TheoryFeaturizer()
texts = [a["title"] + "\n\n" + a["body_text"] for a in articles]

from transformers import AutoTokenizer, AutoModel
import torch
print("Loading M3 semantic transformer locally...")
tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")

emb = []
for txt in texts:
     inputs = tokenizer(txt, return_tensors="pt", padding=True, truncation=True, max_length=512)
     with torch.no_grad():
         o = model(**inputs)
     emb.append(o.last_hidden_state.mean(dim=1).squeeze().numpy())

X_emb = np.stack(emb)
df_for_features = pd.DataFrame(articles)
X_theory_arr = theory_feat.transform(df_for_features).values

X_m3 = np.hstack([X_emb, X_theory_arr])

for i, a in enumerate(articles):
    d3_probs = m3_dec.predict_proba(X_m3[i:i+1])[0]
    d3_p1 = d3_probs[2] 
    
    m3_ps = {}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        if m3_methods[m] is not None:
            m_probs = m3_methods[m].predict_proba(X_m3[i:i+1])[0]
            m3_ps[m] = m_probs[2]
        else:
            m3_ps[m] = 0.0
            
    m3_max = max(m3_ps.values())
    p3 = d3_p1 >= t['model3']['t_dec'] and m3_max >= t['model3']['t_meth']
    
    print(f"\n--- Article {i+1}: {a['url_canon']} ---")
    print(f"Model 3:")
    print(f"  Decision Score p1={d3_p1:.3f} | PASS={p3}")
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
         print(f"  {m}: {m3_ps[m]:.3f}")
    
