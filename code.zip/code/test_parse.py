import json

def extract_labels(json_str):
    try:
        data = json.loads(json_str)
        labels = {}
        labels['decision'] = data.get("decision", {}).get("score", 0)
        for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
            labels[m] = data.get(f"method_{m}", {}).get("score", 0)
        return labels
    except:
        return None

with open('fine_tune_data/dpo_train_v2.jsonl') as f:
    for i in range(5):
        line = f.readline()
        data = json.loads(line)
        pref = data['preferred_output'][0]['content']
        non_pref = data['non_preferred_output'][0]['content']
        
        pref_labels = extract_labels(pref)
        non_pref_labels = extract_labels(non_pref)
        print(f"Row {i}")
        print("P:", pref_labels)
        print("N:", non_pref_labels)
        
        diffs = {k: (pref_labels[k], non_pref_labels[k]) for k in pref_labels if pref_labels[k] != non_pref_labels[k]}
        print("Diffs:", diffs)
        print("---")
