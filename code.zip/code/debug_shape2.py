import pandas as pd
import numpy as np
from src.tgml.models import FeaturePipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
df = pd.read_parquet("outputs/master_vector.parquet")
SEED = 42
df["title_clean"] = df["title"].fillna("")
df["body_clean"] = df["body"].fillna("").str.slice(0, 4000)
df["text_for_model"] = df["title_clean"] + "\n\n" + df["body_clean"]
urls = df["url_canon"].values
strat = df["decision"].fillna(-1).values
train_urls, temp_urls, _, strat_temp = train_test_split(urls, strat, test_size=0.30, random_state=SEED, stratify=strat)
train = df[df["url_canon"].isin(set(train_urls))].copy()
feat_pipe = FeaturePipeline()
feat_pipe.fit(train)
X_train = feat_pipe.transform(train)
mask_tr = train["method_case_study"].notna()
print(f"X_train shape: {X_train.shape}")
print(f"X_train[mask_tr.values] shape: {X_train[mask_tr.values].shape}")
y_tr = train.loc[mask_tr, "method_case_study"].astype(str).values
clf = LogisticRegression(solver="saga", multi_class="multinomial", C=1.0, max_iter=5000, class_weight="balanced", n_jobs=-1, random_state=SEED)
cal_clf = CalibratedClassifierCV(clf, method='sigmoid', cv=3)
try:
    cal_clf.fit(X_train[mask_tr.values], y_tr)
    print("Fit succeeded?!")
except Exception as e:
    print(f"Fit failed: {e}")
