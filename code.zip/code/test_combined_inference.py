import json
import logging
import sys
import numpy as np
import pandas as pd
import joblib

logging.basicConfig(level=logging.ERROR)

articles = []
with open("test_articles.jsonl") as f:
    for line in f:
        if not line.strip(): continue
        a = json.loads(line)
        articles.append({
            "url_canon": a["url_canon"],
            "title": a["title"],
            "section": a["section"],
            "body_text": a["body"],
            "publication_date_utc": "2026-02-21T00:00:00Z"
        })

print(f"Loaded {len(articles)} articles.")

with open("project_state/PER_MODEL_THRESHOLDS.json") as f:
     t = json.load(f)

# --- MODEL 1 NATIVE ---
class OrdinalClassifier: pass
class DataFrameSelector:
    def __init__(self, attribute_names=None):
        self.attribute_names = attribute_names
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        return X[self.attribute_names].values

sys.modules["__main__"].DataFrameSelector = DataFrameSelector
sys.modules["__main__"].OrdinalClassifier = OrdinalClassifier
def preprocess_numeric(x): return x
sys.modules['__main__'].preprocess_numeric = preprocess_numeric

print("Loading original TGML Model 1 wrappers natively...")
import src.tgml.theory_features as tf
from scipy.sparse import hstack, csr_matrix
from src.scorers import Model1ClassifierWrapper

df = pd.DataFrame(articles)
df["text_for_model"] = df["title"] + "\n\n" + df["body_text"]

theory_feat = tf.TheoryFeaturizer()
X_theory_arr = theory_feat.transform(df).values
tfidf = joblib.load("models/tgml/tfidf_vectorizer.joblib")
X_tfidf = tfidf.transform(df["text_for_model"])

X_m1_unpadded = hstack([X_tfidf, csr_matrix(X_theory_arr)])

# Delete hardcoded global padding
m1_dec = Model1ClassifierWrapper(joblib.load("models/tgml/model_decision.joblib").steps[-1][1])
m1_methods = {}
for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
    pth = f"models/tgml/model_method_{m}.joblib"
    import os
    if os.path.exists(pth):
        m1_methods[m] = Model1ClassifierWrapper(joblib.load(pth).steps[-1][1])
    else:
        m1_methods[m] = None

def pad_slice(X_in, target_dim):
    if X_in.shape[1] < target_dim:
        return hstack([X_in, csr_matrix((X_in.shape[0], target_dim - X_in.shape[1]))]).tocsr()
    elif X_in.shape[1] > target_dim:
        return X_in[:, :target_dim]
    return X_in

print("Calculating Model 1 scores via batch inference...")

for i, a in enumerate(articles):
    tgt_dec = m1_dec.clf.calibrated_classifiers_[0].estimator.n_features_in_
    X_dec = pad_slice(X_m1_unpadded[i:i+1], tgt_dec)
    
    d1_p0, d1_p05, d1_p1 = m1_dec.predict_proba(X_dec)[0]
    
    m1_ps = {}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        if m1_methods[m] is not None:
             tgt_meth = m1_methods[m].clf.calibrated_classifiers_[0].estimator.n_features_in_
             X_meth = pad_slice(X_m1_unpadded[i:i+1], tgt_meth)
             p_arr = m1_methods[m].predict_proba(X_meth)[0]
             m1_ps[m] = p_arr[-1]
        else:
             m1_ps[m] = 0.0
            
    m1_max = max(m1_ps.values()) if m1_ps else 0.0
    p1 = d1_p1 >= t['model1']['t_dec'] and m1_max >= t['model1']['t_meth']
    
    print(f"\n--- Article {i+1}: {a['url_canon']} ---")
    print(f"Model 1 (TFIDF+Theory):")
    print(f"  Decision Score p1={d1_p1:.3f} | PASS={p1}")
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
         print(f"  {m}: {m1_ps[m]:.3f}")

# --- MODEL 3 NATIVE ---
print("\nLoading models manually for M3 validation...")
m3_dict = joblib.load("models/model3/model3_models.joblib")
m3_dec = m3_dict["decision"]

m3_methods = {}
for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
    k = f"method_{m}"
    if k in m3_dict:
        m3_methods[m] = m3_dict[k]
    else:
        m3_methods[m] = None

import src.tgml.theory_features as tf
theory_feat = tf.TheoryFeaturizer()
texts = [a["title"] + "\n\n" + a["body_text"] for a in articles]
X_theory_arr = theory_feat.transform(pd.DataFrame(articles)).values

from transformers import AutoTokenizer, AutoModel
import torch
print("Loading M3 semantic transformer locally...")
tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")

emb = []
for txt in texts:
     inputs = tokenizer(txt, return_tensors="pt", padding=True, truncation=True, max_length=512)
     with torch.no_grad():
         o = model(**inputs)
     emb.append(o.last_hidden_state.mean(dim=1).squeeze().numpy())

X_emb = np.stack(emb)
X_m3 = np.hstack([X_emb, X_theory_arr])

print("\nCalculating Model 3 scores...")
for i, a in enumerate(articles):
    d3_probs = m3_dec.predict_proba(X_m3[i:i+1])[0]
    d3_p1 = d3_probs[-1] 
    
    m3_ps = {}
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
        if m3_methods[m] is not None:
            m_probs = m3_methods[m].predict_proba(X_m3[i:i+1])[0]
            m3_ps[m] = m_probs[-1]
        else:
            m3_ps[m] = 0.0
            
    m3_max = max(m3_ps.values())
    p3 = d3_p1 >= t['model3']['t_dec'] and m3_max >= t['model3']['t_meth']
    
    print(f"\n--- Article {i+1}: {a['url_canon']} ---")
    print(f"Model 3 (DeBerta+Theory):")
    print(f"  Decision Score p1={d3_p1:.3f} | PASS={p3}")
    for m in ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]:
         print(f"  {m}: {m3_ps[m]:.3f}")

