import pandas as pd
import json
from pathlib import Path
from src.rebuild_pools_and_highrelevant_llmmerge import pass_model

METHOD_NAMES = ["rct", "prepost", "case_study", "expert_qual", "expert_secondary", "gut"]

with open("project_state/PER_MODEL_THRESHOLDS.json", "r") as f:
    thresholds = json.load(f)

rounds_dir = Path("outputs/rounds")
m1_pass = 0
m3_pass = 0
llm_pass = 0
all_pass = 0

for rd in rounds_dir.glob("round_*"):
    pq = rd / "scored_results_full.parquet"
    if pq.exists():
        try:
            df = pd.read_parquet(pq)
        except: continue
        
        for _, r in df.iterrows():
            rdict = r.to_dict()
            p_m1 = pass_model(rdict, "model1", thresholds)
            p_m3 = pass_model(rdict, "model3", thresholds)
            
            final_d_score = float(rdict.get("llm_final_decision_score", 0)) if pd.notna(rdict.get("llm_final_decision_score")) else 0
            final_p1s = [float(rdict.get(f"llm_final_method_{m}_p1", 0)) for m in METHOD_NAMES if pd.notna(rdict.get(f"llm_final_method_{m}_p1"))]
            final_max_p1 = max(final_p1s) if final_p1s else 0.0
            pass_final = (abs(final_d_score - 1.0) < 1e-6) and (final_max_p1 >= 0.80)
            
            dpo_valid = rdict.get("dpo_valid", False)
            if pd.isna(dpo_valid): dpo_valid = False
            dpo_d_score = float(rdict.get("llm_dpo_decision_score", 0)) if pd.notna(rdict.get("llm_dpo_decision_score")) else 0
            dpo_p1s = [float(rdict.get(f"llm_dpo_method_{m}_p1", 0)) for m in METHOD_NAMES if pd.notna(rdict.get(f"llm_dpo_method_{m}_p1"))]
            dpo_max_p1 = max(dpo_p1s) if dpo_p1s else 0.0
            pass_dpo = bool(dpo_valid) and (abs(dpo_d_score - 1.0) < 1e-6) and (dpo_max_p1 >= 0.80)
            
            p_llm = pass_final or pass_dpo
            
            if p_m1: m1_pass += 1
            if p_m3: m3_pass += 1
            if p_llm: llm_pass += 1
            if p_m1 and p_m3 and p_llm: all_pass += 1

print(f"M1 pass: {m1_pass}")
print(f"M3 pass: {m3_pass}")
print(f"LLM pass: {llm_pass}")
print(f"ALL pass: {all_pass}")

