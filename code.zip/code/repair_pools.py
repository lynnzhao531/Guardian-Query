from src.pool_manager import ensure_pool_files_exist
print("Running ensure_pool_files_exist...")
ensure_pool_files_exist()
print("Done.")
