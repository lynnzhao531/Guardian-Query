import pandas as pd
from sklearn.compose import ColumnTransformer
import src.tgml.theory_features as tf
import joblib

tf.TheoryFeaturizer.fit = lambda self, X, y=None: self

df = pd.DataFrame({"title": ["A"], "body": ["B"], "text_for_model": ["A\n\nB"], "url_canon": ["C"]})

col_trans = ColumnTransformer(
    transformers=[
        ("theory", tf.TheoryFeaturizer(), ["title", "body", "url_canon", "text_for_model"])
    ]
)

col_trans.fit(df)
joblib.dump(col_trans, "test_ct.joblib")
print("Saved successful.")
