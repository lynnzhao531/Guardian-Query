
import pandas as pd
from pathlib import Path
import datetime
import sys

def fix_log():
    log_path = Path("outputs/query_log.csv")
    try:
        df = pd.read_csv(log_path)
        print(f"Read success. Rows: {len(df)}")
    except Exception as e:
        print(f"Read failed: {e}")
        # Try reading as text to see if empty
        content = log_path.read_text()
        print(f"File content length: {len(content)}")
        return

    # Check if Round 7 exists
    if 7 in df["round_id"].values:
        print("Round 7 already in log. Removing to re-add (integrity update).")
        df = df[df["round_id"] != 7]
        
    # Stats from Files
    r_dir = Path("outputs/rounds/round_7")
    try:
        filt = len(pd.read_csv(r_dir / "candidates_filtered.csv"))
        scored = len(pd.read_csv(r_dir / "scored_set.csv"))
        m1 = len(pd.read_csv(r_dir / "round_7_model1_papers.csv"))
        m3 = len(pd.read_csv(r_dir / "round_7_model3_papers.csv"))
        
        # Read full parquet or scored set for llm_final count
        scored_df = pd.read_csv(r_dir / "scored_set.csv")
        # llm_final requires checking column "llm_final_decision_score" == 1
        llm_high = len(scored_df[scored_df["llm_final_decision_score"] == 1]) if "llm_final_decision_score" in scored_df.columns else 0
        
        # SFT/DPO counts
        # SFT high = len(sft_csv)
        sft_high_df = pd.read_csv(r_dir / "round_7_SFT_papers.csv")
        sft_high = len(sft_high_df)
        
        dpo_csv = r_dir / "round_7_DPO_papers.csv"
        dpo_high = len(pd.read_csv(dpo_csv)) if dpo_csv.exists() else 0
        
        cons_csv = r_dir / "round_7_high_relevant_papers.csv"
        cons = len(pd.read_csv(cons_csv)) if cons_csv.exists() else 0
        
    except Exception as e:
        print(f"Failed to read round files: {e}")
        return

    # Mock other fields
    row = {col: 0 for col in df.columns}
    row["round_id"] = 7
    row["timestamp_utc_iso"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row["query_base"] = "REPAIRED_LOG_ENTRY"
    row["query_final"] = "REPAIRED_LOG_ENTRY"
    row["filtered_remaining_count"] = filt
    row["scored_count"] = scored
    row["high_rel_model1_count"] = m1
    row["high_rel_model3_count"] = m3
    row["high_rel_llm_final_count"] = llm_high
    row["consensus_high_rel_count"] = cons
    
    # Reward V for recompute
    # V = min(1, scored/100)
    # Log V should match this
    row["reward_V"] = min(1.0, scored / 100.0)
    
    # Weights (defaults from round runner)
    row["reward_weight_alpha"] = 0.25
    row["reward_weight_beta"] = 0.15
    row["reward_weight_gamma"] = 0.60
    row["reward_weight_delta"] = 0.20
    
    # Append
    new_row_df = pd.DataFrame([row])
    # Ensure correct columns order?
    # pd.concat aligns columns.
    final_df = pd.concat([df, new_row_df], ignore_index=True)
    final_df.to_csv(log_path, index=False)
    print("Appended Round 7 to query_log.csv")
    
if __name__ == "__main__":
    fix_log()
